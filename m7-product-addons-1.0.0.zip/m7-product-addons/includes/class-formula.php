<?php
/**
 * Veilige rekenformules voor berekeningsvelden (geen eval).
 *
 * Ondersteunt: getallen, + - * / ^ % mod, haakjes, vergelijkingen (< <= > >= == !=),
 * and/or/not (ook && || !), a ? b : c, functies min, max, round, ceil, floor, abs, sqrt, pow, log, exp,
 * if(voorwaarde, dan, anders), en variabelen tussen accolades:
 *   {product_price}, {quantity}, {field:<veld-id>} en {field:<veld-id>_option_price|_option_value|
 *   _field_price|_number_uploads|_quantity}.
 * Een variabele zonder waarde (null) maakt de hele formule onberekenbaar (zoals bij het origineel,
 * waar een leeg getalveld de formule laat mislukken). Dezelfde grammatica staat in assets/m7pa.js.
 *
 * @package M7PA
 */

namespace M7PA;

defined( 'ABSPATH' ) || exit;

final class Formula {

	const FUNCTIONS = array( 'min', 'max', 'round', 'ceil', 'floor', 'abs', 'if', 'sqrt', 'pow', 'log', 'exp' );

	public static function sanitize( $formula ) {
		$formula = (string) $formula;
		// Alleen toegestane tekens; variabelen tussen accolades.
		return trim( preg_replace( '/[^0-9a-z_\.\+\-\*\/\^%\(\),<>=!&|?\{\}:\s]/i', '', $formula ) );
	}

	/**
	 * Berekent een formule.
	 *
	 * @param string $formula Formule.
	 * @param array  $vars    Variabelen (naam => getal of null), bijv. ['product_price' => 10, 'field:p12' => 3].
	 * @return float|null Null bij een ongeldige formule of ontbrekende waarde.
	 */
	public static function evaluate( $formula, array $vars ) {
		$tokens = self::tokenize( self::sanitize( $formula ), $vars );
		if ( null === $tokens ) {
			return null;
		}
		$pos = 0;
		try {
			$value = self::parse_ternary( $tokens, $pos );
			if ( $pos !== count( $tokens ) ) {
				return null;
			}
			return is_finite( $value ) ? (float) $value : null;
		} catch ( \Throwable $e ) {
			return null;
		}
	}

	private static function tokenize( $s, array $vars ) {
		$tokens = array();
		$len    = strlen( $s );
		$i      = 0;
		while ( $i < $len ) {
			$c = $s[ $i ];
			if ( ctype_space( $c ) ) {
				$i++;
				continue;
			}
			if ( '{' === $c ) {
				$end = strpos( $s, '}', $i );
				if ( false === $end ) {
					return null;
				}
				$name = trim( substr( $s, $i + 1, $end - $i - 1 ) );
				if ( ! isset( $vars[ $name ] ) || ! is_numeric( $vars[ $name ] ) ) {
					return null;
				}
				$tokens[] = array( 'n', (float) $vars[ $name ] );
				$i        = $end + 1;
				continue;
			}
			if ( ctype_digit( $c ) || ( '.' === $c && $i + 1 < $len && ctype_digit( $s[ $i + 1 ] ) ) ) {
				$j = $i;
				while ( $j < $len && ( ctype_digit( $s[ $j ] ) || '.' === $s[ $j ] ) ) {
					$j++;
				}
				$tokens[] = array( 'n', (float) substr( $s, $i, $j - $i ) );
				$i        = $j;
				continue;
			}
			if ( ctype_alpha( $c ) ) {
				$j = $i;
				while ( $j < $len && ( ctype_alnum( $s[ $j ] ) || '_' === $s[ $j ] ) ) {
					$j++;
				}
				$word = strtolower( substr( $s, $i, $j - $i ) );
				$i    = $j;
				if ( in_array( $word, array( 'and', 'or', 'not', 'mod' ), true ) ) {
					$tokens[] = array( 'o', $word );
					continue;
				}
				if ( ! in_array( $word, self::FUNCTIONS, true ) ) {
					return null;
				}
				$tokens[] = array( 'f', $word );
				continue;
			}
			$two = substr( $s, $i, 2 );
			if ( in_array( $two, array( '<=', '>=', '==', '!=', '&&', '||' ), true ) ) {
				$tokens[] = array( 'o', '&&' === $two ? 'and' : ( '||' === $two ? 'or' : $two ) );
				$i       += 2;
				continue;
			}
			if ( false !== strpos( '+-*/^%(),<>?:!', $c ) ) {
				$tokens[] = array( 'o', '!' === $c ? 'not' : $c );
				$i++;
				continue;
			}
			return null;
		}
		return $tokens;
	}

	private static function peek( array $t, $pos ) {
		return isset( $t[ $pos ] ) ? $t[ $pos ] : null;
	}

	private static function is_op( $tok, $ops ) {
		return $tok && 'o' === $tok[0] && in_array( $tok[1], (array) $ops, true );
	}

	private static function expect( array $t, &$pos, $op ) {
		if ( ! self::is_op( self::peek( $t, $pos ), $op ) ) {
			throw new \RuntimeException( 'Verwacht ' . $op );
		}
		$pos++;
	}

	private static function parse_ternary( array $t, &$pos ) {
		$cond = self::parse_or( $t, $pos );
		if ( self::is_op( self::peek( $t, $pos ), '?' ) ) {
			$pos++;
			$a = self::parse_ternary( $t, $pos );
			self::expect( $t, $pos, ':' );
			$b = self::parse_ternary( $t, $pos );
			return 0.0 !== (float) $cond ? $a : $b;
		}
		return $cond;
	}

	private static function parse_or( array $t, &$pos ) {
		$left = self::parse_and( $t, $pos );
		while ( self::is_op( self::peek( $t, $pos ), 'or' ) ) {
			$pos++;
			$right = self::parse_and( $t, $pos );
			$left  = ( 0.0 !== (float) $left || 0.0 !== (float) $right ) ? 1.0 : 0.0;
		}
		return $left;
	}

	private static function parse_and( array $t, &$pos ) {
		$left = self::parse_comparison( $t, $pos );
		while ( self::is_op( self::peek( $t, $pos ), 'and' ) ) {
			$pos++;
			$right = self::parse_comparison( $t, $pos );
			$left  = ( 0.0 !== (float) $left && 0.0 !== (float) $right ) ? 1.0 : 0.0;
		}
		return $left;
	}

	private static function parse_comparison( array $t, &$pos ) {
		$left = self::parse_additive( $t, $pos );
		$tok  = self::peek( $t, $pos );
		if ( self::is_op( $tok, array( '<', '<=', '>', '>=', '==', '!=' ) ) ) {
			$pos++;
			$right = self::parse_additive( $t, $pos );
			switch ( $tok[1] ) {
				case '<':
					return $left < $right ? 1.0 : 0.0;
				case '<=':
					return $left <= $right ? 1.0 : 0.0;
				case '>':
					return $left > $right ? 1.0 : 0.0;
				case '>=':
					return $left >= $right ? 1.0 : 0.0;
				case '==':
					return abs( $left - $right ) < 1e-9 ? 1.0 : 0.0;
				default:
					return abs( $left - $right ) >= 1e-9 ? 1.0 : 0.0;
			}
		}
		return $left;
	}

	private static function parse_additive( array $t, &$pos ) {
		$value = self::parse_multiplicative( $t, $pos );
		while ( self::is_op( $tok = self::peek( $t, $pos ), array( '+', '-' ) ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition
			$pos++;
			$right = self::parse_multiplicative( $t, $pos );
			$value = '+' === $tok[1] ? $value + $right : $value - $right;
		}
		return $value;
	}

	private static function parse_multiplicative( array $t, &$pos ) {
		$value = self::parse_power( $t, $pos );
		while ( self::is_op( $tok = self::peek( $t, $pos ), array( '*', '/', '%', 'mod' ) ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition
			$pos++;
			$right = self::parse_power( $t, $pos );
			if ( '*' === $tok[1] ) {
				$value *= $right;
			} elseif ( 0.0 === (float) $right ) {
				$value = 0.0; // Delen door nul geeft 0 in plaats van een fout.
			} elseif ( '/' === $tok[1] ) {
				$value /= $right;
			} else {
				$value = fmod( $value, $right );
			}
		}
		return $value;
	}

	private static function parse_power( array $t, &$pos ) {
		$base = self::parse_unary( $t, $pos );
		if ( self::is_op( self::peek( $t, $pos ), '^' ) ) {
			$pos++;
			return pow( $base, self::parse_unary( $t, $pos ) );
		}
		return $base;
	}

	private static function parse_unary( array $t, &$pos ) {
		$tok = self::peek( $t, $pos );
		if ( self::is_op( $tok, array( '-', '+' ) ) ) {
			$pos++;
			$v = self::parse_unary( $t, $pos );
			return '-' === $tok[1] ? -$v : $v;
		}
		if ( self::is_op( $tok, 'not' ) ) {
			$pos++;
			return 0.0 === (float) self::parse_unary( $t, $pos ) ? 1.0 : 0.0;
		}
		return self::parse_primary( $t, $pos );
	}

	private static function parse_primary( array $t, &$pos ) {
		$tok = self::peek( $t, $pos );
		if ( ! $tok ) {
			throw new \RuntimeException( 'Onverwacht einde' );
		}
		if ( 'n' === $tok[0] ) {
			$pos++;
			return $tok[1];
		}
		if ( 'f' === $tok[0] ) {
			$pos++;
			self::expect( $t, $pos, '(' );
			$args = array();
			if ( ! self::is_op( self::peek( $t, $pos ), ')' ) ) {
				$args[] = self::parse_ternary( $t, $pos );
				while ( self::is_op( self::peek( $t, $pos ), ',' ) ) {
					$pos++;
					$args[] = self::parse_ternary( $t, $pos );
				}
			}
			self::expect( $t, $pos, ')' );
			return self::call( $tok[1], $args );
		}
		if ( self::is_op( $tok, '(' ) ) {
			$pos++;
			$v = self::parse_ternary( $t, $pos );
			self::expect( $t, $pos, ')' );
			return $v;
		}
		throw new \RuntimeException( 'Onverwacht teken' );
	}

	private static function call( $fn, array $args ) {
		$a0 = isset( $args[0] ) ? (float) $args[0] : 0.0;
		$a1 = isset( $args[1] ) ? (float) $args[1] : 0.0;
		switch ( $fn ) {
			case 'min':
				return $args ? min( $args ) : 0.0;
			case 'max':
				return $args ? max( $args ) : 0.0;
			case 'round':
				$p = pow( 10, (int) $a1 );
				return floor( $a0 * $p + 0.5 ) / $p; // Zoals Math.round in de browser.
			case 'ceil':
				return ceil( $a0 );
			case 'floor':
				return floor( $a0 );
			case 'abs':
				return abs( $a0 );
			case 'sqrt':
				return sqrt( $a0 );
			case 'pow':
				return pow( $a0, $a1 );
			case 'log':
				return count( $args ) > 1 ? log( $a0 ) / log( $a1 ) : log( $a0 );
			case 'exp':
				return exp( $a0 );
			case 'if':
				return 0.0 !== $a0 ? $a1 : ( isset( $args[2] ) ? (float) $args[2] : 0.0 );
		}
		return 0.0;
	}
}
