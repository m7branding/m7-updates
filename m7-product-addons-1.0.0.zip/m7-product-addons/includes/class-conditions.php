<?php
/**
 * Voorwaarden: welke velden en groepen zichtbaar zijn op basis van andere velden, aantal, totaalprijs,
 * inlogstatus en variatie. Dezelfde logica draait in de browser (assets/m7pa.js); op de server
 * controleren we opnieuw, zodat verborgen velden niet verplicht zijn en niet worden berekend.
 *
 * De vergelijkingen volgen Product Add-Ons Ultimate in de browser (dat is wat de klant ziet):
 * - "is" vergelijkt de hele waarde (meerdere keuzes = met komma's samengevoegd);
 * - "bevat" zoekt in een lijst naar een gelijke waarde, in tekst naar een stukje tekst; met komma's
 *   in de voorwaarde moeten alle delen voorkomen;
 * - een radiogroep zonder keuze voldoet aan geen enkele regel (ook "is niet" niet);
 * - getallen (gelijk aan, groter, kleiner, ...) vergelijken als getal.
 *
 * Regel: field = "<veld-id>" | "quantity" | "cost" | "product_price" | "logged_in" | "attribute:<attribuut>",
 *        operator (zie OPERATORS), value.
 *
 * @package M7PA
 */

namespace M7PA;

defined( 'ABSPATH' ) || exit;

final class Conditions {

	const OPERATORS = array(
		'is'            => 'is',
		'is_not'        => 'is niet',
		'contains'      => 'bevat',
		'not_contains'  => 'bevat niet',
		'equals'        => 'gelijk aan (getal)',
		'greater'       => 'groter dan',
		'less'          => 'kleiner dan',
		'greater_equal' => 'groter dan of gelijk aan',
		'less_equal'    => 'kleiner dan of gelijk aan',
		'empty'         => 'is leeg',
		'not_empty'     => 'is ingevuld',
	);

	/** Waarde "niet bepaald" (radio zonder keuze): geen enkele regel klopt. */
	const UNDEFINED = "\0undefined";

	/**
	 * Zichtbaarheid van alle velden en groepen.
	 *
	 * @param array $groups  Groepen.
	 * @param array $values  veld-ID => lijst strings (genormaliseerd, zie Selection::normalize).
	 * @param array $context quantity, cost, product_price, attributes (naam => waarde), variation_id.
	 * @return array veld-ID => bool, plus 'group:<id>' => bool.
	 */
	public static function visibility( array $groups, array $values, array $context ) {
		$fields = array();
		$owner  = array();
		foreach ( $groups as $g ) {
			foreach ( $g['fields'] as $f ) {
				$fields[ $f['id'] ] = $f;
				$owner[ $f['id'] ]  = (int) $g['id'];
			}
		}
		$visible = array_fill_keys( array_keys( $fields ), true );
		foreach ( $groups as $g ) {
			$visible[ 'group:' . (int) $g['id'] ] = true;
		}

		// Herhaal tot stabiel: een verborgen veld telt als leeg voor velden die ervan afhangen.
		for ( $pass = 0; $pass < 8; $pass++ ) {
			$changed = false;
			foreach ( $groups as $g ) {
				$key = 'group:' . (int) $g['id'];
				$now = self::rules_visible( isset( $g['conditions'] ) ? $g['conditions'] : array(), $fields, $values, $visible, $owner, $context );
				if ( $now !== $visible[ $key ] ) {
					$visible[ $key ] = $now;
					$changed         = true;
				}
			}
			foreach ( $fields as $id => $f ) {
				$now = self::rules_visible( $f['conditions'], $fields, $values, $visible, $owner, $context );
				if ( $now && ! empty( $f['variations'] ) ) {
					$now = in_array( (int) ( isset( $context['variation_id'] ) ? $context['variation_id'] : 0 ), $f['variations'], true );
				}
				if ( $now !== $visible[ $id ] ) {
					$visible[ $id ] = $now;
					$changed        = true;
				}
			}
			if ( ! $changed ) {
				break;
			}
		}
		// Een veld in een verborgen groep is zelf ook verborgen (behalve als de groep altijd meetelt).
		foreach ( $groups as $g ) {
			if ( ! $visible[ 'group:' . (int) $g['id'] ] && empty( $g['always_include'] ) ) {
				foreach ( $g['fields'] as $f ) {
					$visible[ $f['id'] ] = false;
				}
			}
		}
		return $visible;
	}

	private static function rules_visible( array $c, array $fields, array $values, array $visible, array $owner, array $context ) {
		if ( empty( $c['rules'] ) ) {
			return true;
		}
		$results = array();
		foreach ( $c['rules'] as $r ) {
			$results[] = self::rule_matches( $r, $fields, $values, $visible, $owner, $context );
		}
		$met = 'any' === $c['match'] ? in_array( true, $results, true ) : ! in_array( false, $results, true );
		return 'hide' === $c['action'] ? ! $met : $met;
	}

	/**
	 * De waarde van een bron voor een voorwaarde (zoals de browser die leest).
	 *
	 * @return string|array|false|null String, lijst, false (vinkje uit) of UNDEFINED.
	 */
	public static function source_value( $target, array $fields, array $values, array $visible, array $owner, array $context ) {
		if ( 'quantity' === $target ) {
			return (string) ( isset( $context['quantity'] ) ? $context['quantity'] : 1 );
		}
		if ( 'cost' === $target ) {
			return (string) ( isset( $context['cost'] ) ? $context['cost'] : 0 );
		}
		if ( 'product_price' === $target ) {
			return (string) ( isset( $context['product_price'] ) ? $context['product_price'] : 0 );
		}
		if ( 'logged_in' === $target ) {
			return is_user_logged_in() ? 'true' : 'false';
		}
		if ( 0 === strpos( $target, 'attribute:' ) ) {
			$name  = substr( $target, 10 );
			$attrs = isset( $context['attributes'] ) ? (array) $context['attributes'] : array();
			if ( ! isset( $attrs[ $name ] ) ) {
				return self::UNDEFINED;
			}
			$v = (string) $attrs[ $name ];
			return false !== strpos( $v, ',' ) ? explode( ',', $v ) : $v;
		}
		if ( ! isset( $fields[ $target ] ) ) {
			return self::UNDEFINED;
		}
		$f      = $fields[ $target ];
		$hidden = ( isset( $visible[ $target ] ) && ! $visible[ $target ] ) || ( isset( $owner[ $target ] ) && isset( $visible[ 'group:' . $owner[ $target ] ] ) && ! $visible[ 'group:' . $owner[ $target ] ] );
		if ( $hidden ) {
			return '';
		}
		$v = isset( $values[ $target ] ) ? array_values( (array) $values[ $target ] ) : array();
		switch ( $f['type'] ) {
			case 'checkbox':
				return $v ? '1' : false;
			case 'radio':
				return $v ? (string) $v[0] : self::UNDEFINED;
			case 'checkbox_group':
				return array_map( 'strval', $v );
			case 'image_swatch':
				return $f['multiple'] ? array_map( 'strval', $v ) : ( $v ? (string) $v[0] : '' );
			case 'products':
				return 'select' === $f['products']['layout'] ? ( $v ? (string) $v[0] : '' ) : array_map( 'strval', $v );
			case 'upload':
				return $v ? (string) count( $v ) : '';
			default:
				return $v ? (string) $v[0] : '';
		}
	}

	public static function rule_matches( array $r, array $fields, array $values, array $visible, array $owner, array $context ) {
		return self::compare( $r['operator'], self::source_value( $r['field'], $fields, $values, $visible, $owner, $context ), (string) $r['value'] );
	}

	/**
	 * Losse vergelijking zoals in JavaScript (==): gelijke tekst, of beide getallen en gelijk.
	 */
	private static function loose_equal( $a, $b ) {
		$a = (string) $a;
		$b = (string) $b;
		if ( $a === $b ) {
			return true;
		}
		return is_numeric( $a ) && is_numeric( $b ) && (float) $a === (float) $b;
	}

	private static function includes( $actual, $needle ) {
		if ( is_array( $actual ) ) {
			foreach ( $actual as $a ) {
				if ( self::loose_equal( $a, $needle ) ) {
					return true;
				}
			}
			return false;
		}
		return '' !== (string) $needle && false !== strpos( (string) $actual, (string) $needle );
	}

	/**
	 * @param string            $op     Operator.
	 * @param string|array|bool $actual Waarde van de bron (zie source_value).
	 * @param string            $value  Vergelijkingswaarde.
	 * @return bool
	 */
	public static function compare( $op, $actual, $value ) {
		if ( self::UNDEFINED === $actual ) {
			return false;
		}
		$is_empty = ( false === $actual || '' === $actual || array() === $actual );
		$joined   = is_array( $actual ) ? implode( ',', $actual ) : ( false === $actual ? '' : (string) $actual );
		switch ( $op ) {
			case 'empty':
				return $is_empty;
			case 'not_empty':
				return ! $is_empty;
			case 'is':
				return false === $actual ? false : self::loose_equal( $joined, $value );
			case 'is_not':
				return false === $actual ? true : ! self::loose_equal( $joined, $value );
			case 'contains':
			case 'not_contains':
				if ( false === $actual ) {
					$found = false;
				} elseif ( false !== strpos( $value, ',' ) ) {
					$found = true;
					foreach ( explode( ',', $value ) as $part ) {
						if ( ! self::includes( $actual, $part ) ) {
							$found = false;
							break;
						}
					}
				} else {
					$found = self::includes( $actual, $value ) || ( is_numeric( $value ) && self::includes( $actual, (string) (float) $value ) );
				}
				return 'contains' === $op ? $found : ! $found;
			case 'equals':
			case 'greater':
			case 'less':
			case 'greater_equal':
			case 'less_equal':
				if ( ! is_numeric( $joined ) || ! is_numeric( $value ) ) {
					return false;
				}
				$a = (float) $joined;
				$b = (float) $value;
				switch ( $op ) {
					case 'equals':
						return abs( $a - $b ) < 1e-9;
					case 'greater':
						return $a > $b;
					case 'less':
						return $a < $b;
					case 'greater_equal':
						return $a >= $b;
					default:
						return $a <= $b;
				}
		}
		return false;
	}
}
