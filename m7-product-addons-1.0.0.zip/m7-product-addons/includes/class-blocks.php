<?php
/**
 * Winkelwagen en afrekenen met blokken: gekoppelde producten tonen zoals het origineel
 * (pijltje in plaats van "Verwijderen", vaste aantallen) via de Store API-uitbreiding m7pa_data.
 *
 * @package M7PA
 */

namespace M7PA;

use Automattic\WooCommerce\StoreApi\Schemas\V1\CartItemSchema;

defined( 'ABSPATH' ) || exit;

final class Blocks {

	public static function init() {
		if ( did_action( 'woocommerce_blocks_loaded' ) ) {
			self::register_endpoint();
		} else {
			add_action( 'woocommerce_blocks_loaded', array( __CLASS__, 'register_endpoint' ) );
		}
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
	}

	public static function register_endpoint() {
		if ( ! function_exists( 'woocommerce_store_api_register_endpoint_data' ) || ! class_exists( CartItemSchema::class ) ) {
			return;
		}
		woocommerce_store_api_register_endpoint_data(
			array(
				'endpoint'        => CartItemSchema::IDENTIFIER,
				'namespace'       => 'm7pa_data',
				'data_callback'   => array( __CLASS__, 'item_data' ),
				'schema_callback' => array( __CLASS__, 'schema' ),
				'schema_type'     => ARRAY_A,
			)
		);
	}

	public static function item_data( $cart_item ) {
		if ( empty( $cart_item['m7pa'] ) && empty( $cart_item['m7pa_child'] ) ) {
			return array(); // Alleen regels van M7 (andere plugins houden hun eigen klassen).
		}
		$data = array( 'key' => isset( $cart_item['key'] ) ? $cart_item['key'] : '' );
		if ( ! empty( $cart_item['m7pa_child'] ) ) {
			$mode         = 'one' === $cart_item['m7pa_child']['mode'] ? 'one-only' : $cart_item['m7pa_child']['mode'];
			$data['key'] .= ' m7pa-quantities-' . $mode;
			if ( 'independent' !== $mode ) {
				$data['arrow_right'] = esc_url( M7PA_URL . 'assets/images/arrow-right.svg' );
			}
		}
		return $data;
	}

	public static function schema() {
		return array(
			'key'         => array(
				'description' => 'Cart key met M7-kenmerken',
				'type'        => 'string',
				'readonly'    => true,
			),
			'arrow_right' => array(
				'description' => 'Pijltje voor gekoppelde producten',
				'type'        => 'string',
				'readonly'    => true,
			),
		);
	}

	public static function enqueue() {
		if ( ! class_exists( 'WC_Blocks_Utils' ) ) {
			return;
		}
		$id = get_the_ID();
		if ( \WC_Blocks_Utils::has_block_in_page( $id, 'woocommerce/cart' ) ) {
			$deps = wp_script_is( 'wc-cart-block-frontend', 'registered' ) ? array( 'wc-cart-block-frontend' ) : array( 'wc-blocks-checkout' );
		} elseif ( \WC_Blocks_Utils::has_block_in_page( $id, 'woocommerce/checkout' ) ) {
			$deps = wp_script_is( 'wc-checkout-block-frontend', 'registered' ) ? array( 'wc-checkout-block-frontend' ) : array( 'wc-blocks-checkout' );
		} else {
			return;
		}
		$deps[] = 'jquery';
		wp_enqueue_script( 'm7pa-blocks', M7PA_URL . 'assets/m7pa-blocks.js', $deps, M7PA_VERSION . '.' . (int) @filemtime( M7PA_DIR . 'assets/m7pa-blocks.js' ), true ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	}
}
