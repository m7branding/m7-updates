<?php
/**
 * Elementor: widget "M7 Product Add-Ons" (winkelwagen-formulier met productopties) in de groep "M7".
 * De opties werken ook in elk ander winkelwagen-formulier; dit widget geeft daarnaast stijlinstellingen in Elementor.
 *
 * @package M7PA
 */

namespace M7PA;

defined( 'ABSPATH' ) || exit;

final class Elementor {

	public static function init() {
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'category' ) );
		add_action( 'elementor/widgets/register', array( __CLASS__, 'register' ) );
		add_action( 'admin_notices', array( __CLASS__, 'old_plugin_notice' ) );
	}

	/**
	 * Na het overstappen: Product Add-Ons Ultimate uitzetten, anders tonen producten met gegevens in beide plugins
	 * de opties dubbel.
	 */
	public static function old_plugin_notice() {
		if ( ! current_user_can( 'activate_plugins' ) || ! defined( 'PEWC_PLUGIN_VERSION' ) && ! class_exists( 'PEWC_Product_Extra_Post_Type' ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ! in_array( $screen->id, array( 'plugins', 'dashboard' ), true ) && false === strpos( (string) $screen->id, 'm7' ) ) {
			return;
		}
		echo '<div class="notice notice-warning"><p>' . esc_html__( 'M7 Product Add-Ons: Product Add-Ons Ultimate staat nog aan. Zet die uit zodra de overstap klaar is; anders kunnen opties dubbel op de productpagina staan.', 'm7-product-addons' ) . '</p></div>';
	}

	public static function category( $manager ) {
		if ( class_exists( 'M7_Admin_Menu' ) && method_exists( 'M7_Admin_Menu', 'elementor_category' ) ) {
			\M7_Admin_Menu::elementor_category( $manager );
		}
	}

	public static function register( $widgets_manager ) {
		if ( ! class_exists( '\Elementor\Widget_Base' ) || ! function_exists( 'wc_get_product' ) ) {
			return;
		}
		require_once __DIR__ . '/elementor/class-widget-add-to-cart.php';
		if ( class_exists( 'M7_Admin_Menu' ) && method_exists( 'M7_Admin_Menu', 'elementor_icons' ) ) {
			\M7_Admin_Menu::elementor_icons();
		}
		$widgets_manager->register( new Elementor\Widget_Add_To_Cart() );
	}
}
