<?php
/**
 * Overstappen van WooCommerce Product Add-Ons Ultimate (Plugin Republic, prefix pewc).
 *
 * Leest groepen (pewc_group) en velden (pewc_field) zoals beschreven in
 * docs/ref-product-addons-ultimate.md en maakt er M7-groepen van. Productgroepen worden per
 * product gekoppeld (_m7pa_group_ids), globale groepen krijgen hun regels.
 * De oude gegevens blijven onaangeroerd; opnieuw importeren slaat al geïmporteerde groepen over.
 *
 * @package M7PA
 */

namespace M7PA;

defined( 'ABSPATH' ) || exit;

final class Importer_Pewc {

	const LEGACY_META       = '_m7pa_legacy_pewc';
	const BACKUP_ELEMENTOR  = '_m7pa_pewc_backup';
	const BACKUP_PAGE_CSS   = '_m7pa_pewc_backup_css';
	const BACKUP_CSS_OPTION = 'm7pa_pewc_backup_custom_css';
	const PAGE        = 'm7pa-pewc-migrate';

	const TYPE_MAP = array(
		'checkbox'       => 'checkbox',
		'checkbox_group' => 'checkbox_group',
		'radio'          => 'radio',
		'select'         => 'select',
		'select-box'     => 'select',
		'image_swatch'   => 'image_swatch',
		'radio_image'    => 'image_swatch',
		'products'       => 'products',
		'text'           => 'text',
		'textarea'       => 'textarea',
		'number'         => 'number',
		'name_price'     => 'name_price',
		'date'           => 'date',
		'color-picker'   => 'color',
		'calculation'    => 'calculation',
		'information'    => 'information',
		'upload'         => 'upload',
		'none'           => 'none',
	);

	const RULE_MAP = array(
		'is'                  => 'is',
		'is-not'              => 'is_not',
		'contains'            => 'contains',
		'does-not-contain'    => 'not_contains',
		'cost-equals'         => 'equals',
		'cost-greater'        => 'greater',
		'greater-than'        => 'greater',
		'cost-less'           => 'less',
		'less-than'           => 'less',
		'greater-than-equals' => 'greater_equal',
		'less-than-equals'    => 'less_equal',
	);

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_post_m7pa_pewc_import', array( __CLASS__, 'handle_import' ) );
	}

	public static function menu() {
		add_submenu_page( 'm7', __( 'Overstappen van Product Add-Ons Ultimate', 'm7-product-addons' ), __( 'Overstappen', 'm7-product-addons' ), 'manage_woocommerce', self::PAGE, array( __CLASS__, 'page' ) );
	}

	/* ------------------------------ lezen ------------------------------ */

	private static function on( $v ) {
		return ! empty( $v ) && ! in_array( strtolower( (string) ( is_scalar( $v ) ? $v : '1' ) ), array( '0', 'no', 'false', 'off' ), true );
	}

	/**
	 * Parameters van een pewc-veld: all_params als die gevuld is, anders losse meta.
	 *
	 * @param int $field_id Veld-ID.
	 * @return array
	 */
	public static function field_params( $field_id ) {
		$all = get_post_meta( $field_id, 'all_params', true );
		if ( is_array( $all ) && $all ) {
			return $all;
		}
		$params = array();
		foreach ( get_post_meta( $field_id ) as $key => $values ) {
			if ( '_' !== substr( $key, 0, 1 ) && isset( $values[0] ) ) {
				$params[ $key ] = maybe_unserialize( $values[0] );
			}
		}
		return $params;
	}

	/**
	 * Velden van een groep in volgorde (field_ids is leidend, niet post_parent).
	 *
	 * @param int $group_id Groep-ID.
	 * @return int[]
	 */
	public static function group_field_ids( $group_id ) {
		$ids = get_post_meta( $group_id, 'field_ids', true );
		$ids = is_array( $ids ) ? array_map( 'absint', $ids ) : array();
		return array_values(
			array_filter(
				$ids,
				static function ( $id ) {
					return 'pewc_field' === get_post_type( $id ) && 'publish' === get_post_status( $id );
				}
			)
		);
	}

	/**
	 * Alle pewc-groepen: [groep-ID => ['scope' => product|global, 'products' => [...]]].
	 *
	 * @return array
	 */
	public static function inventory() {
		global $wpdb;
		$out = array();
		// Productgroepen via group_order (CSV) op producten.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = 'group_order' AND meta_value <> ''" );
		foreach ( $rows as $r ) {
			if ( 'product' !== get_post_type( (int) $r->post_id ) ) {
				continue;
			}
			foreach ( array_filter( array_map( 'absint', explode( ',', $r->meta_value ) ) ) as $gid ) {
				if ( 'pewc_group' !== get_post_type( $gid ) ) {
					continue;
				}
				if ( ! isset( $out[ $gid ] ) ) {
					$out[ $gid ] = array( 'scope' => 'product', 'products' => array() );
				}
				$out[ $gid ]['products'][] = (int) $r->post_id;
			}
		}
		// Globale groepen: post_parent 0, gepubliceerd.
		$globals = get_posts(
			array(
				'post_type'      => 'pewc_group',
				'post_status'    => 'publish',
				'post_parent'    => 0,
				'posts_per_page' => -1,
				'orderby'        => 'menu_order',
				'order'          => 'ASC',
				'fields'         => 'ids',
			)
		);
		$order = array_filter( array_map( 'absint', explode( ',', (string) get_option( 'pewc_global_group_order', '' ) ) ) );
		foreach ( array_unique( array_merge( $order, $globals ) ) as $gid ) {
			if ( 'pewc_group' === get_post_type( $gid ) && ! isset( $out[ $gid ] ) && 0 === (int) wp_get_post_parent_id( $gid ) ) {
				$out[ $gid ] = array( 'scope' => 'global', 'products' => array() );
			}
		}
		return $out;
	}

	/**
	 * Zet één pewc-groep om naar een M7-groep.
	 *
	 * @param int   $gid   Groep-ID.
	 * @param array $info  scope/products.
	 * @return array [group, title, warnings]
	 */
	public static function map_group( $gid, array $info ) {
		$warnings = array();
		$title    = (string) get_post_meta( $gid, 'group_title', true );
		$title    = '' !== $title ? $title : get_the_title( $gid );
		$group    = array(
			'description'    => (string) get_post_meta( $gid, 'group_description', true ),
			'display'        => 'standard',
			'layout'         => (string) get_post_meta( $gid, 'group_layout', true ),
			'class'          => (string) get_post_meta( $gid, 'group_class', true ),
			'always_include' => self::on( get_post_meta( $gid, 'always_include', true ) ),
			'scope'          => $info['scope'],
			'fields'         => array(),
			'legacy'         => array( 'pewc_group' => $gid ),
		);

		if ( $info['products'] ) {
			$display = (string) get_post_meta( $info['products'][0], 'pewc_display_groups', true );
			if ( in_array( $display, array( 'accordion', 'tabs', 'steps' ), true ) ) {
				$group['display'] = $display;
			} elseif ( 'lightbox' === $display ) {
				$warnings[] = __( 'Weergave "modal/lightbox" wordt standaard.', 'm7-product-addons' );
			}
		}

		if ( 'global' === $info['scope'] ) {
			$r     = get_post_meta( $gid, 'global_rules', true );
			$r     = is_array( $r ) ? $r : array();
			$rules = array( 'all' => false, 'categories' => array(), 'products' => array() );
			$count = 0;
			if ( ! empty( $r['all']['is_selected'] ) ) {
				$rules['all'] = true;
				$count++;
			}
			if ( ! empty( $r['ids']['is_selected'] ) && ! empty( $r['ids']['products'] ) ) {
				$rules['products'] = array_map( 'absint', (array) $r['ids']['products'] );
				$count++;
			}
			if ( ! empty( $r['categories']['is_selected'] ) && ! empty( $r['categories']['cats'] ) ) {
				foreach ( (array) $r['categories']['cats'] as $cat ) {
					$term = ctype_digit( (string) $cat ) ? get_term( (int) $cat, 'product_cat' ) : get_term_by( 'slug', (string) $cat, 'product_cat' );
					if ( $term && ! is_wp_error( $term ) ) {
						$rules['categories'][] = (int) $term->term_id;
					}
				}
				$count++;
			}
			if ( $count > 1 && isset( $r['operator'] ) && 'all' === $r['operator'] && ! $rules['all'] ) {
				$warnings[] = __( 'Regels met "alle moeten kloppen" (producten EN categorieën) worden "een van".', 'm7-product-addons' );
			}
			if ( ! $count ) {
				$warnings[] = __( 'Globale groep zonder regels: staat nergens aan.', 'm7-product-addons' );
			}
			$group['rules'] = $rules;
		}

		// Groepsvoorwaarden: de hele groep (kop en velden) tonen/verbergen, zoals het origineel.
		$group['conditions'] = self::conditions(
			get_post_meta( $gid, 'condition_action', true ),
			get_post_meta( $gid, 'condition_match', true ),
			(array) get_post_meta( $gid, 'conditions', true ),
			$warnings
		);

		foreach ( self::group_field_ids( $gid ) as $fid ) {
			$field = self::map_field( $fid, $warnings );
			if ( $field ) {
				$group['fields'][] = $field;
			}
		}
		if ( self::on( get_post_meta( $gid, 'repeatable', true ) ) ) {
			$warnings[] = __( 'Herhaalbare groep wordt niet ondersteund (één keer getoond).', 'm7-product-addons' );
		}
		return array( Groups::sanitize_group( $group ), $title, array_values( array_unique( $warnings ) ) );
	}

	public static function field_key( $pewc_id ) {
		if ( preg_match( '/pewc_group_\d+_(\d+)/', (string) $pewc_id, $m ) ) {
			return 'p' . $m[1];
		}
		return ctype_digit( (string) $pewc_id ) ? 'p' . $pewc_id : '';
	}

	private static function conditions( $action, $match, array $rows, array &$warnings, $fields = null, $rules = null, $values = null ) {
		$out = array(
			'action' => 'hide' === $action ? 'hide' : 'show',
			'match'  => 'any' === $match ? 'any' : 'all',
			'rules'  => array(),
		);
		if ( null !== $fields ) {
			$rows = array();
			foreach ( (array) $fields as $i => $target ) {
				$rows[] = array(
					'field' => $target,
					'rule'  => isset( $rules[ $i ] ) ? $rules[ $i ] : '',
					'value' => isset( $values[ $i ] ) ? $values[ $i ] : '',
				);
			}
		}
		if ( ! $action || 'false' === $action ) {
			return $out;
		}
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) || empty( $row['field'] ) || 'not-selected' === $row['field'] || empty( $row['rule'] ) ) {
				continue;
			}
			$target = (string) $row['field'];
			if ( in_array( $target, array( 'quantity', 'cost' ), true ) ) {
				$field = $target;
			} elseif ( 0 === strpos( $target, 'pa_' ) ) {
				$field = 'attribute:' . $target;
			} elseif ( 'log-in-status' === $target ) {
				$field = 'logged_in';
			} elseif ( 'user-role' === $target ) {
				$warnings[] = __( 'Voorwaarde op gebruikersrol wordt niet ondersteund en is overgeslagen.', 'm7-product-addons' );
				continue;
			} else {
				$field = self::field_key( $target );
			}
			$rule = (string) $row['rule'];
			if ( '' === $field || ! isset( self::RULE_MAP[ $rule ] ) ) {
				continue;
			}
			$value = (string) ( is_array( $row['value'] ) ? implode( ',', $row['value'] ) : $row['value'] );
			if ( '__checked__' === $value ) {
				$value = '1';
			}
			$out['rules'][] = array(
				'field'    => $field,
				'operator' => self::RULE_MAP[ $rule ],
				'value'    => $value,
			);
		}
		return $out;
	}

	/**
	 * Formule omzetten: {field_12} → {field:p12}, {field_12_option_price} → {field:p12_option_price}, enz.
	 */
	public static function formula( $formula, array &$warnings ) {
		$formula = (string) $formula;
		$formula = preg_replace( '/\{field_(\d+)(_option_price|_option_value|_option_label|_field_price|_number_uploads|_quantity)?\}/', '{field:p$1$2}', $formula );
		if ( preg_match( '/\{(?!field:p\d+(?:_[a-z_]+)?\}|quantity\}|product_price\})[^}]+\}/', $formula ) ) {
			$warnings[] = __( 'Formule bevat variabelen die M7 niet kent (bijv. afmetingen, opzoektabel, variabelen); controleer de formule.', 'm7-product-addons' );
		}
		return $formula;
	}

	/** Prijs als getal (formules in prijzen worden niet ondersteund). */
	private static function price_value( $price, array &$warnings ) {
		$price = (string) $price;
		if ( false !== strpos( $price, '{' ) ) {
			$warnings[] = __( 'Prijs als formule wordt niet ondersteund; prijs op 0 gezet.', 'm7-product-addons' );
			return '0';
		}
		return $price;
	}

	public static function map_field( $fid, array &$warnings ) {
		$p    = self::field_params( $fid );
		$get  = static function ( $k, $d = '' ) use ( $p ) {
			return isset( $p[ $k ] ) && '' !== $p[ $k ] ? $p[ $k ] : $d;
		};
		$raw  = static function ( $k ) use ( $p ) {
			return isset( $p[ $k ] ) && is_scalar( $p[ $k ] ) ? (string) $p[ $k ] : '';
		};
		// Veld zonder type (bijv. nooit ingevuld): het origineel toont alleen een lege regel, zonder invoer.
		$type = (string) $get( 'field_type', 'none' );
		if ( ! isset( self::TYPE_MAP[ $type ] ) ) {
			/* translators: %s: veldtype */
			$warnings[] = sprintf( __( 'Veldtype "%s" wordt (nog) niet ondersteund en is overgeslagen.', 'm7-product-addons' ), $type );
			return null;
		}
		$label = (string) $get( 'field_label', '' );
		$f     = array(
			'id'                      => self::field_key( $get( 'id', $fid ) ) ? self::field_key( $get( 'id', $fid ) ) : 'p' . $fid,
			'type'                    => self::TYPE_MAP[ $type ],
			'label'                   => $label,
			'description'             => is_numeric( $get( 'field_description' ) ) ? '' : (string) $get( 'field_description' ),
			'required'                => self::on( $get( 'field_required' ) ),
			'price'                   => 0,
			'price_type'              => 'fixed',
			'class'                   => (string) $get( 'field_class', '' ),
			'image'                   => absint( $get( 'field_image', 0 ) ),
			'visibility'              => (string) $get( 'field_visibility', 'visible' ),
			// Leeg laten als het origineel niets had opgeslagen (dan gedraagt een checkbox zich anders).
			'price_visibility'        => $raw( 'price_visibility' ),
			'option_price_visibility' => $raw( 'option_price_visibility' ),
			'as_swatch'               => self::on( $get( 'field_display_as_swatch' ) ),
			'columns'                 => '' === $raw( 'number_columns' ) ? 0 : (int) $raw( 'number_columns' ),
			'hide_option_labels'      => self::on( $get( 'hide_labels' ) ),
			'min_checks'              => $get( 'field_minchecks', '' ),
			'max_checks'              => $get( 'field_maxchecks', '' ),
			'free_chars'              => $get( 'field_freechars', '' ),
			'alphanumeric'            => self::on( $get( 'field_alphanumeric' ) ),
			'alphanumeric_charge'     => self::on( $get( 'field_alphanumeric_charge' ) ),
			'show_counter'            => self::on( $get( 'show_char_counter' ) ),
			'slider'                  => '1' === $raw( 'field_enable_range_slider' ),
			'replace_image'           => self::on( $get( 'replace_main_image' ) ),
			'variations'              => array_map( 'absint', (array) $get( 'variation_field', array() ) ),
			'color'                   => (string) $get( 'field_color', '' ),
			'legacy'                  => array(
				'pewc_field' => $fid,
				'pewc_type'  => $type,
			),
		);
		if ( 'select-box' === $type ) {
			$warnings[] = __( 'Afbeeldings-keuzelijst (select box) wordt een gewone keuzelijst.', 'm7-product-addons' );
		}
		if ( 'image_swatch' === self::TYPE_MAP[ $type ] && self::on( $get( 'layered_images' ) ) ) {
			$warnings[] = __( 'Afbeeldingen als lagen over de hoofdafbeelding worden niet ondersteund (alleen vervangen).', 'm7-product-addons' );
		}

		$f['price'] = self::price_value( $get( 'field_price', '0' ), $warnings );
		$flags      = array_filter(
			array(
				'flat'       => self::on( $get( 'field_flatrate' ) ) && ! in_array( $type, array( 'calculation', 'information' ), true ),
				'percentage' => self::on( $get( 'field_percentage' ) ),
				'per_char'   => self::on( $get( 'per_character' ) ) && in_array( $type, array( 'text', 'textarea' ), true ),
				'multiply'   => ( self::on( $get( 'multiply' ) ) && in_array( $type, array( 'number', 'name_price' ), true ) ) || ( self::on( $get( 'multiply_price' ) ) && 'upload' === $type ),
			)
		);
		if ( $flags ) {
			$f['price_type'] = key( $flags );
			if ( count( $flags ) > 1 ) {
				/* translators: %s: label */
				$warnings[] = sprintf( __( '"%s": combinatie van prijssoorten (bijv. eenmalig én percentage) wordt één prijssoort.', 'm7-product-addons' ), $label );
			}
		}

		$f['options'] = array();
		foreach ( (array) $get( 'field_options', array() ) as $o ) {
			if ( is_array( $o ) && isset( $o['value'] ) ) {
				$f['options'][] = array(
					'value' => (string) $o['value'],
					'label' => (string) $o['value'],
					'price' => self::price_value( isset( $o['price'] ) ? $o['price'] : '0', $warnings ),
					'image' => isset( $o['image'] ) ? absint( $o['image'] ) : 0,
					'hex'   => isset( $o['hex'] ) ? (string) $o['hex'] : '',
				);
			}
		}
		if ( 'select' === $f['type'] && self::on( $get( 'first_field_empty' ) ) && $f['options'] ) {
			$first            = array_shift( $f['options'] );
			$f['placeholder'] = '' !== $first['label'] ? $first['label'] : ' ';
		}
		$f['multiple'] = self::on( $get( 'allow_multiple' ) );
		$default       = (string) $get( 'field_default_hidden', $get( 'field_default', '' ) );
		$f['default']  = str_replace( ' | ', ',', $default );

		$f['min_chars'] = $get( 'field_minchars', $get( 'min_chars', '' ) );
		$f['max_chars'] = $get( 'field_maxchars', $get( 'max_chars', '' ) );
		$f['min']       = $get( 'field_minval', '' );
		$f['max']       = $get( 'field_maxval', '' );
		$step           = $get( 'field_step_value', '' );
		if ( '' === $step && (int) $get( 'field_step', 0 ) > 0 ) {
			$step = pow( 10, 0 - absint( $get( 'field_step', 0 ) ) );
		}
		$f['step'] = $step;

		if ( 'date' === $type ) {
			$f['date'] = array(
				'min_today' => self::on( $get( 'min_date_today' ) ),
				'offset'    => $get( 'offset_days', '' ),
				'min'       => $get( 'field_mindate', '' ) ? gmdate( 'Y-m-d', strtotime( $get( 'field_mindate', '' ) ) ) : '',
				'max'       => $get( 'field_maxdate_ymd', '' ) ? $get( 'field_maxdate_ymd', '' ) : ( $get( 'field_maxdate', '' ) ? gmdate( 'Y-m-d', strtotime( $get( 'field_maxdate', '' ) ) ) : '' ),
			);
		}

		if ( 'calculation' === $type ) {
			$f['formula']          = self::formula( $get( 'formula', '' ), $warnings );
			$f['decimals']         = (int) $get( 'decimal_places', 0 );
			$action                = (string) $get( 'formula_action', 'cost' ); // Leeg werkt in het origineel als "kosten".
			$f['formula_action']   = in_array( $action, Groups::FORMULA_ACTIONS, true ) ? $action : 'no-action';
			$f['formula_as_price'] = in_array( $action, array( 'cost', 'price' ), true );
			$f['formula_round']    = in_array( $get( 'formula_round', '' ), array( 'floor', 'ceil' ), true ) ? $get( 'formula_round', '' ) : '';
			$f['suffix']           = (string) $get( 'formula_suffix', '' );
			$f['hidden']           = self::on( $get( 'hidden_calculation' ) );
			if ( ! in_array( $action, array( 'no-action', 'cost', 'price', '' ), true ) ) {
				/* translators: %s: actie */
				$warnings[] = sprintf( __( 'Berekeningsactie "%s" wordt alleen getoond (geen effect op aantal of afmetingen).', 'm7-product-addons' ), $action );
			}
		}

		if ( 'products' === $type ) {
			$layout        = (string) $get( 'products_layout', 'checkboxes' );
			$qty           = (string) $get( 'products_quantities', 'linked' );
			$f['products'] = array(
				'ids'           => array_map( 'absint', (array) $get( 'child_products', array() ) ),
				'layout'        => in_array( $layout, Groups::PRODUCT_LAYOUTS, true ) ? $layout : 'checkboxes',
				'quantities'    => 'one-only' === $qty ? 'one' : ( 'independent' === $qty ? 'independent' : 'linked' ),
				'discount'      => (float) $get( 'child_discount', 0 ),
				'discount_type' => 'fixed' === $get( 'discount_type', 'percentage' ) ? 'fixed' : 'percentage',
				'allow_none'    => ! self::on( $get( 'field_required' ) ),
				'min'           => (int) $get( 'min_products', 0 ) ? (int) $get( 'min_products', 0 ) : '',
				'max'           => (int) $get( 'max_products', 0 ) ? (int) $get( 'max_products', 0 ) : '',
				'placeholder'   => (string) $get( 'select_placeholder', '' ),
				'columns'       => '' === $raw( 'number_columns' ) ? 0 : (int) $raw( 'number_columns' ),
				'hide_labels'   => self::on( $get( 'hide_labels' ) ),
				'force_qty'     => self::on( $get( 'force_quantity' ) ),
				'default_qty'   => $get( 'default_quantity', '' ),
				'min_qty'       => $get( 'min_quantity_per_item', '' ),
				'max_qty'       => $get( 'max_quantity_per_item', '' ),
			);
			if ( in_array( $layout, array( 'column', 'components', 'swatches', 'grid', 'variable-select' ), true ) ) {
				/* translators: %s: weergave */
				$warnings[] = sprintf( __( 'Productweergave "%s" wordt als checkboxes met afbeeldingen (of keuzelijst) getoond.', 'm7-product-addons' ), $layout );
			}
			if ( self::on( $get( 'select_all_enabled' ) ) ) {
				$warnings[] = __( '"Alles selecteren" bij gekoppelde producten wordt niet ondersteund.', 'm7-product-addons' );
			}
		}

		if ( 'upload' === $type ) {
			$mimes       = get_option( 'pewc_upload_mime_types', array() );
			$types       = is_array( $mimes ) && $mimes ? array_map( 'strval', $mimes ) : array( 'jpg', 'jpeg', 'jpe', 'png', 'gif' );
			$f['upload'] = array(
				'max_files' => self::on( $get( 'multiple_uploads' ) ) ? max( 1, (int) $get( 'max_files', 5 ) ) : 1,
				'max_mb'    => max( 1, (int) get_option( 'pewc_max_upload', 1 ) ),
				'types'     => $types,
			);
		}

		if ( 'information' === $type ) {
			$f['rows'] = array();
			foreach ( (array) $get( 'field_rows', array() ) as $r ) {
				if ( is_array( $r ) ) {
					$f['rows'][] = array(
						'image' => isset( $r['image'] ) ? absint( $r['image'] ) : 0,
						'label' => isset( $r['label'] ) ? $r['label'] : '',
						'value' => isset( $r['data'] ) ? $r['data'] : '',
					);
				}
			}
		}

		$f['conditions'] = self::conditions(
			$get( 'condition_action', '' ),
			$get( 'condition_match', 'all' ),
			array(),
			$warnings,
			(array) $get( 'condition_field', array() ),
			(array) $get( 'condition_rule', array() ),
			(array) $get( 'condition_value', array() )
		);
		return $f;
	}

	/**
	 * Instellingen per product (prijslabel, aantal verbergen) van het originele product naar een product.
	 *
	 * @param int $from Product met de oude instellingen.
	 * @param int $to   Product dat ze krijgt (bij overstappen hetzelfde product).
	 */
	public static function import_product_settings( $from, $to ) {
		$map = array(
			'pewc_price_label'   => '_m7pa_price_label',
			'pewc_price_display' => '_m7pa_price_display',
			'pewc_hide_quantity' => '_m7pa_hide_quantity',
		);
		foreach ( $map as $old => $new ) {
			$v = get_post_meta( $from, $old, true );
			if ( '' !== $v && false !== $v && null !== $v ) {
				update_post_meta( $to, $new, in_array( $v, array( 'yes', '1', 1, true ), true ) && 'pewc_hide_quantity' === $old ? '1' : $v );
			}
		}
	}

	/**
	 * Algemene instellingen en Customizer-opmaak van het origineel overnemen.
	 * Niet-opgeslagen opties krijgen de standaardwaarde die het origineel dan gebruikt.
	 */
	public static function import_settings() {
		$opt    = static function ( $k, $d ) {
			return get_option( $k, $d );
		};
		$yes    = static function ( $k, $d = 'no' ) use ( $opt ) {
			return 'yes' === $opt( $k, $d );
		};
		$mod    = static function ( $k, $d = '' ) {
			$v = get_theme_mod( $k, $d );
			return is_scalar( $v ) ? (string) $v : $d;
		};
		$current = Settings::all();
		$s       = array(
			'show_totals'          => (string) $opt( 'pewc_show_totals', 'all' ),
			'label_product'        => (string) $opt( 'pewc_product_total_label', '' ),
			'label_options'        => (string) $opt( 'pewc_options_total_label', '' ),
			'label_flatrate'       => (string) $opt( 'pewc_flatrate_total_label', '' ),
			'label_grand'          => (string) $opt( 'pewc_grand_total_label', '' ),
			'style'                => 'inherit' === $opt( 'pewc_preset_style', 'simple' ) ? 'theme' : 'simple',
			'accent'               => (string) $opt( 'pewc_preset_accent_colour', '#2196F3' ),
			'price_separator'      => (string) $opt( 'pewc_price_separator', '+' ),
			'separator_unsaved'    => false === get_option( 'pewc_price_separator', false ),
			'hide_zero'            => $yes( 'pewc_hide_zero' ),
			'hide_field_prices'    => $yes( 'pewc_hide_field_prices' ),
			'update_price_label'   => $yes( 'pewc_update_price_label' ),
			'price_label'          => (string) $opt( 'pewc_price_label', '' ),
			'price_display'        => (string) $opt( 'pewc_price_display', 'before' ),
			'group_title_tag'      => (string) $opt( 'pewc_group_title_tag', 'h3' ),
			'require_login_upload' => $yes( 'pewc_require_log_in', 'yes' ),
			'max_upload_mb'        => max( 1, (int) $opt( 'pewc_max_upload', 1 ) ),
			'reset_fields'         => $yes( 'pewc_reset_fields' ),
			'tooltips'             => in_array( $opt( 'pewc_enable_tooltips', 'no' ), array( 'yes', 'enhanced' ), true ),
			'replace_image'        => $yes( 'pewc_replace_image' ),
			'cart_group_titles'    => $yes( 'pewc_cart_group_titles' ),
			'child_as_meta'        => $yes( 'pewc_display_child_products_as_meta' ),
			'multiply_independent' => $yes( 'pewc_multiply_independent_quantity' ),
			'show_inputs'          => (bool) $mod( 'pewc_show_inputs', '' ),
			'circular_swatches'    => (bool) $opt( 'pewc_circular_swatches', false ),
			'design'               => array(
				'group_title_color'       => $mod( 'pewc_group_title_color', '#333' ),
				'group_title_size'        => $mod( 'pewc_group_title_size', '32' ),
				'group_title_background'  => $mod( 'pewc_group_title_background', '' ),
				'group_description_color' => $mod( 'pewc_group_description_color', '#222' ),
				'group_description_size'  => $mod( 'pewc_group_description_size', '18' ),
				'hide_group_title'        => (bool) $opt( 'pewc_group_hide_title', false ),
				'next_button'             => $mod( 'pewc_group_next_button', '#eee' ),
				'previous_button'         => $mod( 'pewc_group_previous_button', '#eee' ),
				'step_button_text'        => $mod( 'pewc_group_step_button', '#222' ),
				'step_tab'                => $mod( 'pewc_step_tab', '#f9f9f9' ),
				'active_step_tab'         => $mod( 'pewc_active_step_tab', '#f1f1f1' ),
				'tab'                     => $mod( 'pewc_tab_colour', '#f1f1f1' ),
				'active_tab'              => $mod( 'pewc_active_tab', '#fff' ),
				'justify_tabs'            => (bool) $opt( 'pewc_justify_tabs', false ),
				'accordion_icon'          => $mod( 'pewc_group_accordion_icon', '#222' ),
				'accordion_icon_size'     => $mod( 'pewc_group_accordion_icon_size', '0.3' ),
				'products_border'         => $mod( 'pewc_products_border', '#2196f3' ),
				'swatch_padding'          => (string) $opt( 'pewc_swatch_border_padding', '8' ),
				'swatch_border_width'     => (string) $opt( 'pewc_swatch_border_width', '0' ),
				'swatch_width'            => (string) $opt( 'pewc_swatch_width', '0' ),
				'color_swatch_width'      => (string) $opt( 'pewc_color_swatch_width', '60' ),
				'color_swatch_height'     => (string) $opt( 'pewc_color_swatch_height', '60' ),
				'textarea_height'         => $mod( 'pewc_textarea_height', '' ),
				'text_width'              => (bool) $mod( 'pewc_text_width', '' ),
				'number_width'            => (bool) $mod( 'pewc_number_width', '' ),
				'select_width'            => (bool) $mod( 'pewc_select_width', '' ),
				'block_label'             => (bool) $mod( 'pewc_block_label', '' ),
				'list_margin_left'        => $mod( 'pewc_list_margin_left', '' ),
				'list_margin_bottom'      => $mod( 'pewc_list_margin_bottom', '' ),
				'list_padding'            => $mod( 'pewc_list_padding', '' ),
				'list_background'         => $mod( 'pewc_list_background', '' ),
				'field_margin_left'       => $mod( 'pewc_field_margin_left', '' ),
				'field_margin_bottom'     => $mod( 'pewc_field_margin_bottom', '' ),
				'field_padding_top'       => $mod( 'pewc_field_padding_top', '' ),
				'field_padding_left'      => $mod( 'pewc_field_padding_left', '' ),
				'field_background'        => $mod( 'pewc_field_background', '' ),
				'text_colour'             => $mod( 'pewc_text_colour', '' ),
				'quantity_layout'         => (string) $opt( 'pewc_quantity_layout', 'block' ),
			),
		);
		update_option( Settings::OPTION, Settings::clean( array_merge( $current, $s ) ) );
		Settings::flush();
	}

	/* ------------------------------ uitvoeren ------------------------------ */

	public static function imported_map() {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT pm.post_id, pm.meta_value FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = %s AND p.post_status <> 'trash'", self::LEGACY_META ) );
		$map  = array();
		foreach ( $rows as $r ) {
			$map[ (int) $r->meta_value ] = (int) $r->post_id;
		}
		return $map;
	}

	/**
	 * Zet één pewc-groep om en slaat hem op als M7-groep.
	 *
	 * @param int   $gid  pewc-groep-ID.
	 * @param array $info scope/products (zie inventory()).
	 * @return int Nieuwe groep-ID (0 bij een fout).
	 */
	public static function import_group( $gid, array $info ) {
		list( $group, $title ) = self::map_group( $gid, $info );
		$new                   = wp_insert_post(
			array(
				'post_type'   => Groups::POST_TYPE,
				// Een groep die in het origineel niet gepubliceerd is (concept, ter beoordeling), staat nergens aan.
				'post_status' => 'publish' === get_post_status( $gid ) ? 'publish' : 'draft',
				'post_title'  => $title,
				'menu_order'  => (int) get_post_field( 'menu_order', $gid ),
			)
		);
		if ( ! $new || is_wp_error( $new ) ) {
			return 0;
		}
		update_post_meta( $new, Groups::META, $group );
		update_post_meta( $new, self::LEGACY_META, $gid );
		Groups::flush();
		return (int) $new;
	}

	public static function handle_import() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Geen toegang.', 'm7-product-addons' ) );
		}
		check_admin_referer( 'm7pa_pewc_import' );
		$map      = self::imported_map();
		$created  = 0;
		$products = array();
		foreach ( self::inventory() as $gid => $info ) {
			if ( ! isset( $map[ $gid ] ) ) {
				$new = self::import_group( $gid, $info );
				if ( ! $new ) {
					continue;
				}
				$map[ $gid ] = $new;
				$created++;
			}
			foreach ( $info['products'] as $pid ) {
				$products[ $pid ] = true;
			}
		}

		// Productkoppelingen: volgorde uit group_order plus geforceerde globale groepen.
		foreach ( array_unique( array_merge( array_keys( $products ), array_keys( self::products_with_forced_globals() ) ) ) as $pid ) {
			$ids = array();
			foreach ( array_filter( array_map( 'absint', explode( ',', (string) get_post_meta( $pid, 'group_order', true ) ) ) ) as $gid ) {
				if ( isset( $map[ $gid ] ) ) {
					$ids[] = $map[ $gid ];
				}
			}
			foreach ( array_filter( array_map( 'absint', explode( ',', (string) get_post_meta( $pid, 'pewc_global_groups_by_product', true ) ) ) ) as $gid ) {
				if ( isset( $map[ $gid ] ) ) {
					$ids[] = $map[ $gid ];
				}
			}
			if ( $ids ) {
				update_post_meta( $pid, Groups::PRODUCT_META, array_values( array_unique( $ids ) ) );
			}
			self::import_product_settings( $pid, $pid );
		}
		self::import_settings();
		Groups::flush();
		$code = self::convert_site_code();
		/* translators: 1: groepen, 2: producten */
		$msg = sprintf( __( '%1$d groepen geïmporteerd, %2$d producten gekoppeld.', 'm7-product-addons' ), $created, count( $products ) );
		if ( $code ) {
			/* translators: %s: onderdelen */
			$msg .= ' ' . sprintf( __( 'Eigen CSS/scripts omgezet: %s.', 'm7-product-addons' ), implode( ', ', $code ) );
		}
		set_transient( 'm7pa_migrate_notice_' . get_current_user_id(), $msg, 300 );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE ) );
		exit;
	}

	/* -------------------- eigen CSS en scripts van de site -------------------- */

	/**
	 * Eigen code van de site die de klassen, ID's of veldnamen van Product Add-Ons Ultimate gebruikt, omzetten naar
	 * M7 (zelfde opbouw met "m7pa" in plaats van "pewc"). Veldnamen met groepsnummers krijgen het nummer van de
	 * geïmporteerde M7-groep: pewc_group_2645_2646 wordt m7pa_group_<nieuw>_p2646.
	 *
	 * @param string $text CSS of HTML/JavaScript.
	 * @param array  $map  pewc-groep-ID => M7-groep-ID.
	 * @return string
	 */
	public static function convert_code( $text, array $map ) {
		$text = (string) $text;
		if ( false === strpos( $text, 'pewc' ) ) {
			return $text;
		}
		$gid  = static function ( $g ) use ( $map ) {
			return isset( $map[ (int) $g ] ) ? (int) $map[ (int) $g ] : (int) $g;
		};
		$text = preg_replace_callback( '/pewc_group_(\d+)_(\d+)/', static function ( $m ) use ( $gid ) { return 'm7pa_group_' . $gid( $m[1] ) . '_p' . $m[2]; }, $text );
		$text = preg_replace_callback( '/pewc-group-wrap-(\d+)/', static function ( $m ) use ( $gid ) { return 'm7pa-group-wrap-' . $gid( $m[1] ); }, $text );
		$text = preg_replace_callback( '/pewc-group-(\d+)(?![\d-])/', static function ( $m ) use ( $gid ) { return 'm7pa-group-' . $gid( $m[1] ); }, $text );
		$text = preg_replace( '/pewc-field-(\d+)/', 'm7pa-field-p$1', $text );
		return str_replace( array( 'pewc_group', 'pewc-' ), array( 'm7pa_group', 'm7pa-' ), $text );
	}

	private static function convert_elements_code( array $elements, array $map, &$changed ) {
		foreach ( $elements as $i => $el ) {
			if ( ! is_array( $el ) ) {
				continue;
			}
			$keys = array( 'custom_css' );
			if ( isset( $el['widgetType'] ) && 'html' === $el['widgetType'] ) {
				$keys[] = 'html';
			}
			foreach ( $keys as $k ) {
				if ( ! empty( $el['settings'][ $k ] ) && is_string( $el['settings'][ $k ] ) ) {
					$new = self::convert_code( $el['settings'][ $k ], $map );
					if ( $new !== $el['settings'][ $k ] ) {
						$elements[ $i ]['settings'][ $k ] = $new;
						$changed++;
					}
				}
			}
			if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
				$elements[ $i ]['elements'] = self::convert_elements_code( $el['elements'], $map, $changed );
			}
		}
		return $elements;
	}

	private static function convert_page_css( $post_id, array $map ) {
		$ps = get_post_meta( $post_id, '_elementor_page_settings', true );
		if ( ! is_array( $ps ) || empty( $ps['custom_css'] ) || ! is_string( $ps['custom_css'] ) ) {
			return false;
		}
		$new = self::convert_code( $ps['custom_css'], $map );
		if ( $new === $ps['custom_css'] ) {
			return false;
		}
		if ( '' === get_post_meta( $post_id, self::BACKUP_PAGE_CSS, true ) ) {
			add_post_meta( $post_id, self::BACKUP_PAGE_CSS, $ps['custom_css'], true );
		}
		$ps['custom_css'] = $new;
		update_post_meta( $post_id, '_elementor_page_settings', $ps );
		return true;
	}

	private static function clear_elementor_cache( $post_id ) {
		delete_post_meta( $post_id, '_elementor_css' );
		delete_post_meta( $post_id, '_elementor_element_cache' );
		if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
			\Elementor\Plugin::$instance->files_manager->clear_cache();
		}
	}

	/**
	 * Eigen CSS/scripts in Elementor (elementen, HTML-widgets, pagina- en sitebrede CSS) en de Extra CSS van het
	 * thema omzetten, met back-up. Terugzetten met revert_site_code().
	 *
	 * @return string[] Wat er is aangepast.
	 */
	public static function convert_site_code() {
		global $wpdb;
		$map  = self::imported_map();
		$done = array();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$docs = $wpdb->get_col( "SELECT pm.post_id FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = '_elementor_data' AND pm.meta_value LIKE '%pewc%' AND p.post_type <> 'revision' AND p.post_status <> 'trash'" );
		foreach ( array_map( 'intval', $docs ) as $doc ) {
			$raw  = get_post_meta( $doc, '_elementor_data', true );
			$data = is_array( $raw ) ? $raw : json_decode( (string) $raw, true );
			if ( ! is_array( $data ) ) {
				continue;
			}
			$changed = 0;
			$new     = self::convert_elements_code( $data, $map, $changed );
			$page    = self::convert_page_css( $doc, $map );
			if ( $changed ) {
				if ( '' === get_post_meta( $doc, self::BACKUP_ELEMENTOR, true ) ) {
					add_post_meta( $doc, self::BACKUP_ELEMENTOR, wp_slash( is_array( $raw ) ? wp_json_encode( $raw ) : $raw ), true );
				}
				update_post_meta( $doc, '_elementor_data', wp_slash( wp_json_encode( $new ) ) );
			}
			if ( $changed || $page ) {
				self::clear_elementor_cache( $doc );
				$done[] = get_the_title( $doc ) . ' (#' . $doc . ')';
			}
		}
		$kit = (int) get_option( 'elementor_active_kit' );
		if ( $kit && ! in_array( $kit, array_map( 'intval', $docs ), true ) && self::convert_page_css( $kit, $map ) ) {
			self::clear_elementor_cache( $kit );
			$done[] = __( 'Elementor sitebrede CSS', 'm7-product-addons' );
		}
		if ( function_exists( 'wp_get_custom_css_post' ) ) {
			$post = wp_get_custom_css_post();
			if ( $post && false !== strpos( $post->post_content, 'pewc' ) ) {
				$backups = (array) get_option( self::BACKUP_CSS_OPTION, array() );
				if ( ! isset( $backups[ $post->ID ] ) ) {
					$backups[ $post->ID ] = $post->post_content;
					update_option( self::BACKUP_CSS_OPTION, $backups, false );
				}
				wp_update_custom_css_post( self::convert_code( $post->post_content, $map ), array( 'stylesheet' => $post->post_name ) );
				$done[] = __( 'Extra CSS van het thema', 'm7-product-addons' );
			}
		}
		return $done;
	}

	/**
	 * Eigen CSS/scripts terugzetten naar de versie van vóór de overstap.
	 *
	 * @return int Aantal teruggezette onderdelen.
	 */
	public static function revert_site_code() {
		global $wpdb;
		$n = 0;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key IN (%s, %s)", self::BACKUP_ELEMENTOR, self::BACKUP_PAGE_CSS ) );
		foreach ( array_map( 'intval', $rows ) as $doc ) {
			$backup = get_post_meta( $doc, self::BACKUP_ELEMENTOR, true );
			if ( '' !== $backup ) {
				update_post_meta( $doc, '_elementor_data', wp_slash( $backup ) );
				delete_post_meta( $doc, self::BACKUP_ELEMENTOR );
			}
			$css = get_post_meta( $doc, self::BACKUP_PAGE_CSS, true );
			if ( '' !== $css ) {
				$ps               = get_post_meta( $doc, '_elementor_page_settings', true );
				$ps               = is_array( $ps ) ? $ps : array();
				$ps['custom_css'] = $css;
				update_post_meta( $doc, '_elementor_page_settings', $ps );
				delete_post_meta( $doc, self::BACKUP_PAGE_CSS );
			}
			self::clear_elementor_cache( $doc );
			$n++;
		}
		foreach ( (array) get_option( self::BACKUP_CSS_OPTION, array() ) as $post_id => $css ) {
			$post = get_post( (int) $post_id );
			if ( $post && 'custom_css' === $post->post_type ) {
				wp_update_custom_css_post( $css, array( 'stylesheet' => $post->post_name ) );
				$n++;
			}
		}
		delete_option( self::BACKUP_CSS_OPTION );
		return $n;
	}

	private static function products_with_forced_globals() {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$ids = $wpdb->get_col( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'pewc_global_groups_by_product' AND meta_value NOT IN ('', 'false')" );
		return array_fill_keys( array_map( 'intval', $ids ), true );
	}

	/* ------------------------------ scherm ------------------------------ */

	public static function page() {
		$notice = get_transient( 'm7pa_migrate_notice_' . get_current_user_id() );
		if ( $notice ) {
			delete_transient( 'm7pa_migrate_notice_' . get_current_user_id() );
		}
		$inventory = self::inventory();
		$map       = self::imported_map();
		$active    = defined( 'PEWC_PLUGIN_VERSION' ) || function_exists( 'pewc_get_extra_fields' );
		?>
		<div class="wrap m7-admin">
			<h1 class="screen-reader-text"><?php esc_html_e( 'Product Add-Ons: overstappen van Product Add-Ons Ultimate', 'm7-product-addons' ); ?></h1>
			<?php if ( $notice ) : ?>
				<div class="notice notice-success"><p><?php echo esc_html( $notice ); ?></p></div>
			<?php endif; ?>
			<p><?php esc_html_e( 'Werkwijze: 1) importeren (oude gegevens blijven staan), 2) producten controleren op een testkopie, 3) Product Add-Ons Ultimate deactiveren. Oude bestellingen blijven hun gekozen opties tonen. Eigen CSS en scripts met pewc-klassen of -veldnamen (Elementor, Extra CSS) worden mee omgezet, met back-up.', 'm7-product-addons' ); ?></p>
			<?php if ( $active ) : ?>
				<p><em><?php esc_html_e( 'Product Add-Ons Ultimate is nog actief. Zolang beide actief zijn, tonen producten de velden van beide plugins; deactiveer de oude plugin direct na de controle.', 'm7-product-addons' ); ?></em></p>
			<?php endif; ?>
			<?php if ( ! $inventory ) : ?>
				<p><?php esc_html_e( 'Geen add-on-groepen van Product Add-Ons Ultimate gevonden.', 'm7-product-addons' ); ?></p>
			<?php else : ?>
				<table class="widefat striped">
					<thead><tr><th>ID</th><th><?php esc_html_e( 'Groep', 'm7-product-addons' ); ?></th><th><?php esc_html_e( 'Toepassing', 'm7-product-addons' ); ?></th><th><?php esc_html_e( 'Velden', 'm7-product-addons' ); ?></th><th><?php esc_html_e( 'Let op', 'm7-product-addons' ); ?></th><th><?php esc_html_e( 'Status', 'm7-product-addons' ); ?></th></tr></thead>
					<tbody>
					<?php
					foreach ( $inventory as $gid => $info ) :
						list( $group, $title, $warnings ) = self::map_group( $gid, $info );
						?>
						<tr>
							<td><?php echo (int) $gid; ?></td>
							<td><?php echo esc_html( $title ); ?></td>
							<td><?php echo 'global' === $info['scope'] ? esc_html__( 'Globaal', 'm7-product-addons' ) : esc_html( sprintf( /* translators: %d: aantal */ _n( '%d product', '%d producten', count( $info['products'] ), 'm7-product-addons' ), count( $info['products'] ) ) ); ?></td>
							<td><?php echo esc_html( implode( ', ', array_map( static function ( $f ) { return ( '' !== $f['label'] ? $f['label'] : $f['id'] ) . ' (' . $f['type'] . ')'; }, $group['fields'] ) ) ); ?></td>
							<td><?php echo $warnings ? esc_html( implode( ' ', $warnings ) ) : '—'; ?></td>
							<td><?php echo isset( $map[ $gid ] ) ? '<a href="' . esc_url( get_edit_post_link( $map[ $gid ] ) ) . '">' . esc_html__( 'Geïmporteerd', 'm7-product-addons' ) . ' (#' . (int) $map[ $gid ] . ')</a>' : esc_html__( 'Nog niet', 'm7-product-addons' ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:12px">
					<?php wp_nonce_field( 'm7pa_pewc_import' ); ?>
					<input type="hidden" name="action" value="m7pa_pewc_import">
					<?php submit_button( __( 'Importeren en producten koppelen', 'm7-product-addons' ), 'primary', 'submit', false ); ?>
				</form>
			<?php endif; ?>
		</div>
		<?php
	}
}
