<?php
/**
 * Hoofdklasse: zet alle onderdelen aan.
 *
 * @package M7PA
 */

namespace M7PA;

defined( 'ABSPATH' ) || exit;

final class Plugin {

	/** @var Plugin|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		load_plugin_textdomain( 'm7-product-addons', false, dirname( plugin_basename( M7PA_FILE ) ) . '/languages' );

		Groups::init();
		Frontend::init();
		Cart::init();
		Blocks::init();
		Elementor::init();
		Uploads::init();
		Settings::init();
		add_action( 'init', array( Legacy_Orders::class, 'init' ), 20 );

		if ( is_admin() ) {
			require_once M7PA_DIR . 'includes/m7/class-m7-admin-menu.php';
			add_action( 'init', array( __CLASS__, 'register_m7_menu' ) );
			Admin::init();
			Importer_Pewc::init();
		}
	}

	/**
	 * Aanmelden bij het gedeelde M7-menu in wp-admin.
	 */
	public static function register_m7_menu() {
		\M7_Admin_Menu::register_plugin(
			array(
				'slug'        => 'm7-product-addons',
				'name'        => __( 'Product Add-Ons', 'm7-product-addons' ),
				'version'     => M7PA_VERSION,
				'description' => __( 'Extra opties en velden bij producten, met prijzen en voorwaarden. Vervanger van Product Add-Ons Ultimate.', 'm7-product-addons' ),
				'order'       => 20,
				'tabs'        => array(
					__( 'Groepen', 'm7-product-addons' )      => 'edit.php?post_type=' . Groups::POST_TYPE,
					__( 'Instellingen', 'm7-product-addons' ) => 'm7pa-settings',
					__( 'Overstappen', 'm7-product-addons' )  => Importer_Pewc::PAGE,
				),
			)
		);
	}
}
