<?php
/**
 * Velden op de productpagina, totalen, hoofdprijs en knoppen in het winkeloverzicht.
 *
 * De opbouw (HTML) volgt Product Add-Ons Ultimate 4.7.2 element voor element, met m7pa- in plaats
 * van pewc- in klassen en ID's. Zo ziet een site er na overstappen hetzelfde uit en blijven
 * thema-aanpassingen op dezelfde structuur werken. Teksten zijn de Nederlandse teksten van die plugin.
 *
 * Veld-ID in de pagina ({id}): m7pa_group_<groep-ID>_<veld-ID>; dat is ook de naam van het invoerveld.
 *
 * @package M7PA
 */

namespace M7PA;

defined( 'ABSPATH' ) || exit;

final class Frontend {

	/** @var bool Is het formulier op deze pagina al getoond (sommige thema's roepen de hook twee keer aan). */
	private static $done = false;

	public static function init() {
		add_action( 'woocommerce_before_add_to_cart_button', array( __CLASS__, 'render' ), 10 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
		add_action( 'wp_head', array( __CLASS__, 'design_css' ) );
		add_filter( 'body_class', array( __CLASS__, 'body_class' ) );
		add_filter( 'woocommerce_get_price_html', array( __CLASS__, 'price_label' ), 10, 2 );
		add_filter( 'woocommerce_product_price_class', array( __CLASS__, 'main_price_class' ) );
		add_filter( 'render_block_woocommerce/product-price', array( __CLASS__, 'main_price_block' ), 10, 2 );
		add_filter( 'woocommerce_product_add_to_cart_url', array( __CLASS__, 'archive_url' ), 20, 2 );
		add_filter( 'woocommerce_product_add_to_cart_text', array( __CLASS__, 'archive_text' ), 20, 2 );
		add_filter( 'woocommerce_product_supports', array( __CLASS__, 'no_ajax_add' ), 20, 3 );
		add_filter( 'woocommerce_loop_add_to_cart_args', array( __CLASS__, 'loop_args' ), 20, 2 );
	}

	/* ------------------------------ opmaak ------------------------------ */

	public static function register_assets() {
		$v_css = M7PA_VERSION . '.' . (int) @filemtime( M7PA_DIR . 'assets/m7pa.css' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		$v_js  = M7PA_VERSION . '.' . (int) @filemtime( M7PA_DIR . 'assets/m7pa.js' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		wp_register_style( 'm7pa', M7PA_URL . 'assets/m7pa.css', array( 'dashicons' ), $v_css );
		wp_register_script( 'm7pa', M7PA_URL . 'assets/m7pa.js', array( 'jquery' ), $v_js, array( 'in_footer' => true ) );
		// Net als het origineel overal op de site (o.a. winkelwagen, afrekenen en de focusrand van invoervelden).
		if ( 'theme' !== Settings::get( 'style' ) || is_product() || is_cart() || is_checkout() ) {
			wp_enqueue_style( 'm7pa' );
		}
	}

	private static function preset() {
		return 'theme' === Settings::get( 'style' ) ? 'inherit' : 'simple';
	}

	public static function body_class( $classes ) {
		if ( is_admin() ) {
			return $classes;
		}
		$classes[] = 'm7pa-quantity-layout-' . ( 'grid' === Settings::design( 'quantity_layout' ) ? 'grid' : 'block' );
		if ( Settings::get( 'show_inputs' ) ) {
			$classes[] = 'm7pa-show-inputs';
		}
		if ( 'inherit' !== self::preset() ) {
			$classes[] = 'm7pa-preset-style';
			$classes[] = 'm7pa-style-' . self::preset();
		}
		if ( is_product() ) {
			$product = wc_get_product( get_queried_object_id() );
			if ( $product && Groups::for_product( $product ) ) {
				$classes[] = 'm7pa-has-extra-fields';
				if ( $product->is_type( 'variable' ) ) {
					$classes[] = 'm7pa-variable-product';
				}
				if ( self::has_flat_rate( Groups::for_product( $product ) ) ) {
					$classes[] = 'has-flat-rate';
				}
				if ( $product->get_meta( '_m7pa_hide_quantity', true ) ) {
					$classes[] = 'm7pa-hide-quantity';
				}
			}
		}
		return $classes;
	}

	/**
	 * Opmaak uit de (overgenomen) Customizer-instellingen; zelfde waarden als het origineel.
	 */
	public static function design_css() {
		$d     = Settings::all()['design'];
		$px    = static function ( $v ) {
			return '' !== (string) $v && is_numeric( $v ) ? (float) $v . 'px' : '';
		};
		$rules = array();
		$add   = static function ( $sel, array $decls ) use ( &$rules ) {
			$decls = array_filter( $decls, static function ( $v ) {
				return '' !== (string) $v;
			} );
			if ( $decls ) {
				$body = '';
				foreach ( $decls as $k => $v ) {
					$body .= $k . ':' . $v . ';';
				}
				$rules[] = $sel . '{' . $body . '}';
			}
		};
		$add( '.m7pa-group-content-wrapper', array( 'background-color' => $d['list_background'] ? $d['list_background'] . ' !important' : '' ) );
		$add(
			'ul.m7pa-product-extra-groups',
			array(
				'margin-left'      => $px( $d['list_margin_left'] ),
				'margin-bottom'    => $px( $d['list_margin_bottom'] ),
				'padding'          => $px( $d['list_padding'] ),
				'background-color' => $d['list_background'],
			)
		);
		$add(
			'.m7pa-product-extra-groups > li',
			array(
				'margin-left'      => $px( $d['field_margin_left'] ),
				'margin-bottom'    => $px( $d['field_margin_bottom'] ),
				'padding-top'      => $px( $d['field_padding_top'] ),
				'padding-bottom'   => $px( $d['field_padding_top'] ),
				'padding-left'     => $px( $d['field_padding_left'] ),
				'padding-right'    => $px( $d['field_padding_left'] ),
				'background-color' => $d['field_background'],
				'color'            => $d['text_colour'],
			)
		);
		if ( $d['hide_group_title'] ) {
			$add( '.m7pa-group-heading-wrapper', array( 'display' => 'none' ) );
		}
		if ( $d['justify_tabs'] ) {
			$add( '.m7pa-tabs-wrapper', array( 'justify-content' => 'space-between' ) );
			$add( '.m7pa-tabs-wrapper .m7pa-tab', array( 'flex' => '1', 'text-align' => 'center' ) );
		}
		$add( '.m7pa-group-heading-wrapper .m7pa-group-heading', array( 'color' => $d['group_title_color'], 'font-size' => $px( $d['group_title_size'] ) ) );
		$bg = '' !== $d['group_title_background'] ? $d['group_title_background'] : '';
		$add( '.m7pa-preset-style .m7pa-groups-accordion .m7pa-group-wrap h3', array( 'background-color' => $bg ? $bg : 'transparent' ) );
		$add( '.m7pa-groups-accordion .m7pa-group-heading-wrapper, .m7pa-preset-style .m7pa-groups-accordion .m7pa-group-wrap .m7pa-group-heading', array( 'background-color' => $bg ? $bg : '#eee' ) );
		$add( '.m7pa-group-description', array( 'color' => $d['group_description_color'], 'font-size' => $px( $d['group_description_size'] ) ) );
		$add( '.m7pa-step-buttons .m7pa-next-step-button[data-direction="next"]', array( 'background-color' => $d['next_button'], 'color' => $d['step_button_text'] ) );
		$add( '.m7pa-step-buttons .m7pa-next-step-button[data-direction="previous"]', array( 'background-color' => $d['previous_button'], 'color' => $d['step_button_text'] ) );
		$add( '.m7pa-steps-wrapper .m7pa-tab', array( 'background' => $d['step_tab'] ) );
		$add( '.m7pa-steps-wrapper .m7pa-tab:after', array( 'border-left-color' => $d['step_tab'] ) );
		$add( '.m7pa-steps-wrapper .m7pa-tab.active-tab', array( 'background' => $d['active_step_tab'] ) );
		$add( '.m7pa-steps-wrapper .m7pa-tab.active-tab:after', array( 'border-left-color' => $d['active_step_tab'] ) );
		$add( '.m7pa-preset-style .m7pa-tabs-wrapper .m7pa-tab', array( 'background' => $d['tab'], 'border-color' => $d['tab'], 'border-bottom-color' => $d['active_tab'] ) );
		$add( '.m7pa-preset-style .m7pa-tabs-wrapper .m7pa-tab.active-tab', array( 'background' => $d['active_tab'], 'border-bottom-color' => $d['active_tab'] ) );
		$add( '.m7pa-groups-accordion .m7pa-group-wrap h3::before', array( 'border-color' => $d['accordion_icon'], 'height' => $d['accordion_icon_size'] ? (float) $d['accordion_icon_size'] . 'em' : '', 'width' => $d['accordion_icon_size'] ? (float) $d['accordion_icon_size'] . 'em' : '' ) );
		if ( $d['text_width'] ) {
			$add( 'input[type="text"].m7pa-form-field, textarea.m7pa-form-field', array( 'width' => '100% !important' ) );
		}
		if ( $d['number_width'] ) {
			$add( '.m7pa-item-name_price input[type="number"].m7pa-form-field, .m7pa-item-number input[type="number"].m7pa-form-field', array( 'width' => '100% !important' ) );
		}
		if ( $d['select_width'] ) {
			$add( 'select.m7pa-form-field', array( 'width' => '100% !important' ) );
		}
		$add( 'textarea.m7pa-form-field', array( 'height' => is_numeric( $d['textarea_height'] ) ? (float) $d['textarea_height'] . 'em' : '' ) );
		if ( $d['block_label'] ) {
			$add( 'ul.m7pa-product-extra-groups .m7pa-item:not(.m7pa-item-checkbox):not(.m7pa-item-products-radio-list) label', array( 'display' => 'block !important' ) );
		}
		if ( (int) $d['swatch_border_width'] ) {
			$add( '.m7pa-preset-style.m7pa-show-inputs .m7pa-radio-image-wrapper, .m7pa-preset-style.m7pa-show-inputs .m7pa-checkbox-image-wrapper, .m7pa-hex', array( 'border-width' => (int) $d['swatch_border_width'] . 'px' ) );
		}
		if ( (int) $d['swatch_width'] ) {
			$add( '.m7pa-item-image_swatch .m7pa-radio-image-wrapper label, .m7pa-item-image_swatch .m7pa-checkbox-image-wrapper label', array( 'width' => (int) $d['swatch_width'] . 'px' ) );
			$add( '.m7pa-hex', array( 'width' => (int) $d['swatch_width'] . 'px' ) );
			$add( '.m7pa-circular-swatches .m7pa-hex', array( 'height' => (int) $d['swatch_width'] . 'px' ) );
		}
		if ( (int) $d['color_swatch_width'] ) {
			$add( '.m7pa-has-hex .m7pa-radio-images-wrapper[class*=" m7pa-columns-"] .m7pa-radio-image-wrapper, .m7pa-hex', array( 'width' => (int) $d['color_swatch_width'] . 'px' ) );
			if ( Settings::get( 'circular_swatches' ) ) {
				$add( '.m7pa-hex', array( 'height' => (int) $d['color_swatch_width'] . 'px' ) );
			}
		}
		if ( (int) $d['color_swatch_height'] && ! Settings::get( 'circular_swatches' ) ) {
			$add( '.m7pa-hex', array( 'height' => (int) $d['color_swatch_height'] . 'px' ) );
		}
		if ( $d['products_border'] ) {
			$add( '.m7pa-preset-style .m7pa-radio-image-wrapper.checked, .m7pa-preset-style .m7pa-checkbox-image-wrapper.checked, .m7pa-preset-style .checked .m7pa-hex', array( 'border-color' => $d['products_border'] ) );
			$rules[] = '@media (pointer: fine){.m7pa-preset-style .m7pa-radio-image-wrapper:hover,.m7pa-preset-style .m7pa-checkbox-image-wrapper:hover,.m7pa-preset-style .m7pa-radio-image-wrapper:hover .m7pa-hex{border-color:' . $d['products_border'] . ';}}';
		}
		$add( '.m7pa-preset-style .m7pa-radio-image-wrapper, .m7pa-preset-style .m7pa-checkbox-image-wrapper', array( 'padding' => $px( $d['swatch_padding'] ) ) );
		$add( '.m7pa-preset-style .products-quantities-independent:not(.m7pa-column-wrapper) .m7pa-checkbox-desc-wrapper, .m7pa-preset-style .products-quantities-independent:not(.m7pa-column-wrapper) .m7pa-radio-desc-wrapper', array( 'display' => 'grid' === $d['quantity_layout'] ? 'grid' : 'block' ) );
		$accent = Settings::get( 'accent' );
		if ( $accent && '#2196f3' !== strtolower( $accent ) ) {
			// Andere accentkleur dan de standaard (in m7pa.css staat #2196F3).
			$add( '.m7pa-preset-style .m7pa-checkbox-form-label input:checked ~ span.m7pa-theme-element, .m7pa-preset-style .m7pa-radio-form-label input:checked ~ span.m7pa-theme-element, .m7pa-preset-style .m7pa-item-field-wrapper input:checked ~ span.m7pa-theme-element, .m7pa-preset-style .m7pa-item-checkbox input:checked ~ span.m7pa-theme-element, .m7pa-preset-style .m7pa-checkbox-wrapper input:checked ~ span.m7pa-theme-element, .m7pa-preset-style .m7pa-radio-wrapper input:checked ~ span.m7pa-theme-element', array( 'background' => $accent ) );
			$add( '.m7pa-preset-style .m7pa-text-swatch .m7pa-checkbox-form-label:hover, .m7pa-preset-style .m7pa-text-swatch .m7pa-radio-form-label:hover', array( 'border-color' => $accent ) );
			$add( '.m7pa-preset-style .m7pa-text-swatch .m7pa-checkbox-form-label.active-swatch, .m7pa-preset-style .m7pa-text-swatch .m7pa-radio-form-label.active-swatch', array( 'border-color' => $accent, 'background' => $accent ) );
			$add( '.m7pa-range-slider', array( 'color' => $accent ) );
		}
		echo "<style id=\"m7pa-design-css\">\n" . implode( "\n", $rules ) . "\n</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Opgeschoonde instellingen.
	}

	/* --------------------------- winkeloverzicht --------------------------- */

	private static function has_groups( $product ) {
		return $product instanceof \WC_Product && (bool) Groups::for_product( $product );
	}

	public static function archive_url( $url, $product ) {
		return self::has_groups( $product ) ? $product->get_permalink() : $url;
	}

	public static function archive_text( $text, $product ) {
		if ( self::has_groups( $product ) ) {
			$custom = Settings::get( 'archive_button_text' );
			return $custom ? $custom : __( 'Opties selecteren', 'm7-product-addons' );
		}
		return $text;
	}

	public static function no_ajax_add( $supports, $feature, $product ) {
		if ( 'ajax_add_to_cart' === $feature && ! is_product() && self::has_groups( $product ) ) {
			return false;
		}
		return $supports;
	}

	public static function loop_args( $args, $product ) {
		if ( ! is_product() && self::has_groups( $product ) && isset( $args['class'] ) ) {
			$args['class'] = str_replace( 'ajax_add_to_cart', '', $args['class'] );
		}
		return $args;
	}

	/* ------------------------------ hoofdprijs ------------------------------ */

	public static function price_label( $price, $product ) {
		if ( ! self::has_groups( $product ) ) {
			return $price;
		}
		$label   = (string) $product->get_meta( '_m7pa_price_label', true );
		$display = (string) $product->get_meta( '_m7pa_price_display', true );
		if ( 'hide' !== $display && '' === $label ) {
			$label   = (string) Settings::get( 'price_label' );
			$display = (string) Settings::get( 'price_display' );
		}
		if ( 'hide' === $display ) {
			return '<span class="m7pa-label-hidden">' . esc_html( $label ) . '</span>';
		}
		if ( '' === $label ) {
			return $price;
		}
		return 'after' === $display ? $price . ' <span class="m7pa-label-after">' . esc_html( $label ) . '</span>' : '<span class="m7pa-label-before">' . esc_html( $label ) . '</span> ' . $price;
	}

	public static function main_price_class( $class ) {
		return $class . ' m7pa-main-price';
	}

	public static function main_price_block( $content, $block ) {
		if ( is_product() && false === strpos( $content, 'm7pa-main-price' ) ) {
			$content = str_replace( 'wc-block-components-product-price ', 'wc-block-components-product-price m7pa-main-price ', $content );
		}
		return $content;
	}

	/* ------------------------------ prijzen ------------------------------ */

	/**
	 * Prijs voor weergave (incl./excl. btw zoals de winkel toont); 0 en '' blijven gelijk.
	 */
	public static function maybe_tax( $product, $price, $cart = false ) {
		if ( '' === $price || 0.0 === (float) $price || ! $product instanceof \WC_Product || (float) $price < 0 ) {
			return $price;
		}
		$mode = get_option( $cart ? 'woocommerce_tax_display_cart' : 'woocommerce_tax_display_shop' );
		return 'incl' === $mode ? wc_get_price_including_tax( $product, array( 'price' => $price, 'qty' => 1 ) ) : wc_get_price_excluding_tax( $product, array( 'price' => $price, 'qty' => 1 ) );
	}

	/** Prijs van het veld zelf (percentage al omgerekend), voor de pagina. */
	public static function field_price( array $f, $product, $cart = false ) {
		if ( 'products' === $f['type'] ) {
			return 0;
		}
		$price = (float) $f['price'];
		if ( 'percentage' === $f['price_type'] && $price ) {
			$price = $price / 100 * (float) $product->get_price();
		}
		return self::maybe_tax( $product, $price, $cart );
	}

	public static function option_price( array $o, array $f, $product, $cart = false ) {
		$price = (float) $o['price'];
		if ( 'percentage' === $f['price_type'] && $price ) {
			$price = $price / 100 * (float) $product->get_price();
		}
		return self::maybe_tax( $product, $price, $cart );
	}

	/** Bedrag zoals in veldlabels: valutateken in een span, getal volgens de winkelinstellingen. */
	public static function format_price( $price ) {
		$negative = $price < 0;
		$num      = number_format( abs( (float) $price ), wc_get_price_decimals(), wc_get_price_decimal_separator(), wc_get_price_thousand_separator() );
		if ( apply_filters( 'woocommerce_price_trim_zeros', false ) && wc_get_price_decimals() > 0 ) {
			$num = wc_trim_zeros( $num );
		}
		return ( $negative ? '-' : '' ) . sprintf( get_woocommerce_price_format(), '<span class="woocommerce-Price-currencySymbol">' . get_woocommerce_currency_symbol() . '</span>', $num );
	}

	/** Bedrag als platte tekst (opties). */
	public static function plain_price( $price ) {
		$negative = (float) $price < 0;
		$num      = number_format( abs( (float) $price ), wc_get_price_decimals(), wc_get_price_decimal_separator(), wc_get_price_thousand_separator() );
		if ( apply_filters( 'woocommerce_price_trim_zeros', false ) && wc_get_price_decimals() > 0 ) {
			$num = wc_trim_zeros( $num );
		}
		return ( $negative ? '-' : '' ) . sprintf( get_woocommerce_price_format(), get_woocommerce_currency_symbol(), $num );
	}

	public static function separator() {
		return '<span class="m7pa-separator"> ' . esc_html( Settings::get( 'price_separator' ) ) . ' </span>';
	}

	private static function show_option_prices( array $f ) {
		return Settings::get( 'show_option_prices' ) && ( '' === $f['option_price_visibility'] || 'visible' === $f['option_price_visibility'] );
	}

	/* ------------------------------ helpers ------------------------------ */

	public static function dom_id( $group_id, array $f ) {
		return 'm7pa_group_' . (int) $group_id . '_' . $f['id'];
	}

	/** Typenaam in klassen (gelijk aan het origineel). */
	public static function css_type( array $f ) {
		return 'color' === $f['type'] ? 'color-picker' : $f['type'];
	}

	private static function option_key( $value ) {
		$key = str_replace( '-', '_', sanitize_title( str_replace( array( '"', "'", '/', '&' ), '_', (string) $value ) ) );
		return preg_replace( '/[^a-z0-9_-]/', '', strtolower( str_replace( ' ', '_', $key ) ) );
	}

	private static function id_part( $value ) {
		return preg_replace( '/[^a-z0-9_-]/', '', strtolower( str_replace( ' ', '_', (string) $value ) ) );
	}

	public static function has_flat_rate( array $groups ) {
		foreach ( $groups as $g ) {
			foreach ( $g['fields'] as $f ) {
				if ( 'flat' === $f['price_type'] ) {
					return true;
				}
			}
		}
		return false;
	}

	private static function display_mode( array $groups ) {
		return $groups ? $groups[0]['display'] : 'standard';
	}

	/* ----------------------------- productpagina ----------------------------- */

	public static function render() {
		global $product;
		if ( self::$done || ! $product instanceof \WC_Product ) {
			return;
		}
		$groups = Groups::for_product( $product );
		if ( ! $groups ) {
			return;
		}
		self::$done = true;
		wp_enqueue_style( 'm7pa' );
		self::enqueue_scripts( $groups, $product );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Alleen terugzetten van eerder ingevulde waarden na een validatiefout.
		$posted  = ! empty( $_POST ) ? wp_unslash( $_POST ) : array();
		$display = self::display_mode( $groups );
		$config  = self::config( $groups, $product );

		echo '<div class="m7pa-product-extra-groups-wrap m7pa-groups-' . esc_attr( $display ) . '" data-m7pa-product="' . (int) $product->get_id() . '">';
		if ( in_array( $display, array( 'tabs', 'steps' ), true ) ) {
			echo "\t" . '<div class="m7pa-' . esc_attr( $display ) . '-wrapper">';
			foreach ( $groups as $gi => $g ) {
				echo '<div id="m7pa-tab-' . (int) $g['id'] . '" data-group-id="' . (int) $g['id'] . '" data-group-index="' . (int) $gi . '" class="m7pa-tab ' . ( 0 === $gi ? 'active-tab' : '' ) . '">' . esc_html( get_the_title( $g['id'] ) ) . '</div>';
			}
			echo "</div>\t\n";
		}
		echo '<input type="hidden" name="m7pa_product_hash" value="' . esc_attr( uniqid( 'm7pa_' ) ) . '">';

		$index = 0;
		foreach ( $groups as $gi => $g ) {
			self::render_group( $g, $gi, $groups, $product, $posted, $index, $display );
		}

		// Prijsgegevens voor het script (zelfde rol als de verborgen velden van het origineel).
		echo '<input type="hidden" id="m7pa-product-price" name="m7pa-product-price" value="' . esc_attr( $product->is_type( 'variable' ) ? 0 : self::maybe_tax( $product, $product->get_price() ) ) . '">';
		echo '<input type="hidden" id="m7pa_total_calc_price" name="m7pa_total_calc_price" value="' . esc_attr( $product->is_type( 'variable' ) ? 0 : self::maybe_tax( $product, $product->get_price() ) ) . '">';
		echo '<input type="hidden" id="m7pa_calc_set_price" name="m7pa_calc_set_price" data-calc-set value="">';
		wp_nonce_field( 'm7pa_upload', 'm7pa_upload_nonce', false );

		self::render_totals( $groups, $product );
		if ( $product->get_meta( '_m7pa_hide_quantity', true ) ) {
			echo '<style>form.cart input.qty{ display:none; }</style>';
		}
		echo '<script type="application/json" class="m7pa-config">' . wp_json_encode( $config, JSON_HEX_TAG | JSON_HEX_AMP ) . '</script>';
		echo "\n</div>";
	}

	private static function enqueue_scripts( array $groups, $product ) {
		$deps = array( 'jquery' );
		foreach ( $groups as $g ) {
			foreach ( $g['fields'] as $f ) {
				if ( 'date' === $f['type'] ) {
					$deps[] = 'jquery-ui-datepicker';
				}
				if ( 'color' === $f['type'] ) {
					// Kleurkiezer van WordPress; op de site niet standaard geregistreerd.
					wp_enqueue_style( 'wp-color-picker' );
					if ( ! wp_script_is( 'iris', 'registered' ) ) {
						wp_register_script( 'iris', admin_url( 'js/iris.min.js' ), array( 'jquery-ui-draggable', 'jquery-ui-slider', 'jquery-touch-punch' ), false, 1 );
					}
					if ( ! wp_script_is( 'wp-color-picker', 'registered' ) ) {
						wp_register_script( 'wp-color-picker', admin_url( 'js/color-picker.js' ), array( 'iris' ), false, 1 );
					}
					wp_set_script_translations( 'wp-color-picker' );
					$deps[] = 'wp-color-picker';
				}
			}
		}
		foreach ( array_unique( $deps ) as $dep ) {
			wp_enqueue_script( $dep );
		}
		wp_enqueue_script( 'm7pa' );
	}

	/**
	 * Gegevens voor het script: veldsoorten, voorwaarden, formules, geldnotatie.
	 */
	private static function config( array $groups, $product ) {
		$fields = array();
		foreach ( $groups as $g ) {
			foreach ( $g['fields'] as $f ) {
				$fields[] = array(
					'id'         => $f['id'],
					'dom'        => self::dom_id( $g['id'], $f ),
					'group'      => (int) $g['id'],
					'type'       => $f['type'],
					'multiple'   => (bool) $f['multiple'],
					'layout'     => 'products' === $f['type'] ? $f['products']['layout'] : '',
					'conditions' => $f['conditions'],
					'formula'    => 'calculation' === $f['type'] ? $f['formula'] : '',
					'action'     => 'calculation' === $f['type'] ? $f['formula_action'] : '',
					'decimals'   => (int) $f['decimals'],
					'round'      => $f['formula_round'],
					'suffix'     => $f['suffix'],
					'variations' => $f['variations'],
					'date'       => $f['date'],
				);
			}
		}
		$group_conditions = array();
		foreach ( $groups as $g ) {
			if ( ! empty( $g['conditions']['rules'] ) ) {
				$group_conditions[ (int) $g['id'] ] = $g['conditions'];
			}
		}
		$pos = get_option( 'woocommerce_currency_pos' );
		return array(
			'productId'       => $product->get_id(),
			'fields'          => $fields,
			'groupConditions' => (object) $group_conditions,
			'attributes'      => self::attribute_values( $product ),
			'resetFields'     => (bool) Settings::get( 'reset_fields' ),
			'updatePrice'     => (bool) Settings::get( 'update_price_label' ),
			'multiplyIndependent' => (bool) Settings::get( 'multiply_independent' ),
			'separator'       => Settings::get( 'separator_unsaved' ) ? '  ' : ' ' . Settings::get( 'price_separator' ) . ' ',
			'currency'        => array(
				'symbol'   => html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' ),
				'decimals' => wc_get_price_decimals(),
				'decimal'  => wc_get_price_decimal_separator(),
				'thousand' => wc_get_price_thousand_separator(),
				'pos'      => $pos ? $pos : 'left',
				'trim'     => (bool) apply_filters( 'woocommerce_price_trim_zeros', false ),
			),
			'uploadUrl'       => admin_url( 'admin-ajax.php' ),
			'i18n'            => array(
				'uploading' => __( 'Uploaden…', 'm7-product-addons' ),
				'remove'    => __( 'Verwijderen', 'm7-product-addons' ),
			),
		);
	}

	/** Attribuutwaarden van een eenvoudig product (voor voorwaarden op attributen). */
	private static function attribute_values( $product ) {
		$out = array();
		if ( $product->is_type( 'variable' ) ) {
			return (object) $out;
		}
		foreach ( $product->get_attributes() as $name => $attr ) {
			if ( is_object( $attr ) && method_exists( $attr, 'get_slugs' ) ) {
				$out[ $name ] = implode( ',', $attr->get_slugs() );
			}
		}
		return (object) $out;
	}

	private static function render_group( array $g, $gi, array $groups, $product, array $posted, &$index, $display ) {
		$gid     = (int) $g['id'];
		$classes = array( 'm7pa-group-wrap', 'm7pa-group-wrap-' . $gid, 'm7pa-group-index-' . $gi, 0 === $gi ? 'first-group' : '' );
		if ( '' !== $g['class'] ) {
			$classes[] = $g['class'];
		}
		if ( $g['always_include'] ) {
			$classes[] = 'm7pa-group-always-include';
		}
		$c = $g['conditions'];
		echo '<div id="m7pa-group-' . $gid . '" class="' . esc_attr( implode( ' ', $classes ) ) . '" data-group-id="' . $gid . '" data-group-index="' . (int) $gi . '" data-condition-action="' . esc_attr( $c['rules'] ? $c['action'] : '' ) . '" data-condition-match="' . esc_attr( $c['rules'] ? $c['match'] : '' ) . '">';
		echo '<div class="m7pa-group-heading-wrapper">';
		$title = get_the_title( $gid );
		if ( '' !== $title ) {
			$tag = tag_escape( Settings::get( 'group_title_tag' ) );
			echo '<' . $tag . ' class="m7pa-group-heading">' . esc_html( $title ) . '</' . $tag . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</div>';
		echo '<div class="m7pa-group-content-wrapper ">';
		if ( '' !== $g['description'] ) {
			echo '<p class="m7pa-group-description">' . wp_kses_post( $g['description'] ) . '</p>';
		}
		$layout = $g['layout'];
		$extra  = '';
		if ( false !== strpos( $layout, 'cols' ) ) {
			$extra  = ' ' . $layout;
			$layout = 'ul';
		}
		echo '<' . $layout . ' class="m7pa-product-extra-groups ' . esc_attr( trim( $extra ) ) . '">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( 'table' === $layout ) {
			echo '<tbody>';
		}
		foreach ( $g['fields'] as $f ) {
			self::render_field( $g, $f, $groups, $product, $posted, $index, $layout );
			$index++;
		}
		if ( 'table' === $layout ) {
			echo '</tbody>';
		}
		echo '</' . $layout . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( 'steps' === $display ) {
			echo '<div class="m7pa-step-buttons">';
			if ( isset( $groups[ $gi - 1 ] ) ) {
				echo '<a href="#" class="button m7pa-next-step-button" id="m7pa-step-' . (int) $groups[ $gi - 1 ]['id'] . '" data-group-id="' . (int) $groups[ $gi - 1 ]['id'] . '" data-direction="previous">' . esc_html__( 'Vorige', 'm7-product-addons' ) . '</a>';
			}
			if ( isset( $groups[ $gi + 1 ] ) ) {
				echo '<a href="#" class="button m7pa-next-step-button" id="m7pa-step-' . (int) $groups[ $gi + 1 ]['id'] . '" data-group-id="' . (int) $groups[ $gi + 1 ]['id'] . '" data-direction="next">' . esc_html__( 'Volgende', 'm7-product-addons' ) . '</a>';
			}
			echo '</div>';
		}
		echo '</div>';
		echo '</div>';
	}

	/**
	 * Huidige waarde: ingezonden (na een fout), anders de standaardwaarde.
	 *
	 * @return string|array
	 */
	private static function current_value( array $f, $dom, array $posted ) {
		if ( isset( $posted[ $dom ] ) ) {
			return $posted[ $dom ];
		}
		if ( 'products' === $f['type'] && isset( $posted[ $dom . '_child_product' ] ) ) {
			return $posted[ $dom . '_child_product' ];
		}
		$default = (string) $f['default'];
		if ( in_array( $f['type'], array( 'checkbox_group', 'products' ), true ) || ( 'image_swatch' === $f['type'] && $f['multiple'] ) ) {
			return '' === $default ? array() : array_map( 'trim', explode( ',', $default ) );
		}
		if ( 'checkbox' === $f['type'] ) {
			return in_array( $default, array( '1', 'checked', '__checked__', 'yes', 'on' ), true ) ? 1 : '';
		}
		if ( 'color' === $f['type'] && '' === $default ) {
			return $f['color'];
		}
		return $default;
	}

	private static function render_field( array $g, array $f, array $groups, $product, array $posted, $index, $layout ) {
		$gid   = (int) $g['id'];
		$dom   = self::dom_id( $gid, $f );
		$type  = self::css_type( $f );
		$value = self::current_value( $f, $dom, $posted );
		$price = self::field_price( $f, $product );

		$classes = array( $dom, 'm7pa-group-' . $type, 'm7pa-item-' . $type, 'm7pa-field-' . $f['id'], 'm7pa-field-count-' . $index );
		if ( in_array( $f['type'], array( 'radio', 'checkbox', 'checkbox_group' ), true ) ) {
			$classes[] = $f['as_swatch'] ? 'm7pa-text-swatch' : 'm7pa-option-list';
		}
		if ( 'select' === $f['type'] && '' !== $f['placeholder'] ) {
			$classes[] = 'm7pa-first-field-empty';
		}
		if ( $f['required'] ) {
			$classes[] = 'required-field';
		}
		if ( ! empty( $f['conditions']['rules'] ) && 'show' === $f['conditions']['action'] && ! self::uses_login( $f['conditions'] ) ) {
			$classes[] = 'm7pa-hidden-field';
		}
		if ( (float) $f['price'] && 'products' !== $f['type'] ) {
			$classes[] = 'm7pa-has-field-price';
		}
		if ( 'per_char' === $f['price_type'] ) {
			$classes[] = 'm7pa-per-character-pricing';
		}
		if ( '' !== $f['max_chars'] && in_array( $f['type'], array( 'text', 'textarea' ), true ) ) {
			$classes[] = 'm7pa-has-maxchars';
		}
		if ( 'multiply' === $f['price_type'] && in_array( $f['type'], array( 'number', 'name_price' ), true ) ) {
			$classes[] = 'm7pa-multiply-pricing';
		}
		if ( 'flat' === $f['price_type'] && ! in_array( $f['type'], array( 'calculation', 'information' ), true ) ) {
			$classes[] = 'm7pa-flatrate';
		}
		if ( $f['variations'] ) {
			$classes[] = 'm7pa-variation-dependent';
		}
		if ( 'percentage' === $f['price_type'] ) {
			$classes[] = 'm7pa-percentage';
		}
		if ( '' !== $f['option_price_visibility'] && 'visible' !== $f['option_price_visibility'] ) {
			$classes[] = 'm7pa-hide-option-price';
		}
		if ( 'calculation' === $f['type'] && $f['hidden'] ) {
			$classes[] = 'm7pa-hidden-calculation';
		}
		if ( Settings::get( 'circular_swatches' ) ) {
			$classes[] = 'm7pa-circular-swatches';
		}
		if ( 'image_swatch' === $f['type'] && ! empty( $f['options'][0]['hex'] ) ) {
			$classes[] = 'm7pa-has-hex';
		}
		$field_image = $f['image'] ? wp_get_attachment_image( $f['image'], 'thumbnail' ) : '';
		if ( $field_image ) {
			$classes[] = 'm7pa-has-field-image';
		}
		if ( 'products' === $f['type'] ) {
			$classes[] = 'm7pa-item-products-' . $f['products']['layout'];
			if ( 'independent' === $f['products']['quantities'] ) {
				$classes[] = 'm7pa-item-products-independent';
			}
		}
		if ( self::is_group_condition_source( $f, $groups ) ) {
			$classes[] = 'm7pa-condition-trigger';
		}
		if ( self::is_formula_source( $f, $groups ) ) {
			$classes[] = 'm7pa-calculation-trigger';
		}
		if ( in_array( $f['visibility'], array( 'hide_product', 'hide_customer' ), true ) ) {
			$classes[] = 'm7pa-visibility-hidden';
		}
		$classes[] = $f['class'];
		if ( 'image_swatch' === $f['type'] ) {
			$classes[] = $f['multiple'] ? 'm7pa-item-image-swatch-checkbox' : 'm7pa-item-radio';
			if ( $f['replace_image'] || Settings::get( 'replace_image' ) ) {
				$classes[] = 'm7pa-replace-main-image';
			}
		}
		if ( ! empty( $f['conditions']['rules'] ) ) {
			$classes[] = 'm7pa-field-has-condition';
		}
		if ( self::is_field_condition_source( $f, $groups ) ) {
			$classes[] = 'm7pa-field-triggers-condition';
		}

		$attrs = array(
			'data-price'                 => 'percentage' === $f['price_type'] ? self::num( $price ) : self::num( $price ),
			'data-id'                    => $dom,
			'data-selected-option-price' => '',
			'data-field-id'              => $f['id'],
			'data-field-type'            => $type,
			'data-field-price'           => self::num( $price ),
			'data-field-label'           => $f['label'],
			'data-field-value'           => is_array( $value ) ? implode( ', ', $value ) : (string) $value,
			'data-field-layered'         => 'no',
			'data-field-index'           => $index,
			'data-field-class'           => $f['class'],
		);
		if ( '' !== $f['option_price_visibility'] && 'visible' !== $f['option_price_visibility'] ) {
			$attrs['data-option-price-visibility'] = $f['option_price_visibility'];
		}
		$attrs['data-default-value'] = Settings::get( 'reset_fields' ) ? ( is_array( $value ) ? implode( ', ', $value ) : (string) $value ) : '';
		if ( 'percentage' === $f['price_type'] && (float) $f['price'] ) {
			$attrs['data-percentage'] = self::num( (float) $f['price'] );
		}
		if ( $f['variations'] ) {
			$attrs['data-variations'] = implode( ',', $f['variations'] );
		}
		$attr_string = '';
		foreach ( $attrs as $k => $v ) {
			$attr_string .= ' ' . $k . "='" . esc_attr( $v ) . "'";
		}

		$tag  = 'table' === $layout ? 'tr' : 'li';
		$cell = 'table' === $layout ? 'td' : 'div';
		echo "\n\t<" . $tag . ' class="m7pa-item m7pa-group ' . esc_attr( implode( ' ', $classes ) ) . '" ' . $attr_string . " >\n\n\t\t"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( $field_image ) {
			$full = wp_get_attachment_image_src( $f['image'], 'full' );
			echo '<' . $cell . ' data-image-full-size="' . esc_attr( $full ? $full[0] : '' ) . '" class="m7pa-item-field-image-wrapper">' . $field_image . '</' . $cell . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} elseif ( 'table' === $layout ) {
			echo '<td></td>';
		}
		if ( 'ul' === $layout ) {
			echo '<div class="m7pa-item-field-wrapper">';
		}

		$open_td  = 'table' === $layout ? '<td>' : '';
		$close_td = 'table' === $layout ? '</td>' : '';
		if ( 'table' === $layout || 'checkbox' !== $f['type'] ) {
			echo self::label( $f, $dom, $layout, $product ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		$ctx = compact( 'g', 'f', 'dom', 'value', 'price', 'product', 'layout', 'open_td', 'close_td', 'cell' );
		switch ( $f['type'] ) {
			case 'text':
			case 'textarea':
				self::tpl_text( $ctx );
				break;
			case 'number':
				self::tpl_number( $ctx );
				break;
			case 'name_price':
				self::tpl_name_price( $ctx );
				break;
			case 'select':
				self::tpl_select( $ctx );
				break;
			case 'radio':
				self::tpl_radio( $ctx );
				break;
			case 'checkbox':
				self::tpl_checkbox( $ctx );
				break;
			case 'checkbox_group':
				self::tpl_checkbox_group( $ctx );
				break;
			case 'image_swatch':
				self::tpl_swatch( $ctx );
				break;
			case 'color':
				echo $open_td . '<input type="text" class="m7pa-form-field m7pa-color-picker-field" id="' . esc_attr( $dom ) . '" name="' . esc_attr( $dom ) . '" data-color="' . esc_attr( $f['color'] ) . '" data-box-width="" data-show="" data-palettes="" value="' . esc_attr( is_array( $value ) ? '' : $value ) . '">' . $close_td; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				break;
			case 'date':
				echo $open_td . '<input type="text" autocomplete="off" readonly class="m7pa-form-field m7pa-date-field m7pa-date-field-' . esc_attr( $f['id'] ) . '" id="' . esc_attr( $dom ) . '" name="' . esc_attr( $dom ) . '" value="' . esc_attr( is_array( $value ) ? '' : $value ) . '" aria-label="' . esc_attr( wp_strip_all_tags( $f['label'] ) ) . '" >' . $close_td . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				break;
			case 'upload':
				self::tpl_upload( $ctx );
				break;
			case 'information':
				self::tpl_information( $ctx );
				break;
			case 'calculation':
				self::tpl_calculation( $ctx );
				break;
			case 'products':
				echo $open_td; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				Frontend_Products::render( $ctx );
				echo $close_td; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				break;
		}
		if ( 'ul' === $layout && 'checkbox' === $f['type'] ) {
			echo self::label( $f, $dom, $layout, $product ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		if ( in_array( $f['type'], array( 'text', 'textarea' ), true ) && $f['show_counter'] ) {
			echo '<p class="m7pa-text-counter-container ' . esc_attr( $dom ) . '"><small class="m7pa-text-counter"><span class="m7pa-current-count">0</span>' . ( '' !== $f['max_chars'] ? ' / <span class="m7pa-max-count">' . (int) $f['max_chars'] . '</span>' : '' ) . '</small></p>';
		}
		if ( 'ul' === $layout ) {
			echo self::description( $f ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '</div>';
		}
		echo "\n\t</" . $tag . "><!-- .m7pa-item -->\n\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	private static function num( $v ) {
		if ( '' === $v ) {
			return '';
		}
		return (string) ( 0 + $v );
	}

	private static function uses_login( array $c ) {
		foreach ( $c['rules'] as $r ) {
			if ( 'logged_in' === $r['field'] ) {
				return true;
			}
		}
		return false;
	}

	private static function is_group_condition_source( array $f, array $groups ) {
		foreach ( $groups as $g ) {
			foreach ( $g['conditions']['rules'] as $r ) {
				if ( $r['field'] === $f['id'] ) {
					return true;
				}
			}
		}
		return false;
	}

	private static function is_field_condition_source( array $f, array $groups ) {
		foreach ( $groups as $g ) {
			foreach ( $g['fields'] as $other ) {
				foreach ( $other['conditions']['rules'] as $r ) {
					if ( $r['field'] === $f['id'] ) {
						return true;
					}
				}
			}
		}
		return false;
	}

	private static function is_formula_source( array $f, array $groups ) {
		foreach ( $groups as $g ) {
			foreach ( $g['fields'] as $other ) {
				if ( 'calculation' === $other['type'] && false !== strpos( $other['formula'], '{field:' . $f['id'] . '}' ) ) {
					return true;
				}
			}
		}
		return false;
	}

	/* ------------------------------ label en beschrijving ------------------------------ */

	public static function label( array $f, $dom, $layout, $product ) {
		if ( 'checkbox' === $f['type'] ) {
			return '';
		}
		$open  = 'table' === $layout ? '<td>' : '';
		$close = 'table' === $layout ? '</td>' : '';
		$tag   = 'inherit' === self::preset() ? 'label' : 'h4';
		$out   = $open . '<' . $tag . ' class="m7pa-field-label" for="' . esc_attr( $dom ) . '">';
		$out  .= '<span class="m7pa-field-label-text">' . ( $f['hide_label'] ? '' : wp_kses_post( $f['label'] ) ) . '</span>';
		$out  .= '<span class="required"> &#42;</span>';
		if ( (float) $f['price'] && ! in_array( $f['type'], array( 'name_price', 'products' ), true ) && ( '' === $f['price_visibility'] || 'visible' === $f['price_visibility'] ) ) {
			$out .= '<span class="m7pa-field-price"> ' . self::format_price( self::field_price( $f, $product ) );
			if ( 'per_char' === $f['price_type'] && in_array( $f['type'], array( 'text', 'textarea' ), true ) ) {
				$out .= ' <span class="m7pa-per-character-label">' . esc_html__( 'per karakter', 'm7-product-addons' ) . '</span>';
			}
			$out .= '</span>';
		}
		$out .= self::tooltip_icon( $f );
		$out .= '</' . $tag . '>';
		if ( 'table' === $layout && ! Settings::get( 'tooltips' ) ) {
			$out .= self::description( $f );
		}
		return $out . $close;
	}

	/** Vraagteken met de beschrijving als titel (instelling "tooltips"). */
	private static function tooltip_icon( array $f ) {
		if ( Settings::get( 'tooltips' ) && '' !== $f['description'] ) {
			return '&nbsp;<span title="' . esc_attr( $f['description'] ) . '" class="dashicons dashicons-editor-help tooltip"></span>';
		}
		return '';
	}

	public static function description( array $f ) {
		$info = '';
		if ( in_array( $f['type'], array( 'number', 'name_price' ), true ) ) {
			if ( '' !== $f['min'] && (float) $f['min'] ) {
				$info .= '<small>' . esc_html__( 'Min', 'm7-product-addons' ) . ': ' . ( 'name_price' === $f['type'] ? wc_price( $f['min'] ) : esc_html( self::num( $f['min'] ) ) ) . '</small>';
			}
			if ( '' !== $f['max'] && (float) $f['max'] ) {
				$info .= '<small>' . esc_html__( 'Max', 'm7-product-addons' ) . ': ' . ( 'name_price' === $f['type'] ? wc_price( $f['max'] ) : esc_html( self::num( $f['max'] ) ) ) . '</small>';
			}
		}
		if ( in_array( $f['type'], array( 'text', 'textarea' ), true ) ) {
			if ( '' !== $f['min_chars'] && (int) $f['min_chars'] ) {
				$info .= '<small>' . esc_html__( 'Min', 'm7-product-addons' ) . ': ' . (int) $f['min_chars'] . ' ' . esc_html__( 'tekens', 'm7-product-addons' ) . '</small>';
			}
			if ( '' !== $f['max_chars'] && (int) $f['max_chars'] ) {
				$info .= '<small>' . esc_html__( 'Max', 'm7-product-addons' ) . ': ' . (int) $f['max_chars'] . ' ' . esc_html__( 'tekens', 'm7-product-addons' ) . '</small>';
			}
		}
		if ( 'upload' === $f['type'] ) {
			$info .= '<small>' . esc_html__( 'Max. bestandsgrootte', 'm7-product-addons' ) . ': ' . (int) $f['upload']['max_mb'] . ' MB</small>';
			$info .= '<small>' . esc_html__( 'Toegestane bestandstypes', 'm7-product-addons' ) . ': ' . esc_html( implode( ' ', $f['upload']['types'] ) ) . '</small>';
		}
		if ( '' === $f['description'] && '' === $info ) {
			return '';
		}
		return '<p class="m7pa-description">' . ( Settings::get( 'tooltips' ) ? '' : wp_kses_post( $f['description'] ) ) . $info . '</p>';
	}

	/* ------------------------------ veldsoorten ------------------------------ */

	private static function tpl_text( array $c ) {
		$f     = $c['f'];
		$attrs = 'data-minchars="' . esc_attr( '' !== $f['min_chars'] && (int) $f['min_chars'] ? (int) $f['min_chars'] : '' ) . '" data-maxchars="' . esc_attr( '' !== $f['max_chars'] && (int) $f['max_chars'] ? (int) $f['max_chars'] : '' ) . '" data-freechars="' . esc_attr( '' !== $f['free_chars'] && $f['free_chars'] ? $f['free_chars'] : '' ) . '" data-alphanumeric="' . ( $f['alphanumeric'] ? '1' : '' ) . '" data-alphanumeric-charge="' . ( $f['alphanumeric_charge'] ? '1' : '' ) . '" aria-label="' . esc_attr( wp_strip_all_tags( $f['label'] ) ) . '" ';
		$value = is_array( $c['value'] ) ? '' : (string) $c['value'];
		if ( 'textarea' === $f['type'] ) {
			echo $c['open_td'] . '<textarea class="m7pa-form-field" id="' . esc_attr( $c['dom'] ) . '" name="' . esc_attr( $c['dom'] ) . '" ' . $attrs . ' placeholder="' . esc_attr( $f['placeholder'] ) . '">' . esc_html( $value ) . '</textarea>' . $c['close_td']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} else {
			echo $c['open_td'] . '<input type="text" class="m7pa-form-field" id="' . esc_attr( $c['dom'] ) . '" name="' . esc_attr( $c['dom'] ) . '" ' . $attrs . ' placeholder="' . esc_attr( $f['placeholder'] ) . '" value="' . esc_attr( $value ) . '">' . $c['close_td']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	private static function tpl_number( array $c ) {
		$f    = $c['f'];
		$step = '' !== $f['step'] && (float) $f['step'] ? self::num( $f['step'] ) : '1';
		$type = $f['slider'] ? 'range' : 'number';
		echo $c['open_td'] . '<input type="' . $type . '" class="m7pa-form-field m7pa-number-field m7pa-number-field-' . esc_attr( $f['id'] ) . ( $f['slider'] ? ' m7pa-range-slider' : '' ) . '" id="' . esc_attr( $c['dom'] ) . '" name="' . esc_attr( $c['dom'] ) . '" value="' . esc_attr( is_array( $c['value'] ) ? '' : $c['value'] ) . '" min="' . esc_attr( '' !== $f['min'] ? self::num( $f['min'] ) : '' ) . '" max="' . esc_attr( '' !== $f['max'] ? self::num( $f['max'] ) : '' ) . '" step="' . esc_attr( $step ) . '" autocomplete="off" aria-label="' . esc_attr( wp_strip_all_tags( $f['label'] ) ) . '" data-require-required="no" >' . ( $f['slider'] ? '<span class="m7pa-range-value"></span>' : '' ) . $c['close_td']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	private static function tpl_name_price( array $c ) {
		$f = $c['f'];
		echo $c['open_td'] . '<input type="number" class="m7pa-form-field" id="' . esc_attr( $c['dom'] ) . '" name="' . esc_attr( $c['dom'] ) . '" value="' . esc_attr( is_array( $c['value'] ) ? '' : $c['value'] ) . '" step="0.01" min="' . esc_attr( '' !== $f['min'] ? self::num( $f['min'] ) : '0' ) . '" max="' . esc_attr( '' !== $f['max'] ? self::num( $f['max'] ) : '' ) . '" aria-label="' . esc_attr( wp_strip_all_tags( $f['label'] ) ) . '" data-require-required="no" >' . $c['close_td']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	private static function tpl_select( array $c ) {
		$f       = $c['f'];
		$product = $c['product'];
		$wrap    = 'inherit' !== self::preset();
		$out     = $c['open_td'] . ( $wrap ? '<div class="m7pa-select-wrapper">' : '' );
		$out    .= '<select class="m7pa-form-field" id="' . esc_attr( $c['dom'] ) . '" name="' . esc_attr( $c['dom'] ) . '" aria-label="' . esc_attr( wp_strip_all_tags( $f['label'] ) ) . '" >';
		$options = $f['options'];
		if ( '' !== $f['placeholder'] ) {
			array_unshift( $options, array( 'value' => '', 'label' => $f['placeholder'], 'price' => 0, 'placeholder' => true ) );
		}
		$value = is_array( $c['value'] ) ? (string) reset( $c['value'] ) : (string) $c['value'];
		foreach ( $options as $i => $o ) {
			$name   = esc_html( $o['label'] );
			$oprice = empty( $o['placeholder'] ) ? self::option_price( $o, $f, $product ) : 0;
			if ( (float) $oprice && self::show_option_prices( $f ) ) {
				$name .= self::separator() . self::plain_price( $oprice );
			}
			$val       = empty( $o['placeholder'] ) ? (string) $o['value'] : '';
			$pct       = 'percentage' === $f['price_type'] && (float) $o['price'] && empty( $o['placeholder'] ) ? self::num( (float) $o['price'] ) : '';
			$opt_class = ! empty( $o['placeholder'] ) && 'percentage' === $f['price_type'] ? 'm7pa-first-option' : ( '' !== $pct ? 'm7pa-select-option-has-percentage' : '' );
			$out      .= '<option class="' . esc_attr( $opt_class ) . '" data-option-cost="' . esc_attr( self::num( $oprice ) ) . '" value="' . esc_attr( $val ) . '" ' . ( $val === $value ? 'selected="selected"' : '' ) . ' data-option-percentage="' . esc_attr( $pct ) . '" aria-label="' . esc_attr( wp_strip_all_tags( html_entity_decode( $name, ENT_QUOTES ) ) ) . '">' . $name . '</option>';
		}
		$out .= '</select>' . ( $wrap ? '</div>' : '' ) . $c['close_td'];
		echo $out; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	private static function tpl_radio( array $c ) {
		$f       = $c['f'];
		$product = $c['product'];
		$value   = $c['value'];
		$out     = '<ul class="m7pa-checkbox-group-wrapper">';
		foreach ( $f['options'] as $o ) {
			$label  = wp_kses_post( $o['label'] );
			$oprice = self::option_price( $o, $f, $product );
			$pct    = '';
			$cls    = array( 'm7pa-radio-form-field' );
			if ( 'percentage' === $f['price_type'] && (float) $o['price'] ) {
				$pct   = self::num( (float) $o['price'] );
				$cls[] = 'm7pa-option-has-percentage';
			}
			if ( (float) $oprice && self::show_option_prices( $f ) ) {
				$label .= self::separator() . '<span class="m7pa-option-cost-label">' . self::plain_price( $oprice ) . '</span>';
			}
			$rid     = $c['dom'] . '_' . self::option_key( $o['value'] );
			$checked = ( is_array( $value ) && in_array( (string) $o['value'], array_map( 'strval', $value ), true ) ) || ( ! is_array( $value ) && (string) $value === (string) $o['value'] );
			$lcls    = 'm7pa-radio-form-label' . ( $checked && $f['as_swatch'] ? '  active-swatch' : '' );
			$out    .= '<li><label class="' . esc_attr( $lcls ) . '" for="' . esc_attr( $rid ) . '"><input data-option-cost="' . esc_attr( self::num( $oprice ) ) . '" type="radio" name="' . esc_attr( $c['dom'] ) . '" id="' . esc_attr( $rid ) . '" class="' . esc_attr( implode( ' ', $cls ) ) . '" data-option-percentage="' . esc_attr( $pct ) . '" value="' . esc_attr( $o['value'] ) . '" ' . ( $checked ? 'checked=checked' : '' ) . ' >&nbsp;<span class="m7pa-radio-option-text">' . $label . '</span><span class="m7pa-theme-element"></span></label></li>';
		}
		$out .= '</ul>';
		echo $c['open_td'] . $out . $c['close_td']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	private static function tpl_checkbox( array $c ) {
		$f       = $c['f'];
		$checked = ! empty( $c['value'] );
		$label   = wp_kses_post( $f['label'] ) . '<span class="required"> &#42;</span>';
		if ( (float) $f['price'] && 'visible' === $f['price_visibility'] ) {
			$label .= self::separator() . '<span class="m7pa-checkbox-price">' . self::plain_price( $c['price'] ) . '</span>';
		}
		$label .= self::tooltip_icon( $f );
		$open = 'table' === $c['layout'] ? '<td colspan=2>' : '';
		echo $open . '<label class="m7pa-checkbox-form-label' . ( $checked && $f['as_swatch'] ? ' active-swatch' : '' ) . '" for="' . esc_attr( $c['dom'] ) . '"><input type="checkbox" class="m7pa-form-field" id="' . esc_attr( $c['dom'] ) . '" name="' . esc_attr( $c['dom'] ) . '" aria-label="' . esc_attr( wp_strip_all_tags( $f['label'] ) ) . '" ' . ( $checked ? "checked='checked'" : '' ) . ' value="__checked__">&nbsp;<span>' . $label . '</span><span class="m7pa-theme-element"></span></label>' . $c['close_td']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	private static function tpl_checkbox_group( array $c ) {
		$f       = $c['f'];
		$product = $c['product'];
		$value   = is_array( $c['value'] ) ? array_map( 'strval', $c['value'] ) : explode( ' | ', (string) $c['value'] );
		$out     = '<ul class="m7pa-checkbox-group-wrapper">';
		foreach ( array_values( $f['options'] ) as $i => $o ) {
			$name   = esc_html( $o['label'] );
			$cls    = array( 'm7pa-checkbox-form-field' );
			$pct    = '';
			$oprice = self::option_price( $o, $f, $product );
			if ( 'percentage' === $f['price_type'] && (float) $o['price'] ) {
				$pct   = self::num( (float) $o['price'] );
				$cls[] = 'm7pa-option-has-percentage';
			}
			if ( (float) $oprice && self::show_option_prices( $f ) ) {
				$name .= self::separator() . '<span class="m7pa-option-cost-label">' . self::plain_price( $oprice ) . '</span>';
			}
			$rid     = $c['dom'] . '_' . $i;
			$checked = in_array( (string) $o['value'], $value, true );
			$out    .= '<li><label class="m7pa-checkbox-form-label' . ( $checked && $f['as_swatch'] ? ' active-swatch' : '' ) . '" for="' . esc_attr( $rid ) . '"><input data-option-cost="' . esc_attr( self::num( $oprice ) ) . '" data-option-percentage="' . esc_attr( $pct ) . '" type="checkbox" name="' . esc_attr( $c['dom'] ) . '[]" id="' . esc_attr( $rid ) . '" class="' . esc_attr( implode( ' ', $cls ) ) . '" value="' . esc_attr( $o['value'] ) . '" ' . ( $checked ? 'checked="checked"' : '' ) . ' aria-label="' . esc_attr( wp_strip_all_tags( html_entity_decode( $name, ENT_QUOTES ) ) ) . '">&nbsp;' . $name . '<span class="m7pa-theme-element"></span></label></li>';
		}
		$out .= '</ul>';
		echo $c['open_td'] . $out . $c['close_td']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/** Afbeelding van een keuze; zonder eigen afbeelding de WooCommerce-plaatshouder (zoals het origineel). */
	public static function swatch_image( $image_id ) {
		$size = 'thumbnail';
		if ( $image_id ) {
			$img = wp_get_attachment_image( $image_id, $size, false, self::image_data( $image_id ) );
			if ( $img ) {
				return $img;
			}
		}
		return wc_placeholder_img( $size );
	}

	private static function image_data( $image_id ) {
		$full = wp_get_attachment_image_src( $image_id, 'full' );
		if ( ! $full ) {
			return array();
		}
		return array(
			'title'                   => get_post_field( 'post_title', $image_id ),
			'data-large_image'        => $full[0],
			'data-large_image_width'  => $full[1],
			'data-large_image_height' => $full[2],
			'data-alt_image'          => $full[0],
		);
	}

	private static function tpl_swatch( array $c ) {
		$f       = $c['f'];
		$product = $c['product'];
		$type    = $f['multiple'] ? 'checkbox' : 'radio';
		$value   = $c['value'];
		if ( 'checkbox' === $type && ! is_array( $value ) ) {
			$value = explode( ' | ', (string) $value );
		}
		$classes = array( 'checkbox' === $type ? 'm7pa-checkboxes-images-wrapper' : 'm7pa-radio-images-wrapper', 'm7pa-columns-' . (int) $f['columns'] );
		if ( $f['hide_option_labels'] ) {
			$classes[] = 'm7pa-hide-labels';
		}
		echo $c['open_td']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo "\n\t" . '<div class="' . esc_attr( implode( ' ', $classes ) ) . '">' . "\n  \t";
		foreach ( array_values( $f['options'] ) as $i => $o ) {
			$name   = wp_kses_post( $o['label'] );
			$oprice = self::option_price( $o, $f, $product );
			$pct    = '';
			$cls    = array( 'm7pa-' . $type . '-form-field' );
			if ( 'percentage' === $f['price_type'] && (float) $o['price'] ) {
				$pct   = self::num( (float) $o['price'] );
				$cls[] = 'm7pa-option-has-percentage';
			}
			if ( (float) $oprice && self::show_option_prices( $f ) ) {
				$name .= self::separator() . '<span class="m7pa-option-cost-label">' . self::plain_price( $oprice ) . '</span>';
			}
			$rid     = $c['dom'] . '_' . ( '' !== (string) $o['value'] ? self::id_part( $o['value'] ) : $i );
			$checked = is_array( $value ) ? in_array( (string) $o['value'], array_map( 'strval', $value ), true ) : (string) $value === (string) $o['value'];
			$wrap    = array( 'm7pa-' . $type . '-image-wrapper', 'm7pa-radio-checkbox-image-wrapper', 'm7pa-radio-image-wrapper-' . $i );
			if ( $checked ) {
				$wrap[] = 'checked';
			}
			$hex = '' !== $o['hex'] ? '<span class="m7pa-hex"><span style="background: ' . esc_attr( $o['hex'] ) . '"></span></span>' : '';
			echo '<div class="' . esc_attr( implode( ' ', $wrap ) ) . '">
					<label for="' . esc_attr( $rid ) . '" class="">
						<input data-option-cost="' . esc_attr( self::num( $oprice ) ) . '" type="' . $type . '" name="' . esc_attr( $c['dom'] ) . '[]" id="' . esc_attr( $rid ) . '" class="' . esc_attr( implode( ' ', $cls ) ) . '" data-option-percentage="' . esc_attr( $pct ) . '" value="' . esc_attr( $o['value'] ) . '" ' . ( $checked ? 'checked="checked"' : '' ) . ' >' . self::swatch_image( $o['image'] ) . $hex . '
						<div class="m7pa-radio-image-desc">
							<span>' . $name . '</span>
						</div>
						<span class="m7pa-theme-element"></span>
					</label>
				</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo "\n\t</div><!-- .m7pa-radio-images-wrapper -->\n";
		echo $c['close_td']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	private static function tpl_upload( array $c ) {
		$f = $c['f'];
		echo $c['open_td']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( Settings::get( 'require_login_upload' ) && ! is_user_logged_in() ) {
			echo '<p>' . esc_html__( 'Je moet ingelogd zijn om bestanden te kunnen uploaden', 'm7-product-addons' ) . '</p>';
		} else {
			$value = is_array( $c['value'] ) ? $c['value'] : array();
			echo '<div class="m7pa-input-wrapper m7pa-upload" id="' . esc_attr( $c['dom'] ) . '-wrapper" data-max-files="' . (int) $f['upload']['max_files'] . '">';
			echo '<div><input class="m7pa-file-upload m7pa-upload__input" type="file"' . ( $f['upload']['max_files'] > 1 ? ' multiple' : '' ) . ' id="' . esc_attr( $c['dom'] ) . '_file" accept="' . esc_attr( '.' . implode( ',.', $f['upload']['types'] ) ) . '"></div>';
			echo '<ul class="m7pa-upload__list"></ul>';
			echo '<input type="hidden" class="m7pa-form-field m7pa-number-uploads m7pa-upload__tokens" name="' . esc_attr( $c['dom'] ) . '" id="' . esc_attr( $c['dom'] ) . '" value="' . esc_attr( $value ? wp_json_encode( $value ) : '' ) . '">';
			echo '</div>';
		}
		echo $c['close_td']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	private static function tpl_information( array $c ) {
		$f = $c['f'];
		echo $c['open_td']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo "\n\t" . '<table class="m7pa-information-fields">' . "\n\t\t<tbody>\n\t\t  ";
		foreach ( $f['rows'] as $r ) {
			$image = $r['image'] ? wp_get_attachment_image( $r['image'], 'full' ) : '';
			echo '<tr>
							<td class="m7pa-information-image">' . $image . '</td>
							<td class="m7pa-information-label">' . esc_html( $r['label'] ) . '</td>
							<td class="m7pa-information-data">' . wp_kses_post( $r['value'] ) . '</td>
						</tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo "\n\t\t</tbody>\n\t</table><!-- .m7pa-radio-images-wrapper -->\n";
		echo $c['close_td']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	private static function tpl_calculation( array $c ) {
		$f = $c['f'];
		if ( '' === $f['formula'] ) {
			return;
		}
		echo "\n<" . $c['cell'] . ' class="m7pa-calculation-field-wrapper m7pa-calculation-price-wrapper">' . "\n\t"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<span class="m7pa-calculation-span" id="m7pa-calculation-value"></span><input type="hidden" class="m7pa-form-field m7pa-calculation-value m7pa-number-field m7pa-number-field-' . esc_attr( $f['id'] ) . '" id="' . esc_attr( $c['dom'] ) . '" name="' . esc_attr( $c['dom'] ) . '" value="">';
		echo "\t\n</" . $c['cell'] . ">\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/* ------------------------------ totalen ------------------------------ */

	private static function render_totals( array $groups, $product ) {
		$mode = Settings::get( 'show_totals' );
		if ( 'total' === $mode ) {
			echo '<p class="m7pa-total-only"><span id="m7pa-grand-total" class="m7pa-total-field"></span></p>';
			return;
		}
		if ( 'all' !== $mode ) {
			return;
		}
		$label = static function ( $key, $fallback ) {
			$v = (string) Settings::get( $key );
			return '' !== $v ? $v : $fallback;
		};
		echo '<div class="m7pa-total-field-wrapper">';
		echo '<p><span id="m7pa-per-product-label">' . esc_html( $label( 'label_product', __( 'Product totaal', 'm7-product-addons' ) ) ) . '</span><span id="m7pa-per-product-total" class="m7pa-total-field"></span></p>';
		echo '<p><span id="m7pa-options-total-label">' . esc_html( $label( 'label_options', __( 'Opties totaal', 'm7-product-addons' ) ) ) . '</span><span id="m7pa-options-total" class="m7pa-total-field"></span></p>';
		if ( self::has_flat_rate( $groups ) ) {
			echo '<p><span id="m7pa-flat-rate-total-label">' . esc_html( $label( 'label_flatrate', __( 'Vast bedrag totaal', 'm7-product-addons' ) ) ) . '</span><span id="m7pa-flat-rate-total" class="m7pa-total-field"></span></p>';
		}
		echo '<p><span id="m7pa-grand-total-label">' . esc_html( $label( 'label_grand', __( 'Totaal generaal', 'm7-product-addons' ) ) ) . '</span><span id="m7pa-grand-total" class="m7pa-total-field"></span></p>';
		echo '</div><!-- .m7pa-flat-rate-total-field-wrapper -->';
	}
}
