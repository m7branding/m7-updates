<?php
/**
 * Add-on-groepen: opslag, standaardwaarden, opschonen en welke groepen bij een product horen.
 *
 * Een groep is een bericht van type m7pa_group met alle instellingen en velden in één
 * metaveld (_m7pa_group). Groepen zijn globaal (regels) of horen bij producten
 * (productmeta _m7pa_group_ids, in volgorde).
 *
 * @package M7PA
 */

namespace M7PA;

defined( 'ABSPATH' ) || exit;

final class Groups {

	const POST_TYPE    = 'm7pa_group';
	const META         = '_m7pa_group';
	const PRODUCT_META = '_m7pa_group_ids';
	const NO_GLOBAL    = '_m7pa_no_global';

	const FIELD_TYPES = array(
		'checkbox'       => 'Checkbox',
		'checkbox_group' => 'Checkbox-groep',
		'radio'          => 'Radio-groep',
		'select'         => 'Keuzelijst',
		'image_swatch'   => 'Afbeeldingen (swatches)',
		'products'       => 'Gekoppelde producten',
		'text'           => 'Tekst',
		'textarea'       => 'Tekstvak',
		'number'         => 'Getal',
		'date'           => 'Datum',
		'color'          => 'Kleur',
		'name_price'     => 'Noem je prijs',
		'calculation'    => 'Berekening',
		'upload'         => 'Bestand uploaden',
		'information'    => 'Informatie',
	);

	const OPTION_TYPES = array( 'checkbox_group', 'radio', 'select', 'image_swatch' );

	const PRICE_TYPES = array(
		'fixed'      => 'Vast bedrag per stuk',
		'flat'       => 'Eenmalig per bestelregel',
		'percentage' => 'Percentage van productprijs',
		'per_char'   => 'Per teken',
		'multiply'   => 'Keer ingevulde waarde',
	);

	/** @var array Per verzoek: product-ID => groepen. */
	private static $cache = array();

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'flush' ) );
	}

	public static function register() {
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'          => array(
					'name'          => __( 'Add-on-groepen', 'm7-product-addons' ),
					'singular_name' => __( 'Add-on-groep', 'm7-product-addons' ),
					'add_new'       => __( 'Nieuwe groep', 'm7-product-addons' ),
					'add_new_item'  => __( 'Nieuwe add-on-groep', 'm7-product-addons' ),
					'edit_item'     => __( 'Add-on-groep bewerken', 'm7-product-addons' ),
					'menu_name'     => __( 'Groepen', 'm7-product-addons' ),
					'all_items'     => __( 'Groepen', 'm7-product-addons' ),
				),
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => 'm7', // Gedeeld M7-menu (includes/m7/class-m7-admin-menu.php).
				'supports'        => array( 'title', 'page-attributes' ),
				'capability_type' => 'product',
				'map_meta_cap'    => true,
				'show_in_rest'    => false,
			)
		);
	}

	public static function flush() {
		self::$cache = array();
	}

	/** Weergaven van gekoppelde producten (zelfde namen als Product Add-Ons Ultimate). */
	const PRODUCT_LAYOUTS = array( 'checkboxes', 'checkboxes-list', 'radio', 'radio-list', 'select', 'column', 'components', 'swatches', 'variable-select', 'grid' );

	/** Acties van een berekeningsveld. */
	const FORMULA_ACTIONS = array( 'no-action', 'cost', 'price', 'qty', 'child-qty', 'weight', 'length', 'width', 'height' );

	public static function group_defaults() {
		return array(
			'description'    => '',
			'display'        => 'standard', // standard | accordion | tabs | steps.
			'layout'         => 'ul',       // ul | table | cols-2 | cols-3.
			'class'          => '',
			'always_include' => false,
			'scope'          => 'product',  // product | global.
			'rules'          => array(
				'all'              => false,
				'categories'       => array(),
				'products'         => array(),
				'exclude_products' => array(),
				'roles'            => array(),
			),
			// Voorwaarden voor de hele groep (verbergt kop, beschrijving en velden).
			'conditions'     => array(
				'action' => 'show',
				'match'  => 'all',
				'rules'  => array(),
			),
			'fields'         => array(),
			'legacy'         => array(),
		);
	}

	public static function field_defaults() {
		return array(
			'id'          => '',
			'type'        => 'checkbox',
			'label'       => '',
			'description' => '',
			'required'    => false,
			'hide_label'  => false,
			'price'       => 0.0,
			'price_type'  => 'fixed',
			'options'     => array(),
			'multiple'    => false,
			'default'     => '',
			'placeholder' => '',
			'min'         => '',
			'max'         => '',
			'step'        => '',
			'min_chars'   => '',
			'max_chars'   => '',
			'formula'     => '',
			'decimals'    => 2,
			'formula_as_price' => false,
			// Weergave en gedrag zoals in Product Add-Ons Ultimate (worden bij overstappen overgenomen).
			'class'                   => '',
			'image'                   => 0,
			'visibility'              => 'visible', // visible | display_product | hide_product | hide_customer.
			'price_visibility'        => 'visible', // visible | product | hidden ('' = niet ingesteld).
			'option_price_visibility' => 'visible', // visible | product | hidden | value ('' = niet ingesteld).
			'as_swatch'               => false,     // Radio/checkbox(-groep) als tekstblokjes.
			'columns'                 => 3,         // Kolommen bij afbeeldingen.
			'hide_option_labels'      => false,     // Afbeeldingen zonder naam eronder.
			'min_checks'              => '',
			'max_checks'              => '',
			'free_chars'              => '',
			'alphanumeric'            => false,
			'alphanumeric_charge'     => false,
			'show_counter'            => false,
			'slider'                  => false,     // Getal als schuifbalk.
			'replace_image'           => false,     // Gekozen afbeelding vervangt de hoofdafbeelding.
			'formula_action'          => '',        // Zie FORMULA_ACTIONS; leeg = volgt formula_as_price.
			'formula_round'           => '',        // '' | floor | ceil.
			'suffix'                  => '',        // Achtervoegsel bij de uitkomst van een berekening.
			'hidden'                  => false,     // Berekening verbergen (wel meerekenen).
			'variations'              => array(),   // Alleen tonen bij deze variatie-ID's.
			'color'                   => '',        // Beginkleur van de kleurkiezer.
			'date'                    => array(     // Datumkiezer.
				'min_today' => false,
				'offset'    => '',                  // Vroegste datum = vandaag + dagen.
				'min'       => '',                  // Y-m-d.
				'max'       => '',                  // Y-m-d.
			),
			'products'    => array(
				'ids'           => array(),
				'layout'        => 'checkboxes', // Zie PRODUCT_LAYOUTS.
				'quantities'    => 'linked',     // linked | independent | one.
				'discount'      => 0.0,
				'discount_type' => 'percentage', // percentage | fixed.
				'allow_none'    => true,
				'min'           => '',
				'max'           => '',
				'placeholder'   => '',
				'columns'       => 3,
				'hide_labels'   => false,
				'force_qty'     => false,
				'default_qty'   => '',
				'min_qty'       => '',
				'max_qty'       => '',
			),
			'upload'      => array(
				'max_files' => 1,
				'max_mb'    => 10,
				'types'     => array( 'jpg', 'jpeg', 'png', 'pdf' ),
			),
			'rows'        => array(),
			'conditions'  => array(
				'action' => 'show',
				'match'  => 'all',
				'rules'  => array(),
			),
			'legacy'      => array(),
		);
	}

	/**
	 * Groep ophalen.
	 *
	 * @param int $group_id ID.
	 * @return array|null
	 */
	public static function get( $group_id ) {
		$post = get_post( (int) $group_id );
		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return null;
		}
		$saved = get_post_meta( $post->ID, self::META, true );
		$group = self::sanitize_group( is_array( $saved ) ? $saved : array() );
		$group['id']     = $post->ID;
		$group['title']  = $post->post_title;
		$group['status'] = $post->post_status;
		$group['order']  = (int) $post->menu_order;
		return $group;
	}

	/**
	 * Groepen (gepubliceerd) voor een product, in weergavevolgorde.
	 *
	 * @param \WC_Product|int $product Product of ID.
	 * @return array
	 */
	public static function for_product( $product ) {
		$product = $product instanceof \WC_Product ? $product : wc_get_product( $product );
		if ( ! $product ) {
			return array();
		}
		// Variaties gebruiken de groepen van het hoofdproduct.
		$pid = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
		if ( isset( self::$cache[ $pid ] ) ) {
			return self::$cache[ $pid ];
		}

		$groups = array();
		$ids    = get_post_meta( $pid, self::PRODUCT_META, true );
		foreach ( is_array( $ids ) ? $ids : array() as $gid ) {
			$g = self::get( $gid );
			if ( $g && 'publish' === $g['status'] && $g['fields'] ) {
				$groups[ $g['id'] ] = $g;
			}
		}

		if ( ! get_post_meta( $pid, self::NO_GLOBAL, true ) ) {
			foreach ( self::global_groups() as $g ) {
				if ( ! isset( $groups[ $g['id'] ] ) && self::rules_match( $g['rules'], $pid ) ) {
					$groups[ $g['id'] ] = $g;
				}
			}
		}

		self::$cache[ $pid ] = apply_filters( 'm7pa/groups_for_product', array_values( $groups ), $pid );
		return self::$cache[ $pid ];
	}

	/**
	 * Alle gepubliceerde globale groepen, gesorteerd op volgorde.
	 *
	 * @return array
	 */
	public static function global_groups() {
		static $globals = null;
		if ( null !== $globals ) {
			return $globals;
		}
		$globals = array();
		$posts   = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => array(
					'menu_order' => 'ASC',
					'ID'         => 'ASC',
				),
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		foreach ( $posts as $id ) {
			$g = self::get( $id );
			if ( $g && 'global' === $g['scope'] && $g['fields'] ) {
				$globals[] = $g;
			}
		}
		return $globals;
	}

	public static function rules_match( array $rules, $product_id ) {
		if ( in_array( (int) $product_id, array_map( 'intval', $rules['exclude_products'] ), true ) ) {
			return false;
		}
		if ( $rules['roles'] ) {
			$user = wp_get_current_user();
			if ( ! array_intersect( (array) $user->roles, $rules['roles'] ) && ! ( ! $user->exists() && in_array( 'guest', $rules['roles'], true ) ) ) {
				return false;
			}
		}
		if ( $rules['all'] ) {
			return true;
		}
		if ( in_array( (int) $product_id, array_map( 'intval', $rules['products'] ), true ) ) {
			return true;
		}
		if ( $rules['categories'] ) {
			$cats = wc_get_product_term_ids( $product_id, 'product_cat' );
			// Ook bovenliggende categorieën tellen mee.
			$all = $cats;
			foreach ( $cats as $c ) {
				$all = array_merge( $all, get_ancestors( $c, 'product_cat', 'taxonomy' ) );
			}
			if ( array_intersect( array_map( 'intval', $rules['categories'] ), $all ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Zoekt een veld op in een lijst groepen.
	 *
	 * @param array  $groups   Groepen.
	 * @param string $field_id Veld-ID.
	 * @return array|null [group, field]
	 */
	public static function find_field( array $groups, $field_id ) {
		foreach ( $groups as $g ) {
			foreach ( $g['fields'] as $f ) {
				if ( $f['id'] === $field_id ) {
					return array( $g, $f );
				}
			}
		}
		return null;
	}

	/* ------------------------------ opschonen ------------------------------ */

	public static function sanitize_group( array $raw ) {
		$d   = self::group_defaults();
		$out = array();

		$out['description']    = isset( $raw['description'] ) ? wp_kses_post( $raw['description'] ) : '';
		$out['display']        = isset( $raw['display'] ) && in_array( $raw['display'], array( 'standard', 'accordion', 'tabs', 'steps' ), true ) ? $raw['display'] : 'standard';
		$out['layout']         = isset( $raw['layout'] ) && in_array( $raw['layout'], array( 'ul', 'table', 'cols-2', 'cols-3' ), true ) ? $raw['layout'] : 'ul';
		$out['class']          = isset( $raw['class'] ) ? self::css_classes( $raw['class'] ) : '';
		$out['always_include'] = ! empty( $raw['always_include'] );
		$out['scope']          = ( isset( $raw['scope'] ) && 'global' === $raw['scope'] ) ? 'global' : 'product';
		$out['conditions']     = self::sanitize_conditions( isset( $raw['conditions'] ) && is_array( $raw['conditions'] ) ? $raw['conditions'] : array() );

		$rules        = isset( $raw['rules'] ) && is_array( $raw['rules'] ) ? $raw['rules'] : array();
		$out['rules'] = array(
			'all'              => ! empty( $rules['all'] ),
			'categories'       => self::ids( isset( $rules['categories'] ) ? $rules['categories'] : array() ),
			'products'         => self::ids( isset( $rules['products'] ) ? $rules['products'] : array() ),
			'exclude_products' => self::ids( isset( $rules['exclude_products'] ) ? $rules['exclude_products'] : array() ),
			'roles'            => array_values( array_filter( array_map( 'sanitize_key', isset( $rules['roles'] ) ? (array) $rules['roles'] : array() ) ) ),
		);

		$out['fields'] = array();
		$seen          = array();
		foreach ( isset( $raw['fields'] ) && is_array( $raw['fields'] ) ? $raw['fields'] : array() as $f ) {
			if ( ! is_array( $f ) ) {
				continue;
			}
			$field = self::sanitize_field( $f );
			if ( isset( $seen[ $field['id'] ] ) ) {
				$field['id'] = self::new_field_id();
			}
			$seen[ $field['id'] ]  = true;
			$out['fields'][]       = $field;
		}
		$out['legacy'] = isset( $raw['legacy'] ) && is_array( $raw['legacy'] ) ? self::scalars( $raw['legacy'] ) : array();
		return array_merge( $d, $out );
	}

	public static function sanitize_field( array $raw ) {
		$d = self::field_defaults();
		$f = array();

		$f['id']          = isset( $raw['id'] ) && preg_match( '/^[a-z0-9_]{2,40}$/', (string) $raw['id'] ) ? (string) $raw['id'] : self::new_field_id();
		$f['type']        = isset( $raw['type'] ) && array_key_exists( (string) $raw['type'], self::FIELD_TYPES ) ? (string) $raw['type'] : 'checkbox';
		$f['label']       = isset( $raw['label'] ) ? sanitize_text_field( $raw['label'] ) : '';
		$f['description'] = isset( $raw['description'] ) ? wp_kses_post( $raw['description'] ) : '';
		$f['required']    = ! empty( $raw['required'] );
		$f['hide_label']  = ! empty( $raw['hide_label'] );
		$f['price']       = isset( $raw['price'] ) ? (float) wc_format_decimal( $raw['price'] ) : 0.0;
		$f['price_type']  = isset( $raw['price_type'] ) && array_key_exists( (string) $raw['price_type'], self::PRICE_TYPES ) ? (string) $raw['price_type'] : 'fixed';
		$f['multiple']    = ! empty( $raw['multiple'] );
		$f['default']     = isset( $raw['default'] ) ? sanitize_text_field( is_array( $raw['default'] ) ? implode( ',', $raw['default'] ) : $raw['default'] ) : '';
		$f['placeholder'] = isset( $raw['placeholder'] ) ? sanitize_text_field( $raw['placeholder'] ) : '';
		foreach ( array( 'min', 'max', 'step', 'min_chars', 'max_chars' ) as $k ) {
			$f[ $k ] = ( isset( $raw[ $k ] ) && '' !== $raw[ $k ] && is_numeric( $raw[ $k ] ) ) ? (float) $raw[ $k ] : '';
		}
		$f['formula']          = isset( $raw['formula'] ) ? Formula::sanitize( $raw['formula'] ) : '';
		$f['decimals']         = isset( $raw['decimals'] ) ? min( 6, absint( $raw['decimals'] ) ) : 2;
		$f['formula_as_price'] = ! empty( $raw['formula_as_price'] );
		$action                = isset( $raw['formula_action'] ) && in_array( (string) $raw['formula_action'], self::FORMULA_ACTIONS, true ) ? (string) $raw['formula_action'] : '';
		if ( in_array( $action, array( '', 'cost', 'no-action' ), true ) ) {
			// De schakelaar "uitkomst is de prijs" in het beheer is leidend voor deze twee.
			$action = $f['formula_as_price'] ? 'cost' : 'no-action';
		}
		$f['formula_action'] = $action;
		$f['formula_as_price'] = in_array( $action, array( 'cost', 'price' ), true );
		$f['formula_round']  = isset( $raw['formula_round'] ) && in_array( $raw['formula_round'], array( 'floor', 'ceil' ), true ) ? $raw['formula_round'] : '';
		$f['suffix']         = isset( $raw['suffix'] ) ? sanitize_text_field( $raw['suffix'] ) : '';
		$f['hidden']         = ! empty( $raw['hidden'] );

		$f['class']      = isset( $raw['class'] ) ? self::css_classes( $raw['class'] ) : '';
		$f['image']      = isset( $raw['image'] ) ? absint( $raw['image'] ) : 0;
		$f['visibility'] = isset( $raw['visibility'] ) && in_array( $raw['visibility'], array( 'visible', 'display_product', 'hide_product', 'hide_customer' ), true ) ? $raw['visibility'] : 'visible';
		$f['price_visibility']        = isset( $raw['price_visibility'] ) && in_array( $raw['price_visibility'], array( '', 'visible', 'product', 'hidden' ), true ) ? $raw['price_visibility'] : 'visible';
		$f['option_price_visibility'] = isset( $raw['option_price_visibility'] ) && in_array( $raw['option_price_visibility'], array( '', 'visible', 'product', 'hidden', 'value' ), true ) ? $raw['option_price_visibility'] : 'visible';
		foreach ( array( 'as_swatch', 'hide_option_labels', 'alphanumeric', 'alphanumeric_charge', 'show_counter', 'slider', 'replace_image' ) as $k ) {
			$f[ $k ] = ! empty( $raw[ $k ] );
		}
		$f['columns'] = isset( $raw['columns'] ) && '' !== $raw['columns'] ? max( 0, min( 10, absint( $raw['columns'] ) ) ) : 3;
		foreach ( array( 'min_checks', 'max_checks', 'free_chars' ) as $k ) {
			$f[ $k ] = isset( $raw[ $k ] ) && '' !== $raw[ $k ] && is_numeric( $raw[ $k ] ) ? absint( $raw[ $k ] ) : '';
		}
		$f['variations'] = self::ids( isset( $raw['variations'] ) ? $raw['variations'] : array() );
		$f['color']      = isset( $raw['color'] ) && sanitize_hex_color( $raw['color'] ) ? sanitize_hex_color( $raw['color'] ) : '';
		$dt              = isset( $raw['date'] ) && is_array( $raw['date'] ) ? $raw['date'] : array();
		$ymd             = static function ( $v ) {
			return is_string( $v ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : '';
		};
		$f['date']       = array(
			'min_today' => ! empty( $dt['min_today'] ),
			'offset'    => isset( $dt['offset'] ) && '' !== $dt['offset'] && is_numeric( $dt['offset'] ) ? absint( $dt['offset'] ) : '',
			'min'       => isset( $dt['min'] ) ? $ymd( $dt['min'] ) : '',
			'max'       => isset( $dt['max'] ) ? $ymd( $dt['max'] ) : '',
		);

		$f['options'] = array();
		foreach ( isset( $raw['options'] ) && is_array( $raw['options'] ) ? $raw['options'] : array() as $o ) {
			if ( ! is_array( $o ) ) {
				continue;
			}
			$value = isset( $o['value'] ) ? sanitize_text_field( $o['value'] ) : '';
			$label = isset( $o['label'] ) && '' !== $o['label'] ? sanitize_text_field( $o['label'] ) : $value;
			if ( '' === $value && '' === $label ) {
				continue;
			}
			$f['options'][] = array(
				'value'       => '' !== $value ? $value : $label,
				'label'       => $label,
				'price'       => isset( $o['price'] ) ? (float) wc_format_decimal( $o['price'] ) : 0.0,
				'image'       => isset( $o['image'] ) ? absint( $o['image'] ) : 0,
				'hex'         => isset( $o['hex'] ) && sanitize_hex_color( $o['hex'] ) ? sanitize_hex_color( $o['hex'] ) : '',
				'description' => isset( $o['description'] ) ? sanitize_text_field( $o['description'] ) : '',
			);
		}

		$p             = isset( $raw['products'] ) && is_array( $raw['products'] ) ? $raw['products'] : array();
		$num           = static function ( $k ) use ( $p ) {
			return isset( $p[ $k ] ) && '' !== $p[ $k ] && is_numeric( $p[ $k ] ) ? absint( $p[ $k ] ) : '';
		};
		$f['products'] = array(
			'ids'           => self::ids( isset( $p['ids'] ) ? $p['ids'] : array() ),
			'layout'        => isset( $p['layout'] ) && in_array( $p['layout'], self::PRODUCT_LAYOUTS, true ) ? $p['layout'] : 'checkboxes',
			'quantities'    => isset( $p['quantities'] ) && in_array( $p['quantities'], array( 'linked', 'independent', 'one' ), true ) ? $p['quantities'] : 'linked',
			'discount'      => isset( $p['discount'] ) ? max( 0, (float) wc_format_decimal( $p['discount'] ) ) : 0.0,
			'discount_type' => ( isset( $p['discount_type'] ) && 'fixed' === $p['discount_type'] ) ? 'fixed' : 'percentage',
			'allow_none'    => ! isset( $p['allow_none'] ) || ! empty( $p['allow_none'] ),
			'min'           => $num( 'min' ),
			'max'           => $num( 'max' ),
			'placeholder'   => isset( $p['placeholder'] ) ? sanitize_text_field( $p['placeholder'] ) : '',
			'columns'       => isset( $p['columns'] ) && '' !== $p['columns'] ? max( 0, min( 10, absint( $p['columns'] ) ) ) : 3,
			'hide_labels'   => ! empty( $p['hide_labels'] ),
			'force_qty'     => ! empty( $p['force_qty'] ),
			'default_qty'   => $num( 'default_qty' ),
			'min_qty'       => $num( 'min_qty' ),
			'max_qty'       => $num( 'max_qty' ),
		);

		$u           = isset( $raw['upload'] ) && is_array( $raw['upload'] ) ? $raw['upload'] : array();
		$types       = isset( $u['types'] ) ? ( is_array( $u['types'] ) ? $u['types'] : explode( ',', (string) $u['types'] ) ) : $d['upload']['types'];
		$f['upload'] = array(
			'max_files' => isset( $u['max_files'] ) ? max( 1, min( 20, absint( $u['max_files'] ) ) ) : 1,
			'max_mb'    => isset( $u['max_mb'] ) ? max( 1, min( 100, absint( $u['max_mb'] ) ) ) : 10,
			'types'     => array_values( array_filter( array_map( static function ( $t ) {
				return preg_replace( '/[^a-z0-9]/', '', strtolower( trim( $t ) ) );
			}, $types ) ) ),
		);

		$f['rows'] = array();
		foreach ( isset( $raw['rows'] ) && is_array( $raw['rows'] ) ? $raw['rows'] : array() as $r ) {
			if ( is_array( $r ) && ( ! empty( $r['label'] ) || ! empty( $r['value'] ) || ! empty( $r['image'] ) ) ) {
				$f['rows'][] = array(
					'image' => isset( $r['image'] ) ? absint( $r['image'] ) : 0,
					'label' => isset( $r['label'] ) ? sanitize_text_field( $r['label'] ) : '',
					'value' => isset( $r['value'] ) ? wp_kses_post( $r['value'] ) : '',
				);
			}
		}

		$f['conditions'] = self::sanitize_conditions( isset( $raw['conditions'] ) && is_array( $raw['conditions'] ) ? $raw['conditions'] : array() );

		$f['legacy'] = isset( $raw['legacy'] ) && is_array( $raw['legacy'] ) ? self::scalars( $raw['legacy'] ) : array();

		return array_merge( $d, $f );
	}

	/**
	 * Voorwaarden (veld of groep) opschonen.
	 *
	 * @param array $c action/match/rules.
	 * @return array
	 */
	public static function sanitize_conditions( array $c ) {
		$out = array(
			'action' => ( isset( $c['action'] ) && 'hide' === $c['action'] ) ? 'hide' : 'show',
			'match'  => ( isset( $c['match'] ) && 'any' === $c['match'] ) ? 'any' : 'all',
			'rules'  => array(),
		);
		foreach ( isset( $c['rules'] ) && is_array( $c['rules'] ) ? $c['rules'] : array() as $r ) {
			if ( ! is_array( $r ) || empty( $r['field'] ) || empty( $r['operator'] ) ) {
				continue;
			}
			$op = (string) $r['operator'];
			if ( ! array_key_exists( $op, Conditions::OPERATORS ) ) {
				continue;
			}
			$out['rules'][] = array(
				'field'    => preg_replace( '/[^a-z0-9_:\-]/', '', (string) $r['field'] ),
				'operator' => $op,
				'value'    => isset( $r['value'] ) ? sanitize_text_field( is_array( $r['value'] ) ? implode( ',', $r['value'] ) : $r['value'] ) : '',
			);
		}
		return $out;
	}

	/**
	 * Eén of meer CSS-klassen (spaties gescheiden).
	 */
	private static function css_classes( $value ) {
		return trim( implode( ' ', array_filter( array_map( 'sanitize_html_class', preg_split( '/\s+/', (string) $value ) ) ) ) );
	}

	public static function new_field_id() {
		return 'f' . strtolower( wp_generate_password( 8, false, false ) );
	}

	private static function ids( $value ) {
		$list = is_array( $value ) ? $value : preg_split( '/[\s,]+/', (string) $value );
		return array_values( array_unique( array_filter( array_map( 'absint', $list ) ) ) );
	}

	private static function scalars( array $a ) {
		$out = array();
		foreach ( $a as $k => $v ) {
			if ( is_scalar( $v ) ) {
				$out[ sanitize_key( $k ) ] = is_string( $v ) ? sanitize_text_field( $v ) : $v;
			}
		}
		return $out;
	}
}
