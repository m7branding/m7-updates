<?php
/**
 * Elementor-widget: winkelwagen-formulier met de M7-productopties, met stijlinstellingen.
 *
 * @package M7PA
 */

namespace M7PA\Elementor;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;

defined( 'ABSPATH' ) || exit;

class Widget_Add_To_Cart extends \Elementor\Widget_Base {

	public function get_name() {
		return 'm7pa-add-to-cart';
	}

	public function get_title() {
		return 'M7 Product Add-Ons';
	}

	public function get_icon() {
		return 'm7-eicon';
	}

	public function get_categories() {
		return array( 'm7', 'woocommerce-elements-single' );
	}

	public function get_keywords() {
		return array( 'm7', 'add-ons', 'opties', 'product', 'winkelwagen', 'cart', 'woocommerce' );
	}

	public function get_style_depends() {
		return array( 'm7pa' );
	}

	/**
	 * Kleine helper: één stijlonderdeel met typografie, kleuren en ruimte.
	 */
	private function text_controls( $prefix, $selector, $label_color = '' ) {
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => $prefix . '_typography',
				'selector' => '{{WRAPPER}} ' . $selector,
			)
		);
		$this->add_control(
			$prefix . '_color',
			array(
				'label'     => $label_color ? $label_color : __( 'Kleur', 'm7-product-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} ' . $selector => 'color: {{VALUE}};' ),
			)
		);
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_content', array( 'label' => __( 'Inhoud', 'm7-product-addons' ) ) );
		$this->add_control(
			'info',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => __( 'Toont het winkelwagen-formulier van dit product met de productopties (groepen en velden uit M7 > Product Add-Ons). Gebruik het in een Elementor-productsjabloon.', 'm7-product-addons' ),
				'content_classes' => 'elementor-descriptor',
			)
		);
		$this->add_control(
			'show_quantity',
			array(
				'label'        => __( 'Aantal tonen', 'm7-product-addons' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			)
		);
		$this->end_controls_section();

		/* ---- Groepen ---- */
		$this->start_controls_section( 'section_groups', array( 'label' => __( 'Groepen', 'm7-product-addons' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_control( 'group_heading', array( 'label' => __( 'Titel', 'm7-product-addons' ), 'type' => Controls_Manager::HEADING ) );
		$this->text_controls( 'group_title', '.m7pa-group-heading' );
		$this->add_control(
			'group_title_bg',
			array(
				'label'     => __( 'Achtergrond titel', 'm7-product-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .m7pa-group-heading-wrapper' => 'background-color: {{VALUE}};' ),
			)
		);
		$this->add_control( 'group_desc_heading', array( 'label' => __( 'Beschrijving', 'm7-product-addons' ), 'type' => Controls_Manager::HEADING, 'separator' => 'before' ) );
		$this->text_controls( 'group_desc', '.m7pa-group-description' );
		$this->add_responsive_control(
			'group_gap',
			array(
				'label'      => __( 'Ruimte tussen groepen', 'm7-product-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em' ),
				'separator'  => 'before',
				'selectors'  => array( '{{WRAPPER}} .m7pa-group-wrap' => 'margin-bottom: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->end_controls_section();

		/* ---- Labels en prijzen ---- */
		$this->start_controls_section( 'section_labels', array( 'label' => __( 'Labels en prijzen', 'm7-product-addons' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->text_controls( 'label', '.m7pa-field-label, .m7pa-field-label-text' );
		$this->add_responsive_control(
			'label_gap',
			array(
				'label'      => __( 'Ruimte onder label', 'm7-product-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array( '{{WRAPPER}} .m7pa-field-label' => 'margin-bottom: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->add_control( 'price_heading', array( 'label' => __( 'Prijs bij optie', 'm7-product-addons' ), 'type' => Controls_Manager::HEADING, 'separator' => 'before' ) );
		$this->text_controls( 'price', '.m7pa-field-price, .m7pa-option-price' );
		$this->add_responsive_control(
			'field_gap',
			array(
				'label'      => __( 'Ruimte tussen velden', 'm7-product-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em' ),
				'separator'  => 'before',
				'selectors'  => array( '{{WRAPPER}} .m7pa-item' => 'margin-bottom: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->end_controls_section();

		/* ---- Invoervelden ---- */
		$sel = '.m7pa-form-field:not([type="checkbox"]):not([type="radio"]):not([type="hidden"])';
		$this->start_controls_section( 'section_fields', array( 'label' => __( 'Invoervelden', 'm7-product-addons' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->text_controls( 'field', $sel, __( 'Tekstkleur', 'm7-product-addons' ) );
		$this->add_control(
			'field_bg',
			array(
				'label'     => __( 'Achtergrond', 'm7-product-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} ' . $sel => 'background-color: {{VALUE}};' ),
			)
		);
		$this->add_group_control( Group_Control_Border::get_type(), array( 'name' => 'field_border', 'selector' => '{{WRAPPER}} ' . $sel ) );
		$this->add_control(
			'field_radius',
			array(
				'label'      => __( 'Afronding', 'm7-product-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array( '{{WRAPPER}} ' . $sel => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);
		$this->add_responsive_control(
			'field_padding',
			array(
				'label'      => __( 'Binnenruimte', 'm7-product-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array( '{{WRAPPER}} ' . $sel => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);
		$this->add_control(
			'field_focus',
			array(
				'label'     => __( 'Randkleur bij focus', 'm7-product-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} ' . str_replace( ':not([type="hidden"])', ':not([type="hidden"]):focus', $sel ) => 'border-color: {{VALUE}}; outline-color: {{VALUE}};' ),
			)
		);
		$this->end_controls_section();

		/* ---- Vakjes en rondjes ---- */
		$box = '.m7pa-theme-element';
		$this->start_controls_section( 'section_boxes', array( 'label' => __( 'Vakjes en rondjes', 'm7-product-addons' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_responsive_control(
			'box_size',
			array(
				'label'      => __( 'Grootte', 'm7-product-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 10, 'max' => 50 ) ),
				'selectors'  => array( '{{WRAPPER}} ' . $box => 'width: {{SIZE}}{{UNIT}} !important; height: {{SIZE}}{{UNIT}} !important;' ),
			)
		);
		$this->start_controls_tabs( 'box_tabs' );
		$this->start_controls_tab( 'box_normal', array( 'label' => __( 'Normaal', 'm7-product-addons' ) ) );
		$this->add_control( 'box_bg', array( 'label' => __( 'Achtergrond', 'm7-product-addons' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} ' . $box => 'background-color: {{VALUE}} !important;' ) ) );
		$this->add_control( 'box_border', array( 'label' => __( 'Randkleur', 'm7-product-addons' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} ' . $box => 'border-color: {{VALUE}} !important;' ) ) );
		$this->end_controls_tab();
		$this->start_controls_tab( 'box_checked', array( 'label' => __( 'Gekozen', 'm7-product-addons' ) ) );
		$this->add_control( 'box_checked_bg', array( 'label' => __( 'Achtergrond', 'm7-product-addons' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} input:checked ~ ' . $box => 'background-color: {{VALUE}} !important;' ) ) );
		$this->add_control( 'box_checked_border', array( 'label' => __( 'Randkleur', 'm7-product-addons' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} input:checked ~ ' . $box => 'border-color: {{VALUE}} !important;' ) ) );
		$this->add_control( 'box_check', array( 'label' => __( 'Kleur vinkje/punt', 'm7-product-addons' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} input:checked ~ ' . $box . ':after' => 'border-color: {{VALUE}} !important; background-color: {{VALUE}};' ) ) );
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		/* ---- Afbeeldingen (swatches) ---- */
		$img = '.m7pa-radio-image-wrapper label img, .m7pa-checkbox-image-wrapper label img';
		$this->start_controls_section( 'section_swatches', array( 'label' => __( 'Afbeeldingen en kleuren', 'm7-product-addons' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_control(
			'swatch_radius',
			array(
				'label'      => __( 'Afronding', 'm7-product-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array( '{{WRAPPER}} ' . str_replace( ', ', ', {{WRAPPER}} ', $img ) => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);
		$this->add_control(
			'swatch_selected',
			array(
				'label'     => __( 'Rand gekozen', 'm7-product-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .m7pa-radio-image-wrapper label input:checked + img, {{WRAPPER}} .m7pa-checkbox-image-wrapper label input:checked + img' => 'border-color: {{VALUE}};' ),
			)
		);
		$this->add_responsive_control(
			'swatch_selected_width',
			array(
				'label'      => __( 'Randdikte gekozen', 'm7-product-addons' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 10 ) ),
				'selectors'  => array( '{{WRAPPER}} .m7pa-radio-image-wrapper label input:checked + img, {{WRAPPER}} .m7pa-checkbox-image-wrapper label input:checked + img' => 'border-width: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->add_control( 'swatch_desc_heading', array( 'label' => __( 'Onderschrift', 'm7-product-addons' ), 'type' => Controls_Manager::HEADING, 'separator' => 'before' ) );
		$this->text_controls( 'swatch_desc', '.m7pa-radio-image-desc, .m7pa-checkbox-desc-wrapper' );
		$this->end_controls_section();

		/* ---- Totalen ---- */
		$this->start_controls_section( 'section_totals', array( 'label' => __( 'Totalen', 'm7-product-addons' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->text_controls( 'totals', '.m7pa-total-field-wrapper p, .m7pa-total-only', __( 'Kleur labels', 'm7-product-addons' ) );
		$this->add_control(
			'totals_value_color',
			array(
				'label'     => __( 'Kleur bedragen', 'm7-product-addons' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .m7pa-total-field' => 'color: {{VALUE}};' ),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'grand_typography',
				'label'    => __( 'Typografie totaal', 'm7-product-addons' ),
				'selector' => '{{WRAPPER}} #m7pa-grand-total, {{WRAPPER}} #m7pa-grand-total-label',
			)
		);
		$this->add_responsive_control(
			'totals_align',
			array(
				'label'     => __( 'Uitlijning', 'm7-product-addons' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'left'   => array( 'title' => __( 'Links', 'm7-product-addons' ), 'icon' => 'eicon-text-align-left' ),
					'center' => array( 'title' => __( 'Midden', 'm7-product-addons' ), 'icon' => 'eicon-text-align-center' ),
					'right'  => array( 'title' => __( 'Rechts', 'm7-product-addons' ), 'icon' => 'eicon-text-align-right' ),
				),
				'selectors' => array( '{{WRAPPER}} .m7pa-total-field-wrapper, {{WRAPPER}} .m7pa-total-only' => 'text-align: {{VALUE}};' ),
			)
		);
		$this->end_controls_section();

		/* ---- Knop ---- */
		$btn = '.single_add_to_cart_button';
		$this->start_controls_section( 'section_button', array( 'label' => __( 'Knop', 'm7-product-addons' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'button_typography', 'selector' => '{{WRAPPER}} ' . $btn ) );
		$this->start_controls_tabs( 'button_tabs' );
		$this->start_controls_tab( 'button_normal', array( 'label' => __( 'Normaal', 'm7-product-addons' ) ) );
		$this->add_control( 'button_color', array( 'label' => __( 'Tekstkleur', 'm7-product-addons' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} ' . $btn => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'button_bg', array( 'label' => __( 'Achtergrond', 'm7-product-addons' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} ' . $btn => 'background-color: {{VALUE}};' ) ) );
		$this->end_controls_tab();
		$this->start_controls_tab( 'button_hover', array( 'label' => __( 'Hover', 'm7-product-addons' ) ) );
		$this->add_control( 'button_hover_color', array( 'label' => __( 'Tekstkleur', 'm7-product-addons' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} ' . $btn . ':hover' => 'color: {{VALUE}};' ) ) );
		$this->add_control( 'button_hover_bg', array( 'label' => __( 'Achtergrond', 'm7-product-addons' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} ' . $btn . ':hover' => 'background-color: {{VALUE}};' ) ) );
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->add_group_control( Group_Control_Border::get_type(), array( 'name' => 'button_border', 'selector' => '{{WRAPPER}} ' . $btn, 'separator' => 'before' ) );
		$this->add_control(
			'button_radius',
			array(
				'label'      => __( 'Afronding', 'm7-product-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array( '{{WRAPPER}} ' . $btn => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(), array( 'name' => 'button_shadow', 'selector' => '{{WRAPPER}} ' . $btn ) );
		$this->add_responsive_control(
			'button_padding',
			array(
				'label'      => __( 'Binnenruimte', 'm7-product-addons' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array( '{{WRAPPER}} ' . $btn => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);
		$this->end_controls_section();
	}

	/**
	 * Product van de pagina; in de editor (sjabloon zonder product) het nieuwste product met opties als voorbeeld.
	 */
	private function product() {
		global $product;
		if ( $product instanceof \WC_Product ) {
			return $product;
		}
		$p = wc_get_product( get_queried_object_id() );
		if ( $p ) {
			return $p;
		}
		if ( \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode() ) {
			foreach ( wc_get_products( array( 'limit' => 20, 'status' => 'publish', 'orderby' => 'date', 'order' => 'DESC' ) ) as $candidate ) {
				if ( \M7PA\Groups::for_product( $candidate ) ) {
					return $candidate;
				}
			}
		}
		return null;
	}

	protected function render() {
		global $product;
		$p = $this->product();
		if ( ! $p ) {
			if ( current_user_can( 'edit_posts' ) ) {
				echo '<p>' . esc_html__( 'M7 Product Add-Ons: geen product gevonden. Gebruik dit widget in een productsjabloon.', 'm7-product-addons' ) . '</p>';
			}
			return;
		}
		$saved   = $product;
		$product = $p; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- WooCommerce-sjabloon verwacht het product globaal.
		if ( 'yes' !== $this->get_settings_for_display( 'show_quantity' ) ) {
			echo '<style>.elementor-element-' . esc_attr( $this->get_id() ) . ' form.cart .quantity{display:none}</style>';
		}
		echo '<div class="m7pa-elementor-add-to-cart">';
		woocommerce_template_single_add_to_cart();
		echo '</div>';
		$product = $saved; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
	}
}
