<?php
/**
 * Oude bestellingen van Product Add-Ons Ultimate blijven hun keuzes tonen.
 *
 * Die plugin bewaarde per bestelregel `product_extras` (alles) en per veld een metaregel
 * `_<label>`. WooCommerce verbergt metasleutels met `_` voor klanten en e-mails, dus zonder de
 * oude plugin verdwijnen de keuzes daar. Wij tonen ze uit `product_extras`, en in beheer
 * halen we het `_` weg uit de labels. Alleen actief als de oude plugin niet meer draait.
 * Zie docs/ref-product-addons-ultimate.md §3.4.
 *
 * @package M7PA
 */

namespace M7PA;

defined( 'ABSPATH' ) || exit;

final class Legacy_Orders {

	public static function init() {
		if ( function_exists( 'pewc_get_extra_fields' ) ) {
			return; // Oude plugin is nog actief en toont het zelf.
		}
		add_action( 'woocommerce_order_item_meta_end', array( __CLASS__, 'customer_view' ), 10, 4 );
		add_filter( 'woocommerce_order_item_display_meta_key', array( __CLASS__, 'strip_underscore' ), 10, 3 );
		add_filter( 'woocommerce_order_item_get_formatted_meta_data', array( __CLASS__, 'admin_meta' ), 10, 2 );
		add_action( 'woocommerce_after_order_itemmeta', array( __CLASS__, 'admin_fallback' ), 10, 3 );
		add_filter( 'woocommerce_hidden_order_itemmeta', array( __CLASS__, 'hidden_keys' ) );
		// Winkelwagens die tijdens de overstap al opties van het origineel bevatten: prijs en keuzes behouden.
		add_action( 'woocommerce_before_calculate_totals', array( __CLASS__, 'legacy_cart_prices' ), 10 );
		add_filter( 'woocommerce_get_item_data', array( __CLASS__, 'legacy_cart_rows' ), 10, 2 );
		add_action( 'woocommerce_checkout_create_order_line_item', array( __CLASS__, 'legacy_order_meta' ), 10, 3 );
	}

	/**
	 * Prijs inclusief opties van een winkelwagenregel die nog met het origineel is toegevoegd.
	 *
	 * @param \WC_Cart $cart Winkelwagen.
	 */
	public static function legacy_cart_prices( $cart ) {
		if ( ! is_object( $cart ) || ! method_exists( $cart, 'get_cart' ) ) {
			return;
		}
		foreach ( $cart->get_cart() as $item ) {
			if ( isset( $item['product_extras']['price_with_extras'] ) && is_numeric( $item['product_extras']['price_with_extras'] ) && isset( $item['data'] ) && is_object( $item['data'] ) ) {
				$item['data']->set_price( (float) $item['product_extras']['price_with_extras'] );
			}
		}
	}

	/**
	 * Gekozen opties van zo'n regel in de winkelwagen tonen.
	 *
	 * @param array $data Regelgegevens.
	 * @param array $item Winkelwagenregel.
	 * @return array
	 */
	public static function legacy_cart_rows( $data, $item ) {
		if ( empty( $item['product_extras']['groups'] ) || ! is_array( $item['product_extras']['groups'] ) ) {
			return $data;
		}
		foreach ( $item['product_extras']['groups'] as $fields ) {
			foreach ( (array) $fields as $f ) {
				if ( ! is_array( $f ) || empty( $f['type'] ) || ! empty( $f['hidden'] ) || in_array( (string) $f['type'], array( 'products', 'product-categories', 'group_heading', 'information' ), true ) ) {
					continue;
				}
				$value = isset( $f['value'] ) ? $f['value'] : '';
				$value = is_array( $value ) ? implode( ', ', array_map( 'strval', $value ) ) : (string) $value;
				if ( '' === $value ) {
					continue;
				}
				$data[] = array(
					'name'  => isset( $f['label'] ) ? wp_strip_all_tags( (string) $f['label'] ) : '',
					'value' => esc_html( $value ),
				);
			}
		}
		return $data;
	}

	/**
	 * Bij afrekenen de oude gegevens op de bestelregel bewaren (dan toont rows() ze zoals bij oude bestellingen).
	 *
	 * @param \WC_Order_Item_Product $item   Bestelregel.
	 * @param string                 $key    Sleutel.
	 * @param array                  $values Winkelwagenregel.
	 */
	public static function legacy_order_meta( $item, $key, $values ) {
		if ( ! empty( $values['product_extras']['groups'] ) && is_object( $item ) && ! $item->get_meta( 'product_extras', true ) ) {
			$item->add_meta_data( 'product_extras', $values['product_extras'], true );
		}
	}

	/**
	 * Rijen uit product_extras: [label, waarde (HTML), prijs (HTML)].
	 *
	 * @param \WC_Order_Item $item   Regel.
	 * @param string         $where  'customer' of 'admin'.
	 * @return array
	 */
	public static function rows( $item, $where = 'customer' ) {
		$extras = $item->get_meta( 'product_extras', true );
		if ( ! is_array( $extras ) || empty( $extras['groups'] ) || ! is_array( $extras['groups'] ) ) {
			return array();
		}
		$rows = array();
		foreach ( $extras['groups'] as $fields ) {
			if ( ! is_array( $fields ) ) {
				continue;
			}
			foreach ( $fields as $f ) {
				if ( ! is_array( $f ) || empty( $f['type'] ) ) {
					continue;
				}
				$type = (string) $f['type'];
				if ( in_array( $type, array( 'products', 'product-categories', 'group_heading' ), true ) ) {
					continue;
				}
				if ( 'customer' === $where ) {
					if ( ! empty( $f['hidden'] ) ) {
						continue;
					}
					$vis = isset( $f['field_visibility'] ) ? $f['field_visibility'] : 'visible';
					if ( in_array( $vis, array( 'display_product', 'hide_customer' ), true ) ) {
						continue;
					}
				}
				$label = isset( $f['label'] ) ? (string) $f['label'] : '';
				if ( 'upload' === $type ) {
					$links = array();
					foreach ( isset( $f['files'] ) && is_array( $f['files'] ) ? $f['files'] : array() as $file ) {
						if ( ! empty( $file['url'] ) ) {
							$links[] = '<a href="' . esc_url( $file['url'] ) . '" target="_blank" rel="noopener">' . esc_html( ! empty( $file['display'] ) ? $file['display'] : ( isset( $file['name'] ) ? $file['name'] : basename( $file['url'] ) ) ) . '</a>';
						}
					}
					$value = implode( ', ', $links );
				} elseif ( 'checkbox' === $type || ( isset( $f['value'] ) && '__checked__' === $f['value'] ) ) {
					$value = '';
				} else {
					$value = isset( $f['value'] ) ? wp_kses_post( (string) $f['value'] ) : '';
				}
				$price = '';
				if ( isset( $f['price'] ) && is_numeric( $f['price'] ) && (float) $f['price'] > 0 && ( ! isset( $f['price_visibility'] ) || 'hidden' !== $f['price_visibility'] ) ) {
					$price = wc_price( (float) $f['price'] );
				}
				$rows[] = array( $label, $value, $price, $type );
			}
		}
		return $rows;
	}

	private static function render( array $rows ) {
		$html = '<ul class="m7pa-legacy-extras" style="margin:.4em 0 0 1em;padding:0">';
		foreach ( $rows as $r ) {
			$html .= '<li class="' . esc_attr( $r[3] ) . '"><span class="m7pa-legacy-label">' . esc_html( $r[0] ) . ( '' !== $r[1] ? ':' : '' ) . '</span> ' . $r[1] . ( $r[2] ? ' <span class="m7pa-legacy-price">' . $r[2] . '</span>' : '' ) . '</li>';
		}
		return $html . '</ul>';
	}

	/**
	 * Klant: Mijn account, bedankpagina en e-mails.
	 */
	public static function customer_view( $item_id, $item, $order, $plain_text = false ) {
		if ( $item->get_meta( '_m7pa', true ) ) {
			return; // Nieuwe bestelling: WooCommerce toont onze eigen zichtbare meta al.
		}
		$rows = self::rows( $item, 'customer' );
		if ( ! $rows ) {
			return;
		}
		if ( $plain_text ) {
			foreach ( $rows as $r ) {
				echo "\n" . esc_html( $r[0] ) . ( '' !== $r[1] ? ': ' . wp_strip_all_tags( $r[1] ) : '' ) . ( $r[2] ? ' ' . wp_strip_all_tags( $r[2] ) : '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			return;
		}
		echo self::render( $rows ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- render() escapet.
	}

	/**
	 * Beheer: "_Label" tonen als "Label" bij regels met product_extras.
	 */
	public static function strip_underscore( $display_key, $meta, $item ) {
		if ( is_string( $display_key ) && '_' === substr( $display_key, 0, 1 ) && $item && is_callable( array( $item, 'get_meta' ) ) && $item->get_meta( 'product_extras', true ) ) {
			return substr( $display_key, 1 );
		}
		return $display_key;
	}

	public static function admin_meta( $formatted, $item ) {
		foreach ( $formatted as $id => $meta ) {
			if ( in_array( $meta->key, array( '_pewc_product_extra_id', 'product_extras' ), true ) ) {
				unset( $formatted[ $id ] );
			}
		}
		return $formatted;
	}

	public static function hidden_keys( $keys ) {
		$keys[] = '_pewc_product_extra_id';
		$keys[] = 'product_extras';
		$keys[] = '_m7pa';
		$keys[] = '_m7pa_parent_cart_key';
		return $keys;
	}

	/**
	 * Beheer, bestellingen van vóór 3.7 (alleen product_extras, geen losse metaregels).
	 */
	public static function admin_fallback( $item_id, $item, $product ) {
		if ( ! $item instanceof \WC_Order_Item_Product || ! $item->get_meta( 'product_extras', true ) ) {
			return;
		}
		$rows = self::rows( $item, 'admin' );
		if ( ! $rows ) {
			return;
		}
		$first = '_' . $rows[0][0];
		if ( '' !== (string) $item->get_meta( $first, true ) || '' !== (string) $item->get_meta( $rows[0][0], true ) ) {
			return; // Losse metaregels bestaan al; WooCommerce toont die.
		}
		echo self::render( $rows ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
