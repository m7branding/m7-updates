<?php
/**
 * Veld "gekoppelde producten" op de productpagina (weergaven zoals Product Add-Ons Ultimate:
 * checkboxes met afbeeldingen, checkboxlijst, radio met afbeeldingen, radiolijst en keuzelijst).
 * Weergaven die M7 (nog) niet zelf tekent (kolom, componenten, swatches, variabele keuzelijst,
 * raster) worden als checkboxes met afbeeldingen getoond.
 *
 * Invoernamen: {id}_child_product[] (keuzelijst: {id}_child_product) en per product
 * {id}_child_quantity_<product-ID> bij eigen aantallen.
 *
 * @package M7PA
 */

namespace M7PA;

defined( 'ABSPATH' ) || exit;

final class Frontend_Products {

	/** Prijs van een gekoppeld product na korting (zelfde rekenwijze als het origineel). */
	public static function discounted( $price, $discount, $type ) {
		$price    = (float) $price;
		$discount = (float) $discount;
		if ( ! $discount ) {
			return $price;
		}
		if ( 'fixed' === $type ) {
			return max( 0, $price - $discount );
		}
		return max( 0, $price - ( $price * $discount / 100 ) );
	}

	/**
	 * Gegevens per gekoppeld product: [product, weergaveprijs, prijs na korting, prijs-HTML, uitgeschakeld].
	 */
	public static function children( array $f ) {
		$out = array();
		foreach ( $f['products']['ids'] as $pid ) {
			$p = wc_get_product( $pid );
			if ( ! $p || 'publish' !== get_post_status( $p->is_type( 'variation' ) ? $p->get_parent_id() : $p->get_id() ) ) {
				continue;
			}
			$price = Frontend::maybe_tax( $p, $p->get_price() );
			if ( $f['products']['discount'] ) {
				$cost = self::discounted( $price, $f['products']['discount'], $f['products']['discount_type'] );
				$html = wc_format_sale_price( $price, $cost );
			} else {
				$cost = $price;
				$html = $p->get_price_html();
			}
			$out[] = array(
				'id'       => (int) $pid,
				'product'  => $p,
				'cost'     => $cost,
				'html'     => $html,
				'disabled' => ! $p->is_purchasable() || ( ! $p->is_in_stock() && ! $p->backorders_allowed() ),
			);
		}
		return $out;
	}

	private static function selected( $value ) {
		$value = is_array( $value ) ? $value : ( '' === (string) $value ? array() : explode( ',', (string) $value ) );
		return array_map( 'intval', $value );
	}

	public static function render( array $c ) {
		$f      = $c['f'];
		$layout = $f['products']['layout'];
		$qty    = 'one' === $f['products']['quantities'] ? 'one-only' : $f['products']['quantities'];
		$value  = self::selected( $c['value'] );
		if ( in_array( $layout, array( 'checkboxes-list' ), true ) ) {
			self::checkboxes_list( $c, $qty, $value );
		} elseif ( 'radio' === $layout ) {
			self::radio( $c, $qty, $value );
		} elseif ( 'radio-list' === $layout ) {
			self::radio_list( $c, $qty, $value );
		} elseif ( in_array( $layout, array( 'select', 'variable-select' ), true ) ) {
			self::select( $c, $qty, $value );
		} else {
			self::checkboxes( $c, $qty, $value );
		}
		// Instellingen zoals het origineel ze meestuurt (de server gebruikt de opgeslagen waarden).
		$dom = $c['dom'];
		echo "\n\t" . '<input type="hidden" name="' . esc_attr( $dom ) . '_quantities" value="' . esc_attr( $qty ) . '">' . "\n";
		echo '<input type="hidden" name="' . esc_attr( $dom ) . '_allow_none" value="' . ( $f['required'] ? '' : '1' ) . '">' . "\n";
		echo "\n";
	}

	private static function wrapper_classes( array $base, array $f, $qty, $with_columns = true ) {
		if ( $with_columns ) {
			$base[] = 'm7pa-columns-' . (int) $f['products']['columns'];
		}
		if ( $f['products']['hide_labels'] ) {
			$base[] = 'm7pa-hide-labels';
		}
		$base[] = 'products-quantities-' . $qty;
		return implode( ' ', $base );
	}

	private static function name( array $child ) {
		return esc_html( get_the_title( $child['id'] ) ) . Frontend::separator() . '<span class="m7pa-child-product-price-label">' . $child['html'] . '</span>';
	}

	private static function qty_input( array $c, array $child, $qty_value ) {
		$f   = $c['f'];
		$min = '' !== $f['products']['min_qty'] ? (int) $f['products']['min_qty'] : 0;
		$max = '' !== $f['products']['max_qty'] ? ' max="' . (int) $f['products']['max_qty'] . '"' : '';
		$p   = $child['product'];
		if ( '' === $max && $p->managing_stock() && $p->get_stock_quantity() > 0 && ! $p->backorders_allowed() ) {
			$max = ' max="' . (int) $p->get_stock_quantity() . '"';
		}
		return '<input type="number" min="' . $min . '" step="1" ' . $max . ' class="m7pa-form-field m7pa-child-quantity-field" name="' . esc_attr( $c['dom'] . '_child_quantity_' . $child['id'] ) . '" value="' . (int) $qty_value . '" ' . ( $child['disabled'] ? 'disabled' : '' ) . ' aria-label="' . esc_attr( wp_strip_all_tags( get_the_title( $child['id'] ) ) . ' ' . __( 'Aantal', 'm7-product-addons' ) ) . '" data-default-quantity="' . (int) $qty_value . '">';
	}

	private static function qty_value( array $c, $child_id, array $value ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$posted = isset( $_POST[ $c['dom'] . '_child_quantity_' . $child_id ] ) ? absint( $_POST[ $c['dom'] . '_child_quantity_' . $child_id ] ) : null;
		if ( null !== $posted ) {
			return $posted;
		}
		return in_array( $child_id, $value, true ) ? max( 1, (int) $c['f']['products']['default_qty'] ) : 0;
	}

	private static function checkboxes( array $c, $qty, array $value ) {
		$f   = $c['f'];
		$dom = $c['dom'];
		echo "\n" . '<div class="' . esc_attr( self::wrapper_classes( array( 'm7pa-checkboxes-images-wrapper', 'child-product-wrapper' ), $f, $qty ) ) . '" data-products-quantities="' . esc_attr( $qty ) . '">' . "\n";
		foreach ( self::children( $f ) as $child ) {
			$cid     = $dom . '_' . $child['id'];
			$wrap    = array( 'm7pa-checkbox-image-wrapper', 'm7pa-radio-checkbox-image-wrapper', 'm7pa-checkbox-wrapper' );
			$checked = in_array( $child['id'], $value, true );
			$qv      = 'independent' === $qty ? self::qty_value( $c, $child['id'], $value ) : 0;
			if ( $child['disabled'] ) {
				$wrap[] = 'm7pa-checkbox-disabled';
			}
			if ( $qv > 0 ) {
				$checked = true;
			}
			if ( $checked ) {
				$wrap[] = 'checked';
			}
			$image = Frontend::swatch_image( get_post_thumbnail_id( $child['id'] ) );
			echo '<div class="' . esc_attr( implode( ' ', $wrap ) ) . '"><label for="' . esc_attr( $cid ) . '"><input data-option-cost="' . esc_attr( self::num( $child['cost'] ) ) . '" data-field-label="' . esc_attr( get_the_title( $child['id'] ) ) . '" data-stock="" type="checkbox" name="' . esc_attr( $dom ) . '_child_product[]" id="' . esc_attr( $cid ) . '" class="m7pa-checkbox-form-field" value="' . (int) $child['id'] . '" ' . ( $checked ? 'checked="checked"' : '' ) . ' ' . ( $child['disabled'] ? 'disabled' : '' ) . '>' . $image . '<span class="m7pa-theme-element"></span></label><div class="m7pa-checkbox-desc-wrapper">' . ( 'independent' === $qty ? self::qty_input( $c, $child, $qv ) : '' ) . '<div class="m7pa-radio-image-desc">' . self::name( $child ) . '</div></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo "\n</div><!-- .m7pa-radio-images-wrapper -->\n";
	}

	private static function checkboxes_list( array $c, $qty, array $value ) {
		$f   = $c['f'];
		$dom = $c['dom'];
		echo "\n" . '<div class="' . esc_attr( self::wrapper_classes( array( 'm7pa-checkboxes-list-wrapper', 'm7pa-checkboxes-images-wrapper', 'child-product-wrapper' ), $f, $qty ) ) . '" data-products-quantities="' . esc_attr( $qty ) . '">' . "\n\n\n";
		foreach ( self::children( $f ) as $child ) {
			$cid     = $dom . '_' . $child['id'];
			$wrap    = array( 'm7pa-checkbox-wrapper' );
			$checked = in_array( $child['id'], $value, true );
			$qv      = 'independent' === $qty ? self::qty_value( $c, $child['id'], $value ) : 0;
			if ( $child['disabled'] ) {
				$wrap[] = 'm7pa-checkbox-disabled';
			}
			if ( $qv > 0 ) {
				$checked = true;
			}
			echo '<div class="' . esc_attr( implode( ' ', $wrap ) ) . '">
				<label for="' . esc_attr( $cid ) . '">
					<input data-option-cost="' . esc_attr( self::num( $child['cost'] ) ) . '" data-field-label="' . esc_attr( get_the_title( $child['id'] ) ) . '" data-stock="" type="checkbox" name="' . esc_attr( $dom ) . '_child_product[]" id="' . esc_attr( $cid ) . '" class="m7pa-checkbox-form-field" value="' . (int) $child['id'] . '" ' . ( $checked ? 'checked="checked"' : '' ) . ' ' . ( $child['disabled'] ? 'disabled' : '' ) . '>
					<span class="m7pa-theme-element"></span>
					<div class="m7pa-checkboxes-list-desc-wrapper">' . ( 'independent' === $qty ? self::qty_input( $c, $child, $qv ) : '' ) . '
						<div class="m7pa-checkboxes-list-desc">' . self::name( $child ) . '</div>
					</div>
				</label>
			</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo "\n</div><!-- .m7pa-radio-images-wrapper -->\n";
	}

	private static function radio( array $c, $qty, array $value ) {
		$f   = $c['f'];
		$dom = $c['dom'];
		echo "\n" . '<div class="' . esc_attr( self::wrapper_classes( array( 'm7pa-radio-images-wrapper', 'child-product-wrapper' ), $f, $qty ) ) . '" data-products-quantities="' . esc_attr( $qty ) . '">' . "\n\n";
		$last = 0;
		foreach ( self::children( $f ) as $child ) {
			$cid     = $dom . '_' . $child['id'];
			$wrap    = array( 'm7pa-radio-wrapper', 'm7pa-radio-image-wrapper', 'm7pa-radio-checkbox-image-wrapper' );
			$checked = in_array( $child['id'], $value, true );
			if ( $child['disabled'] ) {
				$wrap[] = 'm7pa-checkbox-disabled';
			}
			if ( $checked ) {
				$wrap[] = 'checked';
			}
			$last  = $child;
			$image = Frontend::swatch_image( get_post_thumbnail_id( $child['id'] ) );
			echo '<div class="' . esc_attr( implode( ' ', $wrap ) ) . '" ' . self::dimensions( $child['product'] ) . '><label for="' . esc_attr( $cid ) . '"><input ' . ( $child['disabled'] ? 'disabled' : '' ) . ' data-stock="" data-option-cost="' . esc_attr( self::num( $child['cost'] ) ) . '" data-field-label="' . esc_attr( get_the_title( $child['id'] ) ) . '" type="radio" name="' . esc_attr( $dom ) . '_child_product[]" id="' . esc_attr( $cid ) . '" class="m7pa-radio-form-field" value="' . (int) $child['id'] . '" ' . ( $checked ? 'checked="checked"' : '' ) . '>' . $image . '<span class="m7pa-theme-element"></span></label><div class="m7pa-radio-image-desc">' . self::name( $child ) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo "\n</div><!-- .m7pa-radio-images-wrapper -->\n";
		if ( 'independent' === $qty && $last ) {
			echo self::qty_input( $c, $last, $value ? 1 : 0 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo "\n";
	}

	private static function radio_list( array $c, $qty, array $value ) {
		$f   = $c['f'];
		$dom = $c['dom'];
		echo "\n" . '<div class="' . esc_attr( self::wrapper_classes( array( 'm7pa-radio-list-wrapper', 'm7pa-radio-images-wrapper', 'child-product-wrapper' ), $f, $qty ) ) . '" data-products-quantities="' . esc_attr( $qty ) . '">' . "\n\n";
		$last = 0;
		foreach ( self::children( $f ) as $child ) {
			$cid     = $dom . '_' . $child['id'];
			$wrap    = array( 'm7pa-radio-wrapper' );
			$checked = in_array( $child['id'], $value, true );
			if ( $child['disabled'] ) {
				$wrap[] = 'm7pa-checkbox-disabled';
			}
			$last = $child;
			echo '<div class="' . esc_attr( implode( ' ', $wrap ) ) . '" ' . self::dimensions( $child['product'] ) . '><label for="' . esc_attr( $cid ) . '" class="m7pa-radio-list-label-wrapper">
				<input ' . ( $child['disabled'] ? 'disabled' : '' ) . ' data-stock="" data-option-cost="' . esc_attr( self::num( $child['cost'] ) ) . '" data-field-label="' . esc_attr( get_the_title( $child['id'] ) ) . '" type="radio" name="' . esc_attr( $dom ) . '_child_product[]" id="' . esc_attr( $cid ) . '" class="m7pa-radio-form-field" value="' . (int) $child['id'] . '" ' . ( $checked ? 'checked="checked"' : '' ) . '>
				<span class="m7pa-theme-element"></span>
				<div class="m7pa-radio-list-desc-wrapper">' . self::name( $child ) . '</div>
			</label></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo "\n</div><!-- .m7pa-radio-images-wrapper -->\n";
		if ( 'independent' === $qty && $last ) {
			echo self::qty_input( $c, $last, $value ? 1 : 0 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	private static function select( array $c, $qty, array $value ) {
		$f   = $c['f'];
		$dom = $c['dom'];
		echo "\n" . '<div class="child-product-wrapper products-quantities-' . esc_attr( $qty ) . '" data-products-quantities="' . esc_attr( $qty ) . '">';
		echo "\n\t" . '<div class="m7pa-select-wrapper">' . "\n\t\t" . '<select class="m7pa-form-field m7pa-child-select-field" id="' . esc_attr( $dom ) . '" name="' . esc_attr( $dom ) . '_child_product">' . "\n\t\t";
		if ( '' !== $f['products']['placeholder'] ) {
			echo '<option value="">' . esc_html( $f['products']['placeholder'] ) . '</option>';
		}
		$last = 0;
		foreach ( self::children( $f ) as $child ) {
			$last = $child;
			$name = esc_html( get_the_title( $child['id'] ) ) . Frontend::separator() . Frontend::plain_price( $child['cost'] );
			echo '<option data-option-cost="' . esc_attr( self::num( $child['cost'] ) ) . '" ' . ( $child['disabled'] ? 'disabled' : '' ) . ' ' . ( in_array( $child['id'], $value, true ) ? 'selected' : '' ) . ' data-field-value="' . esc_attr( get_the_title( $child['id'] ) ) . '" value="' . (int) $child['id'] . '" data-stock="" class="">' . $name . '</option>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo "\n\t\t</select>\n\t</div><!--/m7pa-select-wrapper -->\n\n\t";
		if ( 'independent' === $qty && $last ) {
			echo self::qty_input( $c, $last, 1 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo "\n</div><!-- .child-product-wrapper -->";
	}

	private static function dimensions( $p ) {
		return 'data-product-weight="' . esc_attr( $p->get_weight() ) . '" data-product-length="' . esc_attr( $p->get_length() ) . '" data-product-width="' . esc_attr( $p->get_width() ) . '" data-product-height="' . esc_attr( $p->get_height() ) . '"';
	}

	private static function num( $v ) {
		return (string) ( 0 + $v );
	}
}
