<?php
/**
 * Algemene instellingen (M7 > Product Add-Ons > Instellingen).
 *
 * De standaardwaarden volgen Product Add-Ons Ultimate op een winkel waar de instellingen nooit zijn
 * opgeslagen, zodat een site na overstappen hetzelfde blijft. De overstap (Importer_Pewc::import_settings)
 * neemt de echte waarden van die plugin over, ook de Customizer-opmaak. Instellingen zonder veld op
 * het scherm blijven bij opslaan behouden.
 *
 * @package M7PA
 */

namespace M7PA;

defined( 'ABSPATH' ) || exit;

final class Settings {

	const OPTION = 'm7pa_settings';

	/** @var array|null Per verzoek. */
	private static $cache = null;

	public static function defaults() {
		return array(
			'show_totals'          => 'all',   // all | total | none.
			'label_product'        => '',      // Leeg = "Product totaal".
			'label_options'        => '',      // Leeg = "Opties totaal".
			'label_flatrate'       => '',      // Leeg = "Vast bedrag totaal".
			'label_grand'          => '',      // Leeg = "Totaal generaal".
			'show_option_prices'   => true,
			'show_prices_in_cart'  => true,
			'show_prices_in_order' => true,
			'archive_button_text'  => __( 'Opties selecteren', 'm7-product-addons' ),
			'style'                => 'simple', // simple | theme.
			'accent'               => '#2196F3',
			'price_separator'      => '+',
			'separator_unsaved'    => false,   // Origineel: scheidingsteken nooit opgeslagen (script toont dan twee spaties zonder +).
			'hide_zero'            => false,   // Prijs 0 niet tonen in winkelwagen/bestelling.
			'hide_field_prices'    => false,   // Bij radio/keuzelijst alleen de optieprijs in de winkelwagen.
			'update_price_label'   => false,   // Hoofdprijs vervangen door het totaal.
			'price_label'          => '',
			'price_display'        => 'before', // before | after | hide.
			'group_title_tag'      => 'h3',
			'require_login_upload' => false,
			'max_upload_mb'        => 10,
			'reset_fields'         => false,
			'tooltips'             => false,
			'replace_image'        => false,   // Alle afbeeldingskeuzes vervangen de hoofdafbeelding.   // Beschrijving als vraagteken-icoon naast het label.
			'cart_group_titles'    => false,
			'child_as_meta'        => false,
			'multiply_independent' => false,
			'show_inputs'          => false,
			'circular_swatches'    => false,
			// Opmaak uit de Customizer van Product Add-Ons Ultimate.
			'design'               => array(
				'group_title_color'       => '#333',
				'group_title_size'        => '32',
				'group_title_background'  => '',
				'group_description_color' => '#222',
				'group_description_size'  => '18',
				'hide_group_title'        => false,
				'next_button'             => '#eee',
				'previous_button'         => '#eee',
				'step_button_text'        => '#222',
				'step_tab'                => '#f9f9f9',
				'active_step_tab'         => '#f1f1f1',
				'tab'                     => '#f1f1f1',
				'active_tab'              => '#fff',
				'justify_tabs'            => false,
				'accordion_icon'          => '#222',
				'accordion_icon_size'     => '0.3',
				'products_border'         => '#2196f3',
				'swatch_padding'          => '8',
				'swatch_border_width'     => '0',
				'swatch_width'            => '0',
				'color_swatch_width'      => '60',
				'color_swatch_height'     => '60',
				'textarea_height'         => '',
				'text_width'              => false,
				'number_width'            => false,
				'select_width'            => false,
				'block_label'             => false,
				'list_margin_left'        => '',
				'list_margin_bottom'      => '',
				'list_padding'            => '',
				'list_background'         => '',
				'field_margin_left'       => '',
				'field_margin_bottom'     => '',
				'field_padding_top'       => '',
				'field_padding_left'      => '',
				'field_background'        => '',
				'text_colour'             => '',
				'quantity_layout'         => 'block',
			),
		);
	}

	public static function all() {
		if ( null === self::$cache ) {
			$saved = (array) get_option( self::OPTION, array() );
			$d     = self::defaults();
			$all   = wp_parse_args( $saved, $d );
			$all['design'] = wp_parse_args( isset( $saved['design'] ) && is_array( $saved['design'] ) ? $saved['design'] : array(), $d['design'] );
			// Oude waarden (versie 0.1): aan/uit voor totalen, stijl "m7".
			if ( true === $all['show_totals'] || '1' === (string) $all['show_totals'] ) {
				$all['show_totals'] = 'all';
			} elseif ( false === $all['show_totals'] || '' === (string) $all['show_totals'] || '0' === (string) $all['show_totals'] ) {
				$all['show_totals'] = 'none';
			}
			if ( 'm7' === $all['style'] ) {
				$all['style'] = 'simple';
			}
			self::$cache = $all;
		}
		return self::$cache;
	}

	public static function get( $key ) {
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	public static function design( $key ) {
		$all = self::all();
		return isset( $all['design'][ $key ] ) ? $all['design'][ $key ] : null;
	}

	public static function flush() {
		self::$cache = null;
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'update_option_' . self::OPTION, array( __CLASS__, 'flush' ) );
		add_action( 'add_option_' . self::OPTION, array( __CLASS__, 'flush' ) );
	}

	public static function menu() {
		add_submenu_page( 'm7', __( 'Product Add-Ons: instellingen', 'm7-product-addons' ), __( 'Instellingen', 'm7-product-addons' ), 'manage_woocommerce', 'm7pa-settings', array( __CLASS__, 'page' ) );
	}

	public static function register() {
		register_setting(
			'm7pa_settings',
			self::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
			)
		);
	}

	/**
	 * Opschonen. Velden van het instellingenscherm worden bijgewerkt; de rest (o.a. overgenomen
	 * opmaak) blijft staan.
	 */
	public static function sanitize( $raw ) {
		$raw     = is_array( $raw ) ? $raw : array();
		$current = self::all();
		$out     = $current;
		if ( isset( $raw['_screen'] ) ) {
			$out['show_totals']          = empty( $raw['show_totals'] ) ? 'none' : ( 'none' === $current['show_totals'] ? 'all' : $current['show_totals'] );
			$out['show_option_prices']   = ! empty( $raw['show_option_prices'] );
			$out['show_prices_in_cart']  = ! empty( $raw['show_prices_in_cart'] );
			$out['show_prices_in_order'] = ! empty( $raw['show_prices_in_order'] );
			$out['archive_button_text']  = isset( $raw['archive_button_text'] ) ? sanitize_text_field( $raw['archive_button_text'] ) : '';
			$out['style']                = ( isset( $raw['style'] ) && 'theme' === $raw['style'] ) ? 'theme' : 'simple';
			return $out;
		}
		// Volledige set (bijv. vanuit de overstap).
		return self::clean( array_merge( $current, $raw ) );
	}

	/**
	 * Alle sleutels opschonen (gebruikt door de overstap).
	 */
	public static function clean( array $s ) {
		$d   = self::defaults();
		$out = array();
		foreach ( $d as $k => $default ) {
			$v = isset( $s[ $k ] ) ? $s[ $k ] : $default;
			if ( 'design' === $k ) {
				$v   = is_array( $v ) ? $v : array();
				$des = array();
				foreach ( $default as $dk => $dv ) {
					$x          = isset( $v[ $dk ] ) ? $v[ $dk ] : $dv;
					$des[ $dk ] = is_bool( $dv ) ? (bool) $x : sanitize_text_field( (string) $x );
				}
				$out['design'] = $des;
			} elseif ( is_bool( $default ) ) {
				$out[ $k ] = (bool) $v;
			} elseif ( is_int( $default ) ) {
				$out[ $k ] = max( 0, (int) $v );
			} else {
				$out[ $k ] = sanitize_text_field( (string) $v );
			}
		}
		$out['show_totals']     = in_array( $out['show_totals'], array( 'all', 'total', 'none' ), true ) ? $out['show_totals'] : 'all';
		$out['style']           = 'theme' === $out['style'] ? 'theme' : 'simple';
		$out['price_display']   = in_array( $out['price_display'], array( 'before', 'after', 'hide' ), true ) ? $out['price_display'] : 'before';
		$out['group_title_tag'] = in_array( $out['group_title_tag'], array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'div', 'span' ), true ) ? $out['group_title_tag'] : 'h3';
		$out['accent']          = sanitize_hex_color( $out['accent'] ) ? sanitize_hex_color( $out['accent'] ) : '#2196F3';
		return $out;
	}

	public static function page() {
		$s    = self::all();
		$name = static function ( $k ) {
			return esc_attr( self::OPTION . '[' . $k . ']' );
		};
		?>
		<div class="wrap m7-admin">
			<h1 class="screen-reader-text"><?php esc_html_e( 'Product Add-Ons: instellingen', 'm7-product-addons' ); ?></h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'm7pa_settings' ); ?>
				<input type="hidden" name="<?php echo $name( '_screen' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" value="1">
				<table class="form-table" role="presentation">
					<?php
					$checks = array(
						'show_totals'          => array( __( 'Totalen tonen op de productpagina (product, opties, totaal)', 'm7-product-addons' ), 'none' !== $s['show_totals'] ),
						'show_option_prices'   => array( __( 'Prijs naast opties tonen', 'm7-product-addons' ), $s['show_option_prices'] ),
						'show_prices_in_cart'  => array( __( 'Prijs van opties tonen in winkelwagen', 'm7-product-addons' ), $s['show_prices_in_cart'] ),
						'show_prices_in_order' => array( __( 'Prijs van opties tonen in bestelling en e-mails', 'm7-product-addons' ), $s['show_prices_in_order'] ),
					);
					foreach ( $checks as $key => $row ) :
						?>
						<tr><th scope="row"><?php echo esc_html( $row[0] ); ?></th><td><input type="checkbox" name="<?php echo $name( $key ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" value="1" <?php checked( $row[1] ); ?>></td></tr>
					<?php endforeach; ?>
					<tr><th scope="row"><?php esc_html_e( 'Knoptekst in winkeloverzicht', 'm7-product-addons' ); ?></th><td><input type="text" class="regular-text" name="<?php echo $name( 'archive_button_text' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" value="<?php echo esc_attr( $s['archive_button_text'] ); ?>"><p class="description"><?php esc_html_e( 'Producten met verplichte opties sturen vanuit de winkel naar de productpagina.', 'm7-product-addons' ); ?></p></td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Opmaak op de site', 'm7-product-addons' ); ?></th><td><select name="<?php echo $name( 'style' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>"><option value="simple" <?php selected( $s['style'], 'simple' ); ?>><?php esc_html_e( 'Standaard (zoals Product Add-Ons Ultimate)', 'm7-product-addons' ); ?></option><option value="theme" <?php selected( $s['style'], 'theme' ); ?>><?php esc_html_e( 'Alleen thema-opmaak', 'm7-product-addons' ); ?></option></select></td></tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}
