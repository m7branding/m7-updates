<?php
/**
 * Winkelwagen en bestelling: validatie, prijs per regel, eenmalige toeslagen, gekoppelde producten als
 * eigen regels, weergave van keuzes en opslag in de bestelling.
 *
 * Weergave en opslag volgen Product Add-Ons Ultimate (met m7pa- in klassen):
 * - winkelwagen: per veld "Label" met de waarde en " € x" in <span class="m7pa-cart-item-price">;
 * - eenmalige bedragen (flat rate) zijn een toeslag "<product>: <label>", één keer per veld;
 * - bestelregel: per veld een meta "_<label>" met "waarde € x" (beheer toont hem zonder "_"), en voor
 *   klanten/e-mails een lijst achter de productnaam.
 *
 * Cart item data:
 *   m7pa        => [items, per_unit, flat, flat_items, set_price, children(at add), child_keys]
 *   m7pa_parent => cart key van het hoofdproduct (bij gekoppelde producten)
 *   m7pa_child  => [field_id, field_label, mode, discount, discount_type]
 *
 * @package M7PA
 */

namespace M7PA;

defined( 'ABSPATH' ) || exit;

final class Cart {

	/** @var array Selectie per product binnen dit verzoek (validatie → cart data). */
	private static $pending = array();

	/** @var bool Bezig met toevoegen van gekoppelde producten. */
	private static $adding_children = false;

	public static function init() {
		add_filter( 'woocommerce_add_to_cart_validation', array( __CLASS__, 'validate' ), 10, 5 );
		add_filter( 'woocommerce_add_cart_item_data', array( __CLASS__, 'add_cart_item_data' ), 10, 4 );
		add_action( 'woocommerce_add_to_cart', array( __CLASS__, 'add_children' ), 10, 6 );
		add_filter( 'woocommerce_get_cart_item_from_session', array( __CLASS__, 'from_session' ), 10, 2 );
		add_action( 'woocommerce_before_calculate_totals', array( __CLASS__, 'set_prices' ), 10 );
		add_action( 'woocommerce_before_mini_cart_contents', array( __CLASS__, 'mini_cart_prices' ), 11 );
		add_action( 'woocommerce_cart_calculate_fees', array( __CLASS__, 'fees' ), 25 );
		add_filter( 'woocommerce_get_item_data', array( __CLASS__, 'item_data' ), 10, 2 );
		add_action( 'woocommerce_cart_item_removed', array( __CLASS__, 'remove_children' ), 10, 2 );
		add_action( 'woocommerce_after_cart_item_quantity_update', array( __CLASS__, 'sync_children' ), 10, 3 );
		add_filter( 'woocommerce_cart_item_quantity', array( __CLASS__, 'child_quantity' ), 10, 3 );
		add_filter( 'woocommerce_cart_item_remove_link', array( __CLASS__, 'child_remove_link' ), 10, 2 );
		add_filter( 'woocommerce_cart_item_class', array( __CLASS__, 'item_class' ), 10, 2 );
		add_filter( 'woocommerce_store_api_product_quantity_editable', array( __CLASS__, 'store_api_qty_editable' ), 10, 3 );
		add_action( 'woocommerce_checkout_create_order_line_item', array( __CLASS__, 'order_line_item' ), 10, 4 );
		add_filter( 'woocommerce_order_item_name', array( __CLASS__, 'order_item_name' ), 10, 2 );
		add_filter( 'woocommerce_order_item_display_meta_key', array( __CLASS__, 'order_meta_key' ), 10, 3 );
		add_filter( 'woocommerce_hidden_order_itemmeta', array( __CLASS__, 'hidden_meta' ) );
		add_filter( 'woocommerce_order_again_cart_item_data', array( __CLASS__, 'order_again' ), 10, 3 );
	}

	/* ------------------------------ toevoegen ------------------------------ */

	private static function attributes_from_request() {
		$attrs = array();
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		foreach ( $_POST as $key => $value ) {
			if ( is_string( $key ) && 0 === strpos( $key, 'attribute_' ) && is_string( $value ) ) {
				$attrs[ substr( $key, 10 ) ] = sanitize_title( wp_unslash( $value ) );
			}
		}
		return $attrs;
	}

	public static function validate( $passed, $product_id, $quantity, $variation_id = 0, $variations = array() ) {
		if ( self::$adding_children || ! $passed ) {
			return $passed;
		}
		$groups = Groups::for_product( $product_id );
		if ( ! $groups ) {
			return $passed;
		}
		$product = wc_get_product( $variation_id ? $variation_id : $product_id );
		if ( ! $product ) {
			return $passed;
		}
		$attrs = $variations ? array_map( 'sanitize_title', array_combine( array_map( static function ( $k ) {
			return preg_replace( '/^attribute_/', '', $k );
		}, array_keys( $variations ) ), array_values( $variations ) ) ) : self::attributes_from_request();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce controleert het formulier; Selection schoont per veldtype op.
		$post      = wp_unslash( $_POST );
		$selection = Selection::build(
			$groups,
			is_array( $post ) ? $post : array(),
			array(
				'product'      => $product,
				'quantity'     => (int) $quantity,
				'attributes'   => $attrs,
				'variation_id' => (int) $variation_id,
			)
		);

		foreach ( $selection['errors'] as $error ) {
			wc_add_notice( $error, 'error' );
		}
		if ( $selection['errors'] ) {
			return false;
		}
		foreach ( $selection['children'] as $child ) {
			$cp = wc_get_product( $child['product_id'] );
			if ( ! $cp || ! $cp->is_purchasable() || ( ! $cp->is_in_stock() && ! $cp->backorders_allowed() ) ) {
				wc_add_notice( __( 'Het product is niet aan de winkelwagen toegevoegd omdat een of meer onderdelen niet op voorraad zijn.', 'm7-product-addons' ), 'error' );
				return false;
			}
		}
		self::$pending[ (int) $product_id . ':' . (int) $variation_id ] = $selection;
		return $passed;
	}

	public static function add_cart_item_data( $data, $product_id, $variation_id, $quantity ) {
		if ( self::$adding_children ) {
			return $data;
		}
		$key = (int) $product_id . ':' . (int) $variation_id;
		if ( ! isset( self::$pending[ $key ] ) ) {
			return $data;
		}
		$s = self::$pending[ $key ];
		unset( self::$pending[ $key ] );
		if ( ! $s['items'] && ! $s['children'] ) {
			return $data;
		}
		$data['m7pa'] = array(
			'items'      => $s['items'],
			'per_unit'   => $s['per_unit'],
			'flat'       => $s['flat'],
			'flat_items' => $s['flat_items'],
			'set_price'  => $s['set_price'],
			'children'   => $s['children'],
			'child_keys' => array(),
		);
		if ( $s['children'] ) {
			// Elke keuze met gekoppelde producten wordt een eigen regel (niet samenvoegen).
			$data['m7pa']['uid'] = wp_generate_uuid4();
		}
		return $data;
	}

	public static function add_children( $cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data ) {
		if ( self::$adding_children || empty( $cart_item_data['m7pa']['children'] ) ) {
			return;
		}
		$cart = WC()->cart;
		if ( ! empty( $cart->cart_contents[ $cart_item_key ]['m7pa']['child_keys'] ) ) {
			return; // Bestond al; WooCommerce verhoogde alleen het aantal (sync_children regelt de rest).
		}
		self::$adding_children = true;
		$keys                  = array();
		foreach ( $cart_item_data['m7pa']['children'] as $child ) {
			$cp = wc_get_product( $child['product_id'] );
			if ( ! $cp ) {
				continue;
			}
			$parent_id = $cp->is_type( 'variation' ) ? $cp->get_parent_id() : $cp->get_id();
			$var_id    = $cp->is_type( 'variation' ) ? $cp->get_id() : 0;
			$attrs     = $cp->is_type( 'variation' ) ? $cp->get_variation_attributes() : array();
			$key       = $cart->add_to_cart(
				$parent_id,
				$child['quantity'],
				$var_id,
				$attrs,
				array(
					'm7pa_parent' => $cart_item_key,
					'm7pa_child'  => array(
						'field_id'      => $child['field_id'],
						'field_label'   => $child['field_label'],
						'mode'          => $child['mode'],
						'discount'      => $child['discount'],
						'discount_type' => $child['discount_type'],
					),
				)
			);
			if ( $key ) {
				$keys[] = $key;
			}
		}
		self::$adding_children = false;
		if ( isset( $cart->cart_contents[ $cart_item_key ] ) ) {
			$cart->cart_contents[ $cart_item_key ]['m7pa']['child_keys'] = $keys;
		}
	}

	public static function from_session( $item, $values ) {
		foreach ( array( 'm7pa', 'm7pa_parent', 'm7pa_child' ) as $k ) {
			if ( isset( $values[ $k ] ) ) {
				$item[ $k ] = $values[ $k ];
			}
		}
		return $item;
	}

	/* ------------------------------ prijzen ------------------------------ */

	public static function set_prices( $cart ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return;
		}
		foreach ( $cart->get_cart() as $item ) {
			self::apply_price( $item );
		}
	}

	public static function mini_cart_prices() {
		if ( WC()->cart ) {
			foreach ( WC()->cart->get_cart() as $item ) {
				self::apply_price( $item );
			}
		}
	}

	private static function apply_price( array $item ) {
		if ( empty( $item['m7pa'] ) && empty( $item['m7pa_child'] ) ) {
			return;
		}
		$product = $item['data'];
		// Basisprijs eenmalig vastleggen op het productobject van dit verzoek (voorkomt dubbel optellen).
		$base = $product->get_meta( '_m7pa_base', true );
		if ( '' === $base ) {
			$base = (float) $product->get_price( 'edit' );
			$product->update_meta_data( '_m7pa_base', $base );
		}
		$base = (float) $base;
		if ( ! empty( $item['m7pa'] ) ) {
			$m = $item['m7pa'];
			if ( isset( $m['set_price'] ) && null !== $m['set_price'] ) {
				$price = (float) $m['set_price'];
			} else {
				$price = $base + (float) $m['per_unit'];
				// Gegevens van versie 0.1 hadden geen toeslagen: eenmalig bedrag over de regel verdelen.
				if ( ! isset( $m['flat_items'] ) && ! empty( $m['flat'] ) ) {
					$price += (float) $m['flat'] / max( 1, (int) $item['quantity'] );
				}
			}
			$product->set_price( max( 0, $price ) );
		} else {
			$c = $item['m7pa_child'];
			$product->set_price( Frontend_Products::discounted( $base, $c['discount'], $c['discount_type'] ) );
		}
	}

	/**
	 * Eenmalige bedragen als toeslag, één keer per veld in de hele winkelwagen.
	 */
	public static function fees( $cart ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return;
		}
		$all = array();
		foreach ( $cart->get_cart() as $item ) {
			if ( empty( $item['m7pa']['flat_items'] ) ) {
				continue;
			}
			foreach ( $item['m7pa']['flat_items'] as $field_id => $flat ) {
				if ( isset( $all[ $field_id ] ) ) {
					$flat['label'] = $flat['label'];
				} else {
					$product = wc_get_product( ! empty( $item['variation_id'] ) ? $item['variation_id'] : $item['product_id'] );
					$flat['label'] = ( $product ? $product->get_name() : '' ) . ': ' . $flat['label'];
				}
				$all[ $field_id ] = $flat;
			}
		}
		foreach ( $all as $flat ) {
			$cart->add_fee( $flat['label'], (float) $flat['price'], true, 'standard' );
		}
	}

	/* ------------------------------ weergave ------------------------------ */

	/**
	 * Is een veld met deze zichtbaarheid te zien op deze plek (cart | order | docs)?
	 */
	public static function visible_in( $where, $visibility ) {
		switch ( $visibility ) {
			case 'display_product':
			case 'hide_customer':
				return false;
			default:
				return true;
		}
	}

	private static function show_prices( array $row ) {
		if ( ! Settings::get( 'show_prices_in_cart' ) || 'hidden' === ( isset( $row['price_visibility'] ) ? $row['price_visibility'] : '' ) ) {
			return false;
		}
		return ! ( Settings::get( 'hide_field_prices' ) && in_array( $row['type'], array( 'radio', 'select' ), true ) );
	}

	public static function item_data( $data, $item ) {
		if ( ! empty( $item['m7pa']['items'] ) ) {
			$product = $item['data'];
			foreach ( $item['m7pa']['items'] as $row ) {
				if ( ! empty( $row['hidden'] ) || ! self::visible_in( 'cart', isset( $row['visibility'] ) ? $row['visibility'] : 'visible' ) ) {
					continue;
				}
				if ( 'products' === $row['type'] && ! Settings::get( 'child_as_meta' ) ) {
					continue;
				}
				$value = isset( $row['display'] ) ? (string) $row['display'] : '';
				$show  = self::show_prices( $row );
				$price = '';
				if ( ! isset( $row['has_price'] ) || $row['has_price'] ) {
					if ( ! ( Settings::get( 'hide_zero' ) && 0.0 === (float) $row['price'] ) && $show ) {
						$price = ' ' . wc_price( Frontend::maybe_tax( $product, (float) $row['price'], true ) );
					}
				}
				if ( ! empty( $row['flat'] ) ) {
					$price = '<span class="m7pa-flat-rate-cart-label">(' . esc_html__( 'Vast bedrag kosten', 'm7-product-addons' ) . ')</span>';
				}
				$label = sanitize_text_field( $row['label'] );
				switch ( $row['type'] ) {
					case 'checkbox':
						$data[] = array(
							'name'    => $label,
							'value'   => $show ? '<span class="m7pa-price m7pa-cart-item-price">' . sanitize_text_field( $price ) . '</span>' : '',
							'display' => '',
						);
						break;
					case 'checkbox_group':
						$data[] = array(
							'name'    => $label,
							'value'   => str_replace( ' | ', '<br>', $value ) . ( $show ? '<span class="m7pa-price m7pa-cart-item-price">' . sanitize_text_field( $price ) . '</span>' : '' ),
							'display' => '',
						);
						break;
					case 'name_price':
						$amount = wc_price( isset( $row['value'][0] ) ? (float) $row['value'][0] : 0 );
						$data[] = array(
							'name'    => $label,
							'value'   => sanitize_text_field( $amount ),
							'display' => '',
						);
						break;
					case 'upload':
						$display = '<div class="m7pa-upload-thumb-wrapper">' . ( $show ? '<span class="m7pa-cart-item-price">' . $price . '</span>' : '' );
						foreach ( (array) $row['value'] as $token ) {
							$display .= '<br><span>' . esc_html( Uploads::display_name( $token ) ) . '</span>';
						}
						$display .= '</div>';
						$data[]   = array(
							'name'      => $label,
							'display'   => $display,
							'className' => 'wc-block-components-product-details__item m7pa-upload-' . $row['field_id'],
						);
						break;
					default:
						$is_cost = 'calculation' === $row['type'] && 'cost' === ( isset( $row['formula_action'] ) ? $row['formula_action'] : '' );
						$display = $is_cost ? '' : wp_kses_post( $value );
						if ( $show ) {
							$display .= '<span class="m7pa-cart-item-price">' . $price . '</span>';
						}
						$data[] = array(
							'name'    => $label,
							'value'   => sanitize_text_field( $value ),
							'display' => $display,
						);
				}
			}
		}
		return $data;
	}

	private static function child_mode( array $item ) {
		$mode = isset( $item['m7pa_child']['mode'] ) ? $item['m7pa_child']['mode'] : 'linked';
		return 'one' === $mode ? 'one-only' : $mode;
	}

	public static function item_class( $class, $item ) {
		if ( ! empty( $item['m7pa_parent'] ) ) {
			$class .= ' m7pa-child-product ' . self::child_mode( $item );
		} elseif ( ! empty( $item['m7pa']['children'] ) ) {
			$class .= ' m7pa-parent-product';
		}
		return $class;
	}

	/**
	 * Aantal van een gekoppeld product: vast getal; bij eigen aantallen het invoerveld, uitgeschakeld.
	 */
	public static function child_quantity( $html, $key, $item ) {
		if ( empty( $item['m7pa_parent'] ) ) {
			return $html;
		}
		if ( 'independent' !== self::child_mode( $item ) ) {
			return (string) (int) $item['quantity'];
		}
		return preg_replace( '/<input(?![^>]*type="hidden")/', '<input disabled="disabled"', $html, 1 );
	}

	/**
	 * Gekoppelde producten: pijltje in plaats van de verwijderlink (behalve bij eigen aantallen).
	 */
	public static function child_remove_link( $link, $key ) {
		$item = WC()->cart->get_cart_item( $key );
		if ( ! $item || empty( $item['m7pa_parent'] ) || 'independent' === self::child_mode( $item ) ) {
			return $link;
		}
		return '<img src="' . esc_url( M7PA_URL . 'assets/images/arrow-right.svg' ) . '" class="m7pa-arrow-right">';
	}

	public static function store_api_qty_editable( $editable, $product, $item ) {
		return ! empty( $item['m7pa_parent'] ) ? false : $editable;
	}

	/* ------------------------------ samenhang ------------------------------ */

	public static function remove_children( $key, $cart ) {
		$removed = isset( $cart->removed_cart_contents[ $key ] ) ? $cart->removed_cart_contents[ $key ] : null;
		if ( ! $removed || empty( $removed['m7pa']['child_keys'] ) ) {
			return;
		}
		foreach ( $removed['m7pa']['child_keys'] as $child_key ) {
			if ( isset( $cart->cart_contents[ $child_key ] ) ) {
				$cart->remove_cart_item( $child_key );
			}
		}
	}

	public static function sync_children( $key, $quantity, $old_quantity ) {
		$cart = WC()->cart;
		$item = $cart->get_cart_item( $key );
		if ( ! $item || empty( $item['m7pa']['child_keys'] ) ) {
			return;
		}
		foreach ( $item['m7pa']['child_keys'] as $child_key ) {
			$child = $cart->get_cart_item( $child_key );
			if ( $child && 'linked' === $child['m7pa_child']['mode'] ) {
				$cart->set_quantity( $child_key, $quantity, false );
			}
		}
	}

	/* ------------------------------ bestelling ------------------------------ */

	/** Metawaarde zoals het origineel: "waarde € x" (prijs ook bij 0, tenzij "nul verbergen"). */
	private static function meta_value( array $row, $product ) {
		$is_cost = 'calculation' === $row['type'] && 'cost' === ( isset( $row['formula_action'] ) ? $row['formula_action'] : '' );
		$value   = $is_cost ? '' : (string) $row['display'];
		$value   = str_replace( '__checked__', '<span class="dashicons dashicons-yes"></span>', $value );
		$price   = '';
		if ( ( ! isset( $row['has_price'] ) || $row['has_price'] ) && ! ( Settings::get( 'hide_zero' ) && ! (float) $row['price'] ) ) {
			$price = wc_price( Frontend::maybe_tax( $product, (float) $row['price'], true ) );
		}
		if ( Settings::get( 'show_prices_in_order' ) ) {
			$value .= ' ' . $price;
		}
		return wp_kses_post( $value );
	}

	public static function order_line_item( $order_item, $cart_item_key, $values, $order ) {
		if ( ! empty( $values['m7pa']['items'] ) ) {
			$product = wc_get_product( $values['product_id'] );
			foreach ( $values['m7pa']['items'] as $row ) {
				if ( 'products' === $row['type'] && ! Settings::get( 'child_as_meta' ) ) {
					continue;
				}
				$key = '_' . ( '' !== $row['label'] ? $row['label'] : $row['field_id'] );
				$order_item->add_meta_data( $key, self::meta_value( $row, $product ), true );
			}
			$order_item->add_meta_data(
				'_m7pa',
				array(
					'version'    => M7PA_VERSION,
					'items'      => $values['m7pa']['items'],
					'per_unit'   => $values['m7pa']['per_unit'],
					'flat'       => $values['m7pa']['flat'],
					'flat_items' => isset( $values['m7pa']['flat_items'] ) ? $values['m7pa']['flat_items'] : array(),
					'set_price'  => isset( $values['m7pa']['set_price'] ) ? $values['m7pa']['set_price'] : null,
					'cart_key'   => $cart_item_key,
				)
			);
		}
		if ( ! empty( $values['m7pa_parent'] ) ) {
			// Als lijst opgeslagen: WooCommerce toont lijsten niet in de regel-meta (zoals het origineel).
			$order_item->add_meta_data(
				'_m7pa_child',
				array(
					'parent_cart_key' => $values['m7pa_parent'],
					'field_id'        => isset( $values['m7pa_child']['field_id'] ) ? $values['m7pa_child']['field_id'] : '',
					'mode'            => isset( $values['m7pa_child']['mode'] ) ? $values['m7pa_child']['mode'] : '',
				)
			);
		}
	}

	/**
	 * Keuzes achter de productnaam in de bestelling (klant, e-mails, pdf), zoals het origineel.
	 */
	public static function order_item_name( $name, $item ) {
		if ( ! $item instanceof \WC_Order_Item_Product ) {
			return $name;
		}
		$saved = $item->get_meta( '_m7pa', true );
		if ( ! is_array( $saved ) || empty( $saved['items'] ) ) {
			return $name;
		}
		if ( function_exists( 'get_current_screen' ) ) {
			$screen = get_current_screen();
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			if ( $screen && in_array( $screen->id, array( 'woocommerce_page_wc-orders', 'shop_order' ), true ) && empty( $_POST ) ) {
				return $name;
			}
		}
		$where   = is_wc_endpoint_url() ? 'order' : 'docs';
		$product = wc_get_product( $item->get_product_id() );
		$groups  = array();
		foreach ( $saved['items'] as $row ) {
			$groups[ isset( $row['group_id'] ) ? $row['group_id'] : 0 ][] = $row;
		}
		foreach ( $groups as $rows ) {
			$name .= '<ul>';
			foreach ( $rows as $row ) {
				if ( ! empty( $row['hidden'] ) || ! self::visible_in( $where, isset( $row['visibility'] ) ? $row['visibility'] : 'visible' ) ) {
					continue;
				}
				if ( 'products' === $row['type'] && ! Settings::get( 'child_as_meta' ) ) {
					continue;
				}
				$type    = 'color' === $row['type'] ? 'color-picker' : $row['type']; // Typenaam zoals het origineel.
				$classes = strtolower( str_replace( ' ', '_', $type ) ) . ' ' . strtolower( str_replace( ' ', '_', $row['label'] ) );
				$price   = '';
				if ( 'hidden' !== ( isset( $row['price_visibility'] ) ? $row['price_visibility'] : '' ) && ( ! isset( $row['has_price'] ) || $row['has_price'] ) && ! ( Settings::get( 'hide_zero' ) && ! (float) $row['price'] ) ) {
					$price = wc_price( Frontend::maybe_tax( $product, (float) $row['price'], true ) );
				}
				if ( 'checkbox' === $row['type'] ) {
					$name .= '<li class="' . esc_attr( $classes ) . '"><span class="m7pa-order-item-label">' . wp_kses_post( $row['label'] ) . '</span> <span class="m7pa-order-item-price">' . $price . '</span></li>';
				} else {
					$name .= '<li class="' . esc_attr( $classes ) . '"><span class="m7pa-order-item-label">' . wp_kses_post( $row['label'] ) . ':</span> <span class="m7pa-order-item-item">' . nl2br( wp_kses_post( (string) $row['display'] ) ) . '</span> <span class="m7pa-order-item-price">' . $price . '</span></li>';
				}
			}
			$name .= '</ul>';
		}
		return $name;
	}

	/**
	 * In beheer de "_" voor M7-labels weghalen (zoals het origineel).
	 */
	public static function order_meta_key( $display_key, $meta, $item = null ) {
		if ( $item && is_object( $item ) && method_exists( $item, 'get_meta' ) && 0 === strpos( (string) $meta->key, '_' ) && '_m7pa' !== $meta->key && is_array( $item->get_meta( '_m7pa', true ) ) ) {
			return ltrim( $display_key, '_' );
		}
		return $display_key;
	}

	public static function hidden_meta( $keys ) {
		$keys[] = '_m7pa';
		$keys[] = '_m7pa_child';
		$keys[] = '_m7pa_parent_cart_key'; // Bestellingen van versie 0.1.
		return $keys;
	}

	/**
	 * Opnieuw bestellen: neemt dezelfde keuzes over (zonder gekoppelde producten; die zijn eigen regels).
	 */
	public static function order_again( $data, $item, $order ) {
		$saved = $item->get_meta( '_m7pa', true );
		if ( is_array( $saved ) && ! empty( $saved['items'] ) ) {
			$data['m7pa'] = array(
				'items'      => $saved['items'],
				'per_unit'   => isset( $saved['per_unit'] ) ? (float) $saved['per_unit'] : 0.0,
				'flat'       => isset( $saved['flat'] ) ? (float) $saved['flat'] : 0.0,
				'flat_items' => isset( $saved['flat_items'] ) ? (array) $saved['flat_items'] : array(),
				'set_price'  => isset( $saved['set_price'] ) ? $saved['set_price'] : null,
				'children'   => array(),
				'child_keys' => array(),
			);
		}
		return $data;
	}
}
