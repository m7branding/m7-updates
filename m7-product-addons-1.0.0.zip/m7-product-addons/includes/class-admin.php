<?php
/**
 * Beheer: groepsbouwer, groepsinstellingen, producttab en lijstkolommen (M7-huisstijl).
 *
 * @package M7PA
 */

namespace M7PA;

defined( 'ABSPATH' ) || exit;

final class Admin {

	public static function init() {
		add_action( 'add_meta_boxes_' . Groups::POST_TYPE, array( __CLASS__, 'meta_boxes' ) );
		add_action( 'save_post_' . Groups::POST_TYPE, array( __CLASS__, 'save_group' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'manage_' . Groups::POST_TYPE . '_posts_columns', array( __CLASS__, 'columns' ) );
		add_action( 'manage_' . Groups::POST_TYPE . '_posts_custom_column', array( __CLASS__, 'column' ), 10, 2 );

		add_filter( 'woocommerce_product_data_tabs', array( __CLASS__, 'product_tab' ) );
		add_action( 'woocommerce_product_data_panels', array( __CLASS__, 'product_panel' ) );
		add_action( 'woocommerce_admin_process_product_object', array( __CLASS__, 'save_product' ) );
	}

	private static function is_group_screen() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		return $screen && Groups::POST_TYPE === $screen->post_type;
	}

	public static function assets( $hook ) {
		$screen = get_current_screen();
		if ( ! $screen ) {
			return;
		}
		$is_group   = Groups::POST_TYPE === $screen->post_type;
		$is_product = 'product' === $screen->post_type && in_array( $hook, array( 'post.php', 'post-new.php' ), true );
		$is_page    = false !== strpos( (string) $hook, 'm7pa-' );
		if ( ! $is_group && ! $is_product && ! $is_page ) {
			return;
		}
		wp_enqueue_style( 'm7pa-admin', M7PA_URL . 'assets/m7-admin.css', array(), M7PA_VERSION . '.' . (int) @filemtime( M7PA_DIR . 'assets/m7-admin.css' ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		if ( $is_group && in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			wp_enqueue_script( 'm7pa-admin', M7PA_URL . 'assets/m7-admin.js', array(), M7PA_VERSION . '.' . (int) @filemtime( M7PA_DIR . 'assets/m7-admin.js' ), array( 'in_footer' => true ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			$attributes = array();
			foreach ( wc_get_attribute_taxonomies() as $a ) {
				$attributes[] = array(
					'name'  => 'pa_' . $a->attribute_name,
					'label' => $a->attribute_label,
				);
			}
			wp_localize_script(
				'm7pa-admin',
				'm7paAdmin',
				array(
					'types'             => array_map( 'translate', Groups::FIELD_TYPES ),
					'priceTypes'        => Groups::PRICE_TYPES,
					'operators'         => Conditions::OPERATORS,
					'attributes'        => $attributes,
					'productLayouts'    => array(
						'checkboxes'      => __( 'Checkboxes met afbeeldingen', 'm7-product-addons' ),
						'checkboxes-list' => __( 'Checkboxlijst', 'm7-product-addons' ),
						'radio'           => __( 'Radio met afbeeldingen (één kiezen)', 'm7-product-addons' ),
						'radio-list'      => __( 'Radiolijst (één kiezen)', 'm7-product-addons' ),
						'select'          => __( 'Keuzelijst', 'm7-product-addons' ),
						'swatches'        => __( 'Afbeeldingen', 'm7-product-addons' ),
					),
					'productQuantities' => array(
						'linked'      => __( 'Gekoppeld aan hoofdproduct', 'm7-product-addons' ),
						'independent' => __( 'Klant kiest aantal', 'm7-product-addons' ),
						'one'         => __( 'Altijd één', 'm7-product-addons' ),
					),
					'i18n'              => self::builder_strings(),
				)
			);
		}
	}

	private static function builder_strings() {
		return array(
			'type' => __( 'Type', 'm7-product-addons' ), 'label' => __( 'Label', 'm7-product-addons' ), 'required' => __( 'Verplicht', 'm7-product-addons' ),
			'hideLabel' => __( 'Label verbergen', 'm7-product-addons' ), 'description' => __( 'Beschrijving / tooltip', 'm7-product-addons' ),
			'pricing' => __( 'Prijs', 'm7-product-addons' ), 'price' => __( 'Prijs', 'm7-product-addons' ), 'priceType' => __( 'Prijsberekening', 'm7-product-addons' ),
			'options' => __( 'Opties', 'm7-product-addons' ), 'value' => __( 'Waarde', 'm7-product-addons' ), 'imageId' => __( 'Afbeelding-ID', 'm7-product-addons' ),
			'addOption' => __( '+ Optie', 'm7-product-addons' ), 'default' => __( 'Standaardwaarde', 'm7-product-addons' ), 'defaultHint' => __( 'Waarde(s), kommagescheiden', 'm7-product-addons' ),
			'placeholder' => __( 'Placeholder', 'm7-product-addons' ), 'multiple' => __( 'Meerdere kiezen', 'm7-product-addons' ),
			'minChars' => __( 'Min. tekens', 'm7-product-addons' ), 'maxChars' => __( 'Max. tekens', 'm7-product-addons' ),
			'min' => __( 'Minimum', 'm7-product-addons' ), 'max' => __( 'Maximum', 'm7-product-addons' ), 'step' => __( 'Stap', 'm7-product-addons' ),
			'formula' => __( 'Formule', 'm7-product-addons' ), 'formulaHint' => __( 'Variabelen: {product_price}, {quantity}, {field:<veld-id>}. Functies: min, max, round, ceil, floor, abs, if.', 'm7-product-addons' ),
			'decimals' => __( 'Decimalen', 'm7-product-addons' ), 'formulaAsPrice' => __( 'Uitkomst is de prijs', 'm7-product-addons' ),
			'products' => __( 'Gekoppelde producten', 'm7-product-addons' ), 'productIds' => __( 'Product-ID\'s', 'm7-product-addons' ), 'productIdsHint' => __( 'Kommagescheiden, in weergavevolgorde', 'm7-product-addons' ),
			'layout' => __( 'Weergave', 'm7-product-addons' ), 'quantities' => __( 'Aantallen', 'm7-product-addons' ), 'discount' => __( 'Korting', 'm7-product-addons' ),
			'discountType' => __( 'Soort korting', 'm7-product-addons' ), 'fixedAmount' => __( 'Vast bedrag', 'm7-product-addons' ), 'allowNone' => __( '"Geen" toestaan', 'm7-product-addons' ),
			'upload' => __( 'Upload', 'm7-product-addons' ), 'maxFiles' => __( 'Max. bestanden', 'm7-product-addons' ), 'maxMb' => __( 'Max. MB per bestand', 'm7-product-addons' ), 'fileTypes' => __( 'Bestandstypen', 'm7-product-addons' ),
			'rows' => __( 'Regels', 'm7-product-addons' ), 'addRow' => __( '+ Regel', 'm7-product-addons' ),
			'conditions' => __( 'Voorwaarden', 'm7-product-addons' ), 'condAction' => __( 'Dit veld', 'm7-product-addons' ), 'show' => __( 'tonen als', 'm7-product-addons' ), 'hide' => __( 'verbergen als', 'm7-product-addons' ),
			'condMatch' => __( 'Regels', 'm7-product-addons' ), 'all' => __( 'alle kloppen', 'm7-product-addons' ), 'any' => __( 'een klopt', 'm7-product-addons' ), 'addRule' => __( '+ Voorwaarde', 'm7-product-addons' ),
			'quantity' => __( 'Aantal', 'm7-product-addons' ), 'productPrice' => __( 'Productprijs', 'm7-product-addons' ), 'attribute' => __( 'Attribuut', 'm7-product-addons' ),
			'up' => __( 'Omhoog', 'm7-product-addons' ), 'down' => __( 'Omlaag', 'm7-product-addons' ), 'duplicate' => __( 'Dupliceren', 'm7-product-addons' ), 'remove' => __( 'Verwijderen', 'm7-product-addons' ),
			'copySuffix' => __( '(kopie)', 'm7-product-addons' ), 'confirmRemove' => __( 'Dit veld verwijderen?', 'm7-product-addons' ), 'untitled' => __( '(zonder label)', 'm7-product-addons' ),
			'empty' => __( 'Nog geen velden. Kies een type en klik op "Veld toevoegen".', 'm7-product-addons' ), 'addField' => __( 'Veld toevoegen', 'm7-product-addons' ),
		);
	}


	public static function meta_boxes() {
		add_meta_box( 'm7pa-fields', __( 'Velden', 'm7-product-addons' ), array( __CLASS__, 'fields_box' ), Groups::POST_TYPE, 'normal', 'high' );
		add_meta_box( 'm7pa-group', __( 'Groep', 'm7-product-addons' ), array( __CLASS__, 'group_box' ), Groups::POST_TYPE, 'normal', 'default' );
		add_meta_box( 'm7pa-usage', __( 'Toepassen op', 'm7-product-addons' ), array( __CLASS__, 'rules_box' ), Groups::POST_TYPE, 'side', 'default' );
	}

	private static function current_group( $post ) {
		$g = Groups::get( $post->ID );
		return $g ? $g : array_merge( Groups::group_defaults(), array( 'id' => 0 ) );
	}

	public static function fields_box( $post ) {
		$g = self::current_group( $post );
		wp_nonce_field( 'm7pa_save_group', 'm7pa_nonce' );
		echo '<div class="m7-admin"><div id="m7pa-builder" class="m7pa-builder"></div></div>';
		echo '<input type="hidden" id="m7pa-fields-json" name="m7pa_fields_json" value="' . esc_attr( wp_json_encode( $g['fields'] ) ) . '">';
	}

	public static function group_box( $post ) {
		$g = self::current_group( $post );
		?>
		<div class="m7-admin">
			<p><label for="m7pa-desc"><strong><?php esc_html_e( 'Beschrijving boven de groep', 'm7-product-addons' ); ?></strong></label><br>
			<textarea id="m7pa-desc" name="m7pa_group[description]" rows="3" class="large-text"><?php echo esc_textarea( $g['description'] ); ?></textarea></p>
			<p><label><strong><?php esc_html_e( 'Weergave', 'm7-product-addons' ); ?></strong>
			<select name="m7pa_group[display]">
				<?php foreach ( array( 'standard' => __( 'Standaard', 'm7-product-addons' ), 'accordion' => __( 'Accordeon', 'm7-product-addons' ), 'tabs' => __( 'Tabbladen', 'm7-product-addons' ), 'steps' => __( 'Stappen', 'm7-product-addons' ) ) as $k => $l ) : ?>
					<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $g['display'], $k ); ?>><?php echo esc_html( $l ); ?></option>
				<?php endforeach; ?>
			</select></label>
			<span class="description"><?php esc_html_e( 'Tabbladen en stappen werken als alle groepen van een product die weergave hebben.', 'm7-product-addons' ); ?></span></p>
		</div>
		<?php
	}

	public static function rules_box( $post ) {
		$g     = self::current_group( $post );
		$r     = $g['rules'];
		$cats  = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
			)
		);
		$roles = wp_roles()->get_names();
		?>
		<div class="m7-admin">
			<p><label><input type="radio" name="m7pa_group[scope]" value="product" <?php checked( $g['scope'], 'product' ); ?>> <?php esc_html_e( 'Alleen producten waar deze groep is gekozen', 'm7-product-addons' ); ?></label><br>
			<label><input type="radio" name="m7pa_group[scope]" value="global" <?php checked( $g['scope'], 'global' ); ?>> <?php esc_html_e( 'Globaal, volgens regels hieronder', 'm7-product-addons' ); ?></label></p>
			<p><label><input type="checkbox" name="m7pa_group[rules][all]" value="1" <?php checked( $r['all'] ); ?>> <?php esc_html_e( 'Alle producten', 'm7-product-addons' ); ?></label></p>
			<p><label for="m7pa-cats"><?php esc_html_e( 'Categorieën', 'm7-product-addons' ); ?></label>
			<select id="m7pa-cats" name="m7pa_group[rules][categories][]" multiple size="6" style="width:100%">
				<?php foreach ( is_array( $cats ) ? $cats : array() as $c ) : ?>
					<option value="<?php echo (int) $c->term_id; ?>" <?php selected( in_array( (int) $c->term_id, $r['categories'], true ) ); ?>><?php echo esc_html( $c->name ); ?></option>
				<?php endforeach; ?>
			</select></p>
			<p><label><?php esc_html_e( 'Product-ID\'s', 'm7-product-addons' ); ?><input type="text" class="widefat" name="m7pa_group[rules][products]" value="<?php echo esc_attr( implode( ',', $r['products'] ) ); ?>"></label></p>
			<p><label><?php esc_html_e( 'Uitsluiten (product-ID\'s)', 'm7-product-addons' ); ?><input type="text" class="widefat" name="m7pa_group[rules][exclude_products]" value="<?php echo esc_attr( implode( ',', $r['exclude_products'] ) ); ?>"></label></p>
			<p><label for="m7pa-roles"><?php esc_html_e( 'Alleen voor rollen (leeg = iedereen)', 'm7-product-addons' ); ?></label>
			<select id="m7pa-roles" name="m7pa_group[rules][roles][]" multiple size="4" style="width:100%">
				<option value="guest" <?php selected( in_array( 'guest', $r['roles'], true ) ); ?>><?php esc_html_e( 'Gasten', 'm7-product-addons' ); ?></option>
				<?php foreach ( $roles as $key => $name ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>" <?php selected( in_array( $key, $r['roles'], true ) ); ?>><?php echo esc_html( translate_user_role( $name ) ); ?></option>
				<?php endforeach; ?>
			</select></p>
			<p class="description"><?php esc_html_e( 'Volgorde van globale groepen: veld "Volgorde" (Paginakenmerken).', 'm7-product-addons' ); ?></p>
		</div>
		<?php
	}

	public static function save_group( $post_id, $post ) {
		if ( ! isset( $_POST['m7pa_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['m7pa_nonce'] ) ), 'm7pa_save_group' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Groups::sanitize_group schoont alles op.
		$group = isset( $_POST['m7pa_group'] ) && is_array( $_POST['m7pa_group'] ) ? wp_unslash( $_POST['m7pa_group'] ) : array();
		$json  = isset( $_POST['m7pa_fields_json'] ) ? json_decode( wp_unslash( $_POST['m7pa_fields_json'] ), true ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$group['fields'] = is_array( $json ) ? $json : array();
		$existing        = get_post_meta( $post_id, Groups::META, true );
		if ( is_array( $existing ) && ! empty( $existing['legacy'] ) ) {
			$group['legacy'] = $existing['legacy'];
		}
		// Instellingen zonder veld op dit scherm (o.a. overgenomen uit Product Add-Ons Ultimate) behouden.
		foreach ( array( 'layout', 'class', 'always_include', 'conditions' ) as $keep ) {
			if ( ! isset( $group[ $keep ] ) && is_array( $existing ) && isset( $existing[ $keep ] ) ) {
				$group[ $keep ] = $existing[ $keep ];
			}
		}
		update_post_meta( $post_id, Groups::META, Groups::sanitize_group( $group ) );
		Groups::flush();
	}

	public static function columns( $columns ) {
		$new = array();
		foreach ( $columns as $k => $v ) {
			$new[ $k ] = $v;
			if ( 'title' === $k ) {
				$new['m7pa_scope']  = __( 'Toepassing', 'm7-product-addons' );
				$new['m7pa_fields'] = __( 'Velden', 'm7-product-addons' );
			}
		}
		return $new;
	}

	public static function column( $column, $post_id ) {
		$g = Groups::get( $post_id );
		if ( ! $g ) {
			return;
		}
		if ( 'm7pa_scope' === $column ) {
			if ( 'global' !== $g['scope'] ) {
				esc_html_e( 'Per product', 'm7-product-addons' );
			} elseif ( $g['rules']['all'] ) {
				esc_html_e( 'Globaal: alle producten', 'm7-product-addons' );
			} else {
				/* translators: 1: aantal categorieën, 2: aantal producten */
				echo esc_html( sprintf( __( 'Globaal: %1$d categorieën, %2$d producten', 'm7-product-addons' ), count( $g['rules']['categories'] ), count( $g['rules']['products'] ) ) );
			}
		} elseif ( 'm7pa_fields' === $column ) {
			echo esc_html( implode( ', ', array_map( static function ( $f ) {
				return '' !== $f['label'] ? $f['label'] : $f['id'];
			}, array_slice( $g['fields'], 0, 6 ) ) ) . ( count( $g['fields'] ) > 6 ? ' …' : '' ) );
		}
	}

	/* ------------------------------ product ------------------------------ */

	public static function product_tab( $tabs ) {
		$tabs['m7pa'] = array(
			'label'    => __( 'M7 Add-ons', 'm7-product-addons' ),
			'target'   => 'm7pa_product_data',
			'class'    => array(),
			'priority' => 75,
		);
		return $tabs;
	}

	public static function product_panel() {
		global $post;
		$selected  = get_post_meta( $post->ID, Groups::PRODUCT_META, true );
		$selected  = is_array( $selected ) ? array_map( 'intval', $selected ) : array();
		$no_global = (bool) get_post_meta( $post->ID, Groups::NO_GLOBAL, true );
		$posts     = get_posts(
			array(
				'post_type'      => Groups::POST_TYPE,
				'post_status'    => array( 'publish', 'draft' ),
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);
		$own    = array();
		$global = array();
		foreach ( $posts as $p ) {
			$g = Groups::get( $p->ID );
			if ( ! $g ) {
				continue;
			}
			if ( 'global' === $g['scope'] ) {
				$global[] = $g;
			} else {
				$own[] = $g;
			}
		}
		// Gekozen groepen bovenaan, in de opgeslagen volgorde.
		usort(
			$own,
			static function ( $a, $b ) use ( $selected ) {
				$ia = array_search( $a['id'], $selected, true );
				$ib = array_search( $b['id'], $selected, true );
				$ia = false === $ia ? PHP_INT_MAX : $ia;
				$ib = false === $ib ? PHP_INT_MAX : $ib;
				return $ia === $ib ? strcasecmp( $a['title'], $b['title'] ) : ( $ia < $ib ? -1 : 1 );
			}
		);
		$active_ids = wp_list_pluck( Groups::for_product( $post->ID ), 'id' );

		echo '<div id="m7pa_product_data" class="panel woocommerce_options_panel m7-admin m7pa-product-panel">';
		wp_nonce_field( 'm7pa_save_product', 'm7pa_product_nonce' );

		echo '<div class="m7pa-pp-section"><h4>' . esc_html__( 'Groepen voor dit product', 'm7-product-addons' ) . '</h4>';
		if ( $own ) {
			echo '<p class="m7pa-pp-help">' . esc_html__( 'Vink aan welke groepen bij dit product horen. De volgorde hier is de volgorde op de site.', 'm7-product-addons' ) . '</p><ul class="m7pa-pp-list" data-m7pa-sortable>';
			foreach ( $own as $g ) {
				$on = in_array( (int) $g['id'], $selected, true );
				echo '<li class="m7pa-pp-row">';
				echo '<label class="m7pa-pp-check"><input type="checkbox" name="m7pa_group_ids[]" value="' . (int) $g['id'] . '"' . checked( $on, true, false ) . '> <span class="m7pa-pp-title">' . esc_html( $g['title'] ) . '</span></label>';
				echo '<span class="m7pa-pp-meta">' . esc_html( sprintf( /* translators: %d: aantal velden */ _n( '%d veld', '%d velden', count( $g['fields'] ), 'm7-product-addons' ), count( $g['fields'] ) ) ) . ( 'publish' !== $g['status'] ? ' · ' . esc_html__( 'concept', 'm7-product-addons' ) : '' ) . '</span>';
				echo '<span class="m7pa-pp-actions"><button type="button" class="m7pa-pp-move" data-dir="-1" aria-label="' . esc_attr__( 'Omhoog', 'm7-product-addons' ) . '">&uarr;</button><button type="button" class="m7pa-pp-move" data-dir="1" aria-label="' . esc_attr__( 'Omlaag', 'm7-product-addons' ) . '">&darr;</button><a href="' . esc_url( (string) get_edit_post_link( $g['id'] ) ) . '">' . esc_html__( 'Bewerken', 'm7-product-addons' ) . '</a></span>';
				echo '</li>';
			}
			echo '</ul>';
		} else {
			echo '<p class="m7pa-pp-help">' . esc_html__( 'Er zijn nog geen groepen voor losse producten.', 'm7-product-addons' ) . '</p>';
		}
		echo '<p><a class="button m7-button" href="' . esc_url( admin_url( 'post-new.php?post_type=' . Groups::POST_TYPE ) ) . '">' . esc_html__( 'Nieuwe groep', 'm7-product-addons' ) . '</a></p></div>';

		echo '<div class="m7pa-pp-section"><h4>' . esc_html__( 'Globale groepen', 'm7-product-addons' ) . '</h4>';
		if ( $global ) {
			echo '<p class="m7pa-pp-help">' . esc_html__( 'Deze gelden automatisch volgens hun eigen regels (bijv. categorie).', 'm7-product-addons' ) . '</p><ul class="m7pa-pp-list">';
			foreach ( $global as $g ) {
				$here = in_array( $g['id'], $active_ids, true );
				echo '<li class="m7pa-pp-row"><span class="m7pa-pp-title">' . esc_html( $g['title'] ) . '</span><span class="m7pa-pp-badge' . ( $here ? ' is-on' : '' ) . '">' . ( $here ? esc_html__( 'geldt bij dit product', 'm7-product-addons' ) : esc_html__( 'geldt hier niet', 'm7-product-addons' ) ) . '</span><span class="m7pa-pp-actions"><a href="' . esc_url( (string) get_edit_post_link( $g['id'] ) ) . '">' . esc_html__( 'Bewerken', 'm7-product-addons' ) . '</a></span></li>';
			}
			echo '</ul>';
		} else {
			echo '<p class="m7pa-pp-help">' . esc_html__( 'Geen globale groepen.', 'm7-product-addons' ) . '</p>';
		}
		echo '<p><label class="m7pa-pp-check"><input type="checkbox" name="m7pa_no_global" value="1"' . checked( $no_global, true, false ) . '> ' . esc_html__( 'Geen globale groepen tonen bij dit product', 'm7-product-addons' ) . '</label></p></div>';

		$active = Groups::for_product( $post->ID );
		echo '<p class="m7pa-pp-summary"><strong>' . esc_html__( 'Nu op de site:', 'm7-product-addons' ) . '</strong> ' . ( $active ? esc_html( implode( ', ', wp_list_pluck( $active, 'title' ) ) ) : esc_html__( 'geen opties', 'm7-product-addons' ) ) . '</p>';
		?>
		<script>
		( function () {
			var list = document.querySelector( '#m7pa_product_data [data-m7pa-sortable]' );
			if ( ! list ) { return; }
			list.addEventListener( 'click', function ( e ) {
				var btn = e.target.closest( '.m7pa-pp-move' );
				if ( ! btn ) { return; }
				var row = btn.closest( 'li' );
				if ( '-1' === btn.getAttribute( 'data-dir' ) && row.previousElementSibling ) {
					list.insertBefore( row, row.previousElementSibling );
				} else if ( '1' === btn.getAttribute( 'data-dir' ) && row.nextElementSibling ) {
					list.insertBefore( row.nextElementSibling, row );
				}
				btn.focus();
			} );
		}() );
		</script>
		<?php
		echo '</div>';
	}

	public static function save_product( $product ) {
		if ( ! isset( $_POST['m7pa_product_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['m7pa_product_nonce'] ) ), 'm7pa_save_product' ) ) {
			return;
		}
		$raw = isset( $_POST['m7pa_group_ids'] ) ? wp_unslash( $_POST['m7pa_group_ids'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- hieronder naar gehele getallen.
		$raw = is_array( $raw ) ? $raw : preg_split( '/[\s,]+/', (string) $raw );
		$ids = array_values( array_unique( array_filter( array_map( 'absint', $raw ) ) ) );
		$product->update_meta_data( Groups::PRODUCT_META, $ids );
		if ( ! empty( $_POST['m7pa_no_global'] ) ) {
			$product->update_meta_data( Groups::NO_GLOBAL, 1 );
		} else {
			$product->delete_meta_data( Groups::NO_GLOBAL );
		}
		Groups::flush();
	}
}
