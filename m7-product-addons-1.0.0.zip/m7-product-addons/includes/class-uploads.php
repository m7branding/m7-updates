<?php
/**
 * Bestanden uploaden bij een product (uploadveld).
 *
 * Bestanden komen in wp-content/uploads/m7pa/<jaar-maand>/<willekeurige map>/ met een
 * .htaccess die mappenoverzicht blokkeert. Het formulier krijgt een ondertekend token
 * terug; alleen tokens met een geldige handtekening worden geaccepteerd.
 *
 * @package M7PA
 */

namespace M7PA;

defined( 'ABSPATH' ) || exit;

final class Uploads {

	public static function init() {
		add_action( 'wp_ajax_m7pa_upload', array( __CLASS__, 'ajax_upload' ) );
		add_action( 'wp_ajax_nopriv_m7pa_upload', array( __CLASS__, 'ajax_upload' ) );
	}

	private static function base_dir() {
		$up = wp_upload_dir();
		return array( trailingslashit( $up['basedir'] ) . 'm7pa', trailingslashit( $up['baseurl'] ) . 'm7pa' );
	}

	public static function ajax_upload() {
		check_ajax_referer( 'm7pa_upload', 'nonce' );
		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$field_id   = isset( $_POST['field_id'] ) ? sanitize_key( wp_unslash( $_POST['field_id'] ) ) : '';
		$found      = Groups::find_field( Groups::for_product( $product_id ), $field_id );
		if ( ! $found || 'upload' !== $found[1]['type'] || empty( $_FILES['file'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Upload niet toegestaan.', 'm7-product-addons' ) ), 400 );
		}
		$field = $found[1];
		$file  = $_FILES['file']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

		if ( ! empty( $file['error'] ) || empty( $file['tmp_name'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Upload mislukt.', 'm7-product-addons' ) ), 400 );
		}
		if ( (int) $file['size'] > $field['upload']['max_mb'] * MB_IN_BYTES ) {
			/* translators: %d: maximale grootte in MB */
			wp_send_json_error( array( 'message' => sprintf( __( 'Bestand is groter dan %d MB.', 'm7-product-addons' ), $field['upload']['max_mb'] ) ), 400 );
		}
		$check = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'] );
		$ext   = $check['ext'] ? strtolower( $check['ext'] ) : '';
		if ( ! $ext || ! in_array( $ext, $field['upload']['types'], true ) ) {
			wp_send_json_error( array( 'message' => __( 'Dit bestandstype is niet toegestaan.', 'm7-product-addons' ) ), 400 );
		}

		list( $dir ) = self::base_dir();
		$folder      = gmdate( 'Y-m' ) . '/' . wp_generate_password( 20, false, false );
		$target_dir  = $dir . '/' . $folder;
		if ( ! wp_mkdir_p( $target_dir ) ) {
			wp_send_json_error( array( 'message' => __( 'Upload mislukt.', 'm7-product-addons' ) ), 500 );
		}
		self::protect( $dir );
		$name = sanitize_file_name( $file['name'] );
		$name = $name ? $name : 'bestand.' . $ext;
		if ( ! move_uploaded_file( $file['tmp_name'], $target_dir . '/' . $name ) ) { // phpcs:ignore Generic.PHP.ForbiddenFunctions
			wp_send_json_error( array( 'message' => __( 'Upload mislukt.', 'm7-product-addons' ) ), 500 );
		}
		$path = $folder . '/' . $name;
		wp_send_json_success(
			array(
				'token' => self::sign( $path ),
				'name'  => $name,
			)
		);
	}

	private static function protect( $dir ) {
		if ( ! file_exists( $dir . '/.htaccess' ) ) {
			file_put_contents( $dir . '/.htaccess', "Options -Indexes\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		if ( ! file_exists( $dir . '/index.php' ) ) {
			file_put_contents( $dir . '/index.php', "<?php\n// Stilte.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
	}

	public static function sign( $path ) {
		return $path . '|' . substr( hash_hmac( 'sha256', $path, wp_salt( 'auth' ) ), 0, 32 );
	}

	/**
	 * Controleert ingestuurde tokens; geeft alleen geldige en bestaande bestanden terug.
	 *
	 * @param mixed $raw   Tokens (array of komma-/JSON-lijst).
	 * @param array $field Veld.
	 * @return array
	 */
	public static function validate_tokens( $raw, array $field ) {
		if ( is_string( $raw ) ) {
			$decoded = json_decode( $raw, true );
			$raw     = is_array( $decoded ) ? $decoded : array_filter( explode( ',', $raw ) );
		}
		list( $dir ) = self::base_dir();
		$out         = array();
		foreach ( (array) $raw as $token ) {
			$token = (string) $token;
			$bits  = explode( '|', $token );
			if ( 2 !== count( $bits ) || false !== strpos( $bits[0], '..' ) ) {
				continue;
			}
			if ( hash_equals( self::sign( $bits[0] ), $token ) && is_file( $dir . '/' . $bits[0] ) ) {
				$out[] = $token;
			}
		}
		return array_slice( array_values( array_unique( $out ) ), 0, $field['upload']['max_files'] );
	}

	public static function display_name( $token ) {
		$path = explode( '|', (string) $token )[0];
		return basename( $path );
	}

	public static function url( $token ) {
		list( , $url ) = self::base_dir();
		$path          = explode( '|', (string) $token )[0];
		return $url . '/' . implode( '/', array_map( 'rawurlencode', explode( '/', $path ) ) );
	}
}
