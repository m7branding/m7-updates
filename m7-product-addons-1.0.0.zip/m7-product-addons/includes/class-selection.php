<?php
/**
 * Zet de ingevulde add-ons om naar een gecontroleerde selectie met prijzen.
 * Dit is de enige plek waar prijzen worden bepaald (de browser rekent alleen voor de weergave);
 * ook berekeningsvelden worden hier opnieuw uitgerekend (het origineel vertrouwde de browser).
 *
 * Rekenregels, meldingen en de tekst per regel volgen Product Add-Ons Ultimate, zodat winkelwagen,
 * bestelling en e-mails hetzelfde tonen.
 *
 * @package M7PA
 */

namespace M7PA;

defined( 'ABSPATH' ) || exit;

final class Selection {

	/**
	 * @param array $groups  Groepen van het product.
	 * @param array $post    Ingezonden formulier ($_POST, zonder slashes).
	 * @param array $context product (WC_Product), quantity, attributes, variation_id.
	 * @return array items, children, errors, per_unit, flat, flat_items, set_price
	 */
	public static function build( array $groups, array $post, array $context ) {
		$product  = $context['product'];
		$quantity = max( 1, isset( $context['quantity'] ) ? (int) $context['quantity'] : 1 );
		$base     = (float) $product->get_price();

		// 1. Waarden normaliseren (alleen bekende velden en geldige opties).
		$values = array();
		$doms   = array();
		foreach ( $groups as $g ) {
			foreach ( $g['fields'] as $f ) {
				$dom                = Frontend::dom_id( $g['id'], $f );
				$doms[ $f['id'] ]   = $dom;
				$raw                = 'products' === $f['type'] ? ( isset( $post[ $dom . '_child_product' ] ) ? $post[ $dom . '_child_product' ] : null ) : ( isset( $post[ $dom ] ) ? $post[ $dom ] : null );
				// Oudere M7-formulieren (versie 0.1) stuurden m7pa[<veld-ID>] en m7pa_qty[<veld-ID>][<product-ID>].
				if ( null === $raw && isset( $post['m7pa'][ $f['id'] ] ) ) {
					$raw = $post['m7pa'][ $f['id'] ];
					if ( 'products' === $f['type'] && isset( $post['m7pa_qty'][ $f['id'] ] ) && is_array( $post['m7pa_qty'][ $f['id'] ] ) ) {
						foreach ( $post['m7pa_qty'][ $f['id'] ] as $pid => $q ) {
							$post[ $dom . '_child_quantity_' . absint( $pid ) ] = $q;
						}
					}
				}
				$values[ $f['id'] ] = self::normalize( $f, $raw );
			}
		}

		// 2. Prijzen per veld (eerst zonder berekeningen, die kunnen naar veldprijzen verwijzen).
		$prices = array();
		foreach ( $groups as $g ) {
			foreach ( $g['fields'] as $f ) {
				$prices[ $f['id'] ] = self::price( $f, $values[ $f['id'] ], $product );
			}
		}
		// 3. Berekeningsvelden (kunnen naar andere velden en berekeningen verwijzen).
		for ( $pass = 0; $pass < 3; $pass++ ) {
			$vars = self::formula_vars( $groups, $values, $prices, $product, $quantity );
			foreach ( $groups as $g ) {
				foreach ( $g['fields'] as $f ) {
					if ( 'calculation' !== $f['type'] || '' === $f['formula'] ) {
						continue;
					}
					$result = Formula::evaluate( $f['formula'], $vars );
					if ( null === $result ) {
						$values[ $f['id'] ] = array();
					} else {
						if ( 'floor' === $f['formula_round'] ) {
							$result = floor( $result );
						} elseif ( 'ceil' === $f['formula_round'] ) {
							$result = ceil( $result );
						}
						$values[ $f['id'] ] = array( number_format( $result, (int) $f['decimals'], '.', '' ) );
					}
					$prices[ $f['id'] ] = self::price( $f, $values[ $f['id'] ], $product );
				}
			}
		}

		// 4. Zichtbaarheid.
		$running = $base;
		foreach ( $prices as $p ) {
			$running += $p['amount'];
		}
		$visible = Conditions::visibility(
			$groups,
			$values,
			array(
				'quantity'      => $quantity,
				'cost'          => $running * $quantity,
				'product_price' => Frontend::maybe_tax( $product, $base ),
				'attributes'    => isset( $context['attributes'] ) ? $context['attributes'] : array(),
				'variation_id'  => isset( $context['variation_id'] ) ? (int) $context['variation_id'] : 0,
			)
		);

		$out = array(
			'items'      => array(),
			'children'   => array(),
			'errors'     => array(),
			'per_unit'   => 0.0,
			'flat'       => 0.0,
			'flat_items' => array(),
			'set_price'  => null,
		);

		foreach ( $groups as $g ) {
			foreach ( $g['fields'] as $f ) {
				$label = '' !== $f['label'] ? $f['label'] : $doms[ $f['id'] ];
				$value = $values[ $f['id'] ];
				$shown = ! empty( $visible[ $f['id'] ] );

				$error = self::validate( $f, $value, $label, $shown, $post, $doms[ $f['id'] ] );
				if ( $error ) {
					$out['errors'][] = $error;
					continue;
				}
				if ( ! $shown || in_array( $f['type'], array( 'information', 'none' ), true ) || ! $value ) {
					continue;
				}

				if ( 'products' === $f['type'] ) {
					// Regel voor de gekozen producten (alleen zichtbaar met "gekoppelde producten als meta", zoals het origineel).
					$out['items'][] = array(
						'group_id'         => (int) $g['id'],
						'field_id'         => $f['id'],
						'type'             => 'products',
						'label'            => $label,
						'value'            => $value,
						'display'          => implode( ', ', array_map( 'get_the_title', $value ) ),
						'price'            => 0.0,
						'flat'             => false,
						'has_price'        => false,
						'price_visibility' => $f['price_visibility'],
						'visibility'       => $f['visibility'],
						'formula_action'   => '',
						'hidden'           => false,
					);
					foreach ( $value as $pid ) {
						if ( 'independent' === $f['products']['quantities'] ) {
							$q = isset( $post[ $doms[ $f['id'] ] . '_child_quantity_' . $pid ] ) ? absint( $post[ $doms[ $f['id'] ] . '_child_quantity_' . $pid ] ) : 1;
							if ( Settings::get( 'multiply_independent' ) ) {
								$q *= $quantity;
							}
						} elseif ( 'linked' === $f['products']['quantities'] ) {
							$q = $quantity;
						} else {
							$q = 1;
						}
						if ( $q > 0 ) {
							$out['children'][] = array(
								'field_id'      => $f['id'],
								'field_label'   => $label,
								'product_id'    => (int) $pid,
								'quantity'      => $q,
								'mode'          => $f['products']['quantities'],
								'discount'      => $f['products']['discount'],
								'discount_type' => $f['products']['discount_type'],
							);
						}
					}
					continue;
				}

				$p    = $prices[ $f['id'] ];
				$item = array(
					'group_id'         => (int) $g['id'],
					'field_id'         => $f['id'],
					'type'             => $f['type'],
					'label'            => $label,
					'value'            => $value,
					'display'          => self::display( $f, $value, $product ),
					'price'            => $p['amount'],
					'flat'             => $p['flat'],
					'has_price'        => ! ( 'calculation' === $f['type'] && 'cost' !== $f['formula_action'] ),
					'price_visibility' => $f['price_visibility'],
					'visibility'       => $f['visibility'],
					'formula_action'   => 'calculation' === $f['type'] ? $f['formula_action'] : '',
					'hidden'           => 'calculation' === $f['type'] && $f['hidden'],
				);
				if ( $p['flat'] ) {
					$out['flat']                       += $p['amount'];
					$out['flat_items'][ $f['id'] ]      = array(
						'label' => $p['flat_label'] ? $p['flat_label'] : $label,
						'price' => $p['amount'],
					);
					$item['price']                      = 0.0;
					$item['flat_amount']                = $p['amount'];
				} else {
					$out['per_unit'] += $p['amount'];
				}
				if ( 'calculation' === $f['type'] && 'price' === $f['formula_action'] ) {
					$out['set_price'] = (float) $value[0];
				}
				$out['items'][] = $item;
			}
		}

		return apply_filters( 'm7pa/selection', $out, $groups, $post, $context );
	}

	/**
	 * Normaliseert een ingezonden waarde naar een lijst strings (leeg = niets gekozen).
	 * Net als het origineel telt "0" als leeg (wordt niet bewaard).
	 *
	 * @param array $f   Veld.
	 * @param mixed $raw Waarde.
	 * @return array
	 */
	public static function normalize( array $f, $raw ) {
		if ( null === $raw ) {
			return array();
		}
		$first = is_array( $raw ) ? reset( $raw ) : $raw;
		$first = is_scalar( $first ) ? (string) $first : '';
		switch ( $f['type'] ) {
			case 'checkbox':
				return ( '' !== $first && '0' !== $first ) ? array( '1' ) : array();
			case 'checkbox_group':
			case 'radio':
			case 'select':
			case 'image_swatch':
				$allowed = array_map( 'strval', wp_list_pluck( $f['options'], 'value' ) );
				$picked  = array();
				foreach ( (array) $raw as $r ) {
					if ( is_scalar( $r ) && in_array( (string) $r, $allowed, true ) ) {
						$picked[] = (string) $r;
					}
				}
				$multi = 'checkbox_group' === $f['type'] || ( 'image_swatch' === $f['type'] && $f['multiple'] );
				return $multi ? array_values( array_unique( $picked ) ) : array_slice( $picked, 0, 1 );
			case 'products':
				$ids    = array_map( 'absint', (array) $raw );
				$picked = array_values( array_intersect( $ids, $f['products']['ids'] ) );
				return in_array( $f['products']['layout'], array( 'radio', 'radio-list', 'select', 'variable-select' ), true ) ? array_slice( $picked, 0, 1 ) : array_values( array_unique( $picked ) );
			case 'number':
			case 'name_price':
				$v = trim( str_replace( ',', '.', $first ) );
				return ( '' !== $v && is_numeric( $v ) && 0.0 !== (float) $v ) ? array( (string) ( 0 + $v ) ) : array();
			case 'color':
				$v = sanitize_hex_color( $first );
				return $v ? array( $v ) : array();
			case 'upload':
				return Uploads::validate_tokens( $raw, $f );
			case 'textarea':
				$v = sanitize_textarea_field( $first );
				return '' !== $v && '0' !== $v ? array( $v ) : array();
			case 'calculation':
				return array(); // Wordt op de server uitgerekend.
			default: // text, date.
				$v = sanitize_text_field( $first );
				return '' !== $v && '0' !== $v ? array( $v ) : array();
		}
	}

	private static function validate( array $f, array $value, $label, $shown, array $post, $dom ) {
		$required = $f['required'] && $shown;
		$req_msg  = esc_html( $label ) . __( ' is een verplicht veld.', 'm7-product-addons' );
		if ( in_array( $f['type'], array( 'information', 'calculation', 'none' ), true ) ) {
			return '';
		}
		if ( 'products' === $f['type'] ) {
			if ( $required && ! $value ) {
				return $req_msg;
			}
			if ( $shown && 'independent' === $f['products']['quantities'] && in_array( $f['products']['layout'], array( 'column', 'checkboxes', 'checkboxes-list' ), true ) && ( $f['products']['min'] || $f['products']['max'] ) ) {
				$count = 0;
				foreach ( $f['products']['ids'] as $pid ) {
					$count += isset( $post[ $dom . '_child_quantity_' . $pid ] ) ? absint( $post[ $dom . '_child_quantity_' . $pid ] ) : 0;
				}
				if ( $f['products']['min'] && $count < $f['products']['min'] ) {
					/* translators: 1: veld, 2: aantal */
					return sprintf( __( '%1$s verwacht dat u minimaal %2$s producten kiest', 'm7-product-addons' ), $label, $f['products']['min'] );
				}
				if ( $f['products']['max'] && $count > $f['products']['max'] ) {
					/* translators: 1: veld, 2: aantal */
					return sprintf( __( '%1$s verwacht dat u maximaal %2$s producten kiest', 'm7-product-addons' ), $label, $f['products']['max'] );
				}
			}
			return '';
		}
		if ( 'number' === $f['type'] || 'name_price' === $f['type'] ) {
			$raw = isset( $post[ $dom ] ) && is_scalar( $post[ $dom ] ) ? trim( (string) $post[ $dom ] ) : '';
			if ( $required && '' === $raw ) {
				return $req_msg;
			}
			if ( $shown && '' !== $raw && is_numeric( $raw ) ) {
				$n = (float) $raw;
				if ( '' !== $f['min'] && (float) $f['min'] && $n < (float) $f['min'] ) {
					return esc_html( $label ) . __( ': minimale waarde is', 'm7-product-addons' ) . esc_html( self::num( $f['min'] ) );
				}
				if ( '' !== $f['max'] && (float) $f['max'] && $n > (float) $f['max'] ) {
					return esc_html( $label ) . __( ': maximale waarde is', 'm7-product-addons' ) . esc_html( self::num( $f['max'] ) );
				}
			}
			return '';
		}
		if ( $required && ! $value ) {
			return $req_msg;
		}
		if ( ! $value ) {
			return '';
		}
		if ( in_array( $f['type'], array( 'text', 'textarea' ), true ) && ( (int) $f['min_chars'] || (int) $f['max_chars'] ) ) {
			$len = mb_strlen( str_replace( ' ', '', $value[0] ) );
			if ( (int) $f['min_chars'] && $len < (int) $f['min_chars'] ) {
				return esc_html( $label ) . __( ': minimum aantal tekens:', 'm7-product-addons' ) . (int) $f['min_chars'];
			}
			if ( (int) $f['max_chars'] && $len > (int) $f['max_chars'] ) {
				return esc_html( $label ) . __( ': maximum aantal tekens:', 'm7-product-addons' ) . (int) $f['max_chars'];
			}
		}
		if ( 'checkbox_group' === $f['type'] || ( 'image_swatch' === $f['type'] && $f['multiple'] ) ) {
			if ( (int) $f['min_checks'] && count( $value ) < (int) $f['min_checks'] ) {
				/* translators: 1: veld, 2: aantal */
				return sprintf( __( '%1$s vereist dat minimaal %2$s items geselecteerd zijn', 'm7-product-addons' ), $label, (int) $f['min_checks'] );
			}
			if ( (int) $f['max_checks'] && count( $value ) > (int) $f['max_checks'] ) {
				/* translators: 1: veld, 2: aantal */
				return sprintf( __( '%1$s vereist dat maximaal %2$s items geselecteerd zijn', 'm7-product-addons' ), $label, (int) $f['max_checks'] );
			}
		}
		return '';
	}

	private static function num( $v ) {
		return (string) ( 0 + $v );
	}

	/**
	 * Lengte voor prijs per teken (spaties en regeleinden tellen niet).
	 */
	public static function chargeable_length( array $f, $text ) {
		$len = mb_strlen( str_replace( ' ', '', preg_replace( "/\r|\n/", '', (string) $text ) ) );
		if ( $f['alphanumeric_charge'] ) {
			$len = strlen( preg_replace( '/\W/', '', (string) $text ) );
		}
		if ( $f['free_chars'] ) {
			$len = max( 0, $len - (int) $f['free_chars'] );
		}
		return $len;
	}

	/**
	 * Prijs van een veld voor de gekozen waarde (per stuk, of eenmalig bij flat).
	 *
	 * @return array amount, flat, flat_label, option_price
	 */
	public static function price( array $f, array $value, $product ) {
		$out = array(
			'amount'       => 0.0,
			'flat'         => 'flat' === $f['price_type'],
			'flat_label'   => '',
			'option_price' => 0.0,
		);
		if ( ! $value || in_array( $f['type'], array( 'information', 'products', 'none' ), true ) ) {
			return $out;
		}
		$pct   = 'percentage' === $f['price_type'];
		$base  = (float) $product->get_price();
		$field = (float) $f['price'];
		if ( $pct ) {
			$field = $field / 100 * $base;
		}
		$amount = $field;
		switch ( $f['type'] ) {
			case 'text':
			case 'textarea':
				if ( 'per_char' === $f['price_type'] ) {
					$amount = self::chargeable_length( $f, $value[0] ) * $field;
				}
				break;
			case 'number':
				if ( 'multiply' === $f['price_type'] ) {
					$amount = (float) $value[0] * $field;
				}
				break;
			case 'name_price':
				$amount = 'multiply' === $f['price_type'] ? (float) $value[0] * $field : (float) $value[0];
				break;
			case 'calculation':
				$amount = in_array( $f['formula_action'], array( 'cost' ), true ) ? (float) $value[0] : 0.0;
				break;
			case 'upload':
				$amount = 'multiply' === $f['price_type'] ? $field * count( $value ) : $field;
				break;
			case 'radio':
			case 'select':
			case 'checkbox_group':
			case 'image_swatch':
				$multi = 'checkbox_group' === $f['type'] || ( 'image_swatch' === $f['type'] && $f['multiple'] );
				$sum   = 0.0;
				foreach ( $f['options'] as $o ) {
					if ( in_array( (string) $o['value'], $value, true ) && (float) $o['price'] ) {
						$op = (float) $o['price'];
						if ( $pct ) {
							$op = $op / 100 * $base;
						}
						$sum += $op;
						if ( ! $multi ) {
							$out['option_price'] = $op;
							$out['flat_label']   = $f['label'] . ' (' . $o['value'] . ')';
						}
					}
				}
				if ( ! $multi && 'value' === $f['option_price_visibility'] ) {
					$sum = 0.0; // Optieprijs alleen voor berekeningen.
				}
				$amount = $field + $sum;
				break;
		}
		$out['amount'] = (float) apply_filters( 'm7pa/field_price', $amount, $f, $value, $product );
		return $out;
	}

	/**
	 * Tekst per regel in winkelwagen en bestelling (zelfde opbouw als het origineel).
	 */
	public static function display( array $f, array $value, $product ) {
		$show_option_prices = 'hidden' !== $f['option_price_visibility'] && 'value' !== $f['option_price_visibility'];
		switch ( $f['type'] ) {
			case 'checkbox':
				return '__checked__';
			case 'radio':
			case 'select':
			case 'image_swatch':
			case 'checkbox_group':
				$multi = 'checkbox_group' === $f['type'] || ( 'image_swatch' === $f['type'] && $f['multiple'] );
				$parts = array();
				foreach ( $f['options'] as $o ) {
					if ( ! in_array( (string) $o['value'], $value, true ) ) {
						continue;
					}
					$text = $o['value'];
					if ( (float) $o['price'] && $show_option_prices ) {
						$op   = (float) $o['price'];
						$op   = 'percentage' === $f['price_type'] ? $op / 100 * (float) $product->get_price() : $op;
						$text = $o['value'] . ' (' . wc_price( Frontend::maybe_tax( $product, $op, true ) ) . ')';
					}
					$parts[] = $text;
					if ( ! $multi ) {
						break;
					}
				}
				$joined = implode( ' | ', $parts );
				if ( in_array( $f['type'], array( 'select', 'checkbox_group' ), true ) ) {
					return sanitize_text_field( $joined );
				}
				return wp_kses_post( $joined );
			case 'textarea':
				return sanitize_textarea_field( $value[0] );
			case 'upload':
				return implode( ', ', array_map( array( Uploads::class, 'display_name' ), $value ) );
		}
		return sanitize_text_field( implode( ' ', $value ) );
	}

	/**
	 * Variabelen voor formules: {product_price}, {quantity}, {field:<id>} en de achtervoegsels.
	 * Leeg/niet-getal = null (de formule is dan niet uit te rekenen, zoals in de browser).
	 */
	public static function formula_vars( array $groups, array $values, array $prices, $product, $quantity ) {
		$price = (float) Frontend::maybe_tax( $product, $product->get_price() );
		$vars  = array(
			'product_price' => $price ? $price : null,
			'quantity'      => $quantity ? (int) $quantity : null,
		);
		foreach ( $groups as $g ) {
			foreach ( $g['fields'] as $f ) {
				$v   = isset( $values[ $f['id'] ] ) ? $values[ $f['id'] ] : array();
				$key = 'field:' . $f['id'];
				$num = null;
				if ( in_array( $f['type'], array( 'number', 'calculation', 'name_price' ), true ) && $v && is_numeric( $v[0] ) ) {
					$num = (float) $v[0];
				}
				$vars[ $key ]                     = $num;
				$p                                = isset( $prices[ $f['id'] ] ) ? $prices[ $f['id'] ] : array( 'amount' => 0.0, 'option_price' => 0.0 );
				$vars[ $key . '_option_price' ]   = (float) $p['option_price'];
				$vars[ $key . '_option_value' ]   = $v && is_numeric( $v[0] ) ? (float) $v[0] : ( $v ? (float) $v[0] : 0.0 );
				$vars[ $key . '_option_label' ]   = $vars[ $key . '_option_value' ];
				$vars[ $key . '_field_price' ]    = (float) $p['amount'];
				$vars[ $key . '_number_uploads' ] = 'upload' === $f['type'] ? count( $v ) : 0;
				$vars[ $key . '_quantity' ]       = 0;
			}
		}
		return $vars;
	}
}
