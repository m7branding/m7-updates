/**
 * M7 Product Add-Ons – productpagina: totalen, voorwaarden, berekeningen, keuzes met afbeeldingen,
 * tabbladen/stappen/accordeon, tekentellers en uploads.
 *
 * Werkt op de opbouw uit includes/class-frontend.php (gelijk aan Product Add-Ons Ultimate, met m7pa-).
 * Rekenregels en klassen (m7pa-active-field, data-field-price, group-active, checked, ...) volgen dat
 * origineel, zodat de pagina er hetzelfde uitziet en dezelfde bedragen toont. De server rekent bij het
 * toevoegen aan de winkelwagen alles opnieuw na; dit script is alleen weergave.
 */
( function ( $ ) {
	'use strict';

	/* ---------- formules (zelfde grammatica als includes/class-formula.php) ---------- */

	var FUNCS = [ 'min', 'max', 'round', 'ceil', 'floor', 'abs', 'if', 'sqrt', 'pow', 'log', 'exp' ];

	function evaluate( formula, lookup ) {
		var s = String( formula || '' ), tokens = [], i = 0, m;
		while ( i < s.length ) {
			var c = s[ i ];
			if ( /\s/.test( c ) ) { i++; continue; }
			if ( '{' === c ) {
				var end = s.indexOf( '}', i );
				if ( end < 0 ) { return null; }
				var v = lookup( s.slice( i + 1, end ).trim() );
				if ( null === v || undefined === v || ! isFinite( v ) ) { return null; }
				tokens.push( [ 'n', parseFloat( v ) ] );
				i = end + 1; continue;
			}
			if ( ( m = /^(\d+\.?\d*|\.\d+)/.exec( s.slice( i ) ) ) ) { tokens.push( [ 'n', parseFloat( m[ 1 ] ) ] ); i += m[ 1 ].length; continue; }
			if ( ( m = /^[a-z_][a-z0-9_]*/i.exec( s.slice( i ) ) ) ) {
				var w = m[ 0 ].toLowerCase();
				if ( 'and' === w || 'or' === w || 'not' === w || 'mod' === w ) { tokens.push( [ 'o', w ] ); i += w.length; continue; }
				if ( FUNCS.indexOf( w ) < 0 ) { return null; }
				tokens.push( [ 'f', w ] ); i += m[ 0 ].length; continue;
			}
			var two = s.substr( i, 2 );
			if ( [ '<=', '>=', '==', '!=', '&&', '||' ].indexOf( two ) >= 0 ) { tokens.push( [ 'o', '&&' === two ? 'and' : ( '||' === two ? 'or' : two ) ] ); i += 2; continue; }
			if ( '+-*/^%(),<>?:!'.indexOf( c ) >= 0 ) { tokens.push( [ 'o', '!' === c ? 'not' : c ] ); i++; continue; }
			return null;
		}
		var pos = 0;
		function peek() { return tokens[ pos ]; }
		function isOp( t, v ) { return t && 'o' === t[ 0 ] && ( Array.isArray( v ) ? v.indexOf( t[ 1 ] ) >= 0 : t[ 1 ] === v ); }
		function expect( v ) { if ( ! isOp( peek(), v ) ) { throw new Error( v ); } pos++; }
		function ternary() {
			var cond = logicOr();
			if ( isOp( peek(), '?' ) ) {
				pos++;
				var a = ternary();
				expect( ':' );
				var b = ternary();
				return cond !== 0 ? a : b;
			}
			return cond;
		}
		function logicOr() {
			var l = logicAnd();
			while ( isOp( peek(), 'or' ) ) { pos++; var r = logicAnd(); l = ( l !== 0 || r !== 0 ) ? 1 : 0; }
			return l;
		}
		function logicAnd() {
			var l = comparison();
			while ( isOp( peek(), 'and' ) ) { pos++; var r = comparison(); l = ( l !== 0 && r !== 0 ) ? 1 : 0; }
			return l;
		}
		function comparison() {
			var l = additive(), t = peek();
			if ( isOp( t, [ '<', '<=', '>', '>=', '==', '!=' ] ) ) {
				pos++;
				var r = additive();
				switch ( t[ 1 ] ) {
					case '<': return l < r ? 1 : 0;
					case '<=': return l <= r ? 1 : 0;
					case '>': return l > r ? 1 : 0;
					case '>=': return l >= r ? 1 : 0;
					case '==': return Math.abs( l - r ) < 1e-9 ? 1 : 0;
					default: return Math.abs( l - r ) >= 1e-9 ? 1 : 0;
				}
			}
			return l;
		}
		function additive() {
			var v = multiplicative(), t;
			while ( isOp( t = peek(), [ '+', '-' ] ) ) { pos++; var r = multiplicative(); v = '+' === t[ 1 ] ? v + r : v - r; }
			return v;
		}
		function multiplicative() {
			var v = power(), t;
			while ( isOp( t = peek(), [ '*', '/', '%', 'mod' ] ) ) {
				pos++;
				var r = power();
				if ( '*' === t[ 1 ] ) { v *= r; } else if ( 0 === r ) { v = 0; } else if ( '/' === t[ 1 ] ) { v /= r; } else { v = v % r; }
			}
			return v;
		}
		function power() {
			var b = unary();
			if ( isOp( peek(), '^' ) ) { pos++; return Math.pow( b, unary() ); }
			return b;
		}
		function unary() {
			var t = peek();
			if ( isOp( t, [ '-', '+' ] ) ) { pos++; var v = unary(); return '-' === t[ 1 ] ? -v : v; }
			if ( isOp( t, 'not' ) ) { pos++; return unary() === 0 ? 1 : 0; }
			return primary();
		}
		function primary() {
			var t = peek();
			if ( ! t ) { throw new Error( 'end' ); }
			if ( 'n' === t[ 0 ] ) { pos++; return t[ 1 ]; }
			if ( 'f' === t[ 0 ] ) {
				pos++; expect( '(' );
				var args = [];
				if ( ! isOp( peek(), ')' ) ) {
					args.push( ternary() );
					while ( isOp( peek(), ',' ) ) { pos++; args.push( ternary() ); }
				}
				expect( ')' );
				var a0 = args[ 0 ] || 0;
				switch ( t[ 1 ] ) {
					case 'min': return args.length ? Math.min.apply( null, args ) : 0;
					case 'max': return args.length ? Math.max.apply( null, args ) : 0;
					case 'round': var p = Math.pow( 10, args[ 1 ] || 0 ); return Math.round( a0 * p ) / p;
					case 'ceil': return Math.ceil( a0 );
					case 'floor': return Math.floor( a0 );
					case 'abs': return Math.abs( a0 );
					case 'sqrt': return Math.sqrt( a0 );
					case 'pow': return Math.pow( a0, args[ 1 ] || 0 );
					case 'log': return args.length > 1 ? Math.log( a0 ) / Math.log( args[ 1 ] ) : Math.log( a0 );
					case 'exp': return Math.exp( a0 );
					case 'if': return a0 !== 0 ? ( args[ 1 ] || 0 ) : ( args[ 2 ] || 0 );
				}
				return 0;
			}
			if ( isOp( t, '(' ) ) { pos++; var v = ternary(); expect( ')' ); return v; }
			throw new Error( 'token' );
		}
		try {
			var result = ternary();
			return pos === tokens.length && isFinite( result ) ? result : null;
		} catch ( e ) {
			return null;
		}
	}

	/* ---------- geldnotatie (zoals de totalen van het origineel) ---------- */

	function formatNumber( n, cur, decimals ) {
		var precision = undefined === decimals ? cur.decimals : decimals;
		var number = parseFloat( n );
		if ( isNaN( number ) ) { number = 0; }
		if ( cur.trim && number === parseInt( number, 10 ) ) { precision = 0; }
		var power = Math.pow( 10, precision );
		var fixed = ( Math.round( Math.abs( number ) * power ) / power ).toFixed( precision );
		var parts = fixed.split( '.' );
		var value = parts[ 0 ].replace( /\B(?=(\d{3})+(?!\d))/g, cur.thousand );
		if ( precision > 0 ) { value += cur.decimal + parts[ 1 ]; }
		return ( number < 0 ? '-' : '' ) + value;
	}

	function money( n, cur, plain ) {
		var symbol = plain ? cur.symbol : '<span class="woocommerce-Price-currencySymbol">' + cur.symbol + '</span>';
		var v = formatNumber( n, cur );
		var out;
		switch ( cur.pos ) {
			case 'right': out = v + symbol; break;
			case 'left_space': out = symbol + ' ' + v; break;
			case 'right_space': out = v + ' ' + symbol; break;
			default: out = symbol + v;
		}
		return plain ? out : '<span class="woocommerce-Price-amount amount"><bdi>' + out + '</bdi></span>';
	}

	/* ---------- per formulier ---------- */

	function Addons( wrap ) {
		this.wrap = $( wrap );
		this.form = this.wrap.closest( 'form' );
		this.config = JSON.parse( this.wrap.find( '.m7pa-config' ).first().text() );
		this.cur = this.config.currency;
		this.fields = {};
		var self = this;
		this.config.fields.forEach( function ( f ) { self.fields[ f.id ] = f; } );
		this.timer = null;
		this.costRules = JSON.stringify( this.config ).indexOf( '"field":"cost"' ) > -1;
		this.bind();
		this.initWidgets();
		this.wrap.find( '.first-group' ).addClass( 'group-active' );
		this.runConditions();
		this.recalculate();
		this.updateCounters();
		this.replaceImage( null );
		this.update();
		setTimeout( function () { self.recalculate(); self.update(); }, 250 );
		// Zoals het origineel: berekeningen regelmatig opnieuw (ook na wijzigingen buiten het formulier).
		setInterval( function () { if ( self.recalculate() ) { self.schedule(); } }, 500 );
	}

	Addons.prototype.item = function ( id ) {
		return this.wrap.find( '.m7pa-item[data-field-id="' + id + '"]' ).first();
	};

	Addons.prototype.schedule = function () {
		var self = this;
		clearTimeout( this.timer );
		this.timer = setTimeout( function () { self.update(); }, 0 );
	};

	Addons.prototype.quantity = function () {
		var q = this.form.find( '.quantity .qty' ).first();
		var v = q.length ? q.val() : '';
		return v ? v : 1;
	};

	/* ---- waarden voor voorwaarden (zelfde regels als Conditions::source_value) ---- */

	Addons.prototype.isHidden = function ( el ) {
		return el.hasClass( 'm7pa-hidden-field' ) || el.closest( '.m7pa-group-wrap' ).hasClass( 'm7pa-group-hidden' );
	};

	Addons.prototype.sourceValue = function ( target ) {
		var self = this;
		if ( 'quantity' === target ) { return String( this.form.find( '.quantity input.qty' ).val() || '' ); }
		if ( 'cost' === target ) { return String( this.wrap.find( '#m7pa_total_calc_price' ).val() ); }
		if ( 'product_price' === target ) { return String( this.wrap.find( '#m7pa-product-price' ).val() ); }
		if ( 'logged_in' === target ) { return $( 'body' ).hasClass( 'logged-in' ) ? 'true' : 'false'; }
		if ( 0 === target.indexOf( 'attribute:' ) ) {
			var name = target.slice( 10 );
			var sel = this.form.find( '[name="attribute_' + name + '"]' );
			var v = sel.length ? sel.val() : this.config.attributes[ name ];
			if ( undefined === v || null === v ) { return undefined; }
			v = String( v );
			return v.indexOf( ',' ) > -1 ? v.split( ',' ) : v;
		}
		var f = this.fields[ target ];
		if ( ! f ) { return undefined; }
		var el = this.item( target );
		if ( ! el.length ) { return undefined; }
		if ( this.isHidden( el ) ) { return ''; }
		var checked = function () { return el.find( 'input:checked' ).map( function () { return this.value; } ).get(); };
		switch ( f.type ) {
			case 'checkbox': return el.find( 'input[type=checkbox]' ).prop( 'checked' ) ? '1' : false;
			case 'radio': var r = el.find( 'input[type=radio]:checked' ); return r.length ? r.val() : undefined;
			case 'checkbox_group': return checked();
			case 'image_swatch': return f.multiple ? checked() : ( el.find( 'input:checked' ).val() || '' );
			case 'products':
				if ( 'select' === f.layout || 'variable-select' === f.layout ) { return el.find( 'select' ).val() || ''; }
				return el.find( 'input.m7pa-checkbox-form-field:checked, input.m7pa-radio-form-field:checked' ).map( function () { return String( this.value ); } ).get();
			case 'select': return el.find( 'select' ).val() || '';
			case 'upload': return this.uploadCount( el ) ? String( this.uploadCount( el ) ) : '';
			case 'calculation': return String( el.find( '.m7pa-calculation-value' ).val() || '' );
			default: return String( el.find( '.m7pa-form-field' ).first().val() || '' );
		}
	};

	function looseEqual( a, b ) {
		a = String( a ); b = String( b );
		if ( a === b ) { return true; }
		return a !== '' && b !== '' && isFinite( a ) && isFinite( b ) && parseFloat( a ) === parseFloat( b );
	}
	function includes( actual, needle ) {
		if ( Array.isArray( actual ) ) { return actual.some( function ( a ) { return looseEqual( a, needle ); } ); }
		return needle !== '' && String( actual ).indexOf( needle ) > -1;
	}

	Addons.prototype.compare = function ( op, actual, value ) {
		if ( undefined === actual ) { return false; }
		var isEmpty = false === actual || '' === actual || ( Array.isArray( actual ) && ! actual.length );
		var joined = Array.isArray( actual ) ? actual.join( ',' ) : ( false === actual ? '' : String( actual ) );
		value = String( value );
		switch ( op ) {
			case 'empty': return isEmpty;
			case 'not_empty': return ! isEmpty;
			case 'is': return false === actual ? false : looseEqual( joined, value );
			case 'is_not': return false === actual ? true : ! looseEqual( joined, value );
			case 'contains':
			case 'not_contains':
				var found;
				if ( false === actual ) { found = false; }
				else if ( value.indexOf( ',' ) > -1 ) { found = value.split( ',' ).every( function ( p ) { return includes( actual, p ); } ); }
				else { found = includes( actual, value ) || ( isFinite( value ) && value !== '' && includes( actual, String( parseFloat( value ) ) ) ); }
				return 'contains' === op ? found : ! found;
			case 'equals': case 'greater': case 'less': case 'greater_equal': case 'less_equal':
				if ( joined === '' || ! isFinite( joined ) || value === '' || ! isFinite( value ) ) { return false; }
				var a = parseFloat( joined ), b = parseFloat( value );
				switch ( op ) {
					case 'equals': return Math.abs( a - b ) < 1e-9;
					case 'greater': return a > b;
					case 'less': return a < b;
					case 'greater_equal': return a >= b;
					default: return a <= b;
				}
		}
		return false;
	};

	Addons.prototype.rulesVisible = function ( c ) {
		var self = this;
		if ( ! c || ! c.rules || ! c.rules.length ) { return true; }
		var results = c.rules.map( function ( r ) { return self.compare( r.operator, self.sourceValue( r.field ), r.value ); } );
		var met = 'any' === c.match ? results.indexOf( true ) > -1 : results.indexOf( false ) < 0;
		return 'hide' === c.action ? ! met : met;
	};

	Addons.prototype.runConditions = function () {
		var self = this, changed = false, any = false;
		for ( var pass = 0; pass < 6; pass++ ) {
			changed = false;
			$.each( this.config.groupConditions, function ( gid, c ) {
				var visible = self.rulesVisible( c );
				var g = self.wrap.find( '#m7pa-group-' + gid );
				if ( g.hasClass( 'm7pa-group-hidden' ) === visible ) {
					g.toggleClass( 'm7pa-group-hidden', ! visible );
					if ( ! visible ) { g.addClass( 'm7pa-reset-group' ); }
					self.wrap.find( '#m7pa-tab-' + gid ).toggleClass( 'm7pa-group-hidden', ! visible );
					changed = true;
				}
			} );
			$.each( this.fields, function ( id, f ) {
				if ( ! f.conditions || ! f.conditions.rules || ! f.conditions.rules.length ) { return; }
				var visible = self.rulesVisible( f.conditions );
				var el = self.item( id );
				if ( el.hasClass( 'm7pa-hidden-field' ) === visible ) {
					el.toggleClass( 'm7pa-hidden-field', ! visible );
					if ( ! visible && self.config.resetFields ) { self.resetField( el, f ); }
					changed = true;
				}
			} );
			if ( ! changed ) { break; }
			any = true;
		}
		return any;
	};

	Addons.prototype.resetField = function ( el, f ) {
		var def = el.attr( 'data-default-value' ) || '';
		if ( [ 'date', 'name_price', 'number', 'text', 'textarea' ].indexOf( f.type ) > -1 ) {
			el.find( '.m7pa-form-field' ).val( def );
		} else if ( 'image_swatch' === f.type || 'products' === f.type ) {
			el.find( 'input[type=radio], input[type=checkbox]' ).prop( 'checked', false );
			el.find( '.m7pa-radio-image-wrapper, .m7pa-checkbox-image-wrapper' ).removeClass( 'checked' );
			el.find( 'select' ).prop( 'selectedIndex', 0 );
		} else if ( [ 'checkbox', 'checkbox_group', 'radio' ].indexOf( f.type ) > -1 ) {
			el.find( 'input' ).prop( 'checked', false );
			el.find( '.active-swatch' ).removeClass( 'active-swatch' );
		} else if ( 'select' === f.type ) {
			el.find( 'select' ).prop( 'selectedIndex', 0 );
		}
	};

	/* ---- berekeningen ---- */

	Addons.prototype.uploadCount = function ( el ) {
		var t = el.find( '.m7pa-upload__tokens' ).val();
		try { return t ? JSON.parse( t ).length : 0; } catch ( e ) { return 0; }
	};

	Addons.prototype.lookup = function ( name ) {
		var self = this, qty, price;
		if ( 'product_price' === name ) { price = parseFloat( this.wrap.find( '#m7pa-product-price' ).val() ); return price ? price : null; }
		if ( 'quantity' === name ) { qty = parseFloat( this.form.find( '.quantity .qty' ).val() ); return qty ? qty : null; }
		var m = /^field:([a-z0-9_]+?)(?:_(option_price|option_value|option_label|field_price|number_uploads|quantity))?$/.exec( name );
		if ( ! m ) { return null; }
		var f = this.fields[ m[ 1 ] ];
		var el = this.item( m[ 1 ] );
		if ( ! f || ! el.length ) { return null; }
		var v;
		switch ( m[ 2 ] ) {
			case 'option_price': v = parseFloat( el.attr( 'data-selected-option-price' ) ); return isNaN( v ) ? 0 : v;
			case 'option_value': case 'option_label': v = parseFloat( el.attr( 'data-field-value' ) ); return isNaN( v ) ? 0 : v;
			case 'field_price': v = parseFloat( el.attr( 'data-field-price' ) ); return isNaN( v ) ? 0 : v;
			case 'number_uploads': return this.uploadCount( el );
			case 'quantity': v = parseFloat( el.find( '.m7pa-child-quantity-field' ).first().val() ); return isNaN( v ) ? 0 : v;
		}
		// Alleen getal- en berekeningsvelden hebben een getalswaarde; leeg = formule niet uit te rekenen.
		var input = el.find( '.m7pa-number-field-' + m[ 1 ] );
		if ( ! input.length ) { return null; }
		v = input.val();
		return '' === v || null === v || ! isFinite( v ) ? null : parseFloat( v );
	};

	/**
	 * Rekent alle zichtbare berekeningsvelden uit. Geeft true terug als er iets veranderde.
	 */
	Addons.prototype.recalculate = function () {
		var self = this, changed = false;
		$.each( this.fields, function ( id, f ) {
			if ( 'calculation' !== f.type || ! f.formula ) { return; }
			var el = self.item( id );
			if ( ! el.length || el.hasClass( 'm7pa-hidden-field' ) || el.closest( '.m7pa-group-wrap' ).hasClass( 'm7pa-group-hidden' ) ) { return; }
			if ( el.hasClass( 'm7pa-variation-dependent' ) && ! el.hasClass( 'active' ) ) { return; }
			var r = evaluate( f.formula, function ( n ) { return self.lookup( n ); } );
			if ( null === r ) { return; } // Zoals het origineel: bij een fout blijft de vorige uitkomst staan.
			if ( 'floor' === f.round ) { r = Math.floor( r ); } else if ( 'ceil' === f.round ) { r = Math.ceil( r ); }
			var result = r.toFixed( f.decimals );
			var span = el.find( '.m7pa-calculation-span' );
			var input = el.find( '.m7pa-calculation-value' );
			if ( 'cost' === f.action || 'price' === f.action ) {
				el.attr( 'data-price', result );
				span.html( money( result, self.cur ) );
				if ( 'price' === f.action ) {
					self.wrap.find( '#m7pa_calc_set_price' ).val( result ).attr( 'data-calc-set', 1 );
				}
			} else {
				span.html( result + ( f.suffix ? ' ' + f.suffix : '' ) );
				if ( 'qty' === f.action ) {
					var q = self.form.find( '.quantity .qty' );
					if ( q.val() !== result ) { q.val( result ).trigger( 'change' ); }
				}
			}
			if ( input.val() !== result ) {
				input.val( result ).trigger( 'm7pa_calculation_updated' );
				changed = true;
			}
		} );
		return changed;
	};

	/* ---- totalen (zelfde volgorde en regels als het origineel) ---- */

	Addons.prototype.textLength = function ( str, el ) {
		var field = el.find( '.m7pa-form-field' ).first();
		var s = str.replace( /\s/g, '' );
		if ( '1' === field.attr( 'data-alphanumeric' ) ) {
			s = s.replace( /\W/g, '' );
			field.val( s );
		}
		if ( '1' === field.attr( 'data-alphanumeric-charge' ) ) {
			s = s.replace( /\W/g, '' );
		}
		var len = s.length - ( parseInt( field.attr( 'data-freechars' ), 10 ) || 0 );
		return Math.max( 0, len );
	};

	Addons.prototype.update = function () {
		var self = this, w = this.wrap;
		var flat = 0, total = 0, children = 0;
		var productPrice = parseFloat( w.find( '#m7pa-product-price' ).val() ) || 0;
		var dependentOff = function ( el ) { return el.hasClass( 'm7pa-variation-dependent' ) && ! el.hasClass( 'active' ); };
		var groupHidden = function ( el ) { var g = el.closest( '.m7pa-group-wrap' ); return g.hasClass( 'm7pa-group-hidden' ) && ! g.hasClass( 'm7pa-group-always-include' ); };

		w.find( '.m7pa-form-field' ).each( function () {
			var input = $( this ), el = input.closest( '.m7pa-group' ), added = 0;
			if ( input.hasClass( 'm7pa-child-quantity-field' ) || input.hasClass( 'm7pa-child-select-field' ) ) { return; }
			el.removeClass( 'm7pa-active-field' );
			if ( dependentOff( el ) || groupHidden( el ) ) { return; }
			var hidden = el.hasClass( 'm7pa-hidden-field' );
			var price = parseFloat( el.attr( 'data-price' ) ) || 0;
			var val = input.val();
			if ( ! el.hasClass( 'm7pa-flatrate' ) ) {
				if ( el.hasClass( 'm7pa-group-checkbox' ) && ! hidden ) {
					if ( input.prop( 'checked' ) ) { added = price; el.addClass( 'm7pa-active-field' ); }
				} else if ( el.hasClass( 'm7pa-group-select' ) && ! hidden ) {
					if ( ! el.hasClass( 'm7pa-first-field-empty' ) || '' !== input.find( ':selected' ).val() ) {
						el.addClass( 'm7pa-active-field' ).attr( 'data-field-value', input.find( ':selected' ).val() );
						if ( 'value' !== el.attr( 'data-option-price-visibility' ) ) {
							added = parseFloat( input.find( ':selected' ).attr( 'data-option-cost' ) ) + price;
						}
					}
				} else if ( val && ! hidden ) {
					if ( el.hasClass( 'm7pa-per-character-pricing' ) && ( el.hasClass( 'm7pa-item-text' ) || el.hasClass( 'm7pa-item-textarea' ) ) ) {
						added = self.textLength( val, el ) * price;
					} else if ( el.hasClass( 'm7pa-multiply-pricing' ) ) {
						added = val * price;
					} else if ( el.hasClass( 'm7pa-group-name_price' ) ) {
						added = parseFloat( val );
					} else if ( el.hasClass( 'm7pa-item-upload' ) ) {
						var n = self.uploadCount( el );
						added = n ? ( el.hasClass( 'm7pa-multiply-upload' ) ? price * n : price ) : 0;
					} else {
						added = price;
					}
					el.addClass( 'm7pa-active-field' );
					if ( ! input.hasClass( 'm7pa-range-slider' ) || input.attr( 'value' ) !== '' ) {
						el.attr( 'data-field-value', val );
					}
				} else {
					el.attr( 'data-field-value', '' );
				}
				total += isNaN( added ) ? 0 : added;
				if ( ! isNaN( added ) ) { el.attr( 'data-field-price', added ); }
			} else {
				if ( el.hasClass( 'm7pa-group-checkbox' ) && ! hidden ) {
					if ( input.prop( 'checked' ) ) { added = price; el.addClass( 'm7pa-active-field' ); }
				} else if ( el.hasClass( 'm7pa-group-select' ) && ! hidden ) {
					added = parseFloat( input.find( ':selected' ).attr( 'data-option-cost' ) ) + price;
					el.addClass( 'm7pa-active-field' );
				} else if ( val && ! hidden ) {
					if ( el.hasClass( 'm7pa-per-character-pricing' ) ) { added = self.textLength( val, el ) * price; }
					else if ( el.hasClass( 'm7pa-multiply-pricing' ) ) { added = val * price; }
					else if ( el.hasClass( 'm7pa-group-name_price' ) ) { added = parseFloat( val ); }
					else { added = price; }
					el.addClass( 'm7pa-active-field' );
				}
				flat += isNaN( added ) ? 0 : added;
				el.attr( 'data-field-price', added ).attr( 'data-field-value', val );
			}
		} );

		// Radio en enkele afbeeldingen.
		w.find( '.m7pa-item-radio, .m7pa-item-image_swatch' ).each( function () {
			var el = $( this );
			if ( dependentOff( el ) || el.hasClass( 'm7pa-hidden-field' ) || el.closest( '.m7pa-group-wrap' ).hasClass( 'm7pa-group-hidden' ) ) { return; }
			var radio = el.find( 'input[type=radio]:checked' ), added = 0;
			if ( radio.attr( 'data-option-cost' ) ) {
				var opt = radio.attr( 'data-option-cost' );
				el.attr( 'data-selected-option-price', opt );
				if ( 'value' !== el.attr( 'data-option-price-visibility' ) ) {
					added = ( parseFloat( el.attr( 'data-price' ) ) || 0 ) + parseFloat( opt );
					if ( el.hasClass( 'm7pa-flatrate' ) ) { flat += added; } else { total += added; }
				}
			} else {
				el.attr( 'data-selected-option-price', 0 );
			}
			if ( radio.val() ) {
				el.attr( 'data-field-value', radio.val() ).attr( 'data-field-price', added ).addClass( 'm7pa-active-field' );
			} else if ( ! el.hasClass( 'm7pa-item-image-swatch-checkbox' ) ) {
				el.attr( 'data-field-value', '' ).attr( 'data-field-price', 0 ).removeClass( 'm7pa-active-field' );
			}
		} );

		w.find( '.m7pa-item-select' ).each( function () {
			var el = $( this );
			el.attr( 'data-selected-option-price', el.hasClass( 'm7pa-hidden-field' ) ? 0 : el.find( 'option:selected' ).attr( 'data-option-cost' ) );
		} );

		// Checkbox-groepen en meerdere afbeeldingen.
		w.find( '.m7pa-item-checkbox_group, .m7pa-item-image-swatch-checkbox' ).each( function () {
			var el = $( this ), counter = 0, sum = 0, values = [];
			if ( dependentOff( el ) ) { return; }
			if ( ! el.hasClass( 'm7pa-hidden-field' ) && ! el.closest( '.m7pa-group-wrap' ).hasClass( 'm7pa-group-hidden' ) ) {
				var boxes = el.find( 'input[type=checkbox]:checked' );
				if ( boxes.length ) { sum += parseFloat( el.attr( 'data-price' ) ) || 0; }
				boxes.each( function () { sum += parseFloat( $( this ).attr( 'data-option-cost' ) ) || 0; values.push( this.value ); counter++; } );
				if ( el.hasClass( 'm7pa-flatrate' ) ) { flat += sum; } else { total += sum; }
				if ( values.length ) {
					el.attr( 'data-field-price', sum ).attr( 'data-field-value', values.join( ', ' ) ).addClass( 'm7pa-active-field' );
				} else {
					el.attr( 'data-field-price', 0 ).attr( 'data-field-value', '' ).removeClass( 'm7pa-active-field' );
				}
			}
			if ( String( counter ) !== el.attr( 'data-field-selected-counter' ) ) { el.attr( 'data-field-selected-counter', counter ); }
		} );

		// Gekoppelde producten (opgeteld na vermenigvuldigen met het aantal).
		var mainQty = function () { return self.quantity(); };
		var childQty = function ( mode, holder ) {
			if ( 'linked' === mode ) { return mainQty(); }
			if ( 'independent' === mode ) {
				var q = holder.find( '.m7pa-child-quantity-field' ).first().val();
				return self.config.multiplyIndependent ? q * parseFloat( mainQty() ) : q;
			}
			return 1;
		};
		w.find( '.m7pa-child-select-field' ).each( function () {
			var sel = $( this ), el = sel.closest( '.m7pa-item' );
			if ( el.hasClass( 'm7pa-hidden-field' ) || dependentOff( el ) ) { return; }
			el.removeClass( 'm7pa-active-field' );
			if ( sel.val() ) {
				var opt = sel.find( ':selected' ), cost = parseFloat( opt.attr( 'data-option-cost' ) ) || 0;
				var wrapper = sel.closest( '.child-product-wrapper' );
				var q = cost > 0 ? childQty( wrapper.attr( 'data-products-quantities' ), wrapper ) : 0;
				children += cost * parseFloat( q );
				el.attr( 'data-field-price', children ).attr( 'data-field-value', opt.attr( 'data-field-value' ) ).addClass( 'm7pa-active-field' );
			}
		} );
		w.find( '.m7pa-radio-images-wrapper.child-product-wrapper' ).each( function () {
			var wrapper = $( this ), el = wrapper.closest( '.m7pa-item' );
			if ( el.hasClass( 'm7pa-hidden-field' ) || dependentOff( el ) ) { return; }
			var radio = wrapper.find( '.m7pa-radio-form-field:checked' );
			if ( radio.val() ) {
				var cost = parseFloat( radio.attr( 'data-option-cost' ) ) || 0;
				var q = childQty( wrapper.attr( 'data-products-quantities' ), el );
				children += cost * parseFloat( q );
				if ( children > 0 || q > 0 ) {
					el.attr( 'data-field-price', children ).attr( 'data-field-value', radio.attr( 'data-field-label' ) ).addClass( 'm7pa-active-field' );
				}
			} else {
				el.removeClass( 'm7pa-active-field' ).attr( 'data-field-price', 0 ).attr( 'data-field-value', '' );
			}
		} );
		w.find( '.m7pa-checkboxes-images-wrapper.child-product-wrapper' ).each( function () {
			var wrapper = $( this ), el = wrapper.closest( '.m7pa-item' ), own = 0, labels = [], counter = 0;
			if ( ! el.hasClass( 'm7pa-hidden-field' ) && ! dependentOff( el ) ) {
				var mode = wrapper.attr( 'data-products-quantities' );
				el.removeClass( 'm7pa-active-field' );
				wrapper.find( '.m7pa-checkbox-form-field:checked' ).each( function () {
					var box = $( this ), cost = parseFloat( box.attr( 'data-option-cost' ) ) || 0;
					var q = childQty( mode, box.closest( '.m7pa-checkbox-wrapper' ) );
					counter += 'independent' === mode ? parseInt( q, 10 ) || 0 : 1;
					labels.push( box.attr( 'data-field-label' ) );
					if ( cost > 0 ) { children += cost * parseFloat( q ); own += cost * parseFloat( q ); }
				} );
				if ( labels.length ) {
					el.attr( 'data-field-price', children ).attr( 'data-field-value', labels.join( ', ' ) ).addClass( 'm7pa-active-field' );
				}
			}
			if ( String( counter ) !== el.attr( 'data-field-selected-counter' ) ) { el.attr( 'data-field-selected-counter', counter ); }
		} );

		if ( productPrice < 0 ) { productPrice = 0; }
		var qty = parseFloat( mainQty() );
		var productTotal = qty * productPrice;
		var grand = productTotal;
		w.find( '#m7pa-per-product-total' ).html( money( productTotal.toFixed( this.cur.decimals ), this.cur ) );
		total = qty * total + children;
		grand += total;
		if ( ! isNaN( total ) ) {
			w.find( '#m7pa-options-total' ).html( money( total.toFixed( this.cur.decimals ), this.cur ) );
		}
		if ( flat < 0 ) { flat = 0; }
		grand += flat;
		w.find( '#m7pa-flat-rate-total' ).html( money( flat.toFixed( this.cur.decimals ), this.cur ) );
		var setPrice = w.find( '#m7pa_calc_set_price' );
		if ( '1' === String( setPrice.attr( 'data-calc-set' ) ) && w.find( '.m7pa-item-calculation' ).not( '.m7pa-hidden-field' ).length ) {
			grand = parseFloat( setPrice.val() );
			if ( this.form.find( '.quantity .qty' ).length ) { grand = grand * qty; }
		}
		if ( ! isNaN( grand ) ) {
			var html = money( grand.toFixed( this.cur.decimals ), this.cur );
			w.find( '#m7pa-grand-total' ).html( html );
			w.find( '#m7pa_total_calc_price' ).val( grand.toFixed( this.cur.decimals ) );
			if ( this.config.updatePrice ) { this.updateMainPrice( html ); }
		}
		this.wrap.trigger( 'm7pa_after_update_total', [ total, grand ] );
		// Voorwaarden op het totaalbedrag pas na het optellen opnieuw bekijken.
		if ( this.costRules && this.runConditions() ) { this.schedule(); }
	};

	Addons.prototype.updateMainPrice = function ( html ) {
		var main = $( '.m7pa-main-price' ).first();
		if ( ! main.length ) { return; }
		var before = main.find( '.m7pa-label-before' ).html();
		var after = main.find( '.m7pa-label-after' ).html();
		var hide = main.find( '.m7pa-label-hidden' );
		var suffix = main.find( '.woocommerce-price-suffix' ).html();
		var out = '';
		if ( hide.length ) {
			out = '<span class="m7pa-label-hidden">' + hide.html() + '</span>';
		} else {
			if ( before ) { out += '<span class="m7pa-label-before">' + before + ' </span>'; }
			out += html;
			if ( after ) { out += '<span class="m7pa-label-after"> ' + after + '</span>'; }
			if ( suffix ) { out += '&nbsp;<small class="woocommerce-price-suffix">' + suffix + '</small>'; }
		}
		main.html( out );
	};

	/* ---- hoofdafbeelding vervangen door de gekozen afbeelding ---- */

	Addons.prototype.replaceImage = function ( changed ) {
		var self = this;
		var fields = this.wrap.find( '.m7pa-replace-main-image' );
		if ( ! fields.length ) { return; }
		var product = this.form.closest( '.product' );
		var gallery = ( product.length ? product : $( document ) ).find( '.images, .woocommerce-product-gallery' ).first();
		var img = gallery.find( '.woocommerce-product-gallery__image, .woocommerce-product-gallery__image--placeholder' ).first().find( 'img' ).first();
		if ( ! img.length ) { return; }
		var attrs = [ 'src', 'srcset', 'data-src', 'data-large_image', 'data-large_image_width', 'data-large_image_height' ];
		if ( undefined === img.attr( 'data-m7pa-saved' ) ) {
			attrs.forEach( function ( a ) { img.attr( 'data-m7pa-old-' + a, img.attr( a ) || '' ); } );
			img.attr( 'data-m7pa-saved', '1' );
		}
		var pick = function ( el ) {
			if ( self.isHidden( el ) ) { return null; }
			var input = el.find( 'input:checked' ).last();
			var src = input.length ? input.siblings( 'img' ).first() : $();
			return src.length && src.attr( 'data-large_image' ) ? { el: el, img: src, input: input } : null;
		};
		var chosen = changed && changed.hasClass( 'm7pa-replace-main-image' ) ? pick( changed ) : null;
		if ( ! chosen ) {
			fields.each( function () { if ( ! chosen ) { chosen = pick( $( this ) ); } } );
		}
		var wrapper = gallery.find( '.woocommerce-product-gallery__wrapper' ).first();
		wrapper.removeClass( function ( i, c ) { return ( c.match( /(^|\s)m7pa-add-on-image-\S+/g ) || [] ).join( ' ' ); } );
		if ( chosen ) {
			var full = chosen.img.attr( 'data-large_image' );
			img.attr( { src: full, srcset: full, 'data-src': full, 'data-large_image': full, 'data-large_image_width': chosen.img.attr( 'data-large_image_width' ), 'data-large_image_height': chosen.img.attr( 'data-large_image_height' ) } );
			gallery.find( 'img.zoomImg' ).attr( 'src', full );
			var fid = chosen.el.attr( 'data-field-id' );
			wrapper.addClass( 'm7pa-add-on-image-' + fid + ' m7pa-add-on-image-' + fid + '-' + String( chosen.input.attr( 'id' ) || '' ).replace( chosen.el.attr( 'data-id' ) + '_', '' ) );
		} else {
			attrs.forEach( function ( a ) {
				var v = img.attr( 'data-m7pa-old-' + a );
				if ( v ) { img.attr( a, v ); } else { img.removeAttr( a ); }
			} );
			gallery.find( 'img.zoomImg' ).attr( 'src', img.attr( 'data-m7pa-old-data-large_image' ) || img.attr( 'src' ) );
		}
	};

	/* ---- tekens tellen ---- */

	Addons.prototype.updateCounter = function ( input ) {
		var el = input.closest( '.m7pa-item' );
		if ( ! el.hasClass( 'm7pa-item-text' ) && ! el.hasClass( 'm7pa-item-textarea' ) ) { return; }
		var len = String( input.val() ).length;
		var count = el.find( '.m7pa-text-counter-container .m7pa-current-count' );
		count.html( len ).removeClass( 'error' );
		var min = parseInt( input.attr( 'data-minchars' ), 10 ), max = parseInt( input.attr( 'data-maxchars' ), 10 );
		if ( min > 0 && len < min ) { count.addClass( 'error' ); } else if ( max > 0 && len > max ) { count.addClass( 'error' ); }
	};

	Addons.prototype.updateCounters = function () {
		var self = this;
		this.wrap.find( '.m7pa-item-text .m7pa-form-field, .m7pa-item-textarea .m7pa-form-field' ).each( function () { self.updateCounter( $( this ) ); } );
	};

	/* ---- widgets: datum, kleur, schuif ---- */

	Addons.prototype.initWidgets = function () {
		var self = this;
		this.wrap.find( '.m7pa-color-picker-field' ).each( function () {
			var el = $( this );
			if ( ! $.fn.wpColorPicker ) { return; }
			el.wpColorPicker( {
				defaultColor: el.data( 'color' ) ? el.data( 'color' ) : false,
				change: function ( e, ui ) { el.closest( '.m7pa-item' ).attr( 'data-field-value', ui.color.toString() ); self.schedule(); },
				clear: function () { el.closest( '.m7pa-item' ).attr( 'data-field-value', '' ); self.schedule(); },
				hide: ! el.data( 'show' ),
				palettes: !! el.data( 'palettes' ),
				width: el.data( 'box-width' ) ? el.data( 'box-width' ) : 255,
				mode: 'hsv',
				type: 'full',
				slider: 'horizontal'
			} );
		} );
		$.each( this.fields, function ( id, f ) {
			if ( 'date' !== f.type || ! $.fn.datepicker ) { return; }
			var input = self.item( id ).find( '.m7pa-date-field' );
			input.on( 'focus', function () {
				if ( input.hasClass( 'hasDatepicker' ) ) { return; }
				var opts = {}, d = f.date || {};
				if ( '' !== d.offset && undefined !== d.offset ) { opts.minDate = parseInt( d.offset, 10 ); }
				else if ( d.min_today ) { opts.minDate = 0; }
				else if ( d.min ) { var a = d.min.split( '-' ); opts.minDate = new Date( a[ 0 ], a[ 1 ] - 1, a[ 2 ] ); }
				if ( d.max ) { var b = d.max.split( '-' ); opts.maxDate = new Date( b[ 0 ], b[ 1 ] - 1, b[ 2 ] ); }
				input.datepicker( opts ).datepicker( 'show' );
			} );
		} );
		this.wrap.find( 'input.m7pa-range-slider' ).each( function () {
			if ( $( this ).attr( 'value' ) > 0 ) { $( this ).trigger( 'change' ); }
		} );
	};

	/* ---- gebeurtenissen ---- */

	Addons.prototype.bind = function () {
		var self = this, w = this.wrap;

		w.on( 'change input keyup paste', 'input, select, textarea', function ( e ) {
			var input = $( this );
			if ( input.hasClass( 'm7pa-upload__input' ) ) {
				if ( 'change' === e.type ) { self.upload( input.closest( '.m7pa-item' ), this.files ); this.value = ''; }
				return;
			}
			var el = input.closest( '.m7pa-item' );
			// Maximaal aantal tekens direct afdwingen (spaties tellen mee).
			if ( el.hasClass( 'm7pa-has-maxchars' ) && ( this.tagName === 'TEXTAREA' || 'text' === this.type ) ) {
				var max = parseInt( input.attr( 'data-maxchars' ), 10 );
				if ( max > 0 && String( input.val() ).length > max ) { input.val( String( input.val() ).substring( 0, max ) ); }
			}
			if ( input.hasClass( 'm7pa-range-slider' ) ) {
				el.find( '.m7pa-range-value' ).text( input.val() );
				el.attr( 'data-field-value', input.val() );
			}
			if ( input.hasClass( 'm7pa-form-field' ) ) { self.updateCounter( input ); }
			self.runConditions();
			self.recalculate();
			self.runConditions();
			if ( 'change' === e.type ) { self.replaceImage( el ); }
			self.schedule();
		} );
		this.form.on( 'change input keyup paste', '.qty, [name^="attribute_"]', function () {
			self.runConditions();
			self.recalculate();
			self.schedule();
		} );
		this.form.on( 'click', '.wc-block-components-quantity-selector', function () { setTimeout( function () { self.recalculate(); self.schedule(); }, 0 ); } );

		// Keuzes met afbeeldingen: klasse "checked"; een gekozen enkele keuze opnieuw aanklikken zet hem uit.
		w.on( 'click', '.m7pa-radio-image-wrapper, .m7pa-checkbox-image-wrapper', function ( e ) {
			var wrap = $( this );
			if ( wrap.hasClass( 'm7pa-checkbox-disabled' ) || wrap.closest( '.child-product-wrapper' ).length ) { return; }
			var input = wrap.find( 'input' ).first();
			if ( $( e.target ).is( 'input' ) ) { return; }
			e.preventDefault();
			if ( 'radio' === input.attr( 'type' ) ) {
				var was = input.prop( 'checked' );
				wrap.siblings().removeClass( 'checked' ).find( 'input' ).prop( 'checked', false );
				input.prop( 'checked', ! was );
				wrap.toggleClass( 'checked', ! was );
			} else {
				input.prop( 'checked', ! input.prop( 'checked' ) );
				wrap.toggleClass( 'checked', input.prop( 'checked' ) );
			}
			input.trigger( 'change' );
		} );
		// Tekstblokjes (radio/checkbox als swatch).
		w.on( 'change', '.m7pa-text-swatch input', function () {
			var input = $( this ), el = input.closest( '.m7pa-item' );
			if ( 'radio' === this.type ) { el.find( 'label' ).removeClass( 'active-swatch' ); }
			input.closest( 'label' ).toggleClass( 'active-swatch', this.checked );
		} );
		// Gekoppelde producten.
		w.on( 'change', '.child-product-wrapper .m7pa-checkbox-form-field', function () {
			var box = $( this ), holder = box.closest( '.m7pa-checkbox-wrapper' );
			holder.toggleClass( 'checked', this.checked );
			if ( box.closest( '.products-quantities-independent' ).length ) {
				var q = holder.find( '.m7pa-child-quantity-field' );
				if ( this.checked && ! ( parseInt( q.val(), 10 ) > 0 ) ) { q.val( 1 ); }
				if ( ! this.checked ) { q.val( 0 ); }
			}
		} );
		w.on( 'change input', '.products-quantities-independent .m7pa-child-quantity-field', function () {
			var q = $( this ), holder = q.closest( '.m7pa-checkbox-wrapper' );
			if ( holder.length ) {
				var on = parseInt( q.val(), 10 ) > 0;
				holder.find( '.m7pa-checkbox-form-field' ).prop( 'checked', on );
				holder.toggleClass( 'checked', on );
			}
		} );
		w.on( 'change', '.child-product-wrapper .m7pa-radio-form-field', function () {
			var wrapper = $( this ).closest( '.child-product-wrapper' );
			wrapper.find( '.m7pa-radio-image-wrapper' ).removeClass( 'checked' );
			$( this ).closest( '.m7pa-radio-image-wrapper' ).addClass( 'checked' );
		} );

		// Accordeon, tabbladen en stappen.
		w.on( 'click', '.m7pa-group-heading', function () {
			if ( ! w.hasClass( 'm7pa-groups-accordion' ) ) { return; }
			$( this ).closest( '.m7pa-group-wrap' ).toggleClass( 'group-active' );
		} );
		w.on( 'click', '.m7pa-tab', function ( e ) {
			e.preventDefault();
			var id = $( this ).attr( 'data-group-id' );
			w.find( '.m7pa-tab' ).removeClass( 'active-tab tab-failed' );
			$( this ).addClass( 'active-tab' );
			w.find( '.m7pa-group-wrap' ).removeClass( 'group-active' );
			w.find( '.m7pa-group-wrap-' + id ).addClass( 'group-active' );
		} );
		w.on( 'click', '.m7pa-next-step-button', function ( e ) {
			e.preventDefault();
			var id = $( this ).attr( 'data-group-id' );
			var index = parseInt( $( this ).closest( '.m7pa-group-wrap' ).attr( 'data-group-index' ), 10 );
			var dir = $( this ).attr( 'data-direction' );
			if ( w.find( '.m7pa-group-wrap-' + id ).hasClass( 'm7pa-group-hidden' ) ) {
				var all = w.find( '.m7pa-group-wrap' );
				for ( var i = 'next' === dir ? index + 1 : index - 1; i >= 0 && i < all.length; i += 'next' === dir ? 1 : -1 ) {
					var g = w.find( '.m7pa-group-index-' + i );
					if ( ! g.hasClass( 'm7pa-group-hidden' ) ) { id = g.attr( 'data-group-id' ); break; }
				}
			}
			w.find( '.m7pa-tab' ).removeClass( 'active-tab tab-failed' );
			w.find( '#m7pa-tab-' + id ).addClass( 'active-tab' );
			w.find( '.m7pa-group-wrap' ).removeClass( 'group-active' );
			w.find( '.m7pa-group-wrap-' + id ).addClass( 'group-active' );
			var nav = w.find( '.m7pa-steps-wrapper' );
			if ( nav.length ) { $( 'html, body' ).animate( { scrollTop: nav.offset().top }, 150 ); }
		} );

		// Variaties: prijs, percentages en velden per variatie.
		this.form.on( 'show_variation', function ( e, variation ) {
			if ( ! variation || ! isFinite( variation.display_price ) ) { return; }
			self.variation( variation );
		} ).on( 'hide_variation', function () { self.variation( null ); } );
	};

	Addons.prototype.variation = function ( variation ) {
		var self = this, w = this.wrap, cur = this.cur;
		var price = variation ? parseFloat( variation.display_price ) : 0;
		w.find( '#m7pa-product-price' ).val( price );
		w.find( '#m7pa_calc_set_price' ).attr( 'data-calc-set', 0 );
		if ( variation ) {
			// Percentages opnieuw uitrekenen en de getoonde bedragen bijwerken (zelfde teksten als het origineel).
			w.find( '.m7pa-percentage' ).each( function () {
				var el = $( this );
				var p = price / 100 * parseFloat( el.attr( 'data-percentage' ) );
				if ( isNaN( p ) ) { p = 0; }
				el.attr( 'data-price', p );
				el.find( '.m7pa-field-price' ).html( money( p.toFixed( cur.decimals ), cur ) );
				if ( el.hasClass( 'm7pa-item-checkbox' ) ) {
					el.find( '.m7pa-checkbox-price' ).html( money( p.toFixed( cur.decimals ), cur, true ) );
					return;
				}
				el.find( '.m7pa-option-has-percentage' ).each( function () {
					var op = price / 100 * $( this ).attr( 'data-option-percentage' );
					$( this ).attr( 'data-option-cost', op.toFixed( cur.decimals ) );
					$( this ).closest( '.m7pa-checkbox-form-label' ).find( '.m7pa-option-cost-label' ).html( money( op.toFixed( cur.decimals ), cur ) );
				} );
			} );
			w.find( '.m7pa-percentage.m7pa-item-select select' ).each( function () {
				var sel = $( this ), item = sel.closest( '.m7pa-item' );
				sel.find( 'option' ).each( function () {
					var np = price / 100 * $( this ).attr( 'data-option-percentage' );
					$( this ).attr( 'data-option-cost', np.toFixed( cur.decimals ) );
					if ( item.hasClass( 'm7pa-hide-option-price' ) || $( this ).hasClass( 'm7pa-first-option' ) ) { return; }
					$( this ).text( $( this ).val() + self.config.separator + money( np.toFixed( cur.decimals ), cur, true ) );
				} );
			} );
			w.find( '.m7pa-percentage.m7pa-item-image_swatch, .m7pa-percentage.m7pa-item-radio' ).each( function () {
				var field = $( this );
				field.find( 'input' ).each( function () {
					var np = price / 100 * $( this ).attr( 'data-option-percentage' );
					$( this ).attr( 'data-option-cost', np.toFixed( cur.decimals ) );
					var text = $( this ).val() + self.config.separator + money( np.toFixed( cur.decimals ), cur, true );
					$( this ).closest( 'label' ).next().text( text );
					if ( field.hasClass( 'm7pa-hide-option-price' ) ) { return; }
					if ( ( field.hasClass( 'm7pa-item-radio' ) || field.hasClass( 'm7pa-item-image-swatch-checkbox' ) ) && field.hasClass( 'm7pa-item-image_swatch' ) ) {
						$( this ).closest( 'label' ).find( '.m7pa-radio-image-desc span' ).text( text );
					} else if ( field.hasClass( 'm7pa-item-radio' ) ) {
						$( this ).closest( 'li' ).find( 'label span.m7pa-radio-option-text' ).text( text );
					}
				} );
			} );
		}
		var vid = variation ? parseInt( variation.variation_id, 10 ) : 0;
		$.each( this.fields, function ( id, f ) {
			if ( ! f.variations || ! f.variations.length ) { return; }
			self.item( id ).toggleClass( 'active', f.variations.indexOf( vid ) > -1 );
		} );
		this.runConditions();
		this.recalculate();
		this.schedule();
	};

	/* ---- uploads (eigen AJAX-upload, alleen als uploaden is toegestaan) ---- */

	Addons.prototype.upload = function ( el, files ) {
		var self = this;
		var tokensInput = el.find( '.m7pa-upload__tokens' );
		var list = el.find( '.m7pa-upload__list' );
		var max = parseInt( el.find( '.m7pa-upload' ).attr( 'data-max-files' ), 10 ) || 1;
		var tokens = [];
		try { tokens = tokensInput.val() ? JSON.parse( tokensInput.val() ) : []; } catch ( e ) { tokens = []; }
		Array.prototype.slice.call( files, 0, Math.max( 0, max - tokens.length ) ).forEach( function ( file ) {
			var li = $( '<li>' ).text( file.name + ' – ' + self.config.i18n.uploading ).appendTo( list );
			var data = new FormData();
			data.append( 'action', 'm7pa_upload' );
			data.append( 'nonce', self.wrap.find( '#m7pa_upload_nonce' ).val() );
			data.append( 'product_id', self.config.productId );
			data.append( 'field_id', el.attr( 'data-field-id' ) );
			data.append( 'file', file );
			fetch( self.config.uploadUrl, { method: 'POST', body: data, credentials: 'same-origin' } )
				.then( function ( r ) { return r.json(); } )
				.then( function ( res ) {
					if ( ! res.success ) { throw new Error( res.data && res.data.message ? res.data.message : 'Upload' ); }
					tokens.push( res.data.token );
					tokensInput.val( JSON.stringify( tokens ) ).trigger( 'change' );
					li.text( res.data.name + ' ' );
					$( '<button type="button" class="m7pa-upload__remove">' ).text( self.config.i18n.remove ).appendTo( li ).on( 'click', function () {
						tokens = tokens.filter( function ( t ) { return t !== res.data.token; } );
						tokensInput.val( tokens.length ? JSON.stringify( tokens ) : '' ).trigger( 'change' );
						li.remove();
					} );
				} )
				.catch( function ( e ) { li.text( file.name + ' – ' + e.message ).addClass( 'is-error' ); } );
		} );
	};

	function boot() {
		$( '.m7pa-product-extra-groups-wrap' ).each( function () {
			if ( ! this.m7pa ) { this.m7pa = new Addons( this ); }
		} );
	}

	window.M7ProductAddons = { evaluate: evaluate, boot: boot, money: money };
	$( boot );
}( jQuery ) );
