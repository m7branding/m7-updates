/**
 * M7 Product Add-Ons – groepsbouwer in wp-admin.
 * De velden staan als JSON in een verborgen invoer; PHP schoont alles op bij opslaan.
 */
( function () {
	'use strict';

	var cfg = window.m7paAdmin || {};
	var T = cfg.i18n || {};
	var root = document.getElementById( 'm7pa-builder' );
	if ( ! root ) { return; }
	var input = document.getElementById( 'm7pa-fields-json' );
	var fields = [];
	try { fields = JSON.parse( input.value || '[]' ); } catch ( e ) { fields = []; }
	var collapsed = {};

	var OPTION_TYPES = [ 'checkbox_group', 'radio', 'select', 'image_swatch' ];

	function uid() { return 'f' + Math.random().toString( 36 ).slice( 2, 10 ); }

	function el( tag, attrs, children ) {
		var n = document.createElement( tag );
		Object.keys( attrs || {} ).forEach( function ( k ) {
			if ( 'text' === k ) { n.textContent = attrs[ k ]; }
			else if ( 'on' === k ) { Object.keys( attrs.on ).forEach( function ( ev ) { n.addEventListener( ev, attrs.on[ ev ] ); } ); }
			else if ( attrs[ k ] === true ) { n.setAttribute( k, '' ); }
			else if ( attrs[ k ] !== false && attrs[ k ] !== null && attrs[ k ] !== undefined ) { n.setAttribute( k, attrs[ k ] ); }
		} );
		( children || [] ).forEach( function ( c ) { if ( c ) { n.appendChild( 'string' === typeof c ? document.createTextNode( c ) : c ); } } );
		return n;
	}

	function save() { input.value = JSON.stringify( fields ); }

	function get( obj, path ) {
		return path.split( '.' ).reduce( function ( o, k ) { return o && o[ k ] !== undefined ? o[ k ] : undefined; }, obj );
	}
	function set( obj, path, value ) {
		var parts = path.split( '.' ), last = parts.pop();
		var target = parts.reduce( function ( o, k ) { if ( ! o[ k ] || 'object' !== typeof o[ k ] ) { o[ k ] = {}; } return o[ k ]; }, obj );
		target[ last ] = value;
		save();
	}

	function text( f, path, label, opts ) {
		opts = opts || {};
		var v = get( f, path );
		var i = el( opts.textarea ? 'textarea' : 'input', { type: opts.type || 'text', value: v === undefined || v === null ? '' : v, placeholder: opts.placeholder || '', step: opts.step || null, rows: opts.textarea ? 3 : null } );
		if ( opts.textarea ) { i.value = v || ''; }
		i.addEventListener( 'input', function () { set( f, path, i.value ); if ( 'label' === path ) { refreshHead( f ); } } );
		return el( 'label', { class: opts.wide ? 'm7pa-wide' : '' }, [ label, i, opts.hint ? el( 'span', { class: 'm7pa-hint', text: opts.hint } ) : null ] );
	}

	function check( f, path, label ) {
		var i = el( 'input', { type: 'checkbox' } );
		i.checked = !! get( f, path );
		i.addEventListener( 'change', function () { set( f, path, i.checked ); } );
		return el( 'label', { class: 'm7pa-inline' }, [ i, label ] );
	}

	function select( f, path, label, options, onChange ) {
		var s = el( 'select' );
		Object.keys( options ).forEach( function ( k ) {
			var o = el( 'option', { value: k, text: options[ k ] } );
			if ( String( get( f, path ) ) === k ) { o.selected = true; }
			s.appendChild( o );
		} );
		s.addEventListener( 'change', function () { set( f, path, s.value ); if ( onChange ) { onChange(); } } );
		return el( 'label', {}, [ label, s ] );
	}

	function title( t ) { return el( 'div', { class: 'm7pa-section-title', text: t } ); }

	function rowsTable( f, path, columns, addLabel ) {
		var list = get( f, path ) || [];
		set( f, path, list );
		var table = el( 'table', { class: 'm7pa-subtable' } );
		var head = el( 'tr', {}, columns.map( function ( c ) { return el( 'th', { text: c.label } ); } ).concat( [ el( 'th' ) ] ) );
		table.appendChild( el( 'thead', {}, [ head ] ) );
		var body = el( 'tbody' );
		function draw() {
			body.innerHTML = '';
			list.forEach( function ( row, idx ) {
				var tr = el( 'tr' );
				columns.forEach( function ( c ) {
					var i = el( 'input', { type: c.type || 'text', value: row[ c.key ] === undefined ? '' : row[ c.key ], step: c.step || null, placeholder: c.placeholder || '' } );
					i.addEventListener( 'input', function () { row[ c.key ] = i.value; save(); } );
					tr.appendChild( el( 'td', {}, [ i ] ) );
				} );
				tr.appendChild( el( 'td', {}, [
					el( 'button', { type: 'button', class: 'button-link', title: T.up, text: '↑', on: { click: function () { if ( idx > 0 ) { list.splice( idx - 1, 0, list.splice( idx, 1 )[ 0 ] ); save(); draw(); } } } } ),
					el( 'button', { type: 'button', class: 'button-link', title: T.remove, text: '✕', on: { click: function () { list.splice( idx, 1 ); save(); draw(); } } } ),
				] ) );
				body.appendChild( tr );
			} );
		}
		draw();
		table.appendChild( body );
		var add = el( 'button', { type: 'button', class: 'button m7pa-add-row', text: addLabel, on: { click: function () { var r = {}; columns.forEach( function ( c ) { r[ c.key ] = ''; } ); list.push( r ); save(); draw(); } } } );
		return el( 'div', { class: 'm7pa-wide' }, [ table, add ] );
	}

	function conditionsBox( f ) {
		f.conditions = f.conditions || { action: 'show', match: 'all', rules: [] };
		var wrap = el( 'div', { class: 'm7pa-wide' } );
		var targets = { '': '—' };
		fields.forEach( function ( o ) { if ( o.id !== f.id ) { targets[ o.id ] = ( o.label || o.id ) + ' (' + ( cfg.types[ o.type ] || o.type ) + ')'; } } );
		targets.quantity = T.quantity;
		targets.product_price = T.productPrice;
		( cfg.attributes || [] ).forEach( function ( a ) { targets[ 'attribute:' + a.name ] = T.attribute + ': ' + a.label; } );

		var head = el( 'div', { style: 'display:flex;gap:8px;align-items:center;flex-wrap:wrap' }, [
			select( f, 'conditions.action', T.condAction, { show: T.show, hide: T.hide } ),
			select( f, 'conditions.match', T.condMatch, { all: T.all, any: T.any } ),
		] );
		wrap.appendChild( head );
		var list = el( 'div' );
		function draw() {
			list.innerHTML = '';
			f.conditions.rules.forEach( function ( r, idx ) {
				var row = el( 'div', { style: 'display:flex;gap:6px;margin-top:6px;align-items:center' } );
				var s1 = el( 'select' );
				Object.keys( targets ).forEach( function ( k ) { var o = el( 'option', { value: k, text: targets[ k ] } ); if ( k === r.field ) { o.selected = true; } s1.appendChild( o ); } );
				s1.addEventListener( 'change', function () { r.field = s1.value; save(); } );
				var s2 = el( 'select' );
				Object.keys( cfg.operators ).forEach( function ( k ) { var o = el( 'option', { value: k, text: cfg.operators[ k ] } ); if ( k === r.operator ) { o.selected = true; } s2.appendChild( o ); } );
				s2.addEventListener( 'change', function () { r.operator = s2.value; save(); } );
				var v = el( 'input', { type: 'text', value: r.value || '', placeholder: T.value } );
				v.addEventListener( 'input', function () { r.value = v.value; save(); } );
				var del = el( 'button', { type: 'button', class: 'button-link', text: '✕', on: { click: function () { f.conditions.rules.splice( idx, 1 ); save(); draw(); } } } );
				row.appendChild( s1 ); row.appendChild( s2 ); row.appendChild( v ); row.appendChild( del );
				list.appendChild( row );
			} );
		}
		draw();
		wrap.appendChild( list );
		wrap.appendChild( el( 'button', { type: 'button', class: 'button m7pa-add-row', text: T.addRule, on: { click: function () { f.conditions.rules.push( { field: '', operator: 'is', value: '' } ); save(); draw(); } } } ) );
		return wrap;
	}

	function body( f ) {
		var b = el( 'div', { class: 'm7pa-card__body' } );
		var add = function ( n ) { if ( n ) { b.appendChild( n ); } };
		add( select( f, 'type', T.type, cfg.types, function () { render(); } ) );
		add( text( f, 'label', T.label ) );
		add( check( f, 'required', T.required ) );
		add( check( f, 'hide_label', T.hideLabel ) );
		add( text( f, 'description', T.description, { textarea: true, wide: true } ) );

		if ( 'information' !== f.type && 'products' !== f.type ) {
			add( title( T.pricing ) );
			if ( 'name_price' !== f.type ) {
				add( text( f, 'price', T.price, { type: 'number', step: 'any' } ) );
				add( select( f, 'price_type', T.priceType, cfg.priceTypes ) );
			}
		}

		if ( OPTION_TYPES.indexOf( f.type ) >= 0 ) {
			add( title( T.options ) );
			if ( 'image_swatch' === f.type ) { add( check( f, 'multiple', T.multiple ) ); }
			add( rowsTable( f, 'options', [
				{ key: 'value', label: T.value },
				{ key: 'label', label: T.label },
				{ key: 'price', label: T.price, type: 'number', step: 'any' },
				{ key: 'image', label: T.imageId, type: 'number' },
			], T.addOption ) );
			add( text( f, 'default', T.default, { hint: T.defaultHint } ) );
			if ( 'select' === f.type ) { add( text( f, 'placeholder', T.placeholder ) ); }
		}
		if ( 'text' === f.type || 'textarea' === f.type ) {
			add( text( f, 'placeholder', T.placeholder ) );
			add( text( f, 'min_chars', T.minChars, { type: 'number' } ) );
			add( text( f, 'max_chars', T.maxChars, { type: 'number' } ) );
			add( text( f, 'default', T.default ) );
		}
		if ( 'number' === f.type || 'name_price' === f.type ) {
			add( text( f, 'min', T.min, { type: 'number', step: 'any' } ) );
			add( text( f, 'max', T.max, { type: 'number', step: 'any' } ) );
			add( text( f, 'step', T.step, { type: 'number', step: 'any' } ) );
			add( text( f, 'default', T.default ) );
		}
		if ( 'calculation' === f.type ) {
			add( title( T.formula ) );
			add( text( f, 'formula', T.formula, { wide: true, placeholder: '{field:fabc123} * {product_price} / 100', hint: T.formulaHint } ) );
			add( text( f, 'decimals', T.decimals, { type: 'number' } ) );
			add( check( f, 'formula_as_price', T.formulaAsPrice ) );
		}
		if ( 'products' === f.type ) {
			add( title( T.products ) );
			add( text( f, 'products.ids', T.productIds, { wide: true, hint: T.productIdsHint } ) );
			add( select( f, 'products.layout', T.layout, cfg.productLayouts ) );
			add( select( f, 'products.quantities', T.quantities, cfg.productQuantities ) );
			add( text( f, 'products.discount', T.discount, { type: 'number', step: 'any' } ) );
			add( select( f, 'products.discount_type', T.discountType, { percentage: '%', fixed: T.fixedAmount } ) );
			add( check( f, 'products.allow_none', T.allowNone ) );
		}
		if ( 'upload' === f.type ) {
			add( title( T.upload ) );
			add( text( f, 'upload.max_files', T.maxFiles, { type: 'number' } ) );
			add( text( f, 'upload.max_mb', T.maxMb, { type: 'number' } ) );
			add( text( f, 'upload.types', T.fileTypes, { hint: 'jpg, png, pdf' } ) );
		}
		if ( 'information' === f.type ) {
			add( title( T.rows ) );
			add( rowsTable( f, 'rows', [ { key: 'label', label: T.label }, { key: 'value', label: T.value } ], T.addRow ) );
		}
		add( title( T.conditions ) );
		add( conditionsBox( f ) );
		return b;
	}

	var heads = {};
	function refreshHead( f ) {
		if ( heads[ f.id ] ) { heads[ f.id ].textContent = f.label || T.untitled; }
	}

	function card( f, idx ) {
		var labelSpan = el( 'span', { class: 'm7pa-card__label', text: f.label || T.untitled } );
		heads[ f.id ] = labelSpan;
		var c = el( 'div', { class: 'm7pa-card' + ( collapsed[ f.id ] ? ' is-collapsed' : '' ) } );
		var head = el( 'div', { class: 'm7pa-card__head' }, [
			el( 'span', { class: 'm7pa-card__type', text: cfg.types[ f.type ] || f.type } ),
			labelSpan,
			el( 'code', { text: f.id } ),
			el( 'span', { class: 'm7pa-card__tools' }, [
				el( 'button', { type: 'button', title: T.up, text: '↑', on: { click: function ( e ) { e.stopPropagation(); if ( idx > 0 ) { fields.splice( idx - 1, 0, fields.splice( idx, 1 )[ 0 ] ); save(); render(); } } } } ),
				el( 'button', { type: 'button', title: T.down, text: '↓', on: { click: function ( e ) { e.stopPropagation(); if ( idx < fields.length - 1 ) { fields.splice( idx + 1, 0, fields.splice( idx, 1 )[ 0 ] ); save(); render(); } } } } ),
				el( 'button', { type: 'button', title: T.duplicate, text: '⧉', on: { click: function ( e ) { e.stopPropagation(); var copy = JSON.parse( JSON.stringify( f ) ); copy.id = uid(); copy.label = ( copy.label || '' ) + ' ' + T.copySuffix; fields.splice( idx + 1, 0, copy ); save(); render(); } } } ),
				el( 'button', { type: 'button', title: T.remove, text: '✕', on: { click: function ( e ) { e.stopPropagation(); if ( window.confirm( T.confirmRemove ) ) { fields.splice( idx, 1 ); save(); render(); } } } } ),
			] ),
		] );
		head.addEventListener( 'click', function () { collapsed[ f.id ] = ! collapsed[ f.id ]; c.classList.toggle( 'is-collapsed' ); } );
		c.appendChild( head );
		c.appendChild( body( f ) );
		return c;
	}

	function render() {
		root.innerHTML = '';
		if ( ! fields.length ) {
			root.appendChild( el( 'div', { class: 'm7pa-empty', text: T.empty } ) );
		}
		fields.forEach( function ( f, idx ) {
			if ( f.products && Array.isArray( f.products.ids ) ) { f.products.ids = f.products.ids.join( ',' ); }
			if ( f.upload && Array.isArray( f.upload.types ) ) { f.upload.types = f.upload.types.join( ',' ); }
			root.appendChild( card( f, idx ) );
		} );
		var typeSel = el( 'select' );
		Object.keys( cfg.types ).forEach( function ( k ) { typeSel.appendChild( el( 'option', { value: k, text: cfg.types[ k ] } ) ); } );
		root.appendChild( el( 'div', { class: 'm7pa-add-field' }, [
			typeSel,
			el( 'button', { type: 'button', class: 'button m7-button', text: T.addField, on: { click: function () {
				fields.push( { id: uid(), type: typeSel.value, label: '', price: '', price_type: 'fixed', options: [], conditions: { action: 'show', match: 'all', rules: [] }, products: { ids: '', layout: 'checkboxes', quantities: 'linked', discount: '', discount_type: 'percentage', allow_none: true }, upload: { max_files: 1, max_mb: 10, types: 'jpg,jpeg,png,pdf' } } );
				save(); render();
			} } } ),
		] ) );
		save();
	}

	render();
} )();
