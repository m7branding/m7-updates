/**
 * M7 Product Add-Ons – winkelwagen met blokken: gekoppelde producten zonder "Verwijderen" en met een
 * pijltje bij de afbeelding (zelfde weergave als het origineel).
 */
( function ( $ ) {
	'use strict';
	if ( 'undefined' === typeof wc || ! wc.blocksCheckout || ! wc.blocksCheckout.registerCheckoutFilters ) {
		return;
	}
	function data( extensions ) {
		return extensions && extensions.m7pa_data && extensions.m7pa_data.key ? extensions.m7pa_data : null;
	}
	function addArrow( d ) {
		$( function () {
			if ( ! d ) { return; }
			// Regel opzoeken via de cart key (werkt ook als een ander filter de klasse vervangt).
			var parts = d.key.split( ' ' );
			var row = $( '[class*="' + parts[ 0 ] + '"]' ).first();
			row.addClass( 'm7pa-key-' + d.key );
			if ( ! d.arrow_right ) { return; }
			var image = row.find( '.wc-block-cart-item__image' );
			if ( image.length && ! image.find( '.m7pa-arrow-right' ).length ) {
				image.prepend( '<img src="' + d.arrow_right + '" class="m7pa-arrow-right">' );
			}
		} );
	}
	wc.blocksCheckout.registerCheckoutFilters( 'm7pa-cart-item-filter', {
		showRemoveItemLink: function ( value, extensions, args ) {
			var d = data( extensions );
			if ( ! args || 'cart' !== args.context || ! d || ! d.key || d.key.indexOf( 'm7pa-quantities-' ) < 0 || d.key.indexOf( 'm7pa-quantities-independent' ) > -1 ) {
				return value;
			}
			return false;
		},
		cartItemClass: function ( value, extensions, args ) {
			var d = data( extensions );
			if ( ! args || ( 'cart' !== args.context && 'summary' !== args.context ) || ! d ) {
				return value;
			}
			setTimeout( addArrow, 200, d );
			return 'm7pa-key-' + d.key;
		}
	} );
}( jQuery ) );
