<?php
/**
 * Plugin Name:          M7 Product Add-Ons
 * Description:          Extra productopties voor WooCommerce: velden, keuzes met prijs, gekoppelde producten, voorwaarden en berekeningen. Vervanger van Product Add-Ons Ultimate.
 * Version:              1.0.0
 * Requires at least:    6.4
 * Requires PHP:         7.4
 * Requires Plugins:     woocommerce
 * Author:               M7 Branding
 * Author URI:           https://m7branding.com
 * License:              GPL-2.0-or-later
 * Text Domain:          m7-product-addons
 * WC requires at least: 8.0
 * WC tested up to:     11.3
 *
 * @package M7PA
 */

defined( 'ABSPATH' ) || exit;

define( 'M7PA_VERSION', '1.0.0' );
define( 'M7PA_FILE', __FILE__ );
define( 'M7PA_DIR', plugin_dir_path( __FILE__ ) );
define( 'M7PA_URL', plugin_dir_url( __FILE__ ) );

// Gedeelde M7-code: M7-menu en updates (nooit automatisch).
require_once M7PA_DIR . 'includes/m7/class-m7-admin-menu.php';
add_action( 'plugins_loaded', array( 'M7_Updates', 'init' ), 1 );

spl_autoload_register(
	static function ( $class ) {
		if ( 0 !== strpos( $class, 'M7PA\\' ) ) {
			return;
		}
		$parts = explode( '\\', substr( $class, 5 ) );
		$name  = array_pop( $parts );
		$file  = strtolower( str_replace( '_', '-', $name ) );
		$dir   = $parts ? strtolower( implode( '/', $parts ) ) . '/' : '';
		foreach ( array( 'class-', 'trait-' ) as $prefix ) {
			$path = M7PA_DIR . 'includes/' . $dir . $prefix . $file . '.php';
			if ( is_readable( $path ) ) {
				require_once $path;
				return;
			}
		}
	}
);

add_action(
	'before_woocommerce_init',
	static function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
		}
	}
);

add_action(
	'plugins_loaded',
	static function () {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}
		M7PA\Plugin::instance();
	},
	20
);
