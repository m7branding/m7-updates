<?php
/**
 * Gedeeld M7-beheermenu: één menu "M7" met het M7-icoon. In het menu staat per actieve M7-plugin één item;
 * de onderdelen van een plugin staan als tabbladen bovenaan de schermen van die plugin.
 * Met de plugin "M7 Branding" toont het overzicht alle M7-plugins (filter m7_admin_catalog), met knoppen
 * om ze te installeren, activeren of bij te werken.
 *
 * Bronbestand: shared/class-m7-admin-menu.php in de repository m7branding/custom-plugins.
 * Elke plugin heeft een kopie in includes/m7/ (tools/sync-shared.sh); de eerst geladen kopie wordt gebruikt.
 * Pas dus altijd het bronbestand aan, synchroniseer en verhoog VERSION.
 *
 * @package M7
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'M7_Admin_Menu', false ) ) {

	final class M7_Admin_Menu {

		const VERSION = '1.5.0';
		const SLUG    = 'm7';

		/** @var array Aangemelde M7-plugins. */
		private static $plugins = array();

		/** @var bool */
		private static $booted = false;

		/**
		 * Meldt een M7-plugin aan.
		 *
		 * @param array $args {
		 *     @type string $slug        Pluginmap, bijv. m7-smart-filters.
		 *     @type string $name        Naam in het menu, het overzicht en de kop.
		 *     @type string $version     Versie.
		 *     @type string $description Korte omschrijving voor het overzicht.
		 *     @type int    $order       Volgorde (laag = hoger).
		 *     @type array  $tabs        Tabbladen: label => menu-slug ("edit.php?post_type=…" of een paginaslug).
		 *                               Het eerste tabblad is het menu-item van de plugin.
		 * }
		 */
		public static function register_plugin( array $args ) {
			$args = array_merge(
				array(
					'slug'        => '',
					'name'        => '',
					'version'     => '',
					'description' => '',
					'order'       => 50,
					'tabs'        => array(),
				),
				$args
			);
			if ( '' === $args['slug'] || ! $args['tabs'] ) {
				return;
			}
			self::$plugins[ $args['slug'] ] = $args;
			self::boot();
		}

		/**
		 * Zet het M7-menu aan zonder plugin aan te melden (voor M7 Branding).
		 */
		public static function boot() {
			if ( self::$booted ) {
				return;
			}
			self::$booted = true;
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 9 );
			add_action( 'admin_menu', array( __CLASS__, 'arrange_submenu' ), 999 );
			add_filter( 'parent_file', array( __CLASS__, 'parent_file' ) );
			add_filter( 'submenu_file', array( __CLASS__, 'submenu_file' ) );
			add_action( 'admin_head', array( __CLASS__, 'css' ) );
			add_action( 'in_admin_header', array( __CLASS__, 'plugin_header' ) );
		}

		/**
		 * M7-logo als icoon in Elementor: widgets en de M7-groep in het paneel gebruiken de class "m7-eicon".
		 * Het logo volgt de kleur van Elementor (licht/donker thema) via een CSS-masker.
		 */
		public static function elementor_icons() {
			static $done = false;
			if ( $done ) {
				return;
			}
			$done = true;
			$css  = static function () {
				$svg  = rawurlencode( str_replace( 'fill="black"', 'fill="#000"', self::icon_svg() ) );
				$mask = 'url("data:image/svg+xml,' . $svg . '") center / contain no-repeat';
				wp_add_inline_style( 'elementor-editor', '.m7-eicon{display:inline-block;width:1em;height:1em;line-height:1}.m7-eicon::before{content:"";display:block;width:100%;height:100%;background-color:currentColor;-webkit-mask:' . $mask . ';mask:' . $mask . '}' );
			};
			add_action( 'elementor/editor/after_enqueue_styles', $css );
		}

		/**
		 * Eén Elementor-groep "M7" (met logo) voor de widgets van alle M7-plugins.
		 *
		 * @param object $manager Elementor elements manager.
		 */
		public static function elementor_category( $manager ) {
			self::elementor_icons();
			$cats = method_exists( $manager, 'get_categories' ) ? $manager->get_categories() : array();
			if ( ! isset( $cats['m7'] ) ) {
				$manager->add_category(
					'm7',
					array(
						'title' => 'M7',
						'icon'  => 'm7-eicon',
					)
				);
			}
		}

		public static function icon_svg() {
			return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path fill="black" d="M1 15.5V4.5h2.6l2.65 5.1 2.65-5.1h2.6v11H9.3V8.6l-2.2 4.2H5.4L3.2 8.6v6.9z"/><path fill="black" d="M12.6 4.5H19v2.1l-3.3 8.9h-2.4l3.3-8.8h-4z"/></svg>';
		}

		public static function menu() {
			add_menu_page(
				'M7 Branding',
				'M7',
				'edit_posts',
				self::SLUG,
				array( __CLASS__, 'overview' ),
				'data:image/svg+xml;base64,' . base64_encode( self::icon_svg() ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- menu-icoon.
				'2.9'
			);
			add_submenu_page( self::SLUG, 'M7 Branding', 'Overzicht', 'edit_posts', self::SLUG, array( __CLASS__, 'overview' ) );
		}

		/* ------------------------------ hulp ------------------------------ */

		private static function sorted_plugins() {
			$plugins = array_values( self::$plugins );
			usort(
				$plugins,
				static function ( $a, $b ) {
					return (int) $a['order'] === (int) $b['order'] ? strcasecmp( $a['name'], $b['name'] ) : (int) $a['order'] - (int) $b['order'];
				}
			);
			return $plugins;
		}

		/**
		 * Kaarten voor het overzicht: alle M7-plugins uit de catalogus (M7 Branding) plus aangemelde plugins.
		 *
		 * @return array
		 */
		public static function cards() {
			$cards = array();
			foreach ( (array) apply_filters( 'm7_admin_catalog', array() ) as $c ) {
				if ( empty( $c['slug'] ) ) {
					continue;
				}
				$cards[ $c['slug'] ] = array_merge(
					array(
						'name'        => $c['slug'],
						'version'     => '',
						'description' => '',
						'status'      => 'missing', // active | inactive | missing.
						'actions'     => array(), // [ label, url ].
						'note'        => '',
						'order'       => 50,
					),
					$c
				);
			}
			foreach ( self::$plugins as $slug => $p ) {
				$base           = isset( $cards[ $slug ] ) ? $cards[ $slug ] : array( 'actions' => array(), 'note' => '' );
				$cards[ $slug ] = array_merge(
					$base,
					array(
						'slug'        => $slug,
						'name'        => $p['name'],
						'version'     => $p['version'],
						'description' => $p['description'] ? $p['description'] : ( isset( $base['description'] ) ? $base['description'] : '' ),
						'status'      => 'active',
						'order'       => (int) $p['order'],
						'open'        => self::url( self::primary( $p ) ),
					)
				);
			}
			$cards = array_values( $cards );
			usort(
				$cards,
				static function ( $a, $b ) {
					return (int) $a['order'] === (int) $b['order'] ? strcasecmp( $a['name'], $b['name'] ) : (int) $a['order'] - (int) $b['order'];
				}
			);
			return $cards;
		}

		private static function url( $slug ) {
			return admin_url( false !== strpos( $slug, '.php' ) ? $slug : 'admin.php?page=' . $slug );
		}

		/**
		 * Plugin en tabblad van het huidige scherm.
		 *
		 * @return array|null [plugin, tab-slug]
		 */
		private static function current() {
			if ( ! is_admin() ) {
				return null;
			}
			$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$page      = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
			$post_type = $screen && $screen->post_type ? $screen->post_type : '';
			$home      = self::home();
			if ( $page && in_array( $page, $home['tabs'], true ) ) {
				return array( $home, $page );
			}
			foreach ( self::$plugins as $p ) {
				foreach ( $p['tabs'] as $slug ) {
					if ( $page && $page === $slug ) {
						return array( $p, $slug );
					}
					if ( ! $page && $post_type && 'edit.php?post_type=' . $post_type === $slug ) {
						return array( $p, $slug );
					}
				}
			}
			return null;
		}

		/**
		 * De M7-schermen zelf: Overzicht en (met M7 Branding) Markt. Filter m7_home_tabs voegt tabbladen toe.
		 *
		 * @return array
		 */
		private static function home() {
			$tabs = (array) apply_filters( 'm7_home_tabs', array( 'Overzicht' => self::SLUG ) );
			return array(
				'slug'    => self::SLUG,
				'name'    => 'M7 Branding',
				'version' => (string) apply_filters( 'm7_home_version', '' ),
				'tabs'    => count( $tabs ) > 1 ? $tabs : array( 'Overzicht' => self::SLUG ),
				'single'  => count( $tabs ) <= 1,
			);
		}

		private static function primary( $plugin ) {
			$tabs = array_values( $plugin['tabs'] );
			return $tabs[0];
		}

		/* ------------------------------ menu ------------------------------ */

		/**
		 * Menu: overzicht en per plugin één item. Andere schermen blijven bereikbaar via de tabbladen.
		 */
		public static function arrange_submenu() {
			global $submenu;
			if ( empty( $submenu[ self::SLUG ] ) ) {
				return;
			}
			$items  = array_values( $submenu[ self::SLUG ] );
			$by     = array();
			$placed = array();
			foreach ( $items as $i => $item ) {
				$by[ $item[2] ] = $i;
			}
			$out = array();
			if ( isset( $by[ self::SLUG ] ) ) {
				$out[]                       = $items[ $by[ self::SLUG ] ];
				$placed[ $by[ self::SLUG ] ] = true;
			}
			$home = self::home();
			foreach ( $home['tabs'] as $slug ) {
				if ( self::SLUG !== $slug && isset( $by[ $slug ] ) ) { // Bijv. Markt: direct onder Overzicht.
					$out[]                  = $items[ $by[ $slug ] ];
					$placed[ $by[ $slug ] ] = true;
				}
			}
			foreach ( self::sorted_plugins() as $p ) {
				$main = null;
				foreach ( $p['tabs'] as $slug ) {
					if ( ! isset( $by[ $slug ] ) ) {
						continue;
					}
					$item = $items[ $by[ $slug ] ];
					if ( null === $main ) {
						$item[0] = $p['name']; // Menutekst = pluginnaam.
						$main    = $slug;
					} else {
						$item[4] = trim( ( isset( $item[4] ) ? $item[4] : '' ) . ' m7-menu-hidden' ); // Wel geregistreerd, niet in het menu.
					}
					$out[]                  = $item;
					$placed[ $by[ $slug ] ] = true;
				}
			}
			foreach ( $items as $i => $item ) {
				if ( empty( $placed[ $i ] ) ) {
					$out[] = $item;
				}
			}
			$submenu[ self::SLUG ] = $out; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- menu-indeling.
		}

		public static function parent_file( $parent_file ) {
			return self::current() ? self::SLUG : $parent_file;
		}

		public static function submenu_file( $submenu_file ) {
			$current = self::current();
			if ( ! $current ) {
				return $submenu_file;
			}
			// Het menu-item van de plugin oplichten, ook op instellingen of overstappen.
			global $submenu;
			$items = (array) ( isset( $submenu[ self::SLUG ] ) ? $submenu[ self::SLUG ] : array() );
			foreach ( $items as $item ) {
				if ( $item[2] === $current[1] && false === strpos( isset( $item[4] ) ? $item[4] : '', 'm7-menu-hidden' ) ) {
					return $item[2]; // Het scherm staat zelf in het menu (bijv. Markt).
				}
			}
			foreach ( $items as $item ) {
				if ( in_array( $item[2], $current[0]['tabs'], true ) && false === strpos( isset( $item[4] ) ? $item[4] : '', 'm7-menu-hidden' ) ) {
					return $item[2];
				}
			}
			return self::primary( $current[0] );
		}

		/* ------------------------------ kop met tabbladen ------------------------------ */

		public static function plugin_header() {
			$current = self::current();
			if ( ! $current ) {
				return;
			}
			list( $p, $active ) = $current;
			echo '<div class="m7-head"><div class="m7-head__bar"><a class="m7-head__home" href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '" aria-label="M7 overzicht">' . self::icon_svg() . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- vaste SVG.
			echo '<span class="m7-head__name">' . esc_html( $p['name'] ) . '</span>';
			if ( $p['version'] ) {
				echo '<span class="m7-head__ver">v' . esc_html( $p['version'] ) . '</span>';
			}
			if ( ! empty( $p['single'] ) ) {
				echo '</div><div class="m7-head__tabs"></div></div>';
				return;
			}
			echo '</div><nav class="m7-head__tabs" aria-label="' . esc_attr( $p['name'] ) . '">';
			foreach ( $p['tabs'] as $label => $slug ) {
				$on = $slug === $active;
				echo '<a href="' . esc_url( self::url( $slug ) ) . '"' . ( $on ? ' class="is-active" aria-current="page"' : '' ) . '>' . esc_html( $label ) . '</a>';
			}
			echo '</nav></div>';
		}

		public static function css() {
			$css  = '#adminmenu .toplevel_page_m7 .wp-submenu li.m7-menu-hidden{display:none}';
			$css .= '#adminmenu .toplevel_page_m7 .wp-menu-name{font-weight:600}';
			$css .= '#adminmenu li.toplevel_page_m7.wp-has-current-submenu > a.wp-has-current-submenu,#adminmenu li.toplevel_page_m7.current > a.menu-top{background:#030304;box-shadow:inset 0 -3px 0 #3affff}';
			$css .= '.folded #adminmenu li.toplevel_page_m7.wp-has-current-submenu .wp-submenu .wp-submenu-head,#adminmenu li.toplevel_page_m7.wp-has-current-submenu .wp-submenu .wp-submenu-head,#adminmenu li.toplevel_page_m7.current .wp-submenu .wp-submenu-head{background:#030304;color:#3affff}';
			if ( self::current() ) {
				$css .= '.m7-head{margin:14px 20px 4px 0;background:#030304;color:#fff;border-radius:14px;position:relative;overflow:hidden}';
				$css .= '.m7-head::after{content:"";position:absolute;left:0;right:0;bottom:0;height:3px;background:linear-gradient(90deg,#3affff,#00ff19)}';
				$css .= '.m7-head__bar{display:flex;align-items:center;gap:12px;padding:14px 20px 8px}';
				$css .= '.m7-head__home{display:inline-flex;line-height:0}.m7-head__home svg{width:30px;height:30px}.m7-head__home svg path{fill:#3affff}';
				$css .= '.m7-head__home:focus{box-shadow:0 0 0 2px #3affff;border-radius:4px;outline:0}';
				$css .= '.m7-head__name{font-size:16px;font-weight:600}.m7-head__ver{margin-left:auto;color:#a7aaad;font-size:12px}';
				$css .= '.m7-head__tabs{display:flex;flex-wrap:wrap;gap:6px;padding:4px 16px 16px}';
				$css .= '.m7-head__tabs a{color:#dcdcde;text-decoration:none;padding:6px 14px;border-radius:999px;font-weight:500}';
				$css .= '.m7-head__tabs a:hover,.m7-head__tabs a:focus{color:#fff;background:rgba(255,255,255,.08);box-shadow:none}';
				$css .= '.m7-head__tabs a.is-active{background:#3affff;color:#030304}';
			}
			echo '<style id="m7-admin-menu">' . $css . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- vaste CSS.
		}

		/* ------------------------------ overzicht ------------------------------ */

		/**
		 * Overzicht: alleen de M7-plugins die op deze site staan.
		 */
		public static function overview() {
			$cards = array_values(
				array_filter(
					self::cards(),
					static function ( $c ) {
						return 'missing' !== $c['status'];
					}
				)
			);
			echo '<div class="wrap m7-overview"><h1 class="screen-reader-text">M7 Branding</h1>';
			do_action( 'm7_admin_overview_top', 'overview' );
			if ( $cards ) {
				self::render_cards( $cards );
			} else {
				$home   = self::home();
				$market = array_search( 'm7-markt', $home['tabs'], true );
				echo '<div class="m7-ov-empty"><p><strong>Nog geen M7-plugins op deze site.</strong></p>';
				if ( false !== $market ) {
					echo '<p><a class="m7-ov-open" href="' . esc_url( self::url( 'm7-markt' ) ) . '">Naar de Markt</a></p>';
				}
				echo '</div>';
			}
			echo '<p class="m7-ov-foot">Maatwerk-plugins van M7 Branding.</p></div>';
			self::cards_css();
		}

		/**
		 * Kaarten tonen (overzicht en Markt).
		 *
		 * @param array $cards Kaarten.
		 */
		public static function render_cards( array $cards ) {
			$labels = array(
				'active'   => 'Actief',
				'inactive' => 'Geïnstalleerd, niet actief',
				'missing'  => 'Niet geïnstalleerd',
			);
			echo '<div class="m7-ov-grid">';
			foreach ( $cards as $c ) {
				echo '<div class="m7-ov-card is-' . esc_attr( $c['status'] ) . '">';
				echo '<h2>' . esc_html( $c['name'] ) . ( $c['version'] ? ' <span>v' . esc_html( $c['version'] ) . '</span>' : '' ) . '</h2>';
				echo '<span class="m7-ov-status">' . esc_html( isset( $labels[ $c['status'] ] ) ? $labels[ $c['status'] ] : $c['status'] ) . '</span>';
				if ( $c['description'] ) {
					echo '<p>' . esc_html( $c['description'] ) . '</p>';
				}
				echo '<div class="m7-ov-actions">';
				if ( ! empty( $c['open'] ) ) {
					echo '<a class="m7-ov-open" href="' . esc_url( $c['open'] ) . '">Openen</a>';
				}
				foreach ( (array) $c['actions'] as $a ) {
					echo '<a class="m7-ov-btn' . ( empty( $c['open'] ) ? ' is-primary' : '' ) . '" href="' . esc_url( $a[1] ) . '">' . esc_html( $a[0] ) . '</a>';
				}
				echo '</div>';
				if ( $c['note'] ) {
					echo '<p class="m7-ov-note">' . esc_html( $c['note'] ) . '</p>';
				}
				echo '</div>';
			}
			echo '</div>';
		}

		public static function cards_css() {
			?>
			<style>
				.m7-overview { --m7-bg: #030304; --m7-teal: #3affff; --m7-green: #00ff19; margin-top: 16px; }
				.m7-overview .m7-ov-intro { margin: 0 0 16px; color: #50575e; max-width: 70ch; }
				.m7-overview .m7-ov-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; }
				.m7-overview .m7-ov-card { position: relative; overflow: hidden; background: #fff; border: 1px solid #dcdcde; border-radius: 12px; padding: 18px 20px; display: grid; gap: 8px; align-content: start; transition: border-color .15s, box-shadow .15s; }
				.m7-overview .m7-ov-card:hover, .m7-overview .m7-ov-card:focus-within { border-color: var(--m7-bg); box-shadow: 0 2px 10px rgba(0,0,0,.06); }
				.m7-overview .m7-ov-card h2 { margin: 0; font-size: 16px; display: flex; align-items: baseline; gap: 8px; }
				.m7-overview .m7-ov-card h2 span { font-size: 12px; font-weight: 400; color: #646970; }
				.m7-overview .m7-ov-card p { margin: 0; color: #50575e; }
				.m7-overview .m7-ov-status { justify-self: start; font-size: 11px; padding: 2px 8px; border-radius: 999px; background: #f0f0f1; color: #50575e; }
				.m7-overview .is-active .m7-ov-status { background: #e6fff9; color: #006b54; }
				.m7-overview .is-missing { background: #fafafa; }
				.m7-overview .m7-ov-actions { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 6px; }
				.m7-overview .m7-ov-open, .m7-overview .m7-ov-btn { position: relative; z-index: 1; display: inline-block; padding: 5px 14px; border-radius: 999px; text-decoration: none; font-weight: 500; border: 1px solid var(--m7-bg); }
				.m7-overview .m7-ov-open, .m7-overview .m7-ov-btn.is-primary { background: var(--m7-bg); color: var(--m7-teal); }
				.m7-overview .m7-ov-btn { background: #fff; color: var(--m7-bg); }
				.m7-overview .m7-ov-card .m7-ov-open::after { content: ""; position: absolute; inset: -400px; z-index: -1; }
				.m7-overview .m7-ov-open:focus, .m7-overview .m7-ov-btn:focus { box-shadow: 0 0 0 2px var(--m7-teal); outline: 0; }
				.m7-overview .m7-ov-note { font-size: 12px; color: #646970; }
				.m7-overview .m7-ov-empty { background: #fff; border: 1px dashed #c3c4c7; border-radius: 12px; padding: 20px; display: grid; gap: 8px; }
				.m7-overview .m7-ov-empty p { margin: 0; }
				.m7-overview .m7-ov-foot { margin-top: 20px; color: #646970; }
				.m7-overview .m7-ov-updates { display: flex; flex-wrap: wrap; align-items: center; gap: 12px; margin: 0 0 16px; }
			</style>
			<?php
		}
	}
}

if ( ! class_exists( 'M7_Updates', false ) ) {

	/**
	 * Updates voor M7-plugins via de M7-updatelijst (manifest.json).
	 *
	 * Nieuwe versies verschijnen als gewone WordPress-update (Plugins, Dashboard > Updates) en op het M7-dashboard.
	 * Automatisch bijwerken staat voor M7-plugins altijd uit: de beheerder kiest zelf wanneer.
	 * Adres van de lijst: constante M7_UPDATE_URL (wp-config.php) of filter m7_update_url, anders DEFAULT_URL.
	 */
	final class M7_Updates {

		const DEFAULT_URL = 'https://raw.githubusercontent.com/m7branding/m7-updates/main/manifest.json'; // Openbare repo met alleen zips + lijst.
		const CACHE       = 'm7_updates_manifest_v2';

		/** @var array|null Licentie-instellingen uit de updatelijst. */
		private static $licensing = null;

		/** @var bool */
		private static $booted = false;

		public static function init() {
			if ( self::$booted ) {
				return;
			}
			self::$booted = true;
			add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'inject' ) );
			add_filter( 'plugins_api', array( __CLASS__, 'info' ), 20, 3 );
			add_filter( 'auto_update_plugin', array( __CLASS__, 'no_auto_update' ), 99, 2 );
			add_filter( 'plugin_auto_update_setting_html', array( __CLASS__, 'auto_update_html' ), 10, 2 );
			add_action( 'upgrader_process_complete', array( __CLASS__, 'flush' ), 10, 0 );
			add_action(
				'load-plugins.php',
				static function () {
					foreach ( array_keys( self::installed() ) as $file ) {
						add_action( 'in_plugin_update_message-' . $file, array( 'M7_License', 'update_message' ), 10, 2 );
					}
				}
			);
			if ( defined( 'M7_UPDATE_ALLOW_HTTP' ) && M7_UPDATE_ALLOW_HTTP ) {
				// Alleen voor lokale tests: downloads van de lokale updateplek toestaan.
				add_filter(
					'http_request_host_is_external',
					static function ( $external, $host ) {
						return $external || wp_parse_url( self::url(), PHP_URL_HOST ) === $host;
					},
					10,
					2
				);
				add_filter(
					'http_allowed_safe_ports',
					static function ( $ports ) {
						$api = is_array( self::$licensing ) && ! empty( self::$licensing['api'] ) ? self::$licensing['api'] : ''; // Geen nieuwe ophaalronde vanuit dit filter.
						foreach ( array( self::url(), $api ) as $u ) {
							$port = $u ? wp_parse_url( $u, PHP_URL_PORT ) : null;
							if ( $port ) {
								$ports[] = (int) $port;
							}
						}
						return $ports;
					}
				);
			}
		}

		public static function url() {
			$url = defined( 'M7_UPDATE_URL' ) ? (string) M7_UPDATE_URL : self::DEFAULT_URL;
			return (string) apply_filters( 'm7_update_url', $url );
		}

		/**
		 * De updatelijst: slug => [version, download_url, name, requires, requires_php, tested, changelog, description].
		 *
		 * @param bool $force Niet uit de cache.
		 * @return array
		 */
		public static function manifest( $force = false ) {
			$url = self::url();
			if ( '' === $url ) {
				return array();
			}
			$cached = $force ? false : get_site_transient( self::CACHE );
			if ( is_array( $cached ) && isset( $cached['plugins'] ) ) {
				self::$licensing = isset( $cached['licensing'] ) ? $cached['licensing'] : array();
				return $cached['plugins'];
			}
			$plugins   = array();
			$licensing = array();
			$response = wp_remote_get( $url, array( 'timeout' => 8 ) );
			if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
				$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
				if ( is_array( $data ) && isset( $data['licensing'] ) && is_array( $data['licensing'] ) ) {
					$l         = $data['licensing'];
					$licensing = array(
						'enabled'    => ! empty( $l['enabled'] ),
						'provider'   => isset( $l['provider'] ) && 'm7' === $l['provider'] ? 'm7' : 'lemonsqueezy',
						'api'        => isset( $l['api'] ) && self::allowed_url( (string) $l['api'] ) ? (string) $l['api'] : '',
						'store_url'  => isset( $l['store_url'] ) && self::allowed_url( (string) $l['store_url'] ) ? (string) $l['store_url'] : '',
						'grace_days' => isset( $l['grace_days'] ) ? max( 0, (int) $l['grace_days'] ) : 7,
						'bundle_ids' => isset( $l['bundle_product_ids'] ) ? array_values( array_map( 'strval', (array) $l['bundle_product_ids'] ) ) : array(),
					);
				}
				foreach ( ( is_array( $data ) && isset( $data['plugins'] ) && is_array( $data['plugins'] ) ) ? $data['plugins'] : array() as $slug => $p ) {
					if ( ! preg_match( '/^m7-[a-z0-9-]+$/', (string) $slug ) || empty( $p['version'] ) || empty( $p['download_url'] ) || ! self::allowed_url( (string) $p['download_url'] ) ) {
						continue;
					}
					$versions = array();
					foreach ( isset( $p['versions'] ) && is_array( $p['versions'] ) ? $p['versions'] : array() as $v ) {
						if ( ! empty( $v['version'] ) && ! empty( $v['download_url'] ) && self::allowed_url( (string) $v['download_url'] ) ) {
							$versions[ (string) $v['version'] ] = array(
								'version'      => (string) $v['version'],
								'download_url' => (string) $v['download_url'],
								'date'         => isset( $v['date'] ) ? (string) $v['date'] : '',
							);
						}
					}
					if ( ! isset( $versions[ (string) $p['version'] ] ) ) {
						$versions[ (string) $p['version'] ] = array(
							'version'      => (string) $p['version'],
							'download_url' => (string) $p['download_url'],
							'date'         => '',
						);
					}
					uksort(
						$versions,
						static function ( $a, $b ) {
							return version_compare( $b, $a );
						}
					);
					$plugins[ $slug ] = array(
						'license'      => isset( $p['license'] ) && 'paid' === $p['license'] ? 'paid' : 'free',
						'product_ids'  => isset( $p['product_ids'] ) ? array_values( array_map( 'strval', (array) $p['product_ids'] ) ) : array(),
						'versions'     => array_values( $versions ),
						'version'      => (string) $p['version'],
						'download_url' => (string) $p['download_url'],
						'name'         => isset( $p['name'] ) ? (string) $p['name'] : $slug,
						'description'  => isset( $p['description'] ) ? (string) $p['description'] : '',
						'changelog'    => isset( $p['changelog'] ) ? (string) $p['changelog'] : '',
						'requires'     => isset( $p['requires'] ) ? (string) $p['requires'] : '',
						'requires_php' => isset( $p['requires_php'] ) ? (string) $p['requires_php'] : '',
						'tested'       => isset( $p['tested'] ) ? (string) $p['tested'] : '',
					);
				}
				set_site_transient( self::CACHE, array( 'plugins' => $plugins, 'licensing' => $licensing ), 12 * HOUR_IN_SECONDS );
			} else {
				set_site_transient( self::CACHE, array( 'plugins' => $plugins, 'licensing' => $licensing ), HOUR_IN_SECONDS ); // Later opnieuw proberen.
			}
			self::$licensing = $licensing;
			return $plugins;
		}

		/**
		 * Licentie-instellingen uit de updatelijst (centraal aan/uit te zetten door M7).
		 *
		 * @return array enabled, provider, api, store_url, grace_days
		 */
		public static function licensing() {
			if ( null === self::$licensing ) {
				self::manifest();
			}
			return wp_parse_args(
				(array) self::$licensing,
				array(
					'enabled'    => false,
					'provider'   => 'lemonsqueezy',
					'api'        => '',
					'store_url'  => '',
					'grace_days' => 7,
					'bundle_ids' => array(),
				)
			);
		}

		private static function allowed_url( $url ) {
			if ( 0 === strpos( $url, 'https://' ) ) {
				return true;
			}
			return defined( 'M7_UPDATE_ALLOW_HTTP' ) && M7_UPDATE_ALLOW_HTTP && 0 === strpos( $url, 'http://' ); // Alleen voor lokale tests.
		}

		/**
		 * Geïnstalleerde M7-plugins: plugin-bestand => [slug, version].
		 *
		 * @return array
		 */
		public static function installed() {
			if ( ! function_exists( 'get_plugins' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}
			$out = array();
			foreach ( get_plugins() as $file => $data ) {
				$slug = dirname( $file );
				if ( 0 === strpos( $slug, 'm7-' ) && $slug . '/' . $slug . '.php' === $file && 'M7 Branding' === $data['Author'] ) {
					$out[ $file ] = array(
						'slug'    => $slug,
						'version' => $data['Version'],
					);
				}
			}
			return $out;
		}

		private static function item( $file, $slug, $remote, $new_version ) {
			return (object) array(
				'id'           => 'm7branding/' . $slug,
				'slug'         => $slug,
				'plugin'       => $file,
				'new_version'  => $new_version,
				'url'          => 'https://m7branding.com',
				'package'      => $remote ? M7_License::package_url( $slug, $remote['download_url'] ) : '',
				'requires'     => $remote ? $remote['requires'] : '',
				'requires_php' => $remote ? $remote['requires_php'] : '',
				'tested'       => $remote ? $remote['tested'] : '',
				'icons'        => array( 'svg' => 'data:image/svg+xml;base64,' . base64_encode( str_replace( 'fill="black"', 'fill="#3affff"', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-4 -4 28 28"><rect x="-4" y="-4" width="28" height="28" fill="#030304"/>' . substr( M7_Admin_Menu::icon_svg(), strpos( M7_Admin_Menu::icon_svg(), '<path' ) ) ) ) ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- icoon.
			);
		}

		/**
		 * Nieuwe versies toevoegen aan de WordPress-updatelijst.
		 *
		 * @param object $transient update_plugins.
		 * @return object
		 */
		public static function inject( $transient ) {
			if ( ! is_object( $transient ) ) {
				return $transient;
			}
			$manifest = self::manifest();
			M7_License::maybe_revalidate();
			foreach ( self::installed() as $file => $p ) {
				$remote = isset( $manifest[ $p['slug'] ] ) ? $manifest[ $p['slug'] ] : null;
				if ( $remote && version_compare( $remote['version'], $p['version'], '>' ) ) {
					$transient->response[ $file ] = self::item( $file, $p['slug'], $remote, $remote['version'] );
					unset( $transient->no_update[ $file ] );
				} else {
					unset( $transient->response[ $file ] );
					$transient->no_update[ $file ] = self::item( $file, $p['slug'], $remote, $p['version'] );
				}
			}
			return $transient;
		}

		/**
		 * Zorgt dat de WordPress-updatelijst de laatste M7-versies kent (voor de knop op het dashboard).
		 */
		public static function sync_transient() {
			$t = get_site_transient( 'update_plugins' );
			if ( ! is_object( $t ) ) {
				$t = new stdClass();
			}
			set_site_transient( 'update_plugins', $t ); // Loopt via inject().
		}

		public static function check_now() {
			self::manifest( true );
			self::sync_transient();
		}

		/**
		 * "Details bekijken" in het pluginscherm.
		 *
		 * @param false|object|array $result Resultaat.
		 * @param string             $action Actie.
		 * @param object             $args   Argumenten.
		 * @return false|object|array
		 */
		public static function info( $result, $action, $args ) {
			if ( 'plugin_information' !== $action || empty( $args->slug ) || 0 !== strpos( (string) $args->slug, 'm7-' ) ) {
				return $result;
			}
			$manifest = self::manifest();
			if ( ! isset( $manifest[ $args->slug ] ) ) {
				return $result;
			}
			$m = $manifest[ $args->slug ];
			return (object) array(
				'name'          => $m['name'],
				'slug'          => $args->slug,
				'version'       => $m['version'],
				'author'        => '<a href="https://m7branding.com">M7 Branding</a>',
				'homepage'      => 'https://m7branding.com',
				'requires'      => $m['requires'],
				'requires_php'  => $m['requires_php'],
				'tested'        => $m['tested'],
				'download_link' => M7_License::package_url( $args->slug, $m['download_url'] ),
				'sections'      => array(
					'description' => wpautop( esc_html( $m['description'] ) ),
					'changelog'   => $m['changelog'] ? wpautop( esc_html( $m['changelog'] ) ) : '',
				),
			);
		}

		private static function is_m7( $file ) {
			$installed = self::installed();
			return isset( $installed[ (string) $file ] );
		}

		/**
		 * Nooit automatisch bijwerken: de beheerder kiest zelf.
		 *
		 * @param bool|null $update Automatisch bijwerken.
		 * @param object    $item   Update.
		 * @return bool|null
		 */
		public static function no_auto_update( $update, $item ) {
			if ( is_object( $item ) && ! empty( $item->plugin ) && self::is_m7( $item->plugin ) ) {
				return false;
			}
			return $update;
		}

		public static function auto_update_html( $html, $file ) {
			return self::is_m7( $file ) ? '<span class="m7-manual-update">Handmatig bijwerken (M7)</span>' : $html;
		}

		public static function flush() {
			delete_site_transient( self::CACHE );
		}
	}
}

if ( ! class_exists( 'M7_License', false ) ) {

	/**
	 * Licenties voor betaalde M7-plugins. Staat uit tot M7 het in de updatelijst aanzet ("licensing.enabled").
	 *
	 * - Per plugin te kopen (product-ID's per plugin in de updatelijst) of als bundel die alles vrijgeeft
	 *   ("licensing.bundle_product_ids"). Een site kan meerdere sleutels hebben.
	 * - Bron: Lemon Squeezy (licentie-API, geen geheime sleutel op de site nodig) of de eigen M7-licentieserver.
	 * - Sleutels worden geactiveerd op het adres van de site (option m7_licenses).
	 * - Zonder geldige licentie blijven geïnstalleerde plugins gewoon werken; alleen installeren uit de Markt en
	 *   bijwerken van betaalde plugins vragen om een licentie.
	 * - Is de licentieserver even onbereikbaar, dan blijft de laatste geldige controle "grace_days" dagen gelden.
	 */
	final class M7_License {

		const OPTION = 'm7_licenses';

		public static function enabled() {
			return class_exists( 'M7_Updates' ) && ! empty( M7_Updates::licensing()['enabled'] );
		}

		/**
		 * Alle sleutels op deze site: sleutel => gegevens.
		 *
		 * @return array
		 */
		public static function all() {
			$out = array();
			foreach ( (array) get_option( self::OPTION, array() ) as $key => $d ) {
				$out[ (string) $key ] = wp_parse_args(
					(array) $d,
					array(
						'key'         => (string) $key,
						'instance'    => '',
						'status'      => '',
						'product_ids' => array(),
						'product'     => '',
						'expires'     => '',
						'checked'     => 0,
						'message'     => '',
					)
				);
			}
			return $out;
		}

		private static function save( array $all ) {
			update_option( self::OPTION, $all, false );
		}

		/**
		 * Is voor deze plugin een licentie nodig?
		 *
		 * @param string $slug Pluginmap.
		 * @return bool
		 */
		public static function requires( $slug ) {
			if ( ! self::enabled() ) {
				return false;
			}
			$m = M7_Updates::manifest();
			return isset( $m[ $slug ] ) && 'paid' === $m[ $slug ]['license'];
		}

		/**
		 * Is dit een bundelsleutel (geeft alle plugins vrij)?
		 *
		 * @param array $d Sleutelgegevens.
		 * @return bool
		 */
		public static function is_bundle( array $d ) {
			$bundle = M7_Updates::licensing()['bundle_ids'];
			return $bundle && array_intersect( $bundle, (array) $d['product_ids'] );
		}

		/**
		 * De sleutel die deze plugin vrijgeeft, of null.
		 *
		 * @param string $slug Pluginmap.
		 * @return array|null
		 */
		public static function license_for( $slug ) {
			$m   = M7_Updates::manifest();
			$ids = isset( $m[ $slug ] ) ? $m[ $slug ]['product_ids'] : array();
			foreach ( self::all() as $d ) {
				if ( self::is_active( $d ) && ( self::is_bundle( $d ) || ( $ids && array_intersect( $ids, (array) $d['product_ids'] ) ) ) ) {
					return $d;
				}
			}
			return null;
		}

		/**
		 * Mag deze site de plugin installeren/bijwerken?
		 *
		 * @param string $slug Pluginmap.
		 * @return bool
		 */
		public static function allows( $slug ) {
			return ! self::requires( $slug ) || null !== self::license_for( $slug );
		}

		private static function is_active( array $d ) {
			if ( '' === $d['key'] || 'active' !== $d['status'] ) {
				return false;
			}
			$grace = (int) M7_Updates::licensing()['grace_days'];
			return ( time() - (int) $d['checked'] ) <= ( max( 0, $grace ) + 1 ) * DAY_IN_SECONDS;
		}

		/**
		 * Welke plugins geeft deze sleutel vrij? (namen voor het scherm)
		 *
		 * @param array $d Sleutelgegevens.
		 * @return array
		 */
		public static function covers( array $d ) {
			if ( self::is_bundle( $d ) ) {
				return array( 'Alle M7-plugins' );
			}
			$names = array();
			foreach ( M7_Updates::manifest() as $p ) {
				if ( 'paid' === $p['license'] && array_intersect( $p['product_ids'], (array) $d['product_ids'] ) ) {
					$names[] = preg_replace( '/^M7\s+/', '', $p['name'] );
				}
			}
			return $names;
		}

		/**
		 * Downloadadres met licentiegegevens voor betaalde plugins.
		 *
		 * @param string $slug Pluginmap.
		 * @param string $url  Downloadadres uit de updatelijst.
		 * @return string Leeg als er geen geldige licentie is.
		 */
		public static function package_url( $slug, $url ) {
			if ( ! self::requires( $slug ) ) {
				return $url;
			}
			$d = self::license_for( $slug );
			if ( ! $d ) {
				return '';
			}
			return add_query_arg(
				array(
					'license_key' => rawurlencode( $d['key'] ),
					'instance'    => rawurlencode( $d['instance'] ),
					'site'        => rawurlencode( home_url() ),
				),
				$url
			);
		}

		/**
		 * Melding onder een betaalde plugin in het pluginscherm als bijwerken een licentie vraagt.
		 */
		public static function update_message( $plugin_data, $response ) {
			$slug = is_object( $response ) && ! empty( $response->slug ) ? (string) $response->slug : '';
			if ( $slug && ! self::allows( $slug ) ) {
				echo '<br><strong>' . esc_html( 'Bijwerken vraagt een geldige M7-licentie.' ) . '</strong> ' . esc_html( 'Vul je licentie in bij M7 > Licentie.' );
			}
		}

		/* ------------------------------ licentieserver ------------------------------ */

		/**
		 * @param string $action activate | validate | deactivate.
		 * @param array  $body   license_key, instance_id / instance_name.
		 * @return array ok, status, instance, product_ids, product, expires, message, network_error
		 */
		private static function request( $action, array $body ) {
			$cfg = M7_Updates::licensing();
			if ( 'm7' === $cfg['provider'] ) {
				if ( '' === $cfg['api'] ) {
					return array( 'ok' => false, 'message' => 'Licentieserver is niet ingesteld.', 'network_error' => true );
				}
				$url = add_query_arg( 'action', $action, $cfg['api'] );
			} else {
				$url = 'https://api.lemonsqueezy.com/v1/licenses/' . $action;
			}
			$response = wp_remote_post(
				$url,
				array(
					'timeout' => 10,
					'headers' => array( 'Accept' => 'application/json' ),
					'body'    => $body,
				)
			);
			if ( is_wp_error( $response ) || (int) wp_remote_retrieve_response_code( $response ) >= 500 ) {
				return array( 'ok' => false, 'message' => 'De licentieserver is niet bereikbaar. Probeer het later opnieuw.', 'network_error' => true );
			}
			$j   = json_decode( (string) wp_remote_retrieve_body( $response ), true );
			$j   = is_array( $j ) ? $j : array();
			$lk  = isset( $j['license_key'] ) && is_array( $j['license_key'] ) ? $j['license_key'] : array();
			$me  = isset( $j['meta'] ) && is_array( $j['meta'] ) ? $j['meta'] : array();
			$ok  = ! empty( $j['activated'] ) || ! empty( $j['valid'] ) || ! empty( $j['deactivated'] );
			$ids = array();
			if ( isset( $me['product_ids'] ) ) {
				$ids = array_map( 'strval', (array) $me['product_ids'] );
			} elseif ( isset( $me['product_id'] ) ) {
				$ids = array( (string) $me['product_id'] );
			}
			return array(
				'ok'            => $ok,
				'status'        => isset( $lk['status'] ) ? (string) $lk['status'] : ( $ok ? 'active' : '' ),
				'instance'      => isset( $j['instance']['id'] ) ? (string) $j['instance']['id'] : '',
				'product_ids'   => $ids,
				'product'       => isset( $me['product_name'] ) ? (string) $me['product_name'] : '',
				'expires'       => isset( $lk['expires_at'] ) ? (string) $lk['expires_at'] : '',
				'message'       => isset( $j['error'] ) && $j['error'] ? (string) $j['error'] : '',
				'network_error' => false,
			);
		}

		/**
		 * Kopen in de plugin kan als de licenties via de eigen M7-licentieserver lopen (die regelt ook het betalen).
		 */
		public static function can_buy() {
			$cfg = M7_Updates::licensing();
			return self::enabled() && 'm7' === $cfg['provider'] && '' !== $cfg['api'];
		}

		/**
		 * Verzoek aan de M7-licentieserver voor afrekenen (catalog, quote, checkout, order_status).
		 *
		 * @param string $action Actie.
		 * @param array  $body   Velden.
		 * @param bool   $get    GET in plaats van POST.
		 * @return array Antwoord; bij een fout met sleutel 'error'.
		 */
		public static function shop( $action, array $body = array(), $get = false ) {
			$cfg = M7_Updates::licensing();
			if ( '' === $cfg['api'] ) {
				return array( 'error' => 'Licentieserver is niet ingesteld.' );
			}
			$url  = add_query_arg( 'action', $action, $cfg['api'] );
			$args = array(
				'timeout' => 20,
				'headers' => array( 'Accept' => 'application/json' ),
			);
			if ( $get ) {
				$response = wp_remote_get( add_query_arg( array_map( 'rawurlencode', $body ), $url ), $args );
			} else {
				$args['body'] = $body;
				$response     = wp_remote_post( $url, $args );
			}
			if ( is_wp_error( $response ) ) {
				return array( 'error' => 'De licentieserver is niet bereikbaar. Probeer het later opnieuw.' );
			}
			$j = json_decode( (string) wp_remote_retrieve_body( $response ), true );
			return is_array( $j ) ? $j : array( 'error' => 'Onverwacht antwoord van de licentieserver.' );
		}

		/**
		 * Sleutel activeren op deze site (naast eventuele andere sleutels).
		 *
		 * @param string $key Licentiesleutel.
		 * @return array [bool ok, string message]
		 */
		public static function activate( $key ) {
			$key = trim( (string) $key );
			if ( '' === $key ) {
				return array( false, 'Vul een licentiesleutel in.' );
			}
			$all = self::all();
			if ( isset( $all[ $key ] ) ) {
				return array( false, 'Deze sleutel staat al op deze site.' );
			}
			$r = self::request(
				'activate',
				array(
					'license_key'   => $key,
					'instance_name' => wp_parse_url( home_url(), PHP_URL_HOST ),
				)
			);
			if ( ! $r['ok'] ) {
				return array( false, $r['message'] ? $r['message'] : 'Deze licentiesleutel is niet geldig of al op te veel sites in gebruik.' );
			}
			$all[ $key ] = array(
				'key'         => $key,
				'instance'    => $r['instance'],
				'status'      => $r['status'] ? $r['status'] : 'active',
				'product_ids' => $r['product_ids'],
				'product'     => $r['product'],
				'expires'     => $r['expires'],
				'checked'     => time(),
				'message'     => '',
			);
			self::save( $all );
			M7_Updates::flush();
			$covers = self::covers( $all[ $key ] );
			return array( true, 'Licentie geactiveerd' . ( $covers ? ': ' . implode( ', ', $covers ) . '.' : '.' ) );
		}

		public static function deactivate( $key ) {
			$all = self::all();
			if ( isset( $all[ $key ] ) ) {
				self::request(
					'deactivate',
					array(
						'license_key' => $key,
						'instance_id' => $all[ $key ]['instance'],
					)
				);
				unset( $all[ $key ] );
				self::save( $all );
			}
			M7_Updates::flush();
			return array( true, 'Licentie losgekoppeld van deze site.' );
		}

		/**
		 * Alle sleutels opnieuw controleren. Bij een netwerkfout blijft de vorige status staan (respijt).
		 *
		 * @return array
		 */
		public static function validate() {
			$all = self::all();
			foreach ( $all as $key => $d ) {
				$r = self::request(
					'validate',
					array(
						'license_key' => $key,
						'instance_id' => $d['instance'],
					)
				);
				if ( $r['network_error'] ) {
					$d['message'] = $r['message'];
				} else {
					$d['status']      = $r['ok'] ? ( $r['status'] ? $r['status'] : 'active' ) : ( $r['status'] ? $r['status'] : 'invalid' );
					$d['product_ids'] = $r['product_ids'] ? $r['product_ids'] : $d['product_ids'];
					$d['expires']     = $r['expires'];
					$d['checked']     = time();
					$d['message']     = $r['ok'] ? '' : ( $r['message'] ? $r['message'] : 'Licentie is niet (meer) geldig.' );
				}
				$all[ $key ] = $d;
			}
			self::save( $all );
			return $all;
		}

		/**
		 * Eens per dag opnieuw controleren (bij de updatecontrole).
		 */
		public static function maybe_revalidate() {
			if ( ! self::enabled() ) {
				return;
			}
			foreach ( self::all() as $d ) {
				if ( time() - (int) $d['checked'] > DAY_IN_SECONDS ) {
					self::validate();
					return;
				}
			}
		}
	}
}
