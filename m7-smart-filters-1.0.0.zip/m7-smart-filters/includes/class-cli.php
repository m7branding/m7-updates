<?php
/**
 * WP-CLI: overstappen van JetSmartFilters via SSH.
 *
 *   wp m7sf status                       Overzicht: JSF-filters, geïmporteerd, documenten met JSF-widgets.
 *   wp m7sf import [--update]            Filters importeren (--update: bestaande opnieuw overnemen).
 *   wp m7sf convert [--document=<id>]    Widgets omzetten (met back-up per document).
 *   wp m7sf revert --document=<id>|--all Back-up terugzetten.
 *
 * @package M7SF
 */

namespace M7SF;

defined( 'ABSPATH' ) || exit;

final class Cli {

	public static function register() {
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'm7sf', __CLASS__ );
		}
	}

	/**
	 * Overzicht van de overstap.
	 *
	 * @subcommand status
	 */
	public function status( $args, $assoc ) {
		$map = Importer_Jsf::id_map();
		$jsf = get_posts(
			array(
				'post_type'      => Importer_Jsf::JSF_POST_TYPE,
				'post_status'    => array( 'publish', 'draft', 'private' ),
				'posts_per_page' => -1,
			)
		);
		$rows = array();
		foreach ( $jsf as $p ) {
			list( $s, $warnings ) = Importer_Jsf::map_filter( $p->ID );
			$rows[]               = array(
				'jsf_id'   => $p->ID,
				'titel'    => $p->post_title,
				'wordt'    => $s['type'] . ' ' . Filter_Post_Type::param_for( $s ),
				'm7_id'    => isset( $map[ $p->ID ] ) ? $map[ $p->ID ] : '-',
				'let_op'   => implode( ' ', $warnings ),
			);
		}
		\WP_CLI::log( 'Filters:' );
		$rows ? \WP_CLI\Utils\format_items( 'table', $rows, array( 'jsf_id', 'titel', 'wordt', 'm7_id', 'let_op' ) ) : \WP_CLI::log( '  (geen)' );

		$docs = array();
		foreach ( array_unique( array_merge( Importer_Jsf::documents(), Importer_Jsf::converted_documents() ) ) as $doc ) {
			$raw    = (string) get_post_meta( $doc, '_elementor_data', true );
			$count  = preg_match_all( '/"widgetType":"jet-smart-filters-([a-z\-]+)"/', $raw, $m );
			$docs[] = array(
				'id'       => $doc,
				'titel'    => get_the_title( $doc ),
				'type'     => get_post_type( $doc ),
				'jsf'      => $count ? implode( ',', array_unique( $m[1] ) ) : '-',
				'back-up'  => '' !== get_post_meta( $doc, Importer_Jsf::BACKUP_META, true ) ? 'ja' : 'nee',
			);
		}
		\WP_CLI::log( 'Elementor-documenten:' );
		$docs ? \WP_CLI\Utils\format_items( 'table', $docs, array( 'id', 'titel', 'type', 'jsf', 'back-up' ) ) : \WP_CLI::log( '  (geen)' );
	}

	/**
	 * Filters importeren.
	 *
	 * @subcommand import
	 */
	public function import( $args, $assoc ) {
		$n = Importer_Jsf::import_filters( ! empty( $assoc['update'] ) );
		\WP_CLI::success( $n . ' filter(s) geïmporteerd.' );
		if ( 'keep' === Settings::get( 'url_mode' ) ) {
			\WP_CLI::log( 'Gedrag zoals JetSmartFilters: adresbalk blijft gelijk en er wordt niet gescrold (aan te passen bij M7 Filters > Instellingen).' );
		}
	}

	/**
	 * Widgets omzetten.
	 *
	 * [--document=<id>]
	 * : Alleen dit document.
	 *
	 * @subcommand convert
	 */
	public function convert( $args, $assoc ) {
		list( $done, $notes ) = Importer_Jsf::convert_documents( isset( $assoc['document'] ) ? absint( $assoc['document'] ) : 0 );
		foreach ( $notes as $note ) {
			\WP_CLI::warning( $note );
		}
		\WP_CLI::success( $done . ' document(en) omgezet.' );
	}

	/**
	 * Back-up terugzetten.
	 *
	 * [--document=<id>]
	 * : Dit document.
	 *
	 * [--all]
	 * : Alle omgezette documenten.
	 *
	 * @subcommand revert
	 */
	public function revert( $args, $assoc ) {
		$docs = ! empty( $assoc['all'] ) ? Importer_Jsf::converted_documents() : array( isset( $assoc['document'] ) ? absint( $assoc['document'] ) : 0 );
		$n    = 0;
		foreach ( $docs as $doc ) {
			$n += Importer_Jsf::revert_document( $doc ) ? 1 : 0;
		}
		$css = ! empty( $assoc['all'] ) ? Importer_Jsf::revert_site_css() : 0;
		\WP_CLI::success( $n . ' document(en) teruggezet.' . ( $css ? ' Sitebrede CSS teruggezet (' . $css . ').' : '' ) );
	}
}
