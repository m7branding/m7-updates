<?php
/**
 * Berichttype voor filters en hun instellingen.
 *
 * @package M7SF
 */

namespace M7SF;

defined( 'ABSPATH' ) || exit;

final class Filter_Post_Type {

	const POST_TYPE    = 'm7sf_filter';
	const META         = '_m7sf';
	const OPTION_KEYS  = 'm7sf_allowed_keys';

	const TYPES = array(
		'checkboxes'  => 'Checkboxes',
		'select'      => 'Select',
		'radio'       => 'Radio',
		'range'       => 'Bereik (slider)',
		'check_range' => 'Vaste bereiken',
		'search'      => 'Zoeken',
		'rating'      => 'Beoordeling',
		'alphabet'    => 'Alfabet',
		'color_image' => 'Kleur/afbeelding',
		'date_range'  => 'Datumbereik',
		'date_period' => 'Datumperiode',
	);

	const SOURCES = array(
		'taxonomy' => 'Taxonomie',
		'manual'   => 'Handmatige invoer',
		'meta'     => 'Custom field (unieke waarden)',
		'posts'    => 'Berichten',
	);

	/** Metasleutels die altijd gefilterd mogen worden. */
	const DEFAULT_META_KEYS = array( '_price', '_regular_price', '_sale_price', '_wc_average_rating', '_stock_status', '_sku', 'total_sales' );

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'on_save' ), 20 );
		add_action( 'trashed_post', array( __CLASS__, 'maybe_rebuild' ) );
		add_action( 'untrashed_post', array( __CLASS__, 'maybe_rebuild' ) );
	}

	public static function register() {
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'              => array(
					'name'          => __( 'Filters', 'm7-smart-filters' ),
					'singular_name' => __( 'Filter', 'm7-smart-filters' ),
					'add_new'       => __( 'Nieuw filter', 'm7-smart-filters' ),
					'add_new_item'  => __( 'Nieuw filter', 'm7-smart-filters' ),
					'edit_item'     => __( 'Filter bewerken', 'm7-smart-filters' ),
					'menu_name'     => __( 'Filters', 'm7-smart-filters' ),
					'all_items'     => __( 'Filters', 'm7-smart-filters' ),
				),
				'public'              => false,
				'show_ui'             => true,
				'show_in_menu'        => 'm7', // Gedeeld M7-menu (includes/m7/class-m7-admin-menu.php).
				'supports'            => array( 'title' ),
				'capability_type'     => 'post',
				'map_meta_cap'        => true,
				'exclude_from_search' => true,
				'show_in_rest'        => false,
			)
		);
	}

	public static function defaults() {
		return array(
			'type'              => 'checkboxes',
			'label'             => '',
			'source'            => 'taxonomy',
			'taxonomy'          => 'product_cat',
			'tax_relation'      => 'IN',
			'terms_include'     => '',
			'terms_exclude'     => '',
			'only_child_of'     => 0,
			'hide_empty'        => true,
			'hierarchical'      => false,
			'collapsible'       => false,  // Boom: subopties in- en uitklapbaar (standaard ingeklapt).
			'can_deselect'      => false,  // Radio: nogmaals klikken zet de keuze uit.
			'terms_orderby'     => 'name',
			'terms_order'       => 'ASC',
			'manual_options'    => array(),
			'meta_key'          => '',
			'meta_compare'      => 'IN',
			'meta_type'         => 'CHAR',
			'posts_post_type'   => 'post',
			'range_min'         => '',
			'range_max'         => '',
			'range_step'        => 1,
			'range_prefix'      => '',
			'range_suffix'      => '',
			'range_decimals'    => 0,
			'check_ranges'      => array(),
			'search_by'         => 'default',
			'search_min_chars'  => 2,
			'placeholder'       => '',
			'multiple'          => false,
			'show_all_option'   => false,
			'all_label'         => '',
			'rating_max'        => 5,
			'alphabet_letters'  => 'A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z',
			'date_source'       => 'post_date',
			'date_period_type'  => 'month',
			'legacy_jsf_id'     => 0,
			// Weergave zoals JetSmartFilters (overgenomen bij importeren).
			'active_label'             => '',
			'range_decimal_sep'        => '.',
			'range_thousand_sep'       => '',
			'range_inputs'             => false,
			'range_inputs_separators'  => false,
			'alphabet_multiple'        => false,
			'color_image_type'         => 'color',
			'rating_compare'           => 'greater',
			'date_format'              => 'mm/dd/yy',
			'date_from_placeholder'    => '',
			'date_to_placeholder'      => '',
			'date_available_range'     => 'all',
			'date_min'                 => '',
			'date_max'                 => '',
			'date_period_button_text'  => 'Select Date',
			'date_period_start_end'    => false,
			'date_period_format'       => '',
			'date_period_start_format' => '',
			'date_period_separator'    => '',
			'date_period_end_format'   => '',
			'hierarchy_levels'         => array(), // Keuzelijst per niveau: [ [label, placeholder, tax], … ].
		);
	}

	/**
	 * Instellingen van een filter, aangevuld met standaardwaarden.
	 *
	 * @param int $post_id Filter-ID.
	 * @return array|null
	 */
	public static function get( $post_id ) {
		$post = get_post( (int) $post_id );
		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return null;
		}
		$saved = get_post_meta( $post->ID, self::META, true );
		$data  = wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
		// Zichtbaar label alleen als het is ingevuld; voor schermlezers valt het terug op de titel.
		$data['display_label'] = (string) $data['label'];
		if ( '' === $data['label'] ) {
			$data['label'] = $post->post_title;
		}
		$data['id'] = $post->ID;
		return $data;
	}

	/**
	 * Schoont ruwe invoer op tot een geldig instellingen-array.
	 *
	 * @param array $raw Ruwe invoer.
	 * @return array
	 */
	public static function sanitize( array $raw ) {
		$d   = self::defaults();
		$out = array();

		$out['type']   = ( isset( $raw['type'] ) && array_key_exists( (string) $raw['type'], self::TYPES ) ) ? (string) $raw['type'] : $d['type'];
		$out['label']  = isset( $raw['label'] ) ? sanitize_text_field( $raw['label'] ) : '';
		$out['source'] = ( isset( $raw['source'] ) && array_key_exists( (string) $raw['source'], self::SOURCES ) ) ? (string) $raw['source'] : $d['source'];

		$out['taxonomy']      = isset( $raw['taxonomy'] ) ? sanitize_key( $raw['taxonomy'] ) : $d['taxonomy'];
		$out['tax_relation']  = ( isset( $raw['tax_relation'] ) && 'AND' === $raw['tax_relation'] ) ? 'AND' : 'IN';
		$out['terms_include'] = isset( $raw['terms_include'] ) ? self::id_list( $raw['terms_include'] ) : '';
		$out['terms_exclude'] = isset( $raw['terms_exclude'] ) ? self::id_list( $raw['terms_exclude'] ) : '';
		$out['only_child_of'] = isset( $raw['only_child_of'] ) ? absint( $raw['only_child_of'] ) : 0;
		$out['hide_empty']    = ! empty( $raw['hide_empty'] );
		$out['hierarchical']  = ! empty( $raw['hierarchical'] );
		$out['collapsible']   = ! empty( $raw['collapsible'] );
		$out['can_deselect']  = ! empty( $raw['can_deselect'] );
		$out['terms_orderby'] = isset( $raw['terms_orderby'] ) && in_array( $raw['terms_orderby'], array( 'name', 'count', 'term_order', 'slug', 'id', 'menu_order', 'include' ), true ) ? $raw['terms_orderby'] : 'name';
		$out['terms_order']   = ( isset( $raw['terms_order'] ) && 'DESC' === strtoupper( $raw['terms_order'] ) ) ? 'DESC' : 'ASC';

		$out['manual_options'] = array();
		if ( ! empty( $raw['manual_options'] ) && is_array( $raw['manual_options'] ) ) {
			foreach ( $raw['manual_options'] as $opt ) {
				if ( ! is_array( $opt ) || ! isset( $opt['value'] ) || '' === trim( (string) $opt['value'] ) ) {
					continue;
				}
				$out['manual_options'][] = array(
					'value' => sanitize_text_field( $opt['value'] ),
					'label' => isset( $opt['label'] ) && '' !== trim( (string) $opt['label'] ) ? sanitize_text_field( $opt['label'] ) : sanitize_text_field( $opt['value'] ),
					'image' => isset( $opt['image'] ) ? absint( $opt['image'] ) : 0,
					'color' => isset( $opt['color'] ) ? (string) sanitize_hex_color( $opt['color'] ) : '',
				);
			}
		}

		$out['meta_key']     = isset( $raw['meta_key'] ) ? self::meta_key( $raw['meta_key'] ) : '';
		$out['meta_compare'] = isset( $raw['meta_compare'] ) && in_array( $raw['meta_compare'], array( '=', 'IN', 'LIKE', 'BETWEEN', '>=', '<=' ), true ) ? $raw['meta_compare'] : 'IN';
		$out['meta_type']    = isset( $raw['meta_type'] ) && in_array( $raw['meta_type'], array( 'CHAR', 'NUMERIC', 'DECIMAL', 'DATE' ), true ) ? $raw['meta_type'] : 'CHAR';

		$out['posts_post_type'] = isset( $raw['posts_post_type'] ) ? sanitize_key( $raw['posts_post_type'] ) : 'post';

		foreach ( array( 'range_min', 'range_max' ) as $k ) {
			$out[ $k ] = ( isset( $raw[ $k ] ) && '' !== trim( (string) $raw[ $k ] ) && is_numeric( $raw[ $k ] ) ) ? (float) $raw[ $k ] : '';
		}
		$out['range_step']     = isset( $raw['range_step'] ) && is_numeric( $raw['range_step'] ) && $raw['range_step'] > 0 ? (float) $raw['range_step'] : 1;
		// Spaties aan het begin/eind horen bij de opmaak ("€ 10"), dus niet trimmen.
		$out['range_prefix']   = isset( $raw['range_prefix'] ) ? substr( strip_tags( (string) $raw['range_prefix'] ), 0, 40 ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.strip_tags_strip_tags
		$out['range_suffix']   = isset( $raw['range_suffix'] ) ? substr( strip_tags( (string) $raw['range_suffix'] ), 0, 40 ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.strip_tags_strip_tags
		$out['range_decimals'] = isset( $raw['range_decimals'] ) ? min( 4, absint( $raw['range_decimals'] ) ) : 0;

		$out['check_ranges'] = array();
		if ( ! empty( $raw['check_ranges'] ) && is_array( $raw['check_ranges'] ) ) {
			foreach ( $raw['check_ranges'] as $r ) {
				if ( ! is_array( $r ) ) {
					continue;
				}
				$min = isset( $r['min'] ) && is_numeric( $r['min'] ) ? (float) $r['min'] : '';
				$max = isset( $r['max'] ) && is_numeric( $r['max'] ) ? (float) $r['max'] : '';
				if ( '' === $min && '' === $max ) {
					continue;
				}
				$out['check_ranges'][] = array(
					'min'   => $min,
					'max'   => $max,
					'label' => isset( $r['label'] ) ? sanitize_text_field( $r['label'] ) : '',
				);
			}
		}

		$out['search_by']        = ( isset( $raw['search_by'] ) && 'meta' === $raw['search_by'] ) ? 'meta' : 'default';
		$out['search_min_chars'] = isset( $raw['search_min_chars'] ) ? absint( $raw['search_min_chars'] ) : 2;
		$out['placeholder']      = isset( $raw['placeholder'] ) ? sanitize_text_field( $raw['placeholder'] ) : '';
		$out['multiple']         = ! empty( $raw['multiple'] );
		$out['show_all_option']  = ! empty( $raw['show_all_option'] );
		$out['all_label']        = isset( $raw['all_label'] ) ? sanitize_text_field( $raw['all_label'] ) : '';
		$out['rating_max']       = isset( $raw['rating_max'] ) ? max( 1, min( 10, absint( $raw['rating_max'] ) ) ) : 5;
		$out['alphabet_letters'] = isset( $raw['alphabet_letters'] ) ? preg_replace( '/[^\p{L}\p{N},#]/u', '', (string) $raw['alphabet_letters'] ) : $d['alphabet_letters'];
		$out['date_source']      = ( isset( $raw['date_source'] ) && 'meta' === $raw['date_source'] ) ? 'meta' : 'post_date';
		$out['date_period_type'] = isset( $raw['date_period_type'] ) && in_array( $raw['date_period_type'], array( 'day', 'week', 'month', 'year', 'range' ), true ) ? $raw['date_period_type'] : 'month';
		$out['legacy_jsf_id']    = isset( $raw['legacy_jsf_id'] ) ? absint( $raw['legacy_jsf_id'] ) : 0;

		$text = static function ( $key ) use ( $raw, $d ) {
			return isset( $raw[ $key ] ) ? sanitize_text_field( (string) $raw[ $key ] ) : $d[ $key ];
		};
		$out['active_label']            = isset( $raw['active_label'] ) ? wp_kses_post( (string) $raw['active_label'] ) : '';
		$out['range_decimal_sep']       = isset( $raw['range_decimal_sep'] ) ? substr( strip_tags( (string) $raw['range_decimal_sep'] ), 0, 10 ) : '.';
		$out['range_thousand_sep']      = isset( $raw['range_thousand_sep'] ) ? substr( strip_tags( (string) $raw['range_thousand_sep'] ), 0, 10 ) : '';
		$out['range_inputs']            = ! empty( $raw['range_inputs'] );
		$out['range_inputs_separators'] = ! empty( $raw['range_inputs_separators'] );
		$out['alphabet_multiple']       = ! empty( $raw['alphabet_multiple'] );
		$out['color_image_type']        = isset( $raw['color_image_type'] ) && in_array( $raw['color_image_type'], array( 'color', 'image', '' ), true ) ? $raw['color_image_type'] : 'color';
		$out['rating_compare']          = isset( $raw['rating_compare'] ) && in_array( $raw['rating_compare'], array( 'greater', 'less', 'equal' ), true ) ? $raw['rating_compare'] : 'greater';
		$out['date_available_range']    = isset( $raw['date_available_range'] ) && in_array( $raw['date_available_range'], array( 'all', 'future', 'past', 'custom' ), true ) ? $raw['date_available_range'] : 'all';
		$out['date_period_start_end']   = ! empty( $raw['date_period_start_end'] );
		foreach ( array( 'date_format', 'date_from_placeholder', 'date_to_placeholder', 'date_min', 'date_max', 'date_period_button_text', 'date_period_format', 'date_period_start_format', 'date_period_separator', 'date_period_end_format' ) as $k ) {
			$out[ $k ] = $text( $k );
		}
		$out['hierarchy_levels'] = array();
		if ( ! empty( $raw['hierarchy_levels'] ) && is_array( $raw['hierarchy_levels'] ) ) {
			foreach ( $raw['hierarchy_levels'] as $lvl ) {
				if ( is_array( $lvl ) && ! empty( $lvl['tax'] ) ) {
					$out['hierarchy_levels'][] = array(
						'label'       => isset( $lvl['label'] ) ? sanitize_text_field( $lvl['label'] ) : '',
						'placeholder' => isset( $lvl['placeholder'] ) ? sanitize_text_field( $lvl['placeholder'] ) : '',
						'tax'         => sanitize_key( $lvl['tax'] ),
					);
				}
			}
		}
		if ( '' === $out['date_format'] ) {
			$out['date_format'] = 'mm/dd/yy';
		}

		return $out;
	}

	public static function on_save( $post_id ) {
		if ( wp_is_post_revision( $post_id ) ) {
			return;
		}
		self::rebuild_allowed_keys();
	}

	public static function maybe_rebuild( $post_id ) {
		if ( self::POST_TYPE === get_post_type( $post_id ) ) {
			self::rebuild_allowed_keys();
		}
	}

	/**
	 * Bewaart welke metasleutels en taxonomieën via de URL gefilterd mogen worden.
	 * Zo kan niemand willekeurige (privé) metavelden aftasten.
	 */
	public static function rebuild_allowed_keys() {
		$meta = self::DEFAULT_META_KEYS;
		$tax  = array();
		$ids  = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		foreach ( $ids as $id ) {
			$s = self::get( $id );
			if ( ! $s ) {
				continue;
			}
			if ( 'taxonomy' === $s['source'] && $s['taxonomy'] ) {
				$tax[] = $s['taxonomy'];
			}
			if ( $s['meta_key'] ) {
				$meta[] = $s['meta_key'];
			}
		}
		update_option(
			self::OPTION_KEYS,
			array(
				'meta' => array_values( array_unique( $meta ) ),
				'tax'  => array_values( array_unique( $tax ) ),
			),
			false
		);
	}

	public static function allowed_keys() {
		$keys = get_option( self::OPTION_KEYS );
		if ( ! is_array( $keys ) ) {
			$keys = array(
				'meta' => self::DEFAULT_META_KEYS,
				'tax'  => array(),
			);
		}
		return apply_filters( 'm7sf/allowed_keys', $keys );
	}

	/**
	 * Naam van de URL-parameter waarmee dit filter zijn waarde doorgeeft.
	 *
	 * @param array $s Instellingen.
	 * @return string
	 */
	public static function param_for( array $s ) {
		switch ( $s['type'] ) {
			case 'search':
				return ( 'meta' === $s['search_by'] && $s['meta_key'] ) ? 'mf_like_' . $s['meta_key'] : 'mf_s';
			case 'rating':
				$by = array(
					'less'  => 'mf_ratingmax',
					'equal' => 'mf_ratingeq',
				);
				return isset( $s['rating_compare'], $by[ $s['rating_compare'] ] ) ? $by[ $s['rating_compare'] ] : 'mf_rating';
			case 'alphabet':
				return 'mf_letter';
			case 'date_range':
			case 'date_period':
				return ( 'meta' === $s['date_source'] && $s['meta_key'] ) ? 'mf_daterange_' . $s['meta_key'] : 'mf_date';
			case 'range':
				return 'mf_range_' . ( $s['meta_key'] ? $s['meta_key'] : '_price' );
			case 'check_range':
				// Eigen parameter, zodat een schuifje en vaste bereiken op hetzelfde veld elkaar niet beïnvloeden.
				return 'mf_ranges_' . ( $s['meta_key'] ? $s['meta_key'] : '_price' );
		}
		if ( 'taxonomy' === $s['source'] ) {
			return ( 'AND' === $s['tax_relation'] ? 'mf_taxall_' : 'mf_tax_' ) . $s['taxonomy'];
		}
		$key = $s['meta_key'];
		switch ( $s['meta_compare'] ) {
			case 'LIKE':
				return 'mf_like_' . $key;
			case 'BETWEEN':
				return 'mf_range_' . $key;
			case '>=':
				return 'mf_min_' . $key;
			case '<=':
				return 'mf_max_' . $key;
		}
		return 'mf_meta_' . $key;
	}

	private static function id_list( $value ) {
		$ids = array_filter( array_map( 'absint', preg_split( '/[\s,]+/', (string) $value ) ) );
		return implode( ',', array_unique( $ids ) );
	}

	private static function meta_key( $value ) {
		return preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $value );
	}
}
