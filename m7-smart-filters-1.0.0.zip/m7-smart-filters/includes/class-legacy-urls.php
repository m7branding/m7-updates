<?php
/**
 * Stuurt oude JetSmartFilters-URL's door naar het M7-formaat (301), zodat bestaande links,
 * bladwijzers en zoekmachine-URL's blijven werken. Alleen actief als JetSmartFilters uit staat.
 *
 * Formaat JetSmartFilters 3.7 (zie docs/ref-jetsmartfilters.md):
 *   ?jsf=<provider>[:<query-id>]&tax=<tax>:<id>,<id>[,operator_AND][;…]&meta=<sleutel>[!<suffix>]:<waarden>[;…]
 *   &date=<J.M.D>-<J.M.D>&_s=<tekst>&_sm=<sleutel>!<tekst>&sort=orderby:<x>;order:<y>[;meta_key:<k>]
 *   &alphabet=<A>&pagenum=<n>
 *   Permalinkvorm: /<pad>/jsf/<provider>:<id>/tax/<data>/meta/<data>/search/<tekst>/pagenum/<n>/
 *
 * @package M7SF
 */

namespace M7SF;

defined( 'ABSPATH' ) || exit;

final class Legacy_Urls {

	const PARAMS = array( 'jsf', 'tax', 'meta', 'date', 'sort', 'alphabet', '_s', '_sm', 'search', 'search-by-meta', 'pagenum', 'plain_query' );

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'maybe_redirect' ), 1 );
	}

	public static function maybe_redirect() {
		if ( ! Settings::get( 'legacy_jsf' ) || class_exists( 'Jet_Smart_Filters' ) ) {
			return;
		}
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '/'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$path = (string) strtok( $uri, '?' );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$get = wp_unslash( $_GET );

		if ( false !== strpos( $path, '/jsf/' ) ) {
			list( $path, $from_path ) = self::parse_permalink( $path );
			$get                      = array_merge( $get, $from_path );
		} elseif ( empty( $get['jsf'] ) ) {
			return;
		}

		$target = self::convert( $get, home_url( self::strip_home_path( $path ) ) );
		if ( $target ) {
			wp_safe_redirect( $target, 301, 'M7 Smart Filters' );
			exit;
		}
	}

	private static function strip_home_path( $path ) {
		$home = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		if ( $home && '/' !== $home && 0 === strpos( $path, $home ) ) {
			return '/' . ltrim( substr( $path, strlen( $home ) ), '/' );
		}
		return $path;
	}

	/**
	 * /pad/jsf/provider:id/tax/x/meta/y/ → ['/pad/', ['jsf' => 'provider:id', 'tax' => 'x', 'meta' => 'y']].
	 *
	 * @param string $path Pad.
	 * @return array
	 */
	public static function parse_permalink( $path ) {
		$pos  = strpos( $path, '/jsf/' );
		$base = substr( $path, 0, $pos + 1 );
		$rest = array_values( array_filter( explode( '/', substr( $path, $pos + 5 ) ), 'strlen' ) );
		$out  = array();
		if ( $rest ) {
			$out['jsf'] = rawurldecode( array_shift( $rest ) );
		}
		for ( $i = 0; $i + 1 < count( $rest ); $i += 2 ) {
			$key = $rest[ $i ];
			if ( 'search' === $key ) {
				$key = '_s';
			} elseif ( 'search-by-meta' === $key ) {
				$key = '_sm';
			}
			if ( in_array( $key, self::PARAMS, true ) ) {
				$out[ $key ] = rawurldecode( $rest[ $i + 1 ] );
			}
		}
		return array( $base, $out );
	}

	/**
	 * Zet JetSmartFilters-parameters om naar een M7-URL.
	 *
	 * @param array  $get  Parameters.
	 * @param string $base URL zonder query.
	 * @return string
	 */
	public static function convert( array $get, $base ) {
		$jsf = isset( $get['jsf'] ) ? (string) $get['jsf'] : '';
		$qid = '';
		if ( preg_match( '#^[^:/]+[:/](.+)$#', $jsf, $m ) ) {
			$qid = $m[1];
		}
		$qid = Query::clean_query_id( $qid );
		if ( '' === $qid || 'default' === $qid ) {
			$qid = Providers::MAIN;
		}

		$params = array();
		self::convert_tax( isset( $get['tax'] ) ? $get['tax'] : '', $params );
		self::convert_meta( isset( $get['meta'] ) ? $get['meta'] : '', $params );

		if ( ! empty( $get['date'] ) && is_string( $get['date'] ) ) {
			$range = self::date_range( $get['date'] );
			if ( $range ) {
				$params['mf_date'] = $range;
			}
		}
		foreach ( array( '_s', 'search' ) as $s ) {
			if ( ! empty( $get[ $s ] ) && is_string( $get[ $s ] ) ) {
				$params['mf_s'] = sanitize_text_field( $get[ $s ] );
			}
		}
		if ( ! empty( $get['_sm'] ) && is_string( $get['_sm'] ) && false !== strpos( $get['_sm'], '!' ) ) {
			list( $key, $term ) = explode( '!', $get['_sm'], 2 );
			$key                = self::key( $key );
			if ( $key && '' !== $term ) {
				$params[ 'mf_like_' . $key ] = sanitize_text_field( $term );
			}
		}
		if ( ! empty( $get['alphabet'] ) && is_string( $get['alphabet'] ) ) {
			$params['mf_letter'] = strtoupper( sanitize_text_field( $get['alphabet'] ) );
		}
		if ( ! empty( $get['sort'] ) && is_string( $get['sort'] ) ) {
			$sort = self::convert_sort( $get['sort'] );
			if ( $sort ) {
				$params['mf_sort'] = $sort;
			}
		}

		$keep = array();
		foreach ( $get as $k => $v ) {
			if ( is_string( $k ) && is_string( $v ) && ! in_array( $k, self::PARAMS, true ) ) {
				$keep[ $k ] = $v;
			}
		}

		$url = $base;
		if ( ! empty( $get['pagenum'] ) && ctype_digit( (string) $get['pagenum'] ) && (int) $get['pagenum'] > 1 ) {
			$url = trailingslashit( $url ) . 'page/' . (int) $get['pagenum'] . '/';
		}
		$args = array_merge( $keep, $params ? array( 'mfq' => $qid ) : array(), $params );
		return add_query_arg( array_map( 'rawurlencode', $args ), $url );
	}

	private static function convert_tax( $raw, array &$params ) {
		if ( ! is_string( $raw ) || '' === $raw ) {
			return;
		}
		foreach ( explode( ';', $raw ) as $part ) {
			if ( false === strpos( $part, ':' ) ) {
				continue;
			}
			list( $taxonomy, $values ) = explode( ':', $part, 2 );
			$taxonomy                  = sanitize_key( $taxonomy );
			if ( ! taxonomy_exists( $taxonomy ) ) {
				continue;
			}
			$and   = false;
			$slugs = array();
			foreach ( explode( ',', $values ) as $v ) {
				$v = rawurldecode( trim( $v ) );
				if ( 'operator_AND' === $v ) {
					$and = true;
					continue;
				}
				if ( 0 === strpos( $v, 'operator_' ) || '' === $v ) {
					continue;
				}
				$term = ctype_digit( $v ) ? get_term( (int) $v, $taxonomy ) : get_term_by( 'slug', $v, $taxonomy );
				if ( $term && ! is_wp_error( $term ) ) {
					$slugs[] = $term->slug;
				}
			}
			if ( $slugs ) {
				$params[ ( $and ? 'mf_taxall_' : 'mf_tax_' ) . $taxonomy ] = implode( ',', array_unique( $slugs ) );
			}
		}
	}

	private static function convert_meta( $raw, array &$params ) {
		if ( ! is_string( $raw ) || '' === $raw ) {
			return;
		}
		foreach ( explode( ';', $raw ) as $part ) {
			if ( false === strpos( $part, ':' ) ) {
				continue;
			}
			list( $key_part, $value ) = explode( ':', $part, 2 );
			$bits                     = explode( '!', $key_part, 2 );
			$key                      = self::key( $bits[0] );
			$suffix                   = isset( $bits[1] ) ? $bits[1] : '';
			$values                   = array_values( array_filter( array_map( 'rawurldecode', explode( ',', $value ) ), static function ( $v ) {
				return '' !== $v && 0 !== strpos( $v, 'operator_' );
			} ) );
			if ( '' === $key || ! $values ) {
				continue;
			}
			if ( false !== strpos( $suffix, 'check-range' ) ) {
				$params[ 'mf_ranges_' . $key ] = implode( ',', $values );
			} elseif ( false !== strpos( $suffix, 'range' ) ) {
				$params[ 'mf_range_' . $key ] = implode( ',', $values );
			} elseif ( false !== strpos( $suffix, 'date' ) ) {
				$range = self::date_range( $values[0] );
				if ( $range ) {
					$params[ 'mf_daterange_' . $key ] = $range;
				}
			} elseif ( false !== strpos( $suffix, 'rating' ) && '_wc_average_rating' === $key ) {
				$params[ false !== strpos( $suffix, 'compare-less' ) ? 'mf_ratingmax' : ( false !== strpos( $suffix, 'compare-greater' ) ? 'mf_rating' : 'mf_ratingeq' ) ] = $values[0];
			} elseif ( false !== strpos( $suffix, 'compare-greater' ) ) {
				$params[ 'mf_min_' . $key ] = $values[0];
			} elseif ( false !== strpos( $suffix, 'compare-less' ) ) {
				$params[ 'mf_max_' . $key ] = $values[0];
			} elseif ( false !== strpos( $suffix, 'compare-like' ) ) {
				$params[ 'mf_like_' . $key ] = $values[0];
			} else {
				$params[ 'mf_meta_' . $key ] = implode( ',', $values );
			}
		}
	}

	/**
	 * "2024.1.1-2024.12.31" → "2024-01-01_2024-12-31".
	 *
	 * @param string $raw Waarde.
	 * @return string
	 */
	public static function date_range( $raw ) {
		$parts = explode( '-', (string) $raw, 2 );
		$fmt   = static function ( $d ) {
			if ( preg_match( '/^(\d{4})\.(\d{1,2})\.(\d{1,2})$/', trim( $d ), $m ) ) {
				return sprintf( '%04d-%02d-%02d', $m[1], $m[2], $m[3] );
			}
			return '';
		};
		$from = $fmt( $parts[0] );
		$to   = isset( $parts[1] ) ? $fmt( $parts[1] ) : $from; // Eén datum = die dag.
		return ( $from || $to ) ? $from . '_' . $to : '';
	}

	private static function convert_sort( $raw ) {
		$sort = array();
		foreach ( explode( ';', $raw ) as $part ) {
			$bits = explode( ':', $part, 2 );
			if ( 2 === count( $bits ) ) {
				$sort[ $bits[0] ] = $bits[1];
			}
		}
		$orderby = isset( $sort['orderby'] ) ? $sort['orderby'] : '';
		$desc    = isset( $sort['order'] ) && 'DESC' === strtoupper( $sort['order'] );
		switch ( $orderby ) {
			case 'price':
				return $desc ? 'price-desc' : 'price-asc';
			case 'date':
				return $desc ? 'date-desc' : 'date-asc';
			case 'modified':
				return 'modified-desc';
			case 'title':
			case 'name':
				return $desc ? 'title-desc' : 'title-asc';
			case 'sales_number':
				return 'popularity';
			case 'rating':
				return 'rating';
			case 'rand':
				return 'rand';
			case 'meta_value':
			case 'meta_value_num':
				$key = isset( $sort['meta_key'] ) ? self::key( $sort['meta_key'] ) : '';
				return $key ? 'meta:' . $key . ':' . ( 'meta_value_num' === $orderby ? 'num' : 'str' ) . ':' . ( $desc ? 'desc' : 'asc' ) : '';
		}
		return '';
	}

	private static function key( $key ) {
		return preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $key );
	}
}
