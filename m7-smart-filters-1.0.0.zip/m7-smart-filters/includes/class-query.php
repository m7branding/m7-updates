<?php
/**
 * Leest de filterwaarden uit de URL en past ze toe op een WP_Query.
 *
 * URL-opbouw (zelfbeschrijvend, deelbaar):
 *   mfq=<query-id>                 Welke query gefilterd wordt (bijv. "rijlaars" of "main").
 *   mf_tax_<taxonomie>=a,b         Termen (slugs), een van.
 *   mf_taxall_<taxonomie>=a,b      Termen (slugs), allemaal.
 *   mf_meta_<sleutel>=x,y          Metawaarde is een van.
 *   mf_like_<sleutel>=tekst        Metawaarde bevat tekst.
 *   mf_range_<sleutel>=10_100      Numeriek bereik (schuifje).
 *   mf_ranges_<sleutel>=0_30,30_100 Vaste bereiken; meerdere met komma (OF).
 *   mf_min_<sleutel>=4 / mf_max_   Groter/kleiner dan of gelijk aan.
 *   mf_daterange_<sleutel>=a_b     Datumbereik op metaveld (JJJJ-MM-DD).
 *   mf_date=a_b                    Publicatiedatum tussen a en b.
 *   mf_s=tekst                     Zoeken.
 *   mf_rating=4                    WooCommerce-beoordeling minimaal.
 *   mf_letter=A                    Titel begint met letter (# = cijfer).
 *   mf_sort=price-asc              Sortering (zie sort_options()).
 *
 * @package M7SF
 */

namespace M7SF;

defined( 'ABSPATH' ) || exit;

final class Query {

	const MAX_VALUES = 50;

	/** @var array|null */
	private static $state = null;

	public static function init() {
		add_filter( 'posts_where', array( __CLASS__, 'letter_where' ), 10, 2 );
	}

	/**
	 * Query-ID uit de URL, of '' als er niet gefilterd wordt.
	 *
	 * @return string
	 */
	public static function query_id() {
		$state = self::state();
		return $state['query_id'];
	}

	/**
	 * Gefilterde staat van dit verzoek.
	 *
	 * @return array
	 */
	public static function state() {
		if ( null === self::$state ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Openbare filter-URL, alleen lezen.
			self::$state = self::parse( wp_unslash( $_GET ) );
		}
		return self::$state;
	}

	/** Alleen voor tests en voor het opnieuw inlezen na een redirect. */
	public static function reset_state() {
		self::$state = null;
	}

	/**
	 * Zet ruwe GET-parameters om naar een gevalideerde staat.
	 *
	 * @param array $get GET-parameters (zonder slashes).
	 * @return array
	 */
	public static function parse( array $get ) {
		$state = array(
			'query_id' => '',
			'tax'      => array(),
			'meta'     => array(),
			'search'   => '',
			'rating'   => 0,
			'letter'   => '',
			'date'     => array(),
			'sort'     => array(),
			'params'   => array(),
		);

		$qid = isset( $get['mfq'] ) && is_string( $get['mfq'] ) ? self::clean_query_id( $get['mfq'] ) : '';
		if ( '' === $qid ) {
			return $state;
		}
		$state['query_id'] = $qid;

		$allowed = Filter_Post_Type::allowed_keys();

		foreach ( $get as $param => $raw ) {
			if ( ! is_string( $param ) || 0 !== strpos( $param, 'mf_' ) || ! is_string( $raw ) ) {
				continue;
			}
			$raw = trim( $raw );
			if ( '' === $raw ) {
				continue;
			}

			if ( 'mf_s' === $param ) {
				$state['search']           = sanitize_text_field( mb_substr( $raw, 0, 200 ) );
				$state['params'][ $param ] = $state['search'];
				continue;
			}
			if ( in_array( $param, array( 'mf_rating', 'mf_ratingmax', 'mf_ratingeq' ), true ) ) {
				$compare = array(
					'mf_rating'    => '>=',
					'mf_ratingmax' => '<=',
					'mf_ratingeq'  => '=',
				);
				$state['rating']           = max( 0, min( 10, (float) $raw ) );
				$state['rating_compare']   = $compare[ $param ];
				$state['params'][ $param ] = (string) $state['rating'];
				continue;
			}
			if ( 'mf_letter' === $param ) {
				// Eén of meer beginletters (kommagescheiden), zoals het alfabetfilter van JetSmartFilters.
				$letters = array();
				foreach ( explode( ',', sanitize_text_field( $raw ) ) as $l ) {
					$l = mb_substr( trim( $l ), 0, 5 );
					if ( '' !== $l ) {
						$letters[] = $l;
					}
				}
				$letters = array_slice( array_values( array_unique( $letters ) ), 0, 40 );
				if ( $letters ) {
					$state['letter']           = implode( ',', $letters );
					$state['params'][ $param ] = $state['letter'];
				}
				continue;
			}
			if ( 'mf_date' === $param ) {
				$range = self::date_range( $raw );
				if ( $range ) {
					$state['date']             = $range;
					$state['params'][ $param ] = $raw;
				}
				continue;
			}
			if ( 'mf_sort' === $param ) {
				$sort = self::parse_sort( $raw );
				if ( $sort ) {
					$state['sort']             = $sort;
					$state['params'][ $param ] = $raw;
				}
				continue;
			}

			foreach ( array( 'mf_taxall_' => 'AND', 'mf_tax_' => 'IN' ) as $prefix => $operator ) {
				if ( 0 === strpos( $param, $prefix ) ) {
					$taxonomy = substr( $param, strlen( $prefix ) );
					if ( self::taxonomy_allowed( $taxonomy, $allowed ) ) {
						$terms = array_slice( array_filter( array_map( 'sanitize_title', explode( ',', $raw ) ) ), 0, self::MAX_VALUES );
						if ( $terms ) {
							$state['tax'][ $taxonomy ] = array(
								'terms'    => array_values( array_unique( $terms ) ),
								'operator' => $operator,
							);
							$state['params'][ $param ] = implode( ',', $state['tax'][ $taxonomy ]['terms'] );
						}
					}
					continue 2;
				}
			}

			$meta_prefixes = array( 'mf_daterange_', 'mf_ranges_', 'mf_range_', 'mf_meta_', 'mf_like_', 'mf_min_', 'mf_max_' );
			foreach ( $meta_prefixes as $prefix ) {
				if ( 0 !== strpos( $param, $prefix ) ) {
					continue;
				}
				$key = substr( $param, strlen( $prefix ) );
				if ( ! in_array( $key, $allowed['meta'], true ) ) {
					continue 2;
				}
				$clause = self::meta_clause( $prefix, $key, $raw );
				if ( $clause ) {
					$state['meta'][]           = $clause;
					$state['params'][ $param ] = $raw;
				}
				continue 2;
			}
		}

		return $state;
	}

	/**
	 * Heeft dit verzoek actieve filters voor de gegeven query?
	 *
	 * @param string $query_id Query-ID.
	 * @return bool
	 */
	public static function is_active_for( $query_id ) {
		$state = self::state();
		// Sorteren telt niet als filter (zoals bij JetSmartFilters).
		return '' !== $state['query_id'] && $state['query_id'] === $query_id && ! empty( array_diff_key( $state['params'], array( 'mf_sort' => 1 ) ) );
	}

	/**
	 * Past de staat toe op een WP_Query (voor pre_get_posts en elementor/query/<id>).
	 *
	 * @param \WP_Query $query Query.
	 * @param array     $state Staat.
	 */
	public static function apply_to_query( \WP_Query $query, array $state ) {
		$vars = self::apply_to_vars( $query->query_vars, $state );
		foreach ( $vars as $key => $value ) {
			$query->set( $key, $value );
		}
	}

	/**
	 * Past de staat toe op een array met query-variabelen.
	 *
	 * @param array $vars  Bestaande query-variabelen.
	 * @param array $state Staat.
	 * @return array
	 */
	public static function apply_to_vars( array $vars, array $state ) {
		if ( ! empty( $state['tax'] ) ) {
			$clauses = array();
			foreach ( $state['tax'] as $taxonomy => $t ) {
				$clauses[] = array(
					'taxonomy'         => $taxonomy,
					'field'            => 'slug',
					'terms'            => $t['terms'],
					'operator'         => $t['operator'],
					'include_children' => true,
				);
			}
			$vars['tax_query'] = self::merge_clauses( isset( $vars['tax_query'] ) ? $vars['tax_query'] : array(), $clauses );
		}

		$meta = $state['meta'];
		if ( $state['rating'] > 0 ) {
			$meta[] = array(
				'key'     => '_wc_average_rating',
				'value'   => $state['rating'],
				'compare' => isset( $state['rating_compare'] ) ? $state['rating_compare'] : '>=',
				'type'    => 'DECIMAL(3,2)',
			);
		}
		if ( $meta ) {
			$vars['meta_query'] = self::merge_clauses( isset( $vars['meta_query'] ) ? $vars['meta_query'] : array(), $meta );
		}

		if ( '' !== $state['search'] ) {
			$vars['s'] = $state['search'];
		}
		if ( '' !== $state['letter'] ) {
			$vars['m7sf_letter'] = $state['letter'];
		}
		if ( ! empty( $state['date'] ) ) {
			$existing           = isset( $vars['date_query'] ) && is_array( $vars['date_query'] ) ? $vars['date_query'] : array();
			$existing[]         = array_merge( $state['date'], array( 'inclusive' => true ) );
			$vars['date_query'] = $existing;
		}
		if ( ! empty( $state['sort'] ) ) {
			$vars['orderby'] = $state['sort']['orderby'];
			$vars['order']   = $state['sort']['order'];
			if ( ! empty( $state['sort']['meta_key'] ) ) {
				$vars['meta_key'] = $state['sort']['meta_key']; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			}
		}

		// Nieuwe filterkeuze begint altijd op pagina 1, behalve als de paginering zelf in de URL staat.
		return apply_filters( 'm7sf/query_vars', $vars, $state );
	}

	/**
	 * Beperkt resultaten op beginletter van de titel.
	 *
	 * @param string    $where WHERE-deel.
	 * @param \WP_Query $query Query.
	 * @return string
	 */
	public static function letter_where( $where, $query ) {
		$letter = $query->get( 'm7sf_letter' );
		if ( ! is_string( $letter ) || '' === $letter ) {
			return $where;
		}
		global $wpdb;
		$parts = array();
		foreach ( explode( ',', $letter ) as $l ) {
			if ( '#' === $l ) {
				$parts[] = "{$wpdb->posts}.post_title REGEXP '^[0-9]'";
			} elseif ( '' !== $l ) {
				$parts[] = $wpdb->prepare( "{$wpdb->posts}.post_title LIKE %s", $wpdb->esc_like( $l ) . '%' ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			}
		}
		return $parts ? $where . ' AND (' . implode( ' OR ', $parts ) . ')' : $where;
	}

	/**
	 * Beschikbare sorteringen. Sleutel staat in de URL.
	 *
	 * @return array
	 */
	public static function sort_options() {
		return apply_filters(
			'm7sf/sort_options',
			array(
				'menu_order'    => array( 'label' => __( 'Standaard', 'm7-smart-filters' ), 'orderby' => 'menu_order title', 'order' => 'ASC' ),
				'date-desc'     => array( 'label' => __( 'Nieuwste eerst', 'm7-smart-filters' ), 'orderby' => 'date', 'order' => 'DESC' ),
				'date-asc'      => array( 'label' => __( 'Oudste eerst', 'm7-smart-filters' ), 'orderby' => 'date', 'order' => 'ASC' ),
				'title-asc'     => array( 'label' => __( 'Naam A-Z', 'm7-smart-filters' ), 'orderby' => 'title', 'order' => 'ASC' ),
				'title-desc'    => array( 'label' => __( 'Naam Z-A', 'm7-smart-filters' ), 'orderby' => 'title', 'order' => 'DESC' ),
				'modified-desc' => array( 'label' => __( 'Laatst bijgewerkt', 'm7-smart-filters' ), 'orderby' => 'modified', 'order' => 'DESC' ),
				'price-asc'     => array( 'label' => __( 'Prijs laag-hoog', 'm7-smart-filters' ), 'orderby' => 'meta_value_num', 'order' => 'ASC', 'meta_key' => '_price' ),
				'price-desc'    => array( 'label' => __( 'Prijs hoog-laag', 'm7-smart-filters' ), 'orderby' => 'meta_value_num', 'order' => 'DESC', 'meta_key' => '_price' ),
				'popularity'    => array( 'label' => __( 'Populariteit', 'm7-smart-filters' ), 'orderby' => 'meta_value_num', 'order' => 'DESC', 'meta_key' => 'total_sales' ),
				'rating'        => array( 'label' => __( 'Beoordeling', 'm7-smart-filters' ), 'orderby' => 'meta_value_num', 'order' => 'DESC', 'meta_key' => '_wc_average_rating' ),
				'rand'          => array( 'label' => __( 'Willekeurig', 'm7-smart-filters' ), 'orderby' => 'rand', 'order' => 'ASC' ),
			)
		);
	}

	/**
	 * Sortering uit de URL. Ondersteunt ook meta:<sleutel>:<num|str>:<asc|desc>.
	 *
	 * @param string $raw Waarde.
	 * @return array
	 */
	public static function parse_sort( $raw ) {
		$options = self::sort_options();
		if ( isset( $options[ $raw ] ) ) {
			$o = $options[ $raw ];
			return array(
				'key'      => $raw,
				'orderby'  => $o['orderby'],
				'order'    => $o['order'],
				'meta_key' => isset( $o['meta_key'] ) ? $o['meta_key'] : '',
			);
		}
		if ( preg_match( '/^meta:([A-Za-z0-9_\-]+):(num|str):(asc|desc)$/', $raw, $m ) ) {
			$allowed = Filter_Post_Type::allowed_keys();
			if ( in_array( $m[1], $allowed['meta'], true ) ) {
				return array(
					'key'      => $raw,
					'orderby'  => 'num' === $m[2] ? 'meta_value_num' : 'meta_value',
					'order'    => strtoupper( $m[3] ),
					'meta_key' => $m[1],
				);
			}
		}
		return array();
	}

	public static function clean_query_id( $raw ) {
		return substr( preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $raw ), 0, 64 );
	}

	private static function taxonomy_allowed( $taxonomy, array $allowed ) {
		if ( ! taxonomy_exists( $taxonomy ) ) {
			return false;
		}
		if ( in_array( $taxonomy, $allowed['tax'], true ) ) {
			return true;
		}
		$tax = get_taxonomy( $taxonomy );
		return $tax && ( $tax->public || $tax->publicly_queryable );
	}

	private static function meta_clause( $prefix, $key, $raw ) {
		switch ( $prefix ) {
			case 'mf_meta_':
				$values = array_slice( array_values( array_filter( array_map( 'sanitize_text_field', explode( ',', $raw ) ), 'strlen' ) ), 0, self::MAX_VALUES );
				if ( ! $values ) {
					return null;
				}
				return array(
					'key'     => $key,
					'value'   => count( $values ) > 1 ? $values : $values[0],
					'compare' => count( $values ) > 1 ? 'IN' : '=',
				);
			case 'mf_like_':
				$value = sanitize_text_field( mb_substr( $raw, 0, 200 ) );
				return '' === $value ? null : array(
					'key'     => $key,
					'value'   => $value,
					'compare' => 'LIKE',
				);
			case 'mf_min_':
			case 'mf_max_':
				if ( ! is_numeric( $raw ) ) {
					return null;
				}
				return array(
					'key'     => $key,
					'value'   => (float) $raw,
					'compare' => 'mf_min_' === $prefix ? '>=' : '<=',
					'type'    => 'DECIMAL(20,4)',
				);
			case 'mf_range_':
			case 'mf_ranges_':
				$ranges = array();
				foreach ( array_slice( explode( ',', $raw ), 0, 10 ) as $part ) {
					$r = self::numeric_range( $part );
					if ( $r ) {
						$ranges[] = self::range_clause( $key, $r[0], $r[1] );
					}
				}
				if ( ! $ranges ) {
					return null;
				}
				return 1 === count( $ranges ) ? $ranges[0] : array_merge( array( 'relation' => 'OR' ), $ranges );
			case 'mf_daterange_':
				$range = self::date_range( $raw );
				if ( ! $range ) {
					return null;
				}
				$from = isset( $range['after'] ) ? $range['after'] : '';
				$to   = isset( $range['before'] ) ? $range['before'] : '';
				if ( $from && $to ) {
					return array( 'key' => $key, 'value' => array( $from, $to ), 'compare' => 'BETWEEN', 'type' => 'DATE' );
				}
				return array( 'key' => $key, 'value' => $from ? $from : $to, 'compare' => $from ? '>=' : '<=', 'type' => 'DATE' );
		}
		return null;
	}

	private static function range_clause( $key, $min, $max ) {
		if ( null !== $min && null !== $max ) {
			return array( 'key' => $key, 'value' => array( $min, $max ), 'compare' => 'BETWEEN', 'type' => 'DECIMAL(20,4)' );
		}
		if ( null !== $min ) {
			return array( 'key' => $key, 'value' => $min, 'compare' => '>=', 'type' => 'DECIMAL(20,4)' );
		}
		return array( 'key' => $key, 'value' => $max, 'compare' => '<=', 'type' => 'DECIMAL(20,4)' );
	}

	/**
	 * "10_100", "10_", "_100" → [min, max] met null voor open kanten.
	 *
	 * @param string $part Deel.
	 * @return array|null
	 */
	public static function numeric_range( $part ) {
		$bits = explode( '_', trim( $part ), 2 );
		if ( 2 !== count( $bits ) ) {
			return null;
		}
		$min = is_numeric( $bits[0] ) ? (float) $bits[0] : null;
		$max = is_numeric( $bits[1] ) ? (float) $bits[1] : null;
		if ( null === $min && null === $max ) {
			return null;
		}
		if ( null !== $min && null !== $max && $min > $max ) {
			list( $min, $max ) = array( $max, $min );
		}
		return array( $min, $max );
	}

	/**
	 * "2026-01-01_2026-01-31" → ['after' => ..., 'before' => ...].
	 *
	 * @param string $raw Waarde.
	 * @return array
	 */
	public static function date_range( $raw ) {
		$bits = explode( '_', (string) $raw, 2 );
		$out  = array();
		if ( isset( $bits[0] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $bits[0] ) ) {
			$out['after'] = $bits[0];
		}
		if ( isset( $bits[1] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $bits[1] ) ) {
			$out['before'] = $bits[1];
		}
		return $out;
	}

	/**
	 * Voegt clauses toe aan een bestaande tax_query/meta_query met AND.
	 *
	 * @param mixed $existing Bestaand.
	 * @param array $clauses  Nieuw.
	 * @return array
	 */
	private static function merge_clauses( $existing, array $clauses ) {
		$existing = is_array( $existing ) ? $existing : array();
		if ( empty( $existing ) ) {
			return array_merge( array( 'relation' => 'AND' ), $clauses );
		}
		if ( isset( $existing['relation'] ) && 'OR' === strtoupper( $existing['relation'] ) ) {
			return array_merge( array( 'relation' => 'AND', $existing ), $clauses );
		}
		$existing['relation'] = 'AND';
		foreach ( $clauses as $clause ) {
			$existing[] = $clause;
		}
		return $existing;
	}
}
