<?php
/**
 * Toegang tot de filter-HTML voor shortcodes en oudere widgets, plus de huidige filterstaat
 * (waarden en actieve filters). De HTML zelf staat in Markup (zelfde opbouw als JetSmartFilters).
 *
 * @package M7SF
 */

namespace M7SF;

defined( 'ABSPATH' ) || exit;

final class Render {

	/** @var array|null Cache van alle filters (param => instellingen). */
	private static $by_param = null;

	/**
	 * Standaard weergave-opties (shortcodes en het oudere M7 Filter-widget).
	 *
	 * @return array
	 */
	public static function default_args() {
		return array(
			'query_id'     => '',
			'apply_type'   => 'ajax',   // ajax | reload | mixed.
			'apply_on'     => 'value',  // value | button.
			'show_label'   => true,
			'show_counter' => false,
			'show_search'  => false,
			'more_less'    => 0,
			'columns'      => 1,
			'selector'     => '',
			'redirect'     => '',
			'class'        => '',
		);
	}

	/**
	 * Een filter (alle typen) via shortcode of het oudere widget.
	 *
	 * @param int   $filter_id Filter-ID.
	 * @param array $args      Weergave-opties.
	 * @return string
	 */
	public static function filter( $filter_id, array $args = array() ) {
		$s = Filter_Post_Type::get( $filter_id );
		if ( ! $s ) {
			return current_user_can( 'edit_posts' ) ? '<p class="m7sf-notice">' . esc_html__( 'M7 Filter: filter niet gevonden.', 'm7-smart-filters' ) . '</p>' : '';
		}
		$args = self::normalize_args( $args );
		$type = array_search( $s['type'], Markup::FILTER_TYPES, true );
		$type = $type ? $type : 'checkboxes';
		$set  = array(
			'filter_id'        => in_array( $type, Markup::SINGLE_TYPES, true ) ? (string) $s['id'] : array( (string) $s['id'] ),
			'query_id'         => $args['query_id'],
			'apply_type'       => $args['apply_type'],
			'apply_on'         => 'button' === $args['apply_on'] ? 'submit' : 'value',
			'show_label'       => $args['show_label'] ? 'yes' : '',
			'apply_indexer'    => $args['show_counter'] ? 'yes' : '',
			'show_counter'     => $args['show_counter'] ? 'yes' : '',
			'search_enabled'   => $args['show_search'] ? 'yes' : '',
			'moreless_enabled' => $args['more_less'] > 0 ? 'yes' : '',
			'less_items_count' => $args['more_less'] > 0 ? $args['more_less'] : 5,
			'm7sf_selector'    => $args['selector'],
			'm7sf_redirect'    => $args['redirect'],
		);
		return self::wrap( Markup::widget( $type, $set ), $type, $args );
	}

	/**
	 * Buiten Elementor ontbreekt de standaardopmaak die Elementor per widget schrijft; .m7sf-sc vult die aan.
	 */
	private static function wrap( $html, $type, array $args ) {
		if ( '' === $html ) {
			return '';
		}
		static $printed = array();
		$style = '';
		if ( ! isset( $printed[ $type ] ) ) {
			$printed[ $type ] = true;
			$css              = Markup::default_css( $type );
			$style            = $css ? '<style id="m7sf-sc-' . esc_attr( $type ) . '">' . wp_strip_all_tags( $css ) . '</style>' : '';
		}
		return $style . '<div class="m7sf-sc m7sf-sc-' . esc_attr( $type ) . ( $args['class'] ? ' ' . esc_attr( $args['class'] ) : '' ) . '">' . $html . '</div>';
	}

	public static function sorting( array $args = array() ) {
		$args = self::normalize_args( $args );
		$keys = isset( $args['options'] ) && $args['options'] ? array_map( 'trim', (array) $args['options'] ) : array_keys( Query::sort_options() );
		$all  = Query::sort_options();
		$list = array();
		foreach ( $keys as $key ) {
			if ( isset( $all[ $key ] ) ) {
				$list[] = array(
					'title'  => isset( $args['labels'][ $key ] ) ? $args['labels'][ $key ] : $all[ $key ]['label'],
					'm7_key' => $key,
				);
			}
		}
		$set = array(
			'query_id'     => $args['query_id'],
			'apply_type'   => $args['apply_type'],
			'label'        => isset( $args['label'] ) ? (string) $args['label'] : '',
			'placeholder'  => isset( $args['placeholder'] ) && '' !== (string) $args['placeholder'] ? (string) $args['placeholder'] : __( 'Sorteren', 'm7-smart-filters' ),
			'sorting_list' => $list,
		);
		return self::wrap( Markup::widget( 'sorting', $set ), 'sorting', $args );
	}

	public static function active_filters( array $args = array() ) {
		$args = self::normalize_args( $args );
		$tags = isset( $args['style'] ) && 'tags' === $args['style'];
		$set  = array(
			'query_id'         => $args['query_id'],
			'apply_type'       => $args['apply_type'],
			'filters_label'    => isset( $args['title'] ) ? (string) $args['title'] : '',
			'tags_label'       => isset( $args['title'] ) ? (string) $args['title'] : '',
			'clear_item'       => ! empty( $args['clear_label'] ) ? 'yes' : '',
			'clear_item_label' => isset( $args['clear_label'] ) ? (string) $args['clear_label'] : '',
		);
		return self::wrap( Markup::widget( $tags ? 'active-tags' : 'active', $set ), 'active', $args );
	}

	public static function remove_filters( array $args = array() ) {
		$args = self::normalize_args( $args );
		$set  = array(
			'query_id'            => $args['query_id'],
			'apply_type'          => $args['apply_type'],
			'remove_filters_text' => ! empty( $args['label'] ) ? $args['label'] : __( 'Filters wissen', 'm7-smart-filters' ),
		);
		return self::wrap( Markup::widget( 'remove-filters', $set ), 'remove-filters', $args );
	}

	public static function apply_button( array $args = array() ) {
		$args = self::normalize_args( $args );
		$set  = array(
			'query_id'          => $args['query_id'],
			'apply_type'        => $args['apply_type'],
			'apply_button_text' => ! empty( $args['label'] ) ? $args['label'] : __( 'Toepassen', 'm7-smart-filters' ),
			'apply_redirect'    => $args['redirect'] ? 'yes' : '',
			'redirect_path'     => $args['redirect'],
		);
		return self::wrap( Markup::widget( 'apply-button', $set ), 'apply-button', $args );
	}

	/* ------------------------------------------------------------------ */

	/**
	 * Huidige waarden voor een parameter, alleen als de URL voor deze query filtert.
	 *
	 * @param string $query_id Query-ID.
	 * @param string $param    Parameter.
	 * @return array
	 */
	public static function current_values( $query_id, $param ) {
		$state = Query::state();
		if ( '' === $state['query_id'] || $state['query_id'] !== $query_id || ! isset( $state['params'][ $param ] ) ) {
			return array();
		}
		$raw = (string) $state['params'][ $param ];
		if ( in_array( $param, array( 'mf_s', 'mf_date' ), true ) || 0 === strpos( $param, 'mf_like_' ) || 0 === strpos( $param, 'mf_daterange_' ) ) {
			return array( $raw );
		}
		return array_values( array_filter( array_map( 'trim', explode( ',', $raw ) ), 'strlen' ) );
	}

	/**
	 * Lijst van actieve filterwaarden met leesbare labels.
	 *
	 * @param string $query_id Query-ID.
	 * @return array
	 */
	public static function active_items( $query_id ) {
		$state = Query::state();
		if ( '' === $state['query_id'] || $state['query_id'] !== $query_id ) {
			return array();
		}
		$items = array();
		foreach ( $state['params'] as $param => $raw ) {
			if ( 'mf_sort' === $param ) {
				continue;
			}
			$filter = self::filter_for_param( $param );
			$label  = $filter ? $filter['label'] : '';
			foreach ( self::current_values( $query_id, $param ) as $value ) {
				$items[] = array(
					'param'       => $param,
					'value'       => $value,
					'label'       => $label,
					'value_label' => self::value_label( $param, $value, $filter ),
					'filter'      => $filter,
				);
			}
		}
		return apply_filters( 'm7sf/active_items', $items, $query_id );
	}

	private static function value_label( $param, $value, $filter ) {
		if ( preg_match( '/^mf_tax(?:all)?_(.+)$/', $param, $m ) ) {
			$term = get_term_by( 'slug', $value, $m[1] );
			return $term ? $term->name : $value;
		}
		if ( 0 === strpos( $param, 'mf_range_' ) || 0 === strpos( $param, 'mf_ranges_' ) ) {
			$r = Query::numeric_range( $value );
			if ( $filter && 'check_range' === $filter['type'] ) {
				foreach ( $filter['check_ranges'] as $cr ) {
					$min = '' === (string) $cr['min'] ? '0' : $cr['min'];
					$max = '' === (string) $cr['max'] ? '100' : $cr['max'];
					if ( Markup::num( $min ) . '_' . Markup::num( $max ) === $value ) {
						return '' !== (string) $cr['label'] ? $cr['label'] : Markup::fmt_number( $filter, $min, true ) . ' — ' . Markup::fmt_number( $filter, $max, true );
					}
				}
			}
			if ( $r && $filter && 'range' === $filter['type'] ) {
				list( $bmin, $bmax ) = Markup::range_bounds( $filter );
				return Markup::fmt_number( $filter, null === $r[0] ? $bmin : $r[0], true ) . ' — ' . Markup::fmt_number( $filter, null === $r[1] ? $bmax : $r[1], true );
			}
			return $r ? self::range_label( $filter ? $filter : array(), $r[0], $r[1] ) : $value;
		}
		if ( in_array( $param, array( 'mf_rating', 'mf_ratingmax', 'mf_ratingeq' ), true ) ) {
			return $value . '/' . ( $filter ? (int) $filter['rating_max'] : 5 );
		}
		if ( 'mf_letter' === $param ) {
			return strtoupper( $value );
		}
		if ( 'mf_date' === $param || 0 === strpos( $param, 'mf_daterange_' ) ) {
			// Zoals JetSmartFilters: in de notatie van het filter, open kant als ∞.
			$r = Query::date_range( $value );
			if ( $filter && 'date_period' === $filter['type'] ) {
				$start = isset( $r['after'] ) ? strtotime( $r['after'] ) : 0;
				$end   = isset( $r['before'] ) ? strtotime( $r['before'] ) : 0;
				if ( ! empty( $filter['date_period_start_end'] ) ) {
					$out = self::ui_date( $filter['date_period_start_format'], $start );
					if ( $end && 'day' !== $filter['date_period_type'] ) {
						$out .= ( '' !== $filter['date_period_separator'] ? ' ' . $filter['date_period_separator'] . ' ' : ' - ' ) . self::ui_date( $filter['date_period_end_format'], $end );
					}
					return $out;
				}
				return self::ui_date( $filter['date_period_format'], $start );
			}
			$fmt = $filter && ! empty( $filter['date_format'] ) ? $filter['date_format'] : 'mm/dd/yy';
			$f   = isset( $r['after'] ) ? self::ui_date( $fmt, strtotime( $r['after'] ) ) : '∞';
			$t   = isset( $r['before'] ) ? self::ui_date( $fmt, strtotime( $r['before'] ) ) : '∞';
			return $f . ' — ' . $t;
		}
		if ( $filter && 'manual' === $filter['source'] ) {
			foreach ( $filter['manual_options'] as $o ) {
				if ( (string) $o['value'] === $value ) {
					return $o['label'];
				}
			}
		}
		if ( $filter && 'posts' === $filter['source'] && ctype_digit( $value ) ) {
			return get_the_title( (int) $value );
		}
		return $value;
	}

	/**
	 * Datum opmaken met jQuery UI-notatie (d dd D DD m mm M MM y yy).
	 */
	private static function ui_date( $format, $ts ) {
		if ( ! $ts ) {
			return '';
		}
		$format = '' !== (string) $format ? (string) $format : 'mm/dd/yy';
		$map    = array(
			'yy' => 'Y',
			'y'  => 'y',
			'MM' => 'F',
			'M'  => 'M',
			'mm' => 'm',
			'm'  => 'n',
			'DD' => 'l',
			'D'  => 'D',
			'dd' => 'd',
			'd'  => 'j',
		);
		return preg_replace_callback(
			'/yy|y|MM|M|mm|m|DD|D|dd|d/',
			static function ( $m ) use ( $map, $ts ) {
				return date_i18n( $map[ $m[0] ], $ts );
			},
			$format
		);
	}

	private static function filter_for_param( $param ) {
		if ( null === self::$by_param ) {
			self::$by_param = array();
			$ids            = get_posts(
				array(
					'post_type'      => Filter_Post_Type::POST_TYPE,
					'post_status'    => 'publish',
					'posts_per_page' => 200,
					'fields'         => 'ids',
					'no_found_rows'  => true,
				)
			);
			foreach ( $ids as $id ) {
				$s = Filter_Post_Type::get( $id );
				if ( $s ) {
					$p = Filter_Post_Type::param_for( $s );
					if ( ! isset( self::$by_param[ $p ] ) ) {
						self::$by_param[ $p ] = $s;
					}
				}
			}
		}
		return isset( self::$by_param[ $param ] ) ? self::$by_param[ $param ] : null;
	}

	private static function range_label( array $s, $min, $max ) {
		$prefix   = isset( $s['range_prefix'] ) ? $s['range_prefix'] : '';
		$suffix   = isset( $s['range_suffix'] ) ? $s['range_suffix'] : '';
		$decimals = isset( $s['range_decimals'] ) ? (int) $s['range_decimals'] : 0;
		$fmt      = static function ( $v ) use ( $prefix, $suffix, $decimals ) {
			return $prefix . number_format_i18n( (float) $v, $decimals ) . $suffix;
		};
		if ( null !== $min && null !== $max ) {
			return $fmt( $min ) . ' – ' . $fmt( $max );
		}
		if ( null !== $min ) {
			/* translators: %s: ondergrens */
			return sprintf( __( 'vanaf %s', 'm7-smart-filters' ), $fmt( $min ) );
		}
		/* translators: %s: bovengrens */
		return sprintf( __( 'tot %s', 'm7-smart-filters' ), $fmt( $max ) );
	}

	private static function num( $v ) {
		$v = (float) $v;
		return floor( $v ) === $v ? (string) (int) $v : rtrim( rtrim( number_format( $v, 4, '.', '' ), '0' ), '.' );
	}

	private static function normalize_args( array $args ) {
		$args               = wp_parse_args( $args, self::default_args() );
		$args['query_id']   = Query::clean_query_id( $args['query_id'] );
		$args['apply_type'] = in_array( $args['apply_type'], array( 'ajax', 'reload', 'mixed' ), true ) ? $args['apply_type'] : 'ajax';
		$args['apply_on']   = 'button' === $args['apply_on'] ? 'button' : 'value';
		foreach ( array( 'show_label', 'show_counter', 'show_search' ) as $b ) {
			$args[ $b ] = filter_var( $args[ $b ], FILTER_VALIDATE_BOOLEAN );
		}
		$args['more_less'] = absint( $args['more_less'] );
		$args['columns']   = max( 1, min( 6, absint( $args['columns'] ) ) );
		$args['selector']  = is_string( $args['selector'] ) ? trim( wp_strip_all_tags( $args['selector'] ) ) : '';
		$args['class']     = is_string( $args['class'] ) ? implode( ' ', array_map( 'sanitize_html_class', preg_split( '/\s+/', $args['class'] ) ) ) : '';
		return $args;
	}

	private static function attrs( array $attrs ) {
		$out = '';
		foreach ( $attrs as $name => $value ) {
			if ( null === $value || false === $value ) {
				continue;
			}
			$out .= ' ' . $name . '="' . esc_attr( (string) $value ) . '"';
		}
		return $out;
	}

	/**
	 * Vinkje in het vakje: zelfde vorm als bij JetSmartFilters (Font Awesome 4 "check", SIL OFL 1.1).
	 */
	public static function check_icon() {
		return '<svg width="28" height="28" viewBox="0 0 28 28" xmlns="http://www.w3.org/2000/svg" focusable="false"><path d="M26.109 8.844c0 0.391-0.156 0.781-0.438 1.062l-13.438 13.438c-0.281 0.281-0.672 0.438-1.062 0.438s-0.781-0.156-1.062-0.438l-7.781-7.781c-0.281-0.281-0.438-0.672-0.438-1.062s0.156-0.781 0.438-1.062l2.125-2.125c0.281-0.281 0.672-0.438 1.062-0.438s0.781 0.156 1.062 0.438l4.594 4.609 10.25-10.266c0.281-0.281 0.672-0.438 1.062-0.438s0.781 0.156 1.062 0.438l2.125 2.125c0.281 0.281 0.438 0.672 0.438 1.062z"/></svg>';
	}
}
