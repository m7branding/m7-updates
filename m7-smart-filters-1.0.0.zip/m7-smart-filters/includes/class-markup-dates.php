<?php
/**
 * Datumfilters (van-tot en periode) in de opbouw van JetSmartFilters 3.7.0.
 * Van-tot gebruikt de jQuery UI-datumkiezer van WordPress, periode de kalender uit assets/m7sf-datepicker.js.
 * Waarde in de M7-URL: JJJJ-MM-DD_JJJJ-MM-DD.
 *
 * @package M7SF
 */

namespace M7SF;

defined( 'ABSPATH' ) || exit;

final class Markup_Dates {

	public static function range( array $s, array $set, array $ctx ) {
		wp_enqueue_script( 'jquery-ui-datepicker' );
		wp_enqueue_script( 'm7sf-dates' );
		$icon  = isset( $set['apply_button_icon'] ) ? (string) $set['apply_button_icon'] : '';
		$pos   = isset( $set['filter_apply_button_icon_position'] ) ? (string) $set['filter_apply_button_icon_position'] : 'left';
		$value = $ctx['current'] ? (string) $ctx['current'][0] : '';
		$name  = 'meta' === $s['date_source'] ? (string) $s['meta_key'] : '';
		$html  = '<div class="m7sf-date-range' . ( '' !== $icon ? ' button-icon-position-' . esc_attr( $pos ) : '' ) . '">';
		$html .= '<fieldset class="m7sf-date-range__inputs"><legend style="display:none;">' . esc_html( wp_strip_all_tags( $s['label'] ) ) . '</legend>';
		$html .= '<input class="m7sf-date-range__from m7sf-date-range__control" type="text" autocomplete="off" placeholder="' . esc_attr( (string) $s['date_from_placeholder'] ) . '" name="' . esc_attr( $name ) . '_from" value="" aria-label="' . esc_attr__( 'Date range from', 'm7-smart-filters' ) . '"' . Markup::tab() . '>';
		$html .= '<input class="m7sf-date-range__to m7sf-date-range__control" type="text" autocomplete="off" placeholder="' . esc_attr( (string) $s['date_to_placeholder'] ) . '" name="' . esc_attr( $name ) . '_to" value="" aria-label="' . esc_attr__( 'Date range to', 'm7-smart-filters' ) . '"' . Markup::tab() . '>';
		$html .= '</fieldset>';
		$html .= '<input class="m7sf-date-range__input" type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" aria-label="' . esc_attr__( 'Date range value', 'm7-smart-filters' ) . '" data-date-format="' . esc_attr( (string) $s['date_format'] ) . '"' . self::limits( $s ) . '>';
		if ( ! Markup::yes( $set, 'hide_apply_button' ) ) {
			$i     = '' !== $icon ? '<i class="' . esc_attr( $icon ) . '"></i>' : '';
			$text  = isset( $set['apply_button_text'] ) ? (string) $set['apply_button_text'] : '';
			$html .= '<button type="button" class="m7sf-date-range__submit m7sf-apply-filters__button" data-m7sf-apply-button' . Markup::tab() . '>' . ( 'left' === $pos ? $i : '' ) . '<span class="m7sf-date-range__submit-text">' . esc_html( $text ) . '</span>' . ( 'right' === $pos ? $i : '' ) . '</button>';
		}
		return $html . '</div>';
	}

	public static function period( array $s, array $set, array $ctx ) {
		wp_enqueue_script( 'm7sf-airdp' );
		wp_enqueue_script( 'm7sf-dates' );
		wp_enqueue_style( 'm7sf-datepicker' );
		$value  = $ctx['current'] ? (string) $ctx['current'][0] : '';
		$name   = 'meta' === $s['date_source'] ? (string) $s['meta_key'] : '';
		$format = ! empty( $s['date_period_start_end'] )
			? wp_json_encode(
				array(
					'start'     => (string) $s['date_period_start_format'],
					'separator' => (string) $s['date_period_separator'],
					'end'       => (string) $s['date_period_end_format'],
				)
			)
			: (string) $s['date_period_format'];
		$type   = (string) $s['date_period_type'];
		$html   = '<div class="m7sf-date-period button-icon-position-left' . ( '' !== $value ? ' m7sf-date-period-is-set' : '' ) . '"' . ( '' !== $type ? ' data-period-type="' . esc_attr( $type ) . '"' : '' ) . '>';
		$html  .= '<div class="m7sf-date-period__wrapper">';
		$html  .= '<div class="m7sf-date-period__prev"' . Markup::tab() . '>' . Markup::icon( 'chevron-left' ) . '</div>';
		$html  .= '<div class="m7sf-date-period__datepicker date"><div class="m7sf-date-period__datepicker-button input-group-addon"' . Markup::tab() . ' data-placeholder="' . esc_attr( (string) $s['date_period_button_text'] ) . '">' . esc_html( (string) $s['date_period_button_text'] ) . Markup::icon( 'angle-down' ) . '</div>';
		$html  .= '<input class="m7sf-date-period__datepicker-input" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" aria-label="' . esc_attr( wp_strip_all_tags( $s['label'] ) ) . '" type="hidden" tabindex="-1" data-format="' . esc_attr( $format ) . '"' . self::limits( $s ) . ' readonly></div>';
		$html  .= '<div class="m7sf-date-period__next"' . Markup::tab() . '>' . Markup::icon( 'chevron-right' ) . '</div>';
		return $html . '</div></div>';
	}

	private static function limits( array $s ) {
		$min = '';
		$max = '';
		switch ( (string) $s['date_available_range'] ) {
			case 'future':
				$min = 'today';
				break;
			case 'past':
				$max = 'today';
				break;
			case 'custom':
				$min = (string) $s['date_min'];
				$max = (string) $s['date_max'];
				break;
		}
		return ( '' !== $min ? ' data-mindate="' . esc_attr( $min ) . '"' : '' ) . ( '' !== $max ? ' data-maxdate="' . esc_attr( $max ) . '"' : '' );
	}
}
