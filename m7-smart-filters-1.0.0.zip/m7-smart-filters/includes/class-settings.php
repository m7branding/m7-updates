<?php
/**
 * Algemene instellingen (M7 Filters > Instellingen).
 *
 * @package M7SF
 */

namespace M7SF;

defined( 'ABSPATH' ) || exit;

final class Settings {

	const OPTION = 'm7sf_settings';

	public static function defaults() {
		return array(
			'main_selector' => '',
			'scroll_top'    => true,
			'scroll_offset' => 120,
			'legacy_jsf'    => true,
			'url_mode'      => 'push', // push = adresbalk bijwerken, keep = ongewijzigd laten (zoals JetSmartFilters).
			// Laadicoon in de resultaten (zelfde vorm en standaardwaarden als JetSmartFilters).
			'preloader'       => false,
			'preloader_fixed' => true,
			'preloader_gap'   => 80,
			'preloader_size'  => 45,
			'preloader_color' => '#007cba',
			'preloader_css'   => '',
			'tabindex'        => false,     // Bediening met toetsenbord (tab) zoals JetSmartFilters "use_tabindex".
			'tabindex_color'  => '#0085f2',
			'dropdown_close'  => false,     // Uitklaplijst sluiten na klik op toepassen.
		);
	}

	/**
	 * Gedrag van JetSmartFilters overnemen (eenmalig bij de import): adresbalk niet wijzigen en niet scrollen bij filteren.
	 */
	public static function adopt_jsf_behaviour() {
		if ( get_option( 'm7sf_jsf_behaviour_applied' ) ) {
			return false;
		}
		$all               = wp_parse_args( (array) get_option( self::OPTION, array() ), self::defaults() );
		$all['url_mode']   = 'keep';
		$all['scroll_top'] = false;

		// Laadicoon uit de JetSmartFilters-instellingen.
		$jsf = (array) get_option( 'jet-smart-filters-settings', array() );
		if ( isset( $jsf['use_provider_preloader'] ) && in_array( $jsf['use_provider_preloader'], array( true, 'true', '1', 1 ), true ) ) {
			$styles                 = isset( $jsf['provider_preloader_styles'] ) && is_array( $jsf['provider_preloader_styles'] ) ? $jsf['provider_preloader_styles'] : array();
			$all['preloader']       = true;
			$all['preloader_fixed'] = isset( $jsf['provider_preloader_fixed_position'] ) && in_array( $jsf['provider_preloader_fixed_position'], array( true, 'true', '1', 1 ), true );
			$all['preloader_gap']   = isset( $jsf['provider_preloader_fixed_edge_gap'] ) ? absint( $jsf['provider_preloader_fixed_edge_gap'] ) : 80;
			$all['preloader_size']  = isset( $styles['size'] ) ? absint( $styles['size'] ) : 45;
			$all['preloader_color'] = isset( $styles['color'] ) && sanitize_hex_color( $styles['color'] ) ? sanitize_hex_color( $styles['color'] ) : '#007cba';
			$all['preloader_css']   = isset( $jsf['provider_preloader_css'] ) ? str_replace( 'jsf_provider-preloader', 'm7sf-preloader', wp_strip_all_tags( (string) $jsf['provider_preloader_css'] ) ) : '';
		}
		$on                    = array( true, 'true', '1', 1 );
		$all['tabindex']       = isset( $jsf['use_tabindex'] ) && in_array( $jsf['use_tabindex'], $on, true );
		$all['tabindex_color'] = isset( $jsf['tabindex_color'] ) && sanitize_hex_color( $jsf['tabindex_color'] ) ? sanitize_hex_color( $jsf['tabindex_color'] ) : '#0085f2';
		$all['dropdown_close'] = isset( $jsf['close_dropdown_on_click_apply_btn'] ) && in_array( $jsf['close_dropdown_on_click_apply_btn'], $on, true );
		update_option( self::OPTION, $all );
		update_option( 'm7sf_jsf_behaviour_applied', 1, false );
		return true;
	}

	public static function get( $key ) {
		$all = wp_parse_args( (array) get_option( self::OPTION, array() ), self::defaults() );
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
	}

	public static function menu() {
		add_submenu_page(
			'm7',
			__( 'Smart Filters: instellingen', 'm7-smart-filters' ),
			__( 'Instellingen', 'm7-smart-filters' ),
			'manage_options',
			'm7sf-settings',
			array( __CLASS__, 'page' )
		);
	}

	public static function register() {
		register_setting(
			'm7sf_settings',
			self::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
				'default'           => self::defaults(),
			)
		);
	}

	public static function sanitize( $raw ) {
		$raw = is_array( $raw ) ? $raw : array();
		return array(
			'main_selector' => isset( $raw['main_selector'] ) ? sanitize_text_field( $raw['main_selector'] ) : '',
			'scroll_top'    => ! empty( $raw['scroll_top'] ),
			'scroll_offset' => isset( $raw['scroll_offset'] ) ? absint( $raw['scroll_offset'] ) : 120,
			'legacy_jsf'    => ! empty( $raw['legacy_jsf'] ),
			'url_mode'      => isset( $raw['url_mode'] ) && 'keep' === $raw['url_mode'] ? 'keep' : 'push',
			'preloader'       => ! empty( $raw['preloader'] ),
			'preloader_fixed' => ! empty( $raw['preloader_fixed'] ),
			'preloader_gap'   => isset( $raw['preloader_gap'] ) ? absint( $raw['preloader_gap'] ) : 80,
			'preloader_size'  => isset( $raw['preloader_size'] ) ? max( 8, absint( $raw['preloader_size'] ) ) : 45,
			'preloader_color' => isset( $raw['preloader_color'] ) && sanitize_hex_color( $raw['preloader_color'] ) ? sanitize_hex_color( $raw['preloader_color'] ) : '#007cba',
			'preloader_css'   => isset( $raw['preloader_css'] ) ? wp_strip_all_tags( (string) $raw['preloader_css'] ) : '',
			'tabindex'        => ! empty( $raw['tabindex'] ),
			'tabindex_color'  => isset( $raw['tabindex_color'] ) && sanitize_hex_color( $raw['tabindex_color'] ) ? sanitize_hex_color( $raw['tabindex_color'] ) : '#0085f2',
			'dropdown_close'  => ! empty( $raw['dropdown_close'] ),
		);
	}

	public static function page() {
		$s = wp_parse_args( (array) get_option( self::OPTION, array() ), self::defaults() );
		?>
		<div class="wrap m7-admin">
			<h1 class="screen-reader-text"><?php esc_html_e( 'Smart Filters: instellingen', 'm7-smart-filters' ); ?></h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'm7sf_settings' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="m7sf-main"><?php esc_html_e( 'Container hoofdquery (CSS-selector)', 'm7-smart-filters' ); ?></label></th>
						<td><input id="m7sf-main" type="text" class="regular-text" name="<?php echo esc_attr( self::OPTION ); ?>[main_selector]" value="<?php echo esc_attr( $s['main_selector'] ); ?>" placeholder=".site-main">
						<p class="description"><?php esc_html_e( 'Alleen nodig voor blog- of themalijsten zonder WooCommerce. WooCommerce-archieven en Elementor-widgets met een Query ID worden automatisch gevonden.', 'm7-smart-filters' ); ?></p></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Na filteren omhoog scrollen', 'm7-smart-filters' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[scroll_top]" value="1" <?php checked( $s['scroll_top'] ); ?>> <?php esc_html_e( 'Scroll naar de resultaten als die buiten beeld staan', 'm7-smart-filters' ); ?></label>
						<p><label><?php esc_html_e( 'Afstand tot bovenkant (px, voor vaste header)', 'm7-smart-filters' ); ?> <input type="number" min="0" name="<?php echo esc_attr( self::OPTION ); ?>[scroll_offset]" value="<?php echo esc_attr( (string) $s['scroll_offset'] ); ?>" class="small-text"></label></p></td>
					</tr>
					<tr>
						<th scope="row"><label for="m7sf-url-mode"><?php esc_html_e( 'Adresbalk bij filteren', 'm7-smart-filters' ); ?></label></th>
						<td><select id="m7sf-url-mode" name="<?php echo esc_attr( self::OPTION ); ?>[url_mode]">
							<option value="push" <?php selected( $s['url_mode'], 'push' ); ?>><?php esc_html_e( 'Bijwerken', 'm7-smart-filters' ); ?></option>
							<option value="keep" <?php selected( $s['url_mode'], 'keep' ); ?>><?php esc_html_e( 'Niet wijzigen (zoals JetSmartFilters)', 'm7-smart-filters' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Bijwerken: de gefilterde pagina is als link te delen en de terug-knop gaat naar het vorige filter.', 'm7-smart-filters' ); ?></p></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Laadicoon', 'm7-smart-filters' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[preloader]" value="1" <?php checked( $s['preloader'] ); ?>> <?php esc_html_e( 'Draaiend icoon in de resultaten tonen tijdens het laden', 'm7-smart-filters' ); ?></label>
						<p class="m7sf-settings-row"><label><?php esc_html_e( 'Grootte (px)', 'm7-smart-filters' ); ?> <input type="number" min="8" name="<?php echo esc_attr( self::OPTION ); ?>[preloader_size]" value="<?php echo esc_attr( (string) $s['preloader_size'] ); ?>" class="small-text"></label>
						<label><?php esc_html_e( 'Kleur', 'm7-smart-filters' ); ?> <input type="color" name="<?php echo esc_attr( self::OPTION ); ?>[preloader_color]" value="<?php echo esc_attr( $s['preloader_color'] ); ?>"></label></p>
						<p class="m7sf-settings-row"><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[preloader_fixed]" value="1" <?php checked( $s['preloader_fixed'] ); ?>> <?php esc_html_e( 'In beeld houden bij scrollen', 'm7-smart-filters' ); ?></label>
						<label><?php esc_html_e( 'Afstand tot rand (px)', 'm7-smart-filters' ); ?> <input type="number" min="0" name="<?php echo esc_attr( self::OPTION ); ?>[preloader_gap]" value="<?php echo esc_attr( (string) $s['preloader_gap'] ); ?>" class="small-text"></label></p>
						<p><label for="m7sf-preloader-css"><?php esc_html_e( 'Extra CSS voor het icoon (optioneel)', 'm7-smart-filters' ); ?></label><br>
						<textarea id="m7sf-preloader-css" name="<?php echo esc_attr( self::OPTION ); ?>[preloader_css]" rows="3" class="large-text code"><?php echo esc_textarea( $s['preloader_css'] ); ?></textarea></p></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Toetsenbord', 'm7-smart-filters' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[tabindex]" value="1" <?php checked( $s['tabindex'] ); ?>> <?php esc_html_e( 'Filters bedienen met Tab, Enter en spatie (met focusrand)', 'm7-smart-filters' ); ?></label>
						<p><label><?php esc_html_e( 'Kleur focusrand', 'm7-smart-filters' ); ?> <input type="color" name="<?php echo esc_attr( self::OPTION ); ?>[tabindex_color]" value="<?php echo esc_attr( $s['tabindex_color'] ); ?>"></label></p>
						<p><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[dropdown_close]" value="1" <?php checked( $s['dropdown_close'] ); ?>> <?php esc_html_e( 'Uitklaplijst sluiten na klik op de toepassen-knop', 'm7-smart-filters' ); ?></label></p></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Oude JetSmartFilters-links', 'm7-smart-filters' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[legacy_jsf]" value="1" <?php checked( $s['legacy_jsf'] ); ?>> <?php esc_html_e( 'Links met ?jsf=… doorsturen naar het nieuwe formaat', 'm7-smart-filters' ); ?></label></td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}
