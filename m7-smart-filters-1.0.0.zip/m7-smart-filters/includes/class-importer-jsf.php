<?php
/**
 * Overstappen van JetSmartFilters (3.x):
 *   1. Filters (berichttype jet-smart-filters) omzetten naar M7-filters.
 *   2. JetSmartFilters-widgets in Elementor-pagina's en -sjablonen vervangen door M7-widgets,
 *      met een back-up van de pagina-opbouw en een knop om terug te zetten.
 * Zie docs/ref-jetsmartfilters.md voor de opslag van JetSmartFilters.
 *
 * @package M7SF
 */

namespace M7SF;

defined( 'ABSPATH' ) || exit;

final class Importer_Jsf {

	const JSF_POST_TYPE = 'jet-smart-filters';
	const LEGACY_META   = '_m7sf_legacy_jsf';
	const BACKUP_META   = '_m7sf_jsf_backup';
	const BACKUP_CSS_META   = '_m7sf_jsf_backup_css';
	const BACKUP_CSS_OPTION = 'm7sf_jsf_backup_custom_css';
	const PAGE          = 'm7sf-jsf-migrate';

	const TYPE_MAP = array(
		'checkboxes'  => 'checkboxes',
		'select'      => 'select',
		'radio'       => 'radio',
		'range'       => 'range',
		'check-range' => 'check_range',
		'search'      => 'search',
		'rating'      => 'rating',
		'alphabet'    => 'alphabet',
		'color-image' => 'color_image',
		'date-range'  => 'date_range',
		'date-period' => 'date_period',
	);

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_post_m7sf_jsf_import', array( __CLASS__, 'handle_import' ) );
		add_action( 'admin_post_m7sf_jsf_convert', array( __CLASS__, 'handle_convert' ) );
		add_action( 'admin_post_m7sf_jsf_revert', array( __CLASS__, 'handle_revert' ) );
	}

	public static function menu() {
		add_submenu_page(
			'm7',
			__( 'Overstappen van JetSmartFilters', 'm7-smart-filters' ),
			__( 'Overstappen', 'm7-smart-filters' ),
			'manage_options',
			self::PAGE,
			array( __CLASS__, 'page' )
		);
	}

	/* ------------------------------ lezen ------------------------------ */

	private static function bool( $v ) {
		if ( is_bool( $v ) ) {
			return $v;
		}
		return in_array( strtolower( trim( (string) $v ) ), array( '1', 'true', 'yes', 'on' ), true );
	}

	private static function list_meta( $post_id, $key ) {
		$v = get_post_meta( $post_id, $key, true );
		if ( is_string( $v ) && '' !== $v ) {
			$decoded = json_decode( $v, true );
			$v       = is_array( $decoded ) ? $decoded : maybe_unserialize( $v );
		}
		return is_array( $v ) ? array_values( $v ) : array();
	}

	private static function currency_macro( $text ) {
		$symbol = function_exists( 'get_woocommerce_currency_symbol' ) ? html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES ) : '€';
		return str_replace( '%woocommerce_currency_symbol%', $symbol, (string) $text );
	}

	/**
	 * Zet één JetSmartFilters-filter om naar M7-instellingen.
	 *
	 * @param int $jsf_id ID.
	 * @return array [settings, warnings, extra] — extra bevat termkleuren/-afbeeldingen.
	 */
	public static function map_filter( $jsf_id ) {
		$m        = static function ( $key, $default = '' ) use ( $jsf_id ) {
			$v = get_post_meta( $jsf_id, $key, true );
			return '' === $v || null === $v ? $default : $v;
		};
		$warnings = array();
		$extra    = array( 'terms' => array() );
		$jtype    = (string) $m( '_filter_type', 'checkboxes' );
		$source   = (string) $m( '_data_source', 'manual_input' );
		$qvars    = array_values( array_filter( array_map( 'trim', explode( ',', (string) $m( '_query_var' ) ) ) ) );
		$qvar     = $qvars ? $qvars[0] : '';
		if ( count( $qvars ) > 1 ) {
			/* translators: %s: metasleutels */
			$warnings[] = sprintf( __( 'Meerdere metasleutels (%s): alleen de eerste wordt gebruikt.', 'm7-smart-filters' ), implode( ', ', $qvars ) );
		}
		if ( 0 === strpos( $qvar, '_tax_query::' ) ) {
			// JetSmartFilters negeert _query_var bij bron "taxonomies" (restwaarde); alleen bij andere bronnen telt hij.
			if ( 'taxonomies' !== $source ) {
				$source = 'taxonomies';
				$tax    = substr( $qvar, 12 );
			}
			$qvar = '';
		}
		if ( 'search' === $jtype && 'meta' !== (string) $m( '_s_by', 'default' ) ) {
			// Zoeken op trefwoord: JetSmartFilters gebruikt _query_var dan niet (restwaarde van een eerdere instelling).
			$qvar = '';
		}
		if ( 0 === strpos( $qvar, '_plain_query::' ) ) {
			$warnings[] = __( '"Plain query"-variabele wordt niet ondersteund.', 'm7-smart-filters' );
			$qvar       = '';
		}

		$s          = array(
			'type'  => isset( self::TYPE_MAP[ $jtype ] ) ? self::TYPE_MAP[ $jtype ] : 'checkboxes',
			'label' => (string) get_post_meta( $jsf_id, '_filter_label', true ), // Leeg = geen zichtbaar label (zoals JetSmartFilters).
		);
		if ( ! isset( self::TYPE_MAP[ $jtype ] ) ) {
			/* translators: %s: filtertype */
			$warnings[] = sprintf( __( 'Onbekend type "%s": omgezet naar checkboxes.', 'm7-smart-filters' ), $jtype );
		}

		switch ( $source ) {
			case 'taxonomies':
				$s['source']        = 'taxonomy';
				$s['taxonomy']      = isset( $tax ) ? $tax : (string) $m( '_source_taxonomy', 'category' );
				$s['tax_relation']  = 'AND' === strtoupper( (string) $m( '_terms_relational_operator', 'OR' ) ) ? 'AND' : 'IN';
				$s['hide_empty']    = ! self::bool( $m( '_show_empty_terms', false ) );
				$s['hierarchical']  = self::bool( $m( '_group_by_parent', false ) );
				$s['collapsible']   = $s['hierarchical'] && self::bool( $m( '_group_collapsible', false ) );
				$orderby            = (string) $m( '_terms_orderby', 'name' );
				$s['terms_orderby'] = in_array( $orderby, array( 'name', 'slug', 'id', 'count' ), true ) ? $orderby : ( 'order' === $m( '_terms_orderby_meta_value' ) ? 'menu_order' : 'name' );
				$s['terms_order']   = (string) $m( '_terms_order', 'ASC' );
				$ids                = implode( ',', array_map( 'absint', self::list_meta( $jsf_id, '_data_exclude_include' ) ) );
				$mode               = (string) $m( '_use_exclude_include' );
				if ( 'include' === $mode ) {
					$s['terms_include'] = $ids;
				} elseif ( 'exclude' === $mode ) {
					$s['terms_exclude'] = $ids;
				}
				if ( self::bool( $m( '_only_child', false ) ) ) {
					$warnings[] = __( '"Alleen kinderen van huidige term" wordt nog niet ondersteund; alle termen worden getoond.', 'm7-smart-filters' );
				}
				if ( self::bool( $m( '_is_custom_query_var', false ) ) ) {
					$warnings[] = __( 'Taxonomie als metaquery (custom query var) wordt niet ondersteund; er wordt op de taxonomie zelf gefilterd.', 'm7-smart-filters' );
				}
				break;
			case 'posts':
				$s['source']          = 'posts';
				$s['posts_post_type'] = (string) $m( '_source_post_type', 'post' );
				$s['meta_key']        = $qvar;
				break;
			case 'custom_fields':
				$s['source']   = 'meta';
				$field         = (string) $m( '_source_custom_field' );
				$s['meta_key'] = $qvar ? $qvar : $field;
				if ( $qvar && $field && $qvar !== $field ) {
					/* translators: 1: bronveld, 2: queryveld */
					$warnings[] = sprintf( __( 'Opties uit "%1$s", filteren op "%2$s": M7 gebruikt hetzelfde veld voor beide (%2$s).', 'm7-smart-filters' ), $field, $qvar );
				}
				if ( self::bool( $m( '_source_get_from_field_data', false ) ) ) {
					$warnings[] = __( 'Opties uit JetEngine/ACF-velddefinitie: controleer de opties na import.', 'm7-smart-filters' );
				}
				break;
			case 'cct':
				$warnings[] = __( 'JetEngine CCT-bron wordt niet ondersteund.', 'm7-smart-filters' );
				$s['source'] = 'manual';
				break;
			default:
				$s['source']         = 'manual';
				$s['meta_key']       = $qvar;
				$s['manual_options'] = array();
				foreach ( self::list_meta( $jsf_id, '_source_manual_input' ) as $o ) {
					if ( is_array( $o ) && isset( $o['value'] ) ) {
						$s['manual_options'][] = array(
							'value' => $o['value'],
							'label' => isset( $o['label'] ) ? $o['label'] : $o['value'],
						);
					}
				}
		}

		$compare_map       = array(
			'equal'   => 'IN',
			'less'    => '<=',
			'greater' => '>=',
			'like'    => 'LIKE',
		);
		$compare           = 'taxonomy' === $s['source'] ? 'equal' : (string) $m( '_query_compare', 'equal' );
		$s['meta_compare'] = isset( $compare_map[ $compare ] ) ? $compare_map[ $compare ] : 'IN';
		if ( ! isset( $compare_map[ $compare ] ) ) {
			/* translators: %s: vergelijking */
			$warnings[] = sprintf( __( 'Vergelijking "%s" wordt niet ondersteund; "is een van" gebruikt.', 'm7-smart-filters' ), $compare );
		}
		if ( self::bool( $m( '_is_custom_checkbox', false ) ) ) {
			$warnings[] = __( 'Geserialiseerde checkbox-velden (JetEngine/ACF) worden nog niet ondersteund.', 'm7-smart-filters' );
		}

		$s['placeholder']  = (string) $m( '_placeholder', $m( '_s_placeholder' ) );
		$s['active_label'] = (string) $m( '_active_label' );

		switch ( $s['type'] ) {
			case 'radio':
				$s['show_all_option'] = self::bool( $m( '_add_all_option', false ) );
				$s['all_label']       = (string) $m( '_all_option_label' );
				$s['can_deselect']    = self::bool( $m( '_ability_deselect_radio', false ) );
				break;
			case 'select':
				if ( self::bool( $m( '_is_hierarchical', false ) ) ) {
					// Keuzelijst per niveau (bijv. hoofdcategorie > subcategorie).
					$map = self::list_meta( $jsf_id, '_ih_source_map' );
					if ( $map && isset( $map[0]['tax'] ) ) {
						$s['source']           = 'taxonomy';
						$s['taxonomy']         = $map[0]['tax'];
						$s['hierarchy_levels'] = array();
						foreach ( $map as $lvl ) {
							if ( is_array( $lvl ) && ! empty( $lvl['tax'] ) ) {
								$s['hierarchy_levels'][] = array(
									'label'       => isset( $lvl['label'] ) ? (string) $lvl['label'] : '',
									'placeholder' => isset( $lvl['placeholder'] ) ? (string) $lvl['placeholder'] : '',
									'tax'         => (string) $lvl['tax'],
								);
							}
						}
						$s['hide_empty']    = ! self::bool( $m( '_show_empty_terms', false ) );
						$s['terms_orderby'] = (string) $m( '_ih_terms_orderby', 'name' );
						$s['terms_order']   = (string) $m( '_ih_terms_order', 'ASC' );
					}
				}
				break;
			case 'range':
				$s['range_inputs']            = self::bool( $m( '_range_inputs_enabled', false ) );
				$s['range_inputs_separators'] = $s['range_inputs'] && self::bool( $m( '_range_inputs_separators_enabled', false ) );
				$callback       = (string) $m( '_source_callback', 'none' );
				$s['meta_key']  = 'jet_smart_filters_woo_prices' === $callback ? '_price' : ( $qvar ? $qvar : '_price' );
				$s['range_min'] = 'none' === $callback ? $m( '_source_min', 0 ) : '';
				$s['range_max'] = 'none' === $callback ? $m( '_source_max', 100 ) : '';
				$s['range_step'] = str_replace( ',', '.', (string) $m( '_source_step', 1 ) );
				// Doorvallen naar getalweergave.
			case 'check_range':
				// Schuifje vult %woocommerce_currency_symbol% in, vaste bereiken tonen de tekst letterlijk (zoals JetSmartFilters).
				$s['range_prefix']       = 'range' === $s['type'] ? self::currency_macro( $m( '_values_prefix' ) ) : (string) $m( '_values_prefix' );
				$s['range_suffix']       = 'range' === $s['type'] ? self::currency_macro( $m( '_values_suffix' ) ) : (string) $m( '_values_suffix' );
				$s['range_decimals']     = (int) $m( '_values_decimal_num', 0 );
				$s['range_decimal_sep']  = (string) get_post_meta( $jsf_id, '_values_decimal_sep', true );
				$s['range_thousand_sep'] = (string) get_post_meta( $jsf_id, '_values_thousand_sep', true );
				if ( '' === $s['range_decimal_sep'] ) {
					$s['range_decimal_sep'] = '.';
				}
				if ( 'check_range' === $s['type'] ) {
					$s['meta_key']     = $qvar ? $qvar : '_price';
					$s['check_ranges'] = array();
					foreach ( self::list_meta( $jsf_id, '_source_manual_input_range' ) as $r ) {
						if ( is_array( $r ) ) {
							$s['check_ranges'][] = array(
								'min' => isset( $r['min'] ) && '' !== $r['min'] ? $r['min'] : 0,
								'max' => isset( $r['max'] ) && '' !== $r['max'] ? $r['max'] : 100,
							);
						}
					}
				}
				break;
			case 'search':
				$s['search_by'] = 'meta' === $m( '_s_by', 'default' ) && $qvar ? 'meta' : 'default';
				$s['meta_key']  = 'meta' === $s['search_by'] ? $qvar : '';
				break;
			case 'rating':
				$s['rating_max']     = (int) $m( '_rating_options', 5 );
				$s['rating_compare'] = (string) $m( '_rating_compare_operand', 'equal' );
				if ( $qvar && '_wc_average_rating' !== $qvar ) {
					/* translators: %s: metasleutel */
					$warnings[] = sprintf( __( 'Beoordeling op "%s": M7 filtert op de WooCommerce-beoordeling.', 'm7-smart-filters' ), $qvar );
				}
				break;
			case 'alphabet':
				$s['alphabet_letters']  = (string) $m( '_alphabet_options', 'A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z' );
				$s['alphabet_multiple'] = 'radio' !== (string) $m( '_alphabet_behavior', 'checkbox' );
				$s['can_deselect']      = ! $s['alphabet_multiple'] && self::bool( $m( '_alphabet_radio_deselect', true ) );
				break;
			case 'date_range':
			case 'date_period':
				$s['date_source'] = 'meta_query' === $m( '_date_source', 'date_query' ) ? 'meta' : 'post_date';
				$s['meta_key']    = 'meta' === $s['date_source'] ? $qvar : '';
				if ( 'meta' === $s['date_source'] ) {
					$warnings[] = __( 'Datum uit custom field: JetSmartFilters vergeleek Unix-tijd, M7 vergelijkt JJJJ-MM-DD. Controleer de resultaten.', 'm7-smart-filters' );
				}
				$s['date_format']           = (string) $m( '_date_format', 'mm/dd/yy' );
				$s['date_from_placeholder'] = (string) $m( '_date_from_placeholder' );
				$s['date_to_placeholder']   = (string) $m( '_date_to_placeholder' );
				$s['date_available_range']  = (string) $m( '_date_available_range', 'all' );
				$s['date_min']              = (string) $m( '_date_available_range_custom_min' );
				$s['date_max']              = (string) $m( '_date_available_range_custom_max' );
				if ( 'date_period' === $s['type'] ) {
					$s['date_period_type']         = (string) $m( '_date_period_type', 'day' );
					$s['date_period_button_text']  = (string) get_post_meta( $jsf_id, '_date_period_datepicker_button_text', true );
					$s['date_period_start_end']    = self::bool( $m( '_date_period_start_end_enabled', false ) );
					$s['date_period_format']       = (string) $m( '_date_period_format' );
					$s['date_period_start_format'] = (string) $m( '_date_period_start_format' );
					$s['date_period_separator']    = (string) $m( '_date_period_separator' );
					$s['date_period_end_format']   = (string) $m( '_date_period_end_format' );
				}
				break;
			case 'color_image':
				$s['multiple']         = 'checkbox' === $m( '_color_image_behavior', 'checkbox' );
				$s['color_image_type'] = (string) $m( '_color_image_type', '' );
				$s['can_deselect']     = ! $s['multiple'] && self::bool( $m( '_color_image_ability_deselect_radio', false ) );
				$s['show_all_option']  = ! $s['multiple'] && self::bool( $m( '_color_image_add_all_option', false ) );
				$s['all_label']        = (string) $m( '_color_image_add_all_option_lael', 'All' );
				$visual        = self::list_meta( $jsf_id, '_source_color_image_input' );
				if ( 'taxonomy' === $s['source'] ) {
					// Volgorde en keuze van de opties = volgorde van de rijen in JetSmartFilters.
					$order = array();
					foreach ( $visual as $o ) {
						if ( is_array( $o ) && ! empty( $o['selected_value'] ) ) {
							$order[] = absint( $o['selected_value'] );
						}
					}
					if ( $order ) {
						$s['terms_include'] = implode( ',', $order );
						$s['terms_orderby'] = 'include';
					}
					foreach ( $visual as $o ) {
						if ( is_array( $o ) && ! empty( $o['selected_value'] ) ) {
							$extra['terms'][ (int) $o['selected_value'] ] = array(
								'color' => isset( $o['source_color'] ) ? (string) $o['source_color'] : '',
								'image' => isset( $o['source_image'] ) ? absint( $o['source_image'] ) : 0,
							);
						}
					}
				} else {
					$s['manual_options'] = array();
					foreach ( $visual as $o ) {
						if ( is_array( $o ) && isset( $o['value'] ) ) {
							$s['manual_options'][] = array(
								'value' => $o['value'],
								'label' => isset( $o['label'] ) ? $o['label'] : $o['value'],
								'color' => isset( $o['source_color'] ) ? (string) $o['source_color'] : '',
								'image' => isset( $o['source_image'] ) ? absint( $o['source_image'] ) : 0,
							);
						}
					}
				}
				break;
		}

		if ( self::bool( $m( '_is_default_filter_value', false ) ) ) {
			$warnings[] = __( 'Vooraf ingestelde filterwaarde wordt nog niet ondersteund.', 'm7-smart-filters' );
		}

		$s['legacy_jsf_id'] = $jsf_id;
		return array( Filter_Post_Type::sanitize( $s ), $warnings, $extra );
	}

	/**
	 * Koppeling JetSmartFilters-ID → M7-ID van al geïmporteerde filters.
	 *
	 * @return array
	 */
	public static function id_map() {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT pm.post_id, pm.meta_value FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = %s AND p.post_status <> 'trash'", self::LEGACY_META ) );
		$map  = array();
		foreach ( $rows as $r ) {
			$map[ (int) $r->meta_value ] = (int) $r->post_id;
		}
		return $map;
	}

	private static function jsf_filters() {
		return get_posts(
			array(
				'post_type'      => self::JSF_POST_TYPE,
				'post_status'    => array( 'publish', 'draft', 'private' ),
				'posts_per_page' => -1,
				'orderby'        => 'ID',
				'order'          => 'ASC',
			)
		);
	}

	/* ------------------------------ Elementor ------------------------------ */

	/**
	 * Documenten met JetSmartFilters-widgets.
	 *
	 * @return int[]
	 */
	public static function documents() {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return array_map(
			'intval',
			$wpdb->get_col( $wpdb->prepare( "SELECT pm.post_id FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = '_elementor_data' AND pm.meta_value LIKE %s AND p.post_type <> 'revision' AND p.post_status <> 'trash' ORDER BY pm.post_id", '%' . $wpdb->esc_like( 'jet-smart-filters-' ) . '%' ) )
		);
	}

	private static function elementor_data( $post_id ) {
		$raw  = get_post_meta( $post_id, '_elementor_data', true );
		$data = is_array( $raw ) ? $raw : json_decode( (string) $raw, true );
		return is_array( $data ) ? $data : array();
	}

	/**
	 * Zet de elementen van een document om. Geeft [nieuwe data, rapport] terug.
	 *
	 * @param array $elements Elementen.
	 * @param array $map      JSF-ID => M7-ID.
	 * @param array $report   Rapport (by-ref).
	 * @return array
	 */
	public static function convert_elements( array $elements, array $map, array &$report ) {
		$out = array();
		foreach ( $elements as $el ) {
			if ( ! is_array( $el ) ) {
				$out[] = $el;
				continue;
			}
			if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
				$el['elements'] = self::convert_elements( $el['elements'], $map, $report );
			}
			$type = isset( $el['widgetType'] ) ? (string) $el['widgetType'] : '';
			if ( 'widget' !== ( isset( $el['elType'] ) ? $el['elType'] : '' ) || 0 !== strpos( $type, 'jet-smart-filters-' ) ) {
				$out[] = $el;
				continue;
			}
			foreach ( self::convert_widget( $el, $map, $report ) as $new ) {
				$out[] = $new;
			}
		}
		return $out;
	}

	/**
	 * Eén JetSmartFilters-widget omzetten naar het M7-widget van hetzelfde type. De M7-widgets hebben dezelfde
	 * instellingen (sleutels, standaarden, opmaakregels), dus alle instellingen gaan ongewijzigd mee;
	 * alleen de filter-ID's worden vervangen door die van de geïmporteerde M7-filters.
	 */
	private static function convert_widget( array $el, array $map, array &$report ) {
		$type = substr( $el['widgetType'], strlen( 'jet-smart-filters-' ) );
		$s    = isset( $el['settings'] ) && is_array( $el['settings'] ) ? $el['settings'] : array();

		if ( ! in_array( $type, Markup::WIDGET_TYPES, true ) ) {
			/* translators: %s: widgettype */
			$report['warnings'][] = sprintf( __( 'Widget "%s" niet omgezet (blijft staan, werkt niet meer zonder JetSmartFilters).', 'm7-smart-filters' ), $type );
			$report['skipped']++;
			return array( $el );
		}

		if ( isset( Markup::FILTER_TYPES[ $type ] ) ) {
			$raw = isset( $s['filter_id'] ) ? ( is_array( $s['filter_id'] ) ? $s['filter_id'] : array( $s['filter_id'] ) ) : array();
			$ids = array();
			foreach ( array_filter( array_map( 'absint', $raw ) ) as $jsf_id ) {
				if ( empty( $map[ $jsf_id ] ) ) {
					/* translators: %d: filter-ID */
					$report['warnings'][] = sprintf( __( 'Filter #%d is nog niet geïmporteerd; overgeslagen in dit widget.', 'm7-smart-filters' ), $jsf_id );
					continue;
				}
				$ids[] = (string) $map[ $jsf_id ];
			}
			if ( ! $ids ) {
				$report['skipped']++;
				return array( $el );
			}
			$s['filter_id'] = in_array( $type, Markup::SINGLE_TYPES, true ) ? $ids[0] : $ids;
		}

		$provider = isset( $s['content_provider'] ) ? (string) $s['content_provider'] : '';
		$qid      = isset( $s['query_id'] ) ? (string) $s['query_id'] : '';
		if ( ( '' === $qid || 'default' === $qid ) && ! in_array( $provider, Markup::ARCHIVE_PROVIDERS, true ) && in_array( $type, array( 'pagination', 'sorting' ), true ) === false ) {
			/* translators: %s: provider */
			$report['warnings'][] = sprintf( __( 'Widget zonder query-ID (provider "%s"): geef de lijst en het filter hetzelfde query-ID.', 'm7-smart-filters' ), $provider );
		}
		$report['converted']++;
		$el['widgetType'] = 'm7sf-' . $type;
		$el['settings']   = $s;
		return array( $el );
	}

	/**
	 * Eigen CSS van de site die JetSmartFilters-klassen gebruikt (bijv. ".jet-search-filter__input") omzetten naar de
	 * M7-klassen. De M7-opbouw is gelijk aan JetSmartFilters met "m7sf-" in plaats van "jet-", dus dezelfde regels
	 * blijven gelden. Alleen klassen van JetSmartFilters worden aangepast, niet die van andere Jet-plugins.
	 *
	 * @param string $css CSS.
	 * @return string
	 */
	public static function convert_css( $css ) {
		$css = (string) $css;
		if ( false === strpos( $css, 'jet-' ) ) {
			return $css;
		}
		$css = str_replace( 'elementor-widget-jet-smart-filters-', 'elementor-widget-m7sf-', $css );
		$roots = 'filter|smart-filter|checkboxes|radio|select|range|search-filter|sorting|rating|alphabet|color-image|date-range|date-period|active-filter|active-tag|apply-filters|remove-all-filters|filters-|list-tree|collapse|hidden-filter|check-range|tabindex';
		return (string) preg_replace( '/(?<![A-Za-z0-9_-])jet-(?=(?:' . $roots . '))/', 'm7sf-', $css );
	}

	/**
	 * Eigen CSS per element (Elementor Pro "Aangepaste CSS") omzetten, in alle elementen van een document.
	 *
	 * @param array $elements Elementen.
	 * @param int   $changed  Aantal aangepaste elementen (by-ref).
	 * @return array
	 */
	private static function convert_element_css( array $elements, &$changed ) {
		foreach ( $elements as $i => $el ) {
			if ( ! is_array( $el ) ) {
				continue;
			}
			if ( ! empty( $el['settings']['custom_css'] ) && is_string( $el['settings']['custom_css'] ) ) {
				$new = self::convert_css( $el['settings']['custom_css'] );
				if ( $new !== $el['settings']['custom_css'] ) {
					$elements[ $i ]['settings']['custom_css'] = $new;
					$changed++;
				}
			}
			if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
				$elements[ $i ]['elements'] = self::convert_element_css( $el['elements'], $changed );
			}
		}
		return $elements;
	}

	/**
	 * Pagina-CSS (Elementor-pagina-instellingen) van een document omzetten, met back-up.
	 *
	 * @param int $post_id Document.
	 * @return bool Aangepast.
	 */
	private static function convert_page_css( $post_id ) {
		$ps = get_post_meta( $post_id, '_elementor_page_settings', true );
		if ( ! is_array( $ps ) || empty( $ps['custom_css'] ) || ! is_string( $ps['custom_css'] ) ) {
			return false;
		}
		$new = self::convert_css( $ps['custom_css'] );
		if ( $new === $ps['custom_css'] ) {
			return false;
		}
		if ( '' === get_post_meta( $post_id, self::BACKUP_CSS_META, true ) ) {
			add_post_meta( $post_id, self::BACKUP_CSS_META, $ps['custom_css'], true );
		}
		$ps['custom_css'] = $new;
		update_post_meta( $post_id, '_elementor_page_settings', $ps );
		return true;
	}

	/**
	 * Sitebrede CSS omzetten: Elementor (Site-instellingen > Aangepaste CSS) en Extra CSS van het thema.
	 * De oorspronkelijke tekst blijft bewaard (terugzetten met revert --all).
	 *
	 * @return string[] Wat er is aangepast.
	 */
	public static function convert_site_css() {
		$done = array();
		$kit  = (int) get_option( 'elementor_active_kit' );
		if ( $kit && self::convert_page_css( $kit ) ) {
			self::clear_elementor_cache( $kit );
			$done[] = __( 'Elementor sitebrede CSS', 'm7-smart-filters' );
		}
		if ( function_exists( 'wp_get_custom_css_post' ) ) {
			$post = wp_get_custom_css_post();
			if ( $post && false !== strpos( $post->post_content, 'jet-' ) ) {
				$new = self::convert_css( $post->post_content );
				if ( $new !== $post->post_content ) {
					$backups = (array) get_option( self::BACKUP_CSS_OPTION, array() );
					if ( ! isset( $backups[ $post->ID ] ) ) {
						$backups[ $post->ID ] = $post->post_content;
						update_option( self::BACKUP_CSS_OPTION, $backups, false );
					}
					wp_update_custom_css_post( $new, array( 'stylesheet' => $post->post_name ) );
					$done[] = __( 'Extra CSS van het thema', 'm7-smart-filters' );
				}
			}
		}
		return $done;
	}

	/**
	 * Sitebrede CSS terugzetten.
	 *
	 * @return int Aantal teruggezet.
	 */
	public static function revert_site_css() {
		$n   = 0;
		$kit = (int) get_option( 'elementor_active_kit' );
		if ( $kit && self::revert_page_css( $kit ) ) {
			self::clear_elementor_cache( $kit );
			$n++;
		}
		$backups = (array) get_option( self::BACKUP_CSS_OPTION, array() );
		foreach ( $backups as $post_id => $css ) {
			$post = get_post( (int) $post_id );
			if ( $post && 'custom_css' === $post->post_type ) {
				wp_update_custom_css_post( $css, array( 'stylesheet' => $post->post_name ) );
				$n++;
			}
		}
		delete_option( self::BACKUP_CSS_OPTION );
		return $n;
	}

	private static function revert_page_css( $post_id ) {
		$css = get_post_meta( $post_id, self::BACKUP_CSS_META, true );
		if ( '' === $css ) {
			return false;
		}
		$ps               = get_post_meta( $post_id, '_elementor_page_settings', true );
		$ps               = is_array( $ps ) ? $ps : array();
		$ps['custom_css'] = $css;
		update_post_meta( $post_id, '_elementor_page_settings', $ps );
		delete_post_meta( $post_id, self::BACKUP_CSS_META );
		return true;
	}

	private static function clear_elementor_cache( $post_id ) {
		delete_post_meta( $post_id, '_elementor_css' );
		delete_post_meta( $post_id, '_elementor_element_cache' );
		if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
			\Elementor\Plugin::$instance->files_manager->clear_cache();
		}
	}

	/* ------------------------------ acties ------------------------------ */

	private static function guard( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Geen toegang.', 'm7-smart-filters' ) );
		}
		check_admin_referer( $action );
	}

	private static function back( $notice ) {
		set_transient( 'm7sf_migrate_notice_' . get_current_user_id(), $notice, 300 );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE ) );
		exit;
	}

	public static function handle_import() {
		self::guard( 'm7sf_jsf_import' );
		$update  = ! empty( $_POST['m7sf_update'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- guard() controleert de nonce.
		$created = self::import_filters( $update );
		/* translators: %d: aantal */
		$msg = sprintf( _n( '%d filter geïmporteerd.', '%d filters geïmporteerd.', $created, 'm7-smart-filters' ), $created );
		self::back( $update ? $msg . ' ' . __( 'Bestaande M7-filters zijn bijgewerkt met de instellingen uit JetSmartFilters.', 'm7-smart-filters' ) : $msg );
	}

	/**
	 * Importeert alle nog niet geïmporteerde JetSmartFilters-filters.
	 *
	 * @return int Aantal nieuwe filters.
	 */
	public static function import_filters( $update = false ) {
		$map     = self::id_map();
		$created = 0;
		foreach ( self::jsf_filters() as $p ) {
			if ( isset( $map[ $p->ID ] ) && ! $update ) {
				continue;
			}
			list( $settings, , $extra ) = self::map_filter( $p->ID );
			if ( isset( $map[ $p->ID ] ) ) {
				$id = (int) $map[ $p->ID ]; // Opnieuw overnemen: instellingen bijwerken, ID blijft gelijk.
			} else {
				$id = wp_insert_post(
					array(
						'post_type'   => Filter_Post_Type::POST_TYPE,
						'post_status' => 'publish' === $p->post_status ? 'publish' : 'draft',
						'post_title'  => $p->post_title,
					)
				);
			}
			if ( ! $id || is_wp_error( $id ) ) {
				continue;
			}
			update_post_meta( $id, Filter_Post_Type::META, $settings );
			update_post_meta( $id, self::LEGACY_META, $p->ID );
			foreach ( $extra['terms'] as $term_id => $visual ) {
				if ( $visual['color'] ) {
					update_term_meta( $term_id, 'm7sf_color', sanitize_text_field( $visual['color'] ) );
				}
				if ( $visual['image'] ) {
					update_term_meta( $term_id, 'm7sf_image', $visual['image'] );
				}
			}
			$created++;
		}
		Filter_Post_Type::rebuild_allowed_keys();
		Sources::flush();
		if ( self::jsf_filters() ) {
			Settings::adopt_jsf_behaviour();
		}
		return $created;
	}

	public static function handle_convert() {
		self::guard( 'm7sf_jsf_convert' );
		list( $done, $notes ) = self::convert_documents( isset( $_POST['document'] ) ? absint( $_POST['document'] ) : 0 );
		/* translators: %d: aantal */
		self::back( sprintf( _n( '%d pagina/sjabloon omgezet.', '%d pagina\'s/sjablonen omgezet.', $done, 'm7-smart-filters' ), $done ) . ( $notes ? ' ' . implode( ' | ', $notes ) : '' ) );
	}

	/**
	 * Zet JetSmartFilters-widgets om in één of alle documenten (met back-up).
	 *
	 * @param int $only Document-ID of 0 voor alle.
	 * @return array [aantal omgezet, notities]
	 */
	public static function convert_documents( $only = 0 ) {
		$map   = self::id_map();
		$done  = 0;
		$notes = array();
		foreach ( $only ? array( $only ) : self::documents() as $doc ) {
			$data = self::elementor_data( $doc );
			if ( ! $data ) {
				continue;
			}
			$report  = array( 'converted' => 0, 'skipped' => 0, 'warnings' => array() );
			$new     = self::convert_elements( $data, $map, $report );
			$css     = 0;
			$new     = self::convert_element_css( $new, $css );
			$page    = self::convert_page_css( $doc );
			if ( ! $report['converted'] && ! $css ) {
				if ( $page ) {
					self::clear_elementor_cache( $doc );
				}
				continue;
			}
			if ( '' === get_post_meta( $doc, self::BACKUP_META, true ) ) {
				add_post_meta( $doc, self::BACKUP_META, wp_slash( get_post_meta( $doc, '_elementor_data', true ) ), true );
			}
			update_post_meta( $doc, '_elementor_data', wp_slash( wp_json_encode( $new ) ) );
			self::clear_elementor_cache( $doc );
			$done++;
			if ( $report['warnings'] ) {
				$notes[] = get_the_title( $doc ) . ' (#' . $doc . '): ' . implode( ' ', array_unique( $report['warnings'] ) );
			}
		}
		if ( ! $only ) {
			$site = self::convert_site_css();
			if ( $site ) {
				/* translators: %s: onderdelen */
				$notes[] = sprintf( __( 'CSS met JetSmartFilters-klassen omgezet: %s.', 'm7-smart-filters' ), implode( ', ', $site ) );
			}
		}
		return array( $done, $notes );
	}

	public static function handle_revert() {
		self::guard( 'm7sf_jsf_revert' );
		$doc = isset( $_POST['document'] ) ? absint( $_POST['document'] ) : 0;
		if ( ! self::revert_document( $doc ) ) {
			self::back( __( 'Geen back-up gevonden.', 'm7-smart-filters' ) );
		}
		/* translators: %s: titel */
		self::back( sprintf( __( '"%s" teruggezet naar JetSmartFilters-widgets.', 'm7-smart-filters' ), get_the_title( $doc ) ) );
	}

	/**
	 * Zet de back-up van één document terug.
	 *
	 * @param int $doc Document-ID.
	 * @return bool
	 */
	public static function revert_document( $doc ) {
		$backup = $doc ? get_post_meta( $doc, self::BACKUP_META, true ) : '';
		if ( '' === $backup ) {
			return false;
		}
		update_post_meta( $doc, '_elementor_data', wp_slash( $backup ) );
		delete_post_meta( $doc, self::BACKUP_META );
		self::revert_page_css( $doc );
		self::clear_elementor_cache( $doc );
		return true;
	}

	/**
	 * Documenten met een back-up (al omgezet).
	 *
	 * @return int[]
	 */
	public static function converted_documents() {
		global $wpdb;
		// Direct op meta: post_type "any" slaat Elementor-sjablonen (elementor_library) over.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return array_map( 'intval', $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s", self::BACKUP_META ) ) );
	}

	/* ------------------------------ scherm ------------------------------ */

	public static function page() {
		$notice = get_transient( 'm7sf_migrate_notice_' . get_current_user_id() );
		if ( $notice ) {
			delete_transient( 'm7sf_migrate_notice_' . get_current_user_id() );
		}
		$filters = self::jsf_filters();
		$map     = self::id_map();
		$active  = class_exists( 'Jet_Smart_Filters' );
		?>
		<div class="wrap m7-admin">
			<h1 class="screen-reader-text"><?php esc_html_e( 'Smart Filters: overstappen van JetSmartFilters', 'm7-smart-filters' ); ?></h1>
			<?php if ( $notice ) : ?>
				<div class="notice notice-success"><p><?php echo esc_html( $notice ); ?></p></div>
			<?php endif; ?>
			<p><?php esc_html_e( 'Werkwijze: 1) filters importeren, 2) pagina\'s omzetten en controleren, 3) JetSmartFilters deactiveren. Oude filterlinks (?jsf=…) worden daarna automatisch doorgestuurd.', 'm7-smart-filters' ); ?></p>
			<?php if ( $active ) : ?>
				<p><em><?php esc_html_e( 'JetSmartFilters is nog actief. Dat is goed tijdens het overstappen; deactiveer het pas als alles werkt.', 'm7-smart-filters' ); ?></em></p>
			<?php endif; ?>

			<h2><?php esc_html_e( '1. Filters', 'm7-smart-filters' ); ?></h2>
			<?php if ( ! $filters ) : ?>
				<p><?php esc_html_e( 'Geen JetSmartFilters-filters gevonden.', 'm7-smart-filters' ); ?></p>
			<?php else : ?>
				<table class="widefat striped">
					<thead><tr><th>ID</th><th><?php esc_html_e( 'Filter', 'm7-smart-filters' ); ?></th><th><?php esc_html_e( 'Wordt', 'm7-smart-filters' ); ?></th><th><?php esc_html_e( 'Let op', 'm7-smart-filters' ); ?></th><th><?php esc_html_e( 'Status', 'm7-smart-filters' ); ?></th></tr></thead>
					<tbody>
					<?php
					foreach ( $filters as $p ) :
						list( $s, $warnings ) = self::map_filter( $p->ID );
						?>
						<tr>
							<td><?php echo (int) $p->ID; ?></td>
							<td><?php echo esc_html( $p->post_title ); ?></td>
							<td><?php echo esc_html( Filter_Post_Type::TYPES[ $s['type'] ] ); ?> · <code><?php echo esc_html( Filter_Post_Type::param_for( $s ) ); ?></code></td>
							<td><?php echo $warnings ? esc_html( implode( ' ', $warnings ) ) : '—'; ?></td>
							<td><?php echo isset( $map[ $p->ID ] ) ? '<a href="' . esc_url( get_edit_post_link( $map[ $p->ID ] ) ) . '">' . esc_html__( 'Geïmporteerd', 'm7-smart-filters' ) . ' (#' . (int) $map[ $p->ID ] . ')</a>' : esc_html__( 'Nog niet', 'm7-smart-filters' ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:12px">
					<?php wp_nonce_field( 'm7sf_jsf_import' ); ?>
					<input type="hidden" name="action" value="m7sf_jsf_import">
					<?php submit_button( __( 'Filters importeren', 'm7-smart-filters' ), 'primary', 'submit', false ); ?>
					<label style="margin-left:12px"><input type="checkbox" name="m7sf_update" value="1"> <?php esc_html_e( 'Al geïmporteerde filters opnieuw overnemen (eigen wijzigingen in M7 gaan dan verloren)', 'm7-smart-filters' ); ?></label>
				</form>
			<?php endif; ?>

			<h2><?php esc_html_e( '2. Elementor-pagina\'s en -sjablonen', 'm7-smart-filters' ); ?></h2>
			<?php
			$docs = self::documents();
			$with_backup = self::converted_documents();
			$all_docs = array_values( array_unique( array_merge( $docs, $with_backup ) ) );
			if ( ! $all_docs ) :
				?>
				<p><?php esc_html_e( 'Geen pagina\'s met JetSmartFilters-widgets gevonden.', 'm7-smart-filters' ); ?></p>
			<?php else : ?>
				<table class="widefat striped">
					<thead><tr><th><?php esc_html_e( 'Pagina/sjabloon', 'm7-smart-filters' ); ?></th><th><?php esc_html_e( 'JetSmartFilters-widgets', 'm7-smart-filters' ); ?></th><th><?php esc_html_e( 'Actie', 'm7-smart-filters' ); ?></th></tr></thead>
					<tbody>
					<?php
					foreach ( $all_docs as $doc ) :
						$raw    = (string) get_post_meta( $doc, '_elementor_data', true );
						$count  = preg_match_all( '/"widgetType":"jet-smart-filters-([a-z\-]+)"/', $raw, $mm );
						$counts = array();
						foreach ( $count ? array_count_values( $mm[1] ) : array() as $wtype => $n ) {
							$counts[] = $wtype . ' ×' . $n;
						}
						?>
						<tr>
							<td><a href="<?php echo esc_url( get_edit_post_link( $doc ) ); ?>"><?php echo esc_html( get_the_title( $doc ) ); ?></a> <span class="description">(#<?php echo (int) $doc; ?>, <?php echo esc_html( get_post_type( $doc ) ); ?>)</span></td>
							<td><?php echo $counts ? esc_html( implode( ', ', $counts ) ) : esc_html__( '— (omgezet)', 'm7-smart-filters' ); ?></td>
							<td>
								<?php if ( $count ) : ?>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
										<?php wp_nonce_field( 'm7sf_jsf_convert' ); ?>
										<input type="hidden" name="action" value="m7sf_jsf_convert"><input type="hidden" name="document" value="<?php echo (int) $doc; ?>">
										<button class="button"><?php esc_html_e( 'Omzetten', 'm7-smart-filters' ); ?></button>
									</form>
								<?php endif; ?>
								<?php if ( '' !== get_post_meta( $doc, self::BACKUP_META, true ) ) : ?>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
										<?php wp_nonce_field( 'm7sf_jsf_revert' ); ?>
										<input type="hidden" name="action" value="m7sf_jsf_revert"><input type="hidden" name="document" value="<?php echo (int) $doc; ?>">
										<button class="button"><?php esc_html_e( 'Terugzetten', 'm7-smart-filters' ); ?></button>
									</form>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:12px">
					<?php wp_nonce_field( 'm7sf_jsf_convert' ); ?>
					<input type="hidden" name="action" value="m7sf_jsf_convert">
					<?php submit_button( __( 'Alles omzetten', 'm7-smart-filters' ), 'primary', 'submit', false ); ?>
					<span class="description"><?php esc_html_e( 'Van elke pagina wordt eerst een back-up van de opbouw bewaard.', 'm7-smart-filters' ); ?></span>
				</form>
			<?php endif; ?>
		</div>
		<?php
	}
}
