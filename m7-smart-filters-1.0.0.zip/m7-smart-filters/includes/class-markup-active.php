<?php
/**
 * Actieve filters, actieve tags en paginering in de opbouw van JetSmartFilters 3.7.0.
 * JetSmartFilters bouwt deze met JavaScript; M7 levert dezelfde HTML direct vanaf de server
 * (en ververst ze na elke filterwijziging), zodat er geen verspringing is.
 *
 * @package M7SF
 */

namespace M7SF;

defined( 'ABSPATH' ) || exit;

final class Markup_Active {

	/**
	 * @param string $type     active | active-tags.
	 * @param array  $set      Widgetinstellingen.
	 * @param string $query_id Query-ID.
	 * @return string
	 */
	public static function render( $type, array $set, $query_id ) {
		$tags  = 'active-tags' === $type;
		$base  = $tags ? 'active-tags' : 'active-filters';
		$item  = $tags ? 'active-tag' : 'active-filter';
		$label = $tags ? ( isset( $set['tags_label'] ) ? (string) $set['tags_label'] : '' ) : ( isset( $set['filters_label'] ) ? (string) $set['filters_label'] : '' );
		$clear = '';
		if ( $tags && Markup::yes( $set, 'clear_item' ) ) {
			$clear = isset( $set['clear_item_label'] ) ? (string) $set['clear_item_label'] : '';
		}
		$entries = self::entries( $query_id, $tags );
		if ( self::editing() ) {
			// Voorbeeld in de Elementor-editor (zoals JetSmartFilters).
			$entries = array(
				array( 'param' => '', 'value' => '', 'label' => __( 'Categories', 'm7-smart-filters' ), 'text' => __( 'Active Category', 'm7-smart-filters' ) ),
				array( 'param' => '', 'value' => '', 'label' => __( 'Tags', 'm7-smart-filters' ), 'text' => __( 'Active Tag', 'm7-smart-filters' ) ),
			);
		}
		$apply   = isset( $set['apply_type'] ) && in_array( $set['apply_type'], array( 'ajax', 'reload', 'mixed' ), true ) ? $set['apply_type'] : 'ajax';
		$attrs   = array(
			'class'             => 'm7sf-filter-' . $type . ' m7sf-' . $base . ' m7sf-filter',
			'data-label'        => $label,
			'data-m7sf-for'     => $query_id,
			'data-m7sf-refresh' => 'active',
			'data-m7sf-apply'   => $apply,
			'data-m7sf-empty'   => $entries ? null : '1',
		);
		$inner = '';
		if ( $entries ) {
			$inner .= '<div class="m7sf-' . $base . '__list">';
			if ( '' !== $label ) {
				$inner .= '<div class="m7sf-' . $base . '__title">' . wp_kses_post( $label ) . '</div>';
			}
			if ( '' !== $clear ) {
				$inner .= '<div class="m7sf-' . $item . ' m7sf-' . $item . '--clear" data-m7sf-clear><div class="m7sf-' . $item . '__val">' . esc_html( $clear ) . '</div><div class="m7sf-' . $item . '__remove">&times;</div></div>';
			}
			foreach ( $entries as $e ) {
				$inner .= '<div class="m7sf-' . $item . '"' . Markup::tab() . ' data-m7sf-remove-param="' . esc_attr( $e['param'] ) . '" data-m7sf-remove-value="' . esc_attr( $e['value'] ) . '">';
				if ( '' !== $e['label'] ) {
					$inner .= '<div class="m7sf-' . $item . '__label">' . wp_kses_post( $e['label'] ) . '<span class="m7sf-' . $item . '__label-separator">:</span></div>';
				}
				$inner .= '<div class="m7sf-' . $item . '__val">' . esc_html( $e['text'] ) . '</div><div class="m7sf-' . $item . '__remove">&times;</div></div>';
			}
			$inner .= '</div>';
		}
		return '<div' . Markup::attrs( $attrs ) . '>' . $inner . '</div>';
	}

	/**
	 * Actieve waarden. Actieve filters: één regel per filter (waarden met ", "). Tags: één tag per waarde.
	 *
	 * @param string $query_id Query-ID.
	 * @param bool   $separate Eén regel per waarde.
	 * @return array
	 */
	public static function entries( $query_id, $separate ) {
		$out    = array();
		$groups = array();
		$items  = Render::active_items( $query_id );
		// Volgorde van de filters op de pagina (voor zover al getoond); het script corrigeert de rest.
		$order = array_flip( Markup::$rendered );
		foreach ( $items as $i => $it ) {
			$items[ $i ]['_pos'] = $i; // Stabiel sorteren (ook op PHP 7).
		}
		usort(
			$items,
			static function ( $a, $b ) use ( $order ) {
				$ra = isset( $order[ $a['param'] ] ) ? $order[ $a['param'] ] : PHP_INT_MAX;
				$rb = isset( $order[ $b['param'] ] ) ? $order[ $b['param'] ] : PHP_INT_MAX;
				if ( $ra === $rb ) {
					return $a['_pos'] - $b['_pos'];
				}
				return $ra < $rb ? -1 : 1;
			}
		);
		foreach ( $items as $it ) {
			$filter = isset( $it['filter'] ) ? $it['filter'] : null;
			$label  = $filter && isset( $filter['active_label'] ) ? (string) $filter['active_label'] : '';
			if ( $separate ) {
				$out[] = array(
					'param' => $it['param'],
					'value' => $it['value'],
					'label' => $label,
					'text'  => $it['value_label'],
				);
				continue;
			}
			if ( ! isset( $groups[ $it['param'] ] ) ) {
				$groups[ $it['param'] ] = array(
					'param' => $it['param'],
					'value' => '',
					'label' => $label,
					'texts' => array(),
				);
			}
			$groups[ $it['param'] ]['texts'][] = $it['value_label'];
		}
		foreach ( $groups as $g ) {
			$g['text'] = implode( ', ', $g['texts'] );
			unset( $g['texts'] );
			$out[] = $g;
		}
		return $out;
	}

	/**
	 * Paginering: lege houder met de instellingen; het script bouwt de pagina's uit de gegevens van de lijst
	 * (zoals JetSmartFilters).
	 *
	 * @param array  $set      Instellingen.
	 * @param string $query_id Query-ID.
	 * @return string
	 */
	public static function editing() {
		return defined( 'ELEMENTOR_VERSION' ) && class_exists( '\\Elementor\\Plugin' ) && \Elementor\Plugin::$instance->editor && \Elementor\Plugin::$instance->editor->is_edit_mode();
	}

	public static function pagination( array $set, $query_id ) {
		$controls = array( 'items_enabled' => Markup::yes( $set, 'enable_items' ) );
		if ( $controls['items_enabled'] ) {
			$controls['pages_mid_size'] = absint( isset( $set['pages_center_offset'] ) ? $set['pages_center_offset'] : 0 );
			$controls['pages_end_size'] = absint( isset( $set['pages_end_offset'] ) ? $set['pages_end_offset'] : 0 );
		}
		$controls['nav_enabled'] = Markup::yes( $set, 'enable_prev_next' );
		if ( $controls['nav_enabled'] ) {
			$controls['prev']              = isset( $set['prev_text'] ) ? (string) $set['prev_text'] : '';
			$controls['next']              = isset( $set['next_text'] ) ? (string) $set['next_text'] : '';
			$controls['hide_inactive_nav'] = Markup::yes( $set, 'hide_inactive_prev_next' );
		}
		$controls['load_more_enabled'] = Markup::yes( $set, 'enable_load_more' );
		if ( $controls['load_more_enabled'] ) {
			$controls['load_more_text'] = isset( $set['load_more_text'] ) ? (string) $set['load_more_text'] : '';
		}
		if ( Markup::yes( $set, 'autoscroll' ) ) {
			$controls['provider_top_offset'] = absint( isset( $set['provider_top_offset'] ) ? $set['provider_top_offset'] : 0 );
		}
		$apply = isset( $set['apply_type'] ) && in_array( $set['apply_type'], array( 'ajax', 'reload', 'mixed' ), true ) ? $set['apply_type'] : 'ajax';
		return '<div' . Markup::attrs(
			array(
				'class'           => 'm7sf-filter-pagination m7sf-filter',
				'data-m7sf-for'   => $query_id,
				'data-m7sf-apply' => $apply,
				'data-m7sf-pagination' => wp_json_encode( $controls ),
				'data-m7sf-sample'     => self::editing() ? '1' : null,
			)
		) . '></div>';
	}
}
