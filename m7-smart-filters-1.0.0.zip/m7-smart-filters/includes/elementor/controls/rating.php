<?php
/**
 * Elementor-instellingen van het M7-widget "rating": zelfde sleutels, standaarden, selectors en
 * volgorde als JetSmartFilters 3.7.0 (gegenereerd door tools/jsf-controls/build.py, niet met de hand wijzigen).
 *
 * @package M7SF
 */

defined( 'ABSPATH' ) || exit;

return array(
	array(
		'section',
		'section_general',
		array(
			'label' => 'Inhoud',
		),
	),
	array(
		'control',
		'filter_id',
		array(
			'label' => 'Kies filter',
			'label_block' => true,
			'type' => 'jet-query',
			'multiple' => false,
			'default' => '',
			'query_type' => 'post',
			'query' => array(
				'post_type' => 'jet-smart-filters',
				'posts_per_page' => -1,
				'meta_query' => array(
					array(
						'key' => '_filter_type',
						'value' => 'rating',
						'compare' => '=',
					),
				),
			),
		),
		array(),
	),
	array(
		'control',
		'content_provider',
		array(
			'label' => 'Dit filter is voor',
			'type' => 'select',
			'default' => '',
			'options' => array(
				'' => 'Kies…',
				'epro-archive-products' => 'Elementor Pro Archive Products',
				'epro-archive' => 'Elementor Pro Archive',
				'epro-loop-builder' => 'Elementor Pro Loop Grid',
				'epro-portfolio' => 'Elementor Pro Portfolio',
				'epro-posts' => 'Elementor Pro Posts',
				'epro-products' => 'Elementor Pro Products',
				'jet-engine-calendar' => 'JetEngine Calendar',
				'jet-engine' => 'JetEngine',
				'jet-woo-products-grid' => 'JetWooBuilder Products Grid',
				'jet-woo-products-list' => 'JetWooBuilder Products List',
				'jsf-listing' => 'JSF Listing',
				'woocommerce-archive' => 'WooCommerce Archive (by JetWooBuilder)',
				'default-woo-archive' => 'Default WooCommerce Archive (Classic)',
				'woocommerce-shortcode' => 'WooCommerce Shortcode',
			),
		),
		array(),
	),
	array(
		'control',
		'epro_posts_notice',
		array(
			'type' => 'raw_html',
			'raw' => 'M7: geef de lijst (Loop Grid / Posts / Products) en dit filter hetzelfde Query-ID.',
			'condition' => array(
				'content_provider' => array(
					'epro-posts',
					'epro-portfolio',
				),
			),
		),
		array(),
	),
	array(
		'control',
		'apply_type',
		array(
			'label' => 'Manier van toepassen',
			'type' => 'select',
			'default' => 'ajax',
			'options' => array(
				'ajax' => 'AJAX',
				'reload' => 'Pagina herladen',
				'mixed' => 'Gemengd',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_on',
		array(
			'label' => 'Toepassen bij',
			'type' => 'select',
			'default' => 'value',
			'options' => array(
				'value' => 'Elke wijziging',
				'submit' => 'Klik op toepassen-knop',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_button',
		array(
			'label' => 'Toepassen-knop tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
			'condition' => array(
				'apply_on' => 'submit',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_button_text',
		array(
			'label' => 'Tekst toepassen-knop',
			'type' => 'text',
			'default' => 'Apply filter',
			'condition' => array(
				'apply_on' => 'submit',
				'apply_button' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'show_label',
		array(
			'label' => 'Filterlabel tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
		),
		array(),
	),
	array(
		'control',
		'rating_icon',
		array(
			'label' => 'Icoon beoordeling',
			'label_block' => true,
			'type' => 'icon',
			'default' => 'fa fa-star',
		),
		array(),
	),
	array(
		'control',
		'query_id',
		array(
			'label' => 'Query-ID',
			'type' => 'text',
			'label_block' => true,
			'description' => 'Set unique query ID if you use multiple widgets of same provider on the page. Same ID you need to set for filtered widget.',
		),
		array(),
	),
	array(
		'control',
		'additional_providers_enabled',
		array(
			'label' => 'Extra lijsten',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => 'no',
		),
		array(),
	),
	array(
		'control',
		'additional_providers_list',
		array(
			'label' => 'Lijst met extra lijsten',
			'type' => 'repeater',
			'fields' => array(
				'_id' => array(
					'type' => 'hidden',
					'tab' => 'content',
					'name' => '_id',
					'default' => '',
				),
				'additional_provider' => array(
					'type' => 'select',
					'tab' => 'content',
					'default' => '',
					'name' => 'additional_provider',
				),
				'additional_query_id' => array(
					'type' => 'text',
					'tab' => 'content',
					'name' => 'additional_query_id',
					'default' => '',
				),
			),
			'title_field' => '{{ additional_provider + ( additional_query_id ? "/" + additional_query_id : "" ) }}',
			'condition' => array(
				'additional_providers_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_stars_style',
		array(
			'label' => 'Sterren',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'stars_size',
		array(
			'label' => 'Grootte',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 1,
					'max' => 50,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-rating-star__icon' => 'font-size: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'stars_gutter',
		array(
			'label' => 'Tussenruimte',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 50,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-rating-star__icon' => 'margin-left: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'stars_color',
		array(
			'label' => 'Standaardkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-rating-star__label' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'stars_selected_color',
		array(
			'label' => 'Kleur gekozen',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-rating input.is-checked ~ label' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-rating input.is-checked ~ label ~ label' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'stars_selected_hover_color',
		array(
			'label' => 'Kleur gekozen bij hover',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-rating input:not(.is-checked) ~ label:hover' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-rating input:not(.is-checked) ~ label:hover ~ label' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'responsive',
		'stars_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-rating-stars' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'stars_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-rating__control' => 'text-align: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_label_style',
		array(
			'label' => 'Label',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'label_typography',
			'selector' => '{{WRAPPER}} .m7sf-filter-label',
		),
		array(),
	),
	array(
		'control',
		'label_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'label_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-filter-label',
		),
		array(),
	),
	array(
		'responsive',
		'label_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'label_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'label_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'separator' => 'before',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'text-align: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_filter_apply_button_style',
		array(
			'label' => 'Knop',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'filter_apply_button_typography',
			'global' => array(
				'default' => 'globals/typography?id=primary',
			),
			'selector' => '{{WRAPPER}} .m7sf-apply-filters__button',
		),
		array(),
	),
	array(
		'tabs',
		'filter_apply_button_style_tabs',
		array(),
	),
	array(
		'tab',
		'filter_apply_button_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'filter_apply_button_normal_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'filter_apply_button_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'filter_apply_button_hover_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button:hover' => 'border-color: {{VALUE}}',
			),
			'condition' => array(
				'filter_apply_button_border_border!' => '',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'filter_apply_button_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-apply-filters__button',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'filter_apply_button_shadow',
			'selector' => '{{WRAPPER}} .m7sf-apply-filters__button',
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'flex-start' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'flex-end' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
				'stretch' => array(
					'title' => 'Uitrekken',
					'icon' => 'eicon-text-align-justify',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'align-self: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
);
