<?php
/**
 * Elementor-instellingen van het M7-widget "sorting": zelfde sleutels, standaarden, selectors en
 * volgorde als JetSmartFilters 3.7.0 (gegenereerd door tools/jsf-controls/build.py, niet met de hand wijzigen).
 *
 * @package M7SF
 */

defined( 'ABSPATH' ) || exit;

return array(
	array(
		'section',
		'section_general',
		array(
			'label' => 'Inhoud',
		),
	),
	array(
		'control',
		'content_provider',
		array(
			'label' => 'Dit filter is voor',
			'type' => 'select',
			'default' => '',
			'options' => array(
				'' => 'Kies…',
				'epro-archive-products' => 'Elementor Pro Archive Products',
				'epro-archive' => 'Elementor Pro Archive',
				'epro-loop-builder' => 'Elementor Pro Loop Grid',
				'epro-portfolio' => 'Elementor Pro Portfolio',
				'epro-posts' => 'Elementor Pro Posts',
				'epro-products' => 'Elementor Pro Products',
				'jet-engine-calendar' => 'JetEngine Calendar',
				'jet-engine' => 'JetEngine',
				'jet-woo-products-grid' => 'JetWooBuilder Products Grid',
				'jet-woo-products-list' => 'JetWooBuilder Products List',
				'jsf-listing' => 'JSF Listing',
				'woocommerce-archive' => 'WooCommerce Archive (by JetWooBuilder)',
				'default-woo-archive' => 'Default WooCommerce Archive (Classic)',
				'woocommerce-shortcode' => 'WooCommerce Shortcode',
			),
		),
		array(),
	),
	array(
		'control',
		'epro_posts_notice',
		array(
			'type' => 'raw_html',
			'raw' => 'M7: geef de lijst (Loop Grid / Posts / Products) en dit filter hetzelfde Query-ID.',
			'condition' => array(
				'content_provider' => array(
					'epro-posts',
					'epro-portfolio',
				),
			),
		),
		array(),
	),
	array(
		'control',
		'apply_type',
		array(
			'label' => 'Manier van toepassen',
			'type' => 'select',
			'default' => 'ajax',
			'options' => array(
				'ajax' => 'AJAX',
				'reload' => 'Pagina herladen',
				'mixed' => 'Gemengd',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_on',
		array(
			'label' => 'Toepassen bij',
			'type' => 'select',
			'default' => 'value',
			'options' => array(
				'value' => 'Elke wijziging',
				'submit' => 'Klik op toepassen-knop',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_button',
		array(
			'label' => 'Toepassen-knop tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
			'condition' => array(
				'apply_on' => 'submit',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_button_text',
		array(
			'label' => 'Tekst toepassen-knop',
			'type' => 'text',
			'default' => 'Apply filter',
			'condition' => array(
				'apply_on' => 'submit',
				'apply_button' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'label',
		array(
			'label' => 'Label',
			'type' => 'text',
			'default' => '',
		),
		array(),
	),
	array(
		'control',
		'label_block',
		array(
			'label' => 'Label boven veld',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => 'yes',
			'condition' => array(
				'label!' => '',
			),
		),
		array(),
	),
	array(
		'control',
		'placeholder',
		array(
			'label' => 'Placeholder',
			'type' => 'text',
			'placeholder' => 'Sort...',
			'default' => 'Sort...',
		),
		array(),
	),
	array(
		'control',
		'query_id',
		array(
			'label' => 'Query-ID',
			'type' => 'text',
			'label_block' => true,
			'description' => 'Set unique query ID if you use multiple widgets of same provider on the page. Same ID you need to set for filtered widget.',
		),
		array(),
	),
	array(
		'control',
		'additional_providers_enabled',
		array(
			'label' => 'Extra lijsten',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => 'no',
		),
		array(),
	),
	array(
		'control',
		'additional_providers_list',
		array(
			'label' => 'Lijst met extra lijsten',
			'type' => 'repeater',
			'fields' => array(
				'_id' => array(
					'type' => 'hidden',
					'tab' => 'content',
					'name' => '_id',
					'default' => '',
				),
				'additional_provider' => array(
					'type' => 'select',
					'tab' => 'content',
					'default' => '',
					'name' => 'additional_provider',
				),
				'additional_query_id' => array(
					'type' => 'text',
					'tab' => 'content',
					'name' => 'additional_query_id',
					'default' => '',
				),
			),
			'title_field' => '{{ additional_provider + ( additional_query_id ? "/" + additional_query_id : "" ) }}',
			'condition' => array(
				'additional_providers_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_sorting_list',
		array(
			'label' => 'Sorteeropties',
		),
	),
	array(
		'control',
		'sorting_list',
		array(
			'label' => 'Sorteeropties',
			'type' => 'repeater',
			'fields' => array(
				'_id' => array(
					'type' => 'hidden',
					'tab' => 'content',
					'name' => '_id',
					'default' => '',
				),
				'title' => array(
					'type' => 'text',
					'tab' => 'content',
					'default' => '',
					'name' => 'title',
				),
				'orderby' => array(
					'type' => 'select',
					'tab' => 'content',
					'default' => 'none',
					'name' => 'orderby',
				),
				'meta_key' => array(
					'type' => 'text',
					'tab' => 'content',
					'default' => '',
					'condition' => array(
						'orderby' => array(
							'meta_value',
							'meta_value_num',
							'clause_value',
						),
					),
					'name' => 'meta_key',
				),
				'order' => array(
					'type' => 'select',
					'tab' => 'content',
					'default' => 'ASC',
					'condition' => array(
						'orderby!' => array(
							'none',
							'rand',
						),
					),
					'name' => 'order',
				),
			),
			'default' => array(
				array(
					'title' => 'By title from lowest to highest',
					'orderby' => 'title',
					'order' => 'ASC',
				),
				array(
					'title' => 'By title from highest to lowest',
					'orderby' => 'title',
					'order' => 'DESC',
				),
				array(
					'title' => 'By date from lowest to highest',
					'orderby' => 'date',
					'order' => 'ASC',
				),
				array(
					'title' => 'By date from highest to lowest',
					'orderby' => 'date',
					'order' => 'DESC',
				),
			),
			'title_field' => '{{{ title }}}',
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_content_style',
		array(
			'label' => 'Inhoud',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'select_width',
		array(
			'label' => 'Breedte keuzelijst',
			'type' => 'slider',
			'size_units' => array(
				'%',
				'px',
			),
			'range' => array(
				'%' => array(
					'min' => 10,
					'max' => 100,
				),
				'px' => array(
					'min' => 50,
					'max' => 400,
				),
			),
			'default' => array(
				'unit' => 'px',
				'size' => 150,
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-sorting-select' => 'max-width: {{SIZE}}{{UNIT}}',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'selectors_dictionary' => array(
				'left' => 'justify-content: flex-start;',
				'center' => 'justify-content: center;',
				'right' => 'justify-content: flex-end;',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-sorting' => '{{VALUE}}',
			),
			'condition' => array(
				'label_block' => '',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_select_style',
		array(
			'label' => 'Keuzelijst',
			'tab' => 'style',
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'select_typography',
			'selector' => '{{WRAPPER}} .m7sf-sorting-select',
		),
		array(),
	),
	array(
		'control',
		'select_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'default' => '',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-sorting-select' => 'color: {{VALUE}};',
			),
		),
		array(),
	),
	array(
		'control',
		'select_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-sorting-select' => 'background-color: {{VALUE}};',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'select_border',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-sorting-select',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'select_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-sorting-select' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'select_box_shadow',
			'selector' => '{{WRAPPER}} .m7sf-sorting-select',
		),
		array(),
	),
	array(
		'responsive',
		'select_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'em',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-sorting-select' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'select_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'selectors_dictionary' => array(
				'left' => 'align-self: flex-start;',
				'center' => 'align-self: center;',
				'right' => 'align-self: flex-end;',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-sorting-select' => '{{VALUE}}',
			),
			'condition' => array(
				'label_block!' => '',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'reset_appearance',
		array(
			'label' => 'Standaardopmaak veld uitzetten',
			'description' => 'Check this option to reset field appearance CSS value. This will make field appearance the same for all browsers',
			'type' => 'switcher',
			'default' => '',
			'separator' => 'before',
			'selectors_dictionary' => array(
				'yes' => '-webkit-appearance: none;',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-sorting-select' => '{{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_label_style',
		array(
			'label' => 'Label',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'label_typography',
			'selector' => '{{WRAPPER}} .m7sf-sorting-label',
		),
		array(),
	),
	array(
		'control',
		'label_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-sorting-label' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'responsive',
		'label_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-sorting-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'label_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'selectors_dictionary' => array(
				'left' => 'align-self: flex-start;',
				'center' => 'align-self: center;',
				'right' => 'align-self: flex-end;',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-sorting-label' => '{{VALUE}}',
			),
			'separator' => 'before',
			'condition' => array(
				'label_block!' => '',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_filter_apply_button_style',
		array(
			'label' => 'Knop',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'filter_apply_button_typography',
			'global' => array(
				'default' => 'globals/typography?id=primary',
			),
			'selector' => '{{WRAPPER}} .m7sf-apply-filters__button',
		),
		array(),
	),
	array(
		'tabs',
		'filter_apply_button_style_tabs',
		array(),
	),
	array(
		'tab',
		'filter_apply_button_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'filter_apply_button_normal_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'filter_apply_button_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'filter_apply_button_hover_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button:hover' => 'border-color: {{VALUE}}',
			),
			'condition' => array(
				'filter_apply_button_border_border!' => '',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'filter_apply_button_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-apply-filters__button',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'filter_apply_button_shadow',
			'selector' => '{{WRAPPER}} .m7sf-apply-filters__button',
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'flex-start' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'flex-end' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
				'stretch' => array(
					'title' => 'Uitrekken',
					'icon' => 'eicon-text-align-justify',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'align-self: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
);
