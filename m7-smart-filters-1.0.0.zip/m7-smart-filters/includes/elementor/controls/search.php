<?php
/**
 * Elementor-instellingen van het M7-widget "search": zelfde sleutels, standaarden, selectors en
 * volgorde als JetSmartFilters 3.7.0 (gegenereerd door tools/jsf-controls/build.py, niet met de hand wijzigen).
 *
 * @package M7SF
 */

defined( 'ABSPATH' ) || exit;

return array(
	array(
		'section',
		'section_general',
		array(
			'label' => 'Inhoud',
		),
	),
	array(
		'control',
		'filter_id',
		array(
			'label' => 'Kies filter',
			'label_block' => true,
			'type' => 'jet-query',
			'multiple' => false,
			'default' => '',
			'query_type' => 'post',
			'query' => array(
				'post_type' => 'jet-smart-filters',
				'posts_per_page' => -1,
				'meta_query' => array(
					array(
						'key' => '_filter_type',
						'value' => 'search',
						'compare' => '=',
					),
				),
			),
		),
		array(),
	),
	array(
		'control',
		'content_provider',
		array(
			'label' => 'Dit filter is voor',
			'type' => 'select',
			'default' => '',
			'options' => array(
				'' => 'Kies…',
				'epro-archive-products' => 'Elementor Pro Archive Products',
				'epro-archive' => 'Elementor Pro Archive',
				'epro-loop-builder' => 'Elementor Pro Loop Grid',
				'epro-portfolio' => 'Elementor Pro Portfolio',
				'epro-posts' => 'Elementor Pro Posts',
				'epro-products' => 'Elementor Pro Products',
				'jet-engine-calendar' => 'JetEngine Calendar',
				'jet-engine' => 'JetEngine',
				'jet-woo-products-grid' => 'JetWooBuilder Products Grid',
				'jet-woo-products-list' => 'JetWooBuilder Products List',
				'jsf-listing' => 'JSF Listing',
				'woocommerce-archive' => 'WooCommerce Archive (by JetWooBuilder)',
				'default-woo-archive' => 'Default WooCommerce Archive (Classic)',
				'woocommerce-shortcode' => 'WooCommerce Shortcode',
			),
		),
		array(),
	),
	array(
		'control',
		'epro_posts_notice',
		array(
			'type' => 'raw_html',
			'raw' => 'M7: geef de lijst (Loop Grid / Posts / Products) en dit filter hetzelfde Query-ID.',
			'condition' => array(
				'content_provider' => array(
					'epro-posts',
					'epro-portfolio',
				),
			),
		),
		array(),
	),
	array(
		'control',
		'apply_type',
		array(
			'label' => 'Manier van toepassen',
			'type' => 'select',
			'default' => 'ajax',
			'options' => array(
				'ajax' => 'AJAX',
				'ajax-ontyping' => 'AJAX on typing',
				'reload' => 'Pagina herladen',
				'mixed' => 'Gemengd',
			),
		),
		array(),
	),
	array(
		'control',
		'typing_min_letters_count',
		array(
			'label' => 'Minimaal aantal letters',
			'description' => 'The minimum number of letters to start the search.',
			'type' => 'number',
			'default' => 3,
			'min' => 1,
			'max' => 10,
			'step' => 1,
			'condition' => array(
				'apply_type' => 'ajax-ontyping',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_button_text',
		array(
			'label' => 'Tekst zoekknop',
			'type' => 'text',
			'default' => 'Apply filter',
			'condition' => array(
				'apply_type' => array(
					'ajax',
					'reload',
					'mixed',
				),
				'hide_apply_button' => '',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_button_icon',
		array(
			'label' => 'Icoon zoekknop',
			'label_block' => true,
			'type' => 'icon',
			'default' => '',
			'condition' => array(
				'apply_type' => array(
					'ajax',
					'reload',
					'mixed',
				),
				'hide_apply_button' => '',
			),
		),
		array(),
	),
	array(
		'control',
		'hide_apply_button',
		array(
			'label' => 'Toepassen-knop verbergen',
			'type' => 'switcher',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
			'condition' => array(
				'apply_type' => array(
					'ajax',
					'reload',
					'mixed',
				),
			),
		),
		array(),
	),
	array(
		'control',
		'show_label',
		array(
			'label' => 'Filterlabel tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
		),
		array(),
	),
	array(
		'control',
		'query_id',
		array(
			'label' => 'Query-ID',
			'type' => 'text',
			'label_block' => true,
			'description' => 'Set unique query ID if you use multiple widgets of same provider on the page. Same ID you need to set for filtered widget.',
		),
		array(),
	),
	array(
		'control',
		'additional_providers_enabled',
		array(
			'label' => 'Extra lijsten',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => 'no',
		),
		array(),
	),
	array(
		'control',
		'additional_providers_list',
		array(
			'label' => 'Lijst met extra lijsten',
			'type' => 'repeater',
			'fields' => array(
				'_id' => array(
					'type' => 'hidden',
					'tab' => 'content',
					'name' => '_id',
					'default' => '',
				),
				'additional_provider' => array(
					'type' => 'select',
					'tab' => 'content',
					'default' => '',
					'name' => 'additional_provider',
				),
				'additional_query_id' => array(
					'type' => 'text',
					'tab' => 'content',
					'name' => 'additional_query_id',
					'default' => '',
				),
			),
			'title_field' => '{{ additional_provider + ( additional_query_id ? "/" + additional_query_id : "" ) }}',
			'condition' => array(
				'additional_providers_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_search_content_style',
		array(
			'label' => 'Inhoud',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'content_position',
		array(
			'label' => 'Positie',
			'type' => 'choose',
			'label_block' => false,
			'options' => array(
				'line' => array(
					'title' => 'Naast elkaar',
					'icon' => 'eicon-ellipsis-h',
				),
				'column' => array(
					'title' => 'Columns',
					'icon' => 'eicon-menu-bar',
				),
			),
			'selectors_dictionary' => array(
				'line' => 'display:flex; flex-direction:row;',
				'column' => 'display:flex; flex-direction:column;',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter' => '{{VALUE}}',
			),
			'prefix_class' => 'm7sf-smart-filter-content-position-',
			'responsive' => array(),
		),
		array(),
	),
	array(
		'responsive',
		'content_search_input_width',
		array(
			'label' => 'Breedte invoerveld',
			'type' => 'slider',
			'size_units' => array(
				'px',
				'%',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 500,
				),
				'%' => array(
					'min' => 0,
					'max' => 100,
				),
			),
			'default' => array(
				'size' => 100,
				'unit' => '%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__input-wrapper' => 'max-width: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'content_line_horizontal_alignment',
		array(
			'label' => 'Horizontale uitlijning',
			'type' => 'choose',
			'options' => array(
				'flex-start' => array(
					'title' => 'Links',
					'icon' => 'eicon-h-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-h-align-center',
				),
				'flex-end' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-h-align-right',
				),
				'space-between' => array(
					'title' => 'Justify',
					'icon' => 'eicon-h-align-stretch',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter' => 'justify-content: {{VALUE}};',
			),
			'condition' => array(
				'content_position' => 'line',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'content_line_vertical_alignment',
		array(
			'label' => 'Verticale uitlijning',
			'type' => 'choose',
			'default' => 'left',
			'options' => array(
				'flex-start' => array(
					'title' => 'Boven',
					'icon' => 'eicon-v-align-top',
				),
				'center' => array(
					'title' => 'Middle',
					'icon' => 'eicon-v-align-middle',
				),
				'flex-end' => array(
					'title' => 'Onder',
					'icon' => 'eicon-v-align-bottom',
				),
				'stretch' => array(
					'title' => 'Uitrekken',
					'icon' => 'eicon-v-align-stretch',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter' => 'align-items: {{VALUE}};',
			),
			'condition' => array(
				'content_position' => 'line',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'content_column_horizontal_alignment',
		array(
			'label' => 'Horizontale uitlijning',
			'type' => 'choose',
			'options' => array(
				'flex-start' => array(
					'title' => 'Links',
					'icon' => 'eicon-h-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-h-align-center',
				),
				'flex-end' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-h-align-right',
				),
				'stretch' => array(
					'title' => 'Uitrekken',
					'icon' => 'eicon-h-align-stretch',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter' => 'align-items: {{VALUE}};',
			),
			'condition' => array(
				'content_position' => 'column',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_search_input_style',
		array(
			'label' => 'Invoerveld',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'search_input_typography',
			'selector' => '{{WRAPPER}} .m7sf-search-filter__input',
		),
		array(),
	),
	array(
		'tabs',
		'search_input_style_tabs',
		array(),
	),
	array(
		'tab',
		'search_input_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'search_input_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__input' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-search-filter__input::placeholder' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-search-filter__input:-ms-input-placeholder' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-search-filter__input::-ms-input-placeholder' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-search-filter__input-clear' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-search-filter__input-loading' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'search_input_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__input' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'search_input_focus_styles',
		array(
			'label' => 'Focus',
		),
	),
	array(
		'control',
		'search_input_focus_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__input:focus' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-search-filter__input:focus::placeholder' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-search-filter__input:focus:-ms-input-placeholder' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-search-filter__input:focus::-ms-input-placeholder' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-search-filter__input:focus ~ .m7sf-search-filter__input-clear' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-search-filter__input:focus ~ .m7sf-search-filter__input-loading' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'search_input_focus_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__input:focus' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'search_input_focus_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__input:focus ' => 'border-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'search_input_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-search-filter__input',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'search_input_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__input' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'search_input_box_shadow',
			'selector' => '{{WRAPPER}} .m7sf-search-filter__input',
		),
		array(),
	),
	array(
		'responsive',
		'search_input_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'search_input_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__input' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; width: calc(100% - {{RIGHT}}{{UNIT}} - {{LEFT}}{{UNIT}});',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_filter_apply_button_style',
		array(
			'label' => 'Knop',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'filter_apply_button_typography',
			'global' => array(
				'default' => 'globals/typography?id=primary',
			),
			'selector' => '{{WRAPPER}} .m7sf-search-filter__submit',
		),
		array(),
	),
	array(
		'tabs',
		'filter_apply_button_style_tabs',
		array(),
	),
	array(
		'tab',
		'filter_apply_button_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'filter_apply_button_normal_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__submit' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__submit' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'filter_apply_button_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'filter_apply_button_hover_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__submit:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__submit:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__submit:hover' => 'border-color: {{VALUE}}',
			),
			'condition' => array(
				'filter_apply_button_border_border!' => '',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'filter_apply_button_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-search-filter__submit',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__submit' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; overflow:hidden;',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'filter_apply_button_shadow',
			'selector' => '{{WRAPPER}} .m7sf-search-filter__submit',
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__submit' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__submit' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter' => 'text-align: {{VALUE}};',
			),
			'condition' => array(
				'content_position' => '',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_icon_heading',
		array(
			'label' => 'Icoon',
			'type' => 'heading',
			'separator' => 'before',
			'condition' => array(
				'apply_button_icon!' => '',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_icon_position',
		array(
			'label' => 'Positie',
			'type' => 'choose',
			'label_block' => false,
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-arrow-left',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-arrow-right',
				),
			),
			'toggle' => true,
			'default' => 'left',
			'condition' => array(
				'apply_button_icon!' => '',
			),
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_icon_size',
		array(
			'label' => 'Grootte',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 40,
				),
			),
			'default' => array(
				'size' => 15,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__submit > i' => 'font-size: {{SIZE}}{{UNIT}};',
			),
			'condition' => array(
				'apply_button_icon!' => '',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_icon_offset',
		array(
			'label' => 'Ruimte icoon',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 50,
				),
			),
			'default' => array(
				'size' => 0,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .button-icon-position-right .m7sf-search-filter__submit > i' => 'margin-left: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .button-icon-position-left .m7sf-search-filter__submit > i' => 'margin-right: {{SIZE}}{{UNIT}};',
			),
			'condition' => array(
				'apply_button_icon!' => '',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_icon_normal_color',
		array(
			'label' => 'Standaardkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__submit > i' => 'color: {{VALUE}}',
			),
			'condition' => array(
				'apply_button_icon!' => '',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_icon_hover_color',
		array(
			'label' => 'Kleur bij hover',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-search-filter__submit:hover > i' => 'color: {{VALUE}}',
			),
			'condition' => array(
				'apply_button_icon!' => '',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_label_style',
		array(
			'label' => 'Label',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'label_typography',
			'selector' => '{{WRAPPER}} .m7sf-filter-label',
		),
		array(),
	),
	array(
		'control',
		'label_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'label_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-filter-label',
		),
		array(),
	),
	array(
		'responsive',
		'label_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'label_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'label_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'text-align: {{VALUE}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
);
