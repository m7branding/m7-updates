<?php
/**
 * Elementor-instellingen van het M7-widget "active-tags": zelfde sleutels, standaarden, selectors en
 * volgorde als JetSmartFilters 3.7.0 (gegenereerd door tools/jsf-controls/build.py, niet met de hand wijzigen).
 *
 * @package M7SF
 */

defined( 'ABSPATH' ) || exit;

return array(
	array(
		'section',
		'section_general',
		array(
			'label' => 'Inhoud',
		),
	),
	array(
		'control',
		'content_provider',
		array(
			'label' => 'Actieve tags tonen voor:',
			'type' => 'select',
			'default' => '',
			'options' => array(
				'' => 'Kies…',
				'epro-archive-products' => 'Elementor Pro Archive Products',
				'epro-archive' => 'Elementor Pro Archive',
				'epro-loop-builder' => 'Elementor Pro Loop Grid',
				'epro-portfolio' => 'Elementor Pro Portfolio',
				'epro-posts' => 'Elementor Pro Posts',
				'epro-products' => 'Elementor Pro Products',
				'jet-engine-calendar' => 'JetEngine Calendar',
				'jet-engine' => 'JetEngine',
				'jet-woo-products-grid' => 'JetWooBuilder Products Grid',
				'jet-woo-products-list' => 'JetWooBuilder Products List',
				'jsf-listing' => 'JSF Listing',
				'woocommerce-archive' => 'WooCommerce Archive (by JetWooBuilder)',
				'default-woo-archive' => 'Default WooCommerce Archive (Classic)',
				'woocommerce-shortcode' => 'WooCommerce Shortcode',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_type',
		array(
			'label' => 'Manier van toepassen',
			'type' => 'select',
			'default' => 'ajax',
			'options' => array(
				'ajax' => 'AJAX',
				'reload' => 'Pagina herladen',
			),
		),
		array(),
	),
	array(
		'control',
		'tags_label',
		array(
			'label' => 'Label',
			'type' => 'text',
			'default' => 'Active tags:',
		),
		array(),
	),
	array(
		'control',
		'clear_item',
		array(
			'label' => 'Alles wissen tonen',
			'type' => 'switcher',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => 'yes',
		),
		array(),
	),
	array(
		'control',
		'clear_item_label',
		array(
			'label' => 'Tekst alles wissen',
			'type' => 'text',
			'default' => 'Clear',
			'condition' => array(
				'clear_item' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'query_id',
		array(
			'label' => 'Query-ID',
			'type' => 'text',
			'label_block' => true,
			'description' => 'Set unique query ID if you use multiple widgets of same provider on the page. Same ID you need to set for filtered widget.',
		),
		array(),
	),
	array(
		'control',
		'additional_providers_enabled',
		array(
			'label' => 'Extra lijsten',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => 'no',
		),
		array(),
	),
	array(
		'control',
		'additional_providers_list',
		array(
			'label' => 'Lijst met extra lijsten',
			'type' => 'repeater',
			'fields' => array(
				'_id' => array(
					'type' => 'hidden',
					'tab' => 'content',
					'name' => '_id',
					'default' => '',
				),
				'additional_provider' => array(
					'type' => 'select',
					'tab' => 'content',
					'default' => '',
					'name' => 'additional_provider',
				),
				'additional_query_id' => array(
					'type' => 'text',
					'tab' => 'content',
					'name' => 'additional_query_id',
					'default' => '',
				),
			),
			'title_field' => '{{ additional_provider + ( additional_query_id ? "/" + additional_query_id : "" ) }}',
			'condition' => array(
				'additional_providers_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_tags_title_style',
		array(
			'label' => 'Titel',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'tags_title_typography',
			'selector' => '{{WRAPPER}} .m7sf-active-tags__title',
		),
		array(),
	),
	array(
		'control',
		'tags_title_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tags__title' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'responsive',
		'tags_title_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tags__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_tags_styles',
		array(
			'label' => 'Tags',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'tags_position',
		array(
			'label' => 'Positie tags',
			'type' => 'choose',
			'label_block' => false,
			'toggle' => false,
			'default' => 'row',
			'options' => array(
				'row' => array(
					'title' => 'Naast elkaar',
					'icon' => 'eicon-ellipsis-h',
				),
				'column' => array(
					'title' => 'Onder elkaar',
					'icon' => 'eicon-menu-bar',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-active-tags' => 'flex-direction: {{VALUE}};',
				'{{WRAPPER}} .m7sf-active-tags__list' => 'flex-direction: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'tags_space_between_horizontal',
		array(
			'label' => 'Horizontale verschuiving',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 40,
				),
			),
			'default' => array(
				'size' => 5,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag' => 'margin-right: {{SIZE}}{{UNIT}};',
			),
			'condition' => array(
				'tags_position' => 'row',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'tags_space_between_vertical',
		array(
			'label' => 'Verticale verschuiving',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 40,
				),
			),
			'default' => array(
				'size' => 5,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag' => 'margin-bottom: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'tags_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tags__list' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'tags_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-active-tags__list',
		),
		array(),
	),
	array(
		'control',
		'tags_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tags__list' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'tags_box_shadow',
			'selector' => '{{WRAPPER}} .m7sf-active-tags__list',
		),
		array(),
	),
	array(
		'responsive',
		'tags_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tags__list' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'tags_alignment_column',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'flex-start' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'flex-end' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tags__list' => 'align-items: {{VALUE}};',
			),
			'condition' => array(
				'tags_position' => 'column',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'tags_alignment_line',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'flex-start' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'flex-end' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tags__list' => 'justify-content: {{VALUE}};',
			),
			'condition' => array(
				'tags_position' => 'row',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_tag_styles',
		array(
			'label' => 'Tag',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'tag_min_width',
		array(
			'label' => 'Minimale breedte',
			'type' => 'slider',
			'size_units' => array(
				'px',
				'%',
			),
			'range' => array(
				'px' => array(
					'min' => 10,
					'max' => 500,
				),
				'%' => array(
					'min' => 0,
					'max' => 100,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag' => 'min-width: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'tag_value_typography',
			'selector' => '{{WRAPPER}} .m7sf-active-tag',
		),
		array(),
	),
	array(
		'tabs',
		'tag_style_tabs',
		array(),
	),
	array(
		'tab',
		'tag_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'tag_value_normal_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'tag_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'tag_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'tag_value_hover_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'tag_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'tag_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag:hover' => 'border-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'tag_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-active-tag',
		),
		array(),
	),
	array(
		'control',
		'tag_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'tag_box_shadow',
			'selector' => '{{WRAPPER}} .m7sf-active-tag',
		),
		array(),
	),
	array(
		'responsive',
		'tag_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'tag_item_label_heading',
		array(
			'label' => 'Label optie',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'tag_item_label_typography',
			'selector' => '{{WRAPPER}} .m7sf-active-tag__label',
		),
		array(),
	),
	array(
		'tabs',
		'tag_item_label_style_tabs',
		array(),
	),
	array(
		'tab',
		'tag_item_label_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'tag_item_label_normal_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag__label' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'tag_item_label_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'tag_item_label_hover_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag:hover .m7sf-active-tag__label' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'responsive',
		'tag_item_label_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag__label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'tags_clear_item_heading',
		array(
			'label' => 'Alles wissen tonen',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'tabs',
		'tag_clear_style_tabs',
		array(),
	),
	array(
		'tab',
		'tag_clear_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'tag_clear_normal_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag--clear ' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'tag_clear_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag--clear ' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'tag_clear_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'tag_clear_hover_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag--clear:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'tag_clear_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag--clear:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'tag_clear_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag--clear:hover' => 'border-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'control',
		'tag_remove_heading',
		array(
			'label' => 'Verwijderen',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'responsive',
		'tag_remove_size',
		array(
			'label' => 'Grootte',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 40,
				),
			),
			'default' => array(
				'size' => 12,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag__remove' => 'font-size: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'tag_remove_offset_top',
		array(
			'label' => 'Afstand boven',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 40,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag__remove' => 'top: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'tag_remove_offset_right',
		array(
			'label' => 'Afstand rechts',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 40,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag__remove' => 'right: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'tabs',
		'tag_remove_style_tabs',
		array(),
	),
	array(
		'tab',
		'tag_remove_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'tag_remove_normal_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag__remove' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'tag_remove_normal_bg_color',
		array(
			'label' => 'Achtergrond',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag__remove' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'tag_remove_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'tag_remove_hover_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag:hover .m7sf-active-tag__remove' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'tag_remove_hover_bg_color',
		array(
			'label' => 'Achtergrond',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag:hover .m7sf-active-tag__remove' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'tag_remove_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag:hover .m7sf-active-tag__remove' => 'border-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'tag_remove_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-active-tag__remove',
		),
		array(),
	),
	array(
		'control',
		'tag_remove_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag__remove' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'responsive',
		'tag_remove_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-tag__remove' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
);
