<?php
/**
 * Elementor-instellingen van het M7-widget "checkboxes": zelfde sleutels, standaarden, selectors en
 * volgorde als JetSmartFilters 3.7.0 (gegenereerd door tools/jsf-controls/build.py, niet met de hand wijzigen).
 *
 * @package M7SF
 */

defined( 'ABSPATH' ) || exit;

return array(
	array(
		'section',
		'section_general',
		array(
			'label' => 'Inhoud',
		),
	),
	array(
		'control',
		'filter_id',
		array(
			'label' => 'Kies filter',
			'label_block' => true,
			'type' => 'jet-query',
			'multiple' => true,
			'default' => '',
			'query_type' => 'post',
			'query' => array(
				'post_type' => 'jet-smart-filters',
				'posts_per_page' => -1,
				'meta_query' => array(
					array(
						'key' => '_filter_type',
						'value' => 'checkboxes',
						'compare' => '=',
					),
				),
			),
		),
		array(),
	),
	array(
		'control',
		'content_provider',
		array(
			'label' => 'Dit filter is voor',
			'type' => 'select',
			'default' => '',
			'options' => array(
				'' => 'Kies…',
				'epro-archive-products' => 'Elementor Pro Archive Products',
				'epro-archive' => 'Elementor Pro Archive',
				'epro-loop-builder' => 'Elementor Pro Loop Grid',
				'epro-portfolio' => 'Elementor Pro Portfolio',
				'epro-posts' => 'Elementor Pro Posts',
				'epro-products' => 'Elementor Pro Products',
				'jet-engine-calendar' => 'JetEngine Calendar',
				'jet-engine' => 'JetEngine',
				'jet-woo-products-grid' => 'JetWooBuilder Products Grid',
				'jet-woo-products-list' => 'JetWooBuilder Products List',
				'jsf-listing' => 'JSF Listing',
				'woocommerce-archive' => 'WooCommerce Archive (by JetWooBuilder)',
				'default-woo-archive' => 'Default WooCommerce Archive (Classic)',
				'woocommerce-shortcode' => 'WooCommerce Shortcode',
			),
		),
		array(),
	),
	array(
		'control',
		'epro_posts_notice',
		array(
			'type' => 'raw_html',
			'raw' => 'M7: geef de lijst (Loop Grid / Posts / Products) en dit filter hetzelfde Query-ID.',
			'condition' => array(
				'content_provider' => array(
					'epro-posts',
					'epro-portfolio',
				),
			),
		),
		array(),
	),
	array(
		'control',
		'apply_type',
		array(
			'label' => 'Manier van toepassen',
			'type' => 'select',
			'default' => 'ajax',
			'options' => array(
				'ajax' => 'AJAX',
				'reload' => 'Pagina herladen',
				'mixed' => 'Gemengd',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_on',
		array(
			'label' => 'Toepassen bij',
			'type' => 'select',
			'default' => 'value',
			'options' => array(
				'value' => 'Elke wijziging',
				'submit' => 'Klik op toepassen-knop',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_button',
		array(
			'label' => 'Toepassen-knop tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
			'condition' => array(
				'apply_on' => 'submit',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_button_text',
		array(
			'label' => 'Tekst toepassen-knop',
			'type' => 'text',
			'default' => 'Apply filter',
			'condition' => array(
				'apply_on' => 'submit',
				'apply_button' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'show_label',
		array(
			'label' => 'Filterlabel tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
		),
		array(),
	),
	array(
		'control',
		'query_id',
		array(
			'label' => 'Query-ID',
			'type' => 'text',
			'label_block' => true,
			'description' => 'Set unique query ID if you use multiple widgets of same provider on the page. Same ID you need to set for filtered widget.',
		),
		array(),
	),
	array(
		'control',
		'query_id_wc_shortcode_notice',
		array(
			'type' => 'raw_html',
			'raw' => '<b>Query ID</b> for <b>WooCommerce Shortcode</b> must be specified as attribute class: [products class="query_id"]',
			'condition' => array(
				'content_provider' => array(
					'woocommerce-shortcode',
				),
			),
		),
		array(),
	),
	array(
		'control',
		'additional_providers_enabled',
		array(
			'label' => 'Extra lijsten',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => 'no',
		),
		array(),
	),
	array(
		'control',
		'additional_providers_list',
		array(
			'label' => 'Lijst met extra lijsten',
			'type' => 'repeater',
			'fields' => array(
				'_id' => array(
					'type' => 'hidden',
					'tab' => 'content',
					'name' => '_id',
					'default' => '',
				),
				'additional_provider' => array(
					'type' => 'select',
					'tab' => 'content',
					'default' => '',
					'name' => 'additional_provider',
				),
				'additional_query_id' => array(
					'type' => 'text',
					'tab' => 'content',
					'name' => 'additional_query_id',
					'default' => '',
				),
			),
			'title_field' => '{{ additional_provider + ( additional_query_id ? "/" + additional_query_id : "" ) }}',
			'condition' => array(
				'additional_providers_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'additional_settings',
		array(
			'label' => 'Extra instellingen',
		),
	),
	array(
		'control',
		'search_enabled',
		array(
			'label' => 'Zoeken in opties',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
		),
		array(),
	),
	array(
		'control',
		'search_placeholder',
		array(
			'label' => 'Placeholder zoeken',
			'type' => 'text',
			'placeholder' => 'Search...',
			'condition' => array(
				'search_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'moreless_enabled',
		array(
			'label' => 'Meer/minder tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'less_items_count',
		array(
			'label' => 'Aantal opties zichtbaar',
			'type' => 'number',
			'default' => 5,
			'min' => 1,
			'max' => 50,
			'step' => 1,
			'condition' => array(
				'moreless_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'more_text',
		array(
			'label' => 'Tekst meer',
			'type' => 'text',
			'placeholder' => 'More',
			'condition' => array(
				'moreless_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'less_text',
		array(
			'label' => 'Tekst minder',
			'type' => 'text',
			'placeholder' => 'Less',
			'condition' => array(
				'moreless_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'dropdown_enabled',
		array(
			'label' => 'Als uitklaplijst',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'dropdown_placeholder',
		array(
			'label' => 'Placeholder',
			'type' => 'text',
			'placeholder' => 'Select some options',
			'condition' => array(
				'dropdown_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'dropdown_n_selected_enabled',
		array(
			'label' => 'Aantal gekozen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
			'condition' => array(
				'dropdown_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'dropdown_n_selected_number',
		array(
			'label' => 'Aantal getoonde namen',
			'type' => 'number',
			'default' => 3,
			'placeholder' => '3',
			'min' => 0,
			'step' => 1,
			'condition' => array(
				'dropdown_enabled' => 'yes',
				'dropdown_n_selected_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'dropdown_n_selected_text',
		array(
			'label' => 'Algemene tekst',
			'label_block' => true,
			'type' => 'text',
			'description' => 'Use a {number} macro to display the number of other items',
			'placeholder' => 'and {number} others',
			'condition' => array(
				'dropdown_enabled' => 'yes',
				'dropdown_n_selected_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'dropdown_apply_button',
		array(
			'label' => 'Toepassen-knop toevoegen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
			'condition' => array(
				'dropdown_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'dropdown_apply_button_text',
		array(
			'label' => 'Tekst toepassen-knop',
			'type' => 'text',
			'placeholder' => 'Apply',
			'condition' => array(
				'dropdown_enabled' => 'yes',
				'dropdown_apply_button' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'scroll_enabled',
		array(
			'label' => 'Scrollen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'scroll_height',
		array(
			'label' => 'Scrollhoogte (px)',
			'type' => 'number',
			'default' => 290,
			'min' => 100,
			'max' => 1000,
			'step' => 1,
			'condition' => array(
				'scroll_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_indexer_options',
		array(
			'label' => 'Tellers',
		),
	),
	array(
		'control',
		'apply_indexer',
		array(
			'label' => 'Tellers gebruiken',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
		),
		array(),
	),
	array(
		'control',
		'show_counter',
		array(
			'label' => 'Teller tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
			'condition' => array(
				'apply_indexer' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'counter_prefix',
		array(
			'label' => 'Voor de teller',
			'type' => 'text',
			'default' => '(',
			'condition' => array(
				'apply_indexer' => 'yes',
				'show_counter' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'counter_suffix',
		array(
			'label' => 'Na de teller',
			'type' => 'text',
			'default' => ')',
			'condition' => array(
				'apply_indexer' => 'yes',
				'show_counter' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'show_items_rule',
		array(
			'label' => 'Als optie leeg is',
			'type' => 'select',
			'default' => 'show',
			'options' => array(
				'show' => 'Tonen',
				'hide' => 'Verbergen',
				'disable' => 'Uitschakelen',
			),
			'condition' => array(
				'apply_indexer' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'change_items_rule',
		array(
			'label' => 'Tellers bijwerken',
			'type' => 'select',
			'default' => 'always',
			'options' => array(
				'always' => 'Altijd',
				'never' => 'Nooit',
				'other_changed' => 'Als andere filters wijzigen',
			),
			'condition' => array(
				'apply_indexer' => 'yes',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_items_style',
		array(
			'label' => 'Opties',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'filters_position',
		array(
			'label' => 'Opties',
			'type' => 'choose',
			'toggle' => false,
			'label_block' => false,
			'default' => 'block',
			'options' => array(
				'block' => array(
					'title' => 'Onder elkaar',
					'icon' => 'eicon-menu-bar',
				),
				'inline-block' => array(
					'title' => 'Naast elkaar',
					'icon' => 'eicon-ellipsis-h',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__row' => 'display: {{VALUE}};',
				'{{WRAPPER}} .m7sf-list-tree__children' => 'display: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'horizontal_layout_description',
		array(
			'raw' => 'Horizontal Offset control works only with Line Filters Position',
			'type' => 'raw_html',
			'content_classes' => 'elementor-descriptor',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'responsive',
		'filters_space_between_horizontal',
		array(
			'label' => 'Horizontale verschuiving',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 40,
				),
			),
			'default' => array(
				'size' => 5,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__row' => 'margin-right: calc({{SIZE}}{{UNIT}}/2); margin-left: calc({{SIZE}}{{UNIT}}/2);',
				'{{WRAPPER}} .m7sf-list-tree__children' => 'margin-right: calc({{SIZE}}{{UNIT}}/2); margin-left: calc({{SIZE}}{{UNIT}}/2);',
				'{{WRAPPER}} .m7sf-checkboxes-list-wrapper' => 'margin-left: calc(-{{SIZE}}{{UNIT}}/2); margin-right: calc(-{{SIZE}}{{UNIT}}/2);',
			),
			'separator' => 'after',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filters_list_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list-wrapper' => 'text-align: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'items_space_between',
		array(
			'label' => 'Ruimte ertussen',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 50,
				),
			),
			'default' => array(
				'size' => 10,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__row' => 'padding-top: calc({{SIZE}}{{UNIT}}/2); margin-bottom: calc({{SIZE}}{{UNIT}}/2);',
				'{{WRAPPER}} .m7sf-checkboxes-list-wrapper' => 'margin-top: calc(-{{SIZE}}{{UNIT}}/2); margin-bottom: calc(-{{SIZE}}{{UNIT}}/2);',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'sub_items_offset_left',
		array(
			'label' => 'Inspringing subopties',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 50,
				),
			),
			'default' => array(
				'size' => 10,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-list-tree__children' => 'padding-left: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_item_style',
		array(
			'label' => 'Optie',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'control',
		'show_decorator',
		array(
			'label' => 'Vakje tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => 'yes',
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'item_typography',
			'selector' => '{{WRAPPER}} .m7sf-checkboxes-list__label',
		),
		array(),
	),
	array(
		'tabs',
		'item_style_tabs',
		array(),
	),
	array(
		'tab',
		'item_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'item_normal_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__button' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'item_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__button' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'item_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'item_hover_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__button:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'item_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__button:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'item_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__button:hover' => 'border-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'item_checked_styles',
		array(
			'label' => 'Gekozen',
		),
	),
	array(
		'control',
		'item_checked_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__input:checked ~ .m7sf-checkboxes-list__button' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'item_checked_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__input:checked ~ .m7sf-checkboxes-list__button' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'item_checked_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__input:checked ~ .m7sf-checkboxes-list__button' => 'border-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'responsive',
		'item_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'item_border',
			'label' => 'Rand',
			'selector' => '{{WRAPPER}} .m7sf-checkboxes-list__button',
		),
		array(),
	),
	array(
		'control',
		'item_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'item_shadow',
			'selector' => '{{WRAPPER}} .m7sf-checkboxes-list__button',
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_checkbox_style',
		array(
			'label' => 'Vakje',
			'tab' => 'style',
			'show_label' => false,
			'condition' => array(
				'show_decorator' => 'yes',
			),
		),
	),
	array(
		'responsive',
		'checkbox_size',
		array(
			'label' => 'Grootte',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 40,
				),
			),
			'default' => array(
				'size' => 16,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__decorator' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}}; min-height: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'checkbox_top_offset',
		array(
			'label' => 'Verticale verschuiving',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 30,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__decorator' => 'margin-top: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'checkbox_label_offset',
		array(
			'label' => 'Horizontale verschuiving',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 30,
				),
			),
			'default' => array(
				'size' => 5,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__decorator' => 'margin-right: {{SIZE}}{{UNIT}};',
				'.rtl {{WRAPPER}} .m7sf-checkboxes-list__decorator' => 'margin-left: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'tabs',
		'checkbox_style_tabs',
		array(),
	),
	array(
		'tab',
		'checkbox_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'checkbox_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__decorator' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'checkbox_checked_styles',
		array(
			'label' => 'Gekozen',
		),
	),
	array(
		'control',
		'checkbox_checked_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__input:checked ~ .m7sf-checkboxes-list__button .m7sf-checkboxes-list__decorator' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'checkbox_checked_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__input:checked ~ .m7sf-checkboxes-list__button .m7sf-checkboxes-list__decorator' => 'border-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'checkbox_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-checkboxes-list__decorator',
		),
		array(),
	),
	array(
		'control',
		'checkbox_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__decorator' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; overflow:hidden;',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_checked_icon_style',
		array(
			'label' => 'Vinkje',
			'tab' => 'style',
			'show_label' => false,
			'condition' => array(
				'show_decorator' => 'yes',
			),
		),
	),
	array(
		'responsive',
		'checked_icon_size',
		array(
			'label' => 'Grootte',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 30,
				),
			),
			'default' => array(
				'size' => 12,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__checked-icon' => 'font-size: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'checked_icon_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list__checked-icon' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'collapse_icon_style_section',
		array(
			'label' => 'In-/uitklapicoon',
			'tab' => 'style',
		),
	),
	array(
		'responsive',
		'collapse_icon_size',
		array(
			'label' => 'Grootte',
			'type' => 'slider',
			'size_units' => array(
				'px',
				'%',
			),
			'range' => array(
				'px' => array(
					'min' => 10,
					'max' => 50,
				),
				'%' => array(
					'min' => 1,
					'max' => 100,
				),
			),
			'default' => array(
				'size' => 20,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-collapse-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-collapse-none' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'collapse_icon_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-collapse-icon svg path' => 'stroke: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'collapse_icon_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-collapse-icon' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'collapse_icon_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-collapse-icon',
		),
		array(),
	),
	array(
		'control',
		'collapse_icon_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-collapse-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'responsive',
		'collapse_icon_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-collapse-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'collapse_icon_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-collapse-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-collapse-none' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'search_items_style_section',
		array(
			'label' => 'Zoeken in opties',
			'tab' => 'style',
			'condition' => array(
				'search_enabled' => 'yes',
			),
		),
	),
	array(
		'responsive',
		'search_items_width',
		array(
			'label' => 'Breedte invoerveld',
			'type' => 'slider',
			'size_units' => array(
				'px',
				'%',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 500,
				),
				'%' => array(
					'min' => 0,
					'max' => 100,
				),
			),
			'default' => array(
				'size' => 100,
				'unit' => '%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-search' => 'max-width: {{SIZE}}{{UNIT}};',
			),
			'separator' => 'after',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'search_items_typography',
			'selector' => '{{WRAPPER}} .m7sf-filter-items-search__input',
		),
		array(),
	),
	array(
		'control',
		'search_items_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-search__input' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-search__input::placeholder' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-search__input:-ms-input-placeholder' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-search__input::-ms-input-placeholder' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'search_items_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-search__input' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'search_input_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-filter-items-search__input',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'search_input_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-search__input' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'search_input_box_shadow',
			'selector' => '{{WRAPPER}} .m7sf-filter-items-search__input',
		),
		array(),
	),
	array(
		'responsive',
		'search_input_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-search__input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'search_input_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-search' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'after',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'search_remove',
		array(
			'label' => 'Verwijderen',
			'type' => 'heading',
		),
		array(),
	),
	array(
		'responsive',
		'search_remove_size',
		array(
			'label' => 'Grootte',
			'type' => 'slider',
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 50,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-search__clear' => 'font-size: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'search_remove_horizontal_offset',
		array(
			'label' => 'Horizontale verschuiving',
			'type' => 'slider',
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 30,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-search__clear' => 'right: {{SIZE}}{{UNIT}};',
				'.rtl {{WRAPPER}} .m7sf-filter-items-search__clear' => 'right: initial; left: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'tabs',
		'search_remove_style_tabs',
		array(),
	),
	array(
		'tab',
		'search_remove_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'search_remove_normal_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-search__clear' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'search_remove_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'search_remove_hover_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-search__clear:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'end_section',
	),
	array(
		'section',
		'more_less_style_section',
		array(
			'label' => 'Meer/minder-knop',
			'tab' => 'style',
			'condition' => array(
				'moreless_enabled' => 'yes',
			),
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'more_less_button_typography',
			'global' => array(
				'default' => 'globals/typography?id=primary',
			),
			'selector' => '{{WRAPPER}} .m7sf-filter-items-moreless__toggle',
		),
		array(),
	),
	array(
		'tabs',
		'more_less_button_style_tabs',
		array(),
	),
	array(
		'tab',
		'more_less_button_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'more_less_button_normal_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-moreless__toggle' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'more_less_button_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-moreless__toggle' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'more_less_button_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'more_less_button_hover_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-moreless__toggle:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'more_less_button_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-moreless__toggle:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'more_less_button_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-moreless__toggle:hover' => 'border-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'more_less_button_border',
			'label' => 'Rand knop',
			'selector' => '{{WRAPPER}} .m7sf-filter-items-moreless__toggle',
		),
		array(),
	),
	array(
		'control',
		'more_less_button_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-moreless__toggle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'more_less_button_shadow',
			'selector' => '{{WRAPPER}} .m7sf-filter-items-moreless__toggle',
		),
		array(),
	),
	array(
		'responsive',
		'more_less_button_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-moreless__toggle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'more_less_heading',
		array(
			'label' => 'Houder',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'more_less_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-moreless' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'more_less_border',
			'selector' => '{{WRAPPER}} .m7sf-filter-items-moreless',
		),
		array(),
	),
	array(
		'responsive',
		'more_less_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-moreless' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'more_less_button_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'toggle' => false,
			'default' => 'left',
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'separator' => 'before',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-moreless' => 'text-align: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'dropdown_style_section',
		array(
			'label' => 'Uitklaplijst',
			'tab' => 'style',
			'condition' => array(
				'dropdown_enabled' => 'yes',
			),
		),
	),
	array(
		'responsive',
		'dropdown_width',
		array(
			'label' => 'Breedte',
			'type' => 'slider',
			'size_units' => array(
				'%',
				'px',
			),
			'range' => array(
				'%' => array(
					'min' => 10,
					'max' => 100,
				),
				'px' => array(
					'min' => 50,
					'max' => 500,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown' => 'max-width: {{SIZE}}{{UNIT}}',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'dropdown_label_heading',
		array(
			'label' => 'Label',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'dropdown_label_typography',
			'selector' => '{{WRAPPER}} .m7sf-filter-items-dropdown__label',
		),
		array(),
	),
	array(
		'control',
		'dropdown_label_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'default' => '',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__label' => 'color: {{VALUE}};',
			),
		),
		array(),
	),
	array(
		'control',
		'dropdown_label_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__label' => 'background-color: {{VALUE}};',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'dropdown_label_border',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-filter-items-dropdown__label',
		),
		array(),
	),
	array(
		'control',
		'dropdown_label_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__label' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'dropdown_label_box_shadow',
			'selector' => '{{WRAPPER}} .m7sf-filter-items-dropdown__label',
		),
		array(),
	),
	array(
		'responsive',
		'dropdown_label_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'em',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'dropdown_active_items_heading',
		array(
			'label' => 'Gekozen opties',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'responsive',
		'dropdown_active_items_offset',
		array(
			'label' => 'Afstand',
			'type' => 'slider',
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 40,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__active' => 'margin: -{{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__active__item' => 'margin: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'dropdown_active_item_typography',
			'selector' => '{{WRAPPER}} .m7sf-filter-items-dropdown__active__item',
		),
		array(),
	),
	array(
		'tabs',
		'dropdown_active_item_style_tabs',
		array(),
	),
	array(
		'tab',
		'dropdown_active_item_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'dropdown_active_item_normal_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__active__item' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'dropdown_active_item_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__active__item' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'dropdown_active_item_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'dropdown_active_item_hover_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__active__item:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'dropdown_active_item_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__active__item:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'dropdown_active_item_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__active__item:hover' => 'border-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'dropdown_active_item_border',
			'label' => 'Rand',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-filter-items-dropdown__active__item',
		),
		array(),
	),
	array(
		'control',
		'dropdown_active_item_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__active__item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'responsive',
		'dropdown_active_item_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__active__item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'dropdown_n_selected_heading',
		array(
			'label' => 'Aantal gekozen',
			'type' => 'heading',
			'separator' => 'before',
			'condition' => array(
				'dropdown_n_selected_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'dropdown_n_selected_typography',
			'selector' => '{{WRAPPER}} .m7sf-filter-items-dropdown__n-selected',
			'condition' => array(
				'dropdown_n_selected_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'dropdown_n_selected_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__n-selected' => 'color: {{VALUE}}',
			),
			'condition' => array(
				'dropdown_n_selected_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'responsive',
		'dropdown_n_selected_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__n-selected' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'condition' => array(
				'dropdown_n_selected_enabled' => 'yes',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'dropdown_body_heading',
		array(
			'label' => 'Inhoud uitklaplijst',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'responsive',
		'dropdown_body_offset',
		array(
			'label' => 'Afstand',
			'type' => 'slider',
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 100,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__body' => 'margin-top: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-dropdown-position-top .m7sf-filter-items-dropdown__body' => 'margin-top: -{{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'dropdown_body_border',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-filter-items-dropdown__body',
		),
		array(),
	),
	array(
		'control',
		'dropdown_body_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__body' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'control',
		'dropdown_body_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__body' => 'background-color: {{VALUE}};',
			),
		),
		array(),
	),
	array(
		'responsive',
		'dropdown_body_items_padding',
		array(
			'label' => 'Binnenruimte opties',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'em',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-checkboxes-list-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'dropdown_footer_heading',
		array(
			'label' => 'Voet uitklaplijst',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'dropdown_footer_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__footer' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'dropdown_footer_border',
			'selector' => '{{WRAPPER}} .m7sf-filter-items-dropdown__footer',
		),
		array(),
	),
	array(
		'responsive',
		'dropdown_footer_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__footer' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'dropdown_footer_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__footer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'dropdown_footer_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'toggle' => false,
			'default' => 'right',
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'separator' => 'before',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-items-dropdown__footer' => 'justify-content: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_label_style',
		array(
			'label' => 'Label',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'label_typography',
			'selector' => '{{WRAPPER}} .m7sf-filter-label',
		),
		array(),
	),
	array(
		'control',
		'label_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'label_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-filter-label',
		),
		array(),
	),
	array(
		'control',
		'label_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'responsive',
		'label_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'label_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'label_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'separator' => 'before',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'text-align: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_filter_apply_button_style',
		array(
			'label' => 'Knop',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'filter_apply_button_typography',
			'global' => array(
				'default' => 'globals/typography?id=primary',
			),
			'selector' => '{{WRAPPER}} .m7sf-apply-filters__button, {{WRAPPER}} .m7sf-filter-items-dropdown__apply-button',
		),
		array(),
	),
	array(
		'tabs',
		'filter_apply_button_style_tabs',
		array(),
	),
	array(
		'tab',
		'filter_apply_button_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'filter_apply_button_normal_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'background-color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'filter_apply_button_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'filter_apply_button_hover_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button:hover' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button:hover' => 'background-color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button:hover' => 'border-color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button:hover' => 'border-color: {{VALUE}}',
			),
			'condition' => array(
				'filter_apply_button_border_border!' => '',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'filter_apply_button_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-apply-filters__button, {{WRAPPER}} .m7sf-filter-items-dropdown__apply-button',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'filter_apply_button_shadow',
			'selector' => '{{WRAPPER}} .m7sf-apply-filters__button, {{WRAPPER}} .m7sf-filter-items-dropdown__apply-button',
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'flex-start' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'flex-end' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
				'stretch' => array(
					'title' => 'Uitrekken',
					'icon' => 'eicon-text-align-justify',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'align-self: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_counter_style',
		array(
			'label' => 'Teller',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'counter_position',
		array(
			'label' => 'Positie',
			'type' => 'choose',
			'toggle' => false,
			'label_block' => false,
			'default' => 'initial',
			'options' => array(
				'initial' => array(
					'title' => 'Standaard',
					'icon' => 'eicon-justify-center-h',
				),
				'auto' => array(
					'title' => 'Ruimte ertussen',
					'icon' => 'eicon-justify-space-between-h',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-counter' => 'margin-left: {{VALUE}};',
				'.rtl {{WRAPPER}} .m7sf-filters-counter' => 'margin-right: {{VALUE}};',
			),
			'condition' => array(
				'filters_position' => 'block',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'counter_typography',
			'selector' => '{{WRAPPER}} .m7sf-filters-counter',
		),
		array(),
	),
	array(
		'responsive',
		'counter_offset',
		array(
			'label' => 'Horizontale verschuiving',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 30,
				),
			),
			'default' => array(
				'size' => 5,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-counter' => 'padding-left: {{SIZE}}{{UNIT}};',
				'.rtl {{WRAPPER}} .m7sf-filters-counter' => 'padding-right: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'tabs',
		'counter_style_tabs',
		array(),
	),
	array(
		'tab',
		'counter_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'counter_normal_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-counter' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'counter_checked_styles',
		array(
			'label' => 'Gekozen',
		),
	),
	array(
		'control',
		'counter_checked_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-row input:checked ~ .m7sf-checkboxes-list__button .m7sf-filters-counter' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-row input:checked ~ .m7sf-radio-list__button .m7sf-filters-counter' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-row input:checked ~ .m7sf-color-image-list__button .m7sf-filters-counter' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_group_filters_style',
		array(
			'label' => 'Gegroepeerde filters',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'group_filters_vertical_offset',
		array(
			'label' => 'Verticale ruimte',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 100,
				),
			),
			'default' => array(
				'size' => 10,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter+.m7sf-filter' => 'margin-top: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-select[data-hierarchical="1"] + .m7sf-select[data-hierarchical="1"]' => 'margin-top: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
);
