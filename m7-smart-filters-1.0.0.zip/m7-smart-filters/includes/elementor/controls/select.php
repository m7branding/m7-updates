<?php
/**
 * Elementor-instellingen van het M7-widget "select": zelfde sleutels, standaarden, selectors en
 * volgorde als JetSmartFilters 3.7.0 (gegenereerd door tools/jsf-controls/build.py, niet met de hand wijzigen).
 *
 * @package M7SF
 */

defined( 'ABSPATH' ) || exit;

return array(
	array(
		'section',
		'section_general',
		array(
			'label' => 'Inhoud',
		),
	),
	array(
		'control',
		'filter_id',
		array(
			'label' => 'Kies filter',
			'label_block' => true,
			'type' => 'jet-query',
			'multiple' => true,
			'default' => '',
			'query_type' => 'post',
			'query' => array(
				'post_type' => 'jet-smart-filters',
				'posts_per_page' => -1,
				'meta_query' => array(
					array(
						'key' => '_filter_type',
						'value' => 'select',
						'compare' => '=',
					),
				),
			),
		),
		array(),
	),
	array(
		'control',
		'content_provider',
		array(
			'label' => 'Dit filter is voor',
			'type' => 'select',
			'default' => '',
			'options' => array(
				'' => 'Kies…',
				'epro-archive-products' => 'Elementor Pro Archive Products',
				'epro-archive' => 'Elementor Pro Archive',
				'epro-loop-builder' => 'Elementor Pro Loop Grid',
				'epro-portfolio' => 'Elementor Pro Portfolio',
				'epro-posts' => 'Elementor Pro Posts',
				'epro-products' => 'Elementor Pro Products',
				'jet-engine-calendar' => 'JetEngine Calendar',
				'jet-engine' => 'JetEngine',
				'jet-woo-products-grid' => 'JetWooBuilder Products Grid',
				'jet-woo-products-list' => 'JetWooBuilder Products List',
				'jsf-listing' => 'JSF Listing',
				'woocommerce-archive' => 'WooCommerce Archive (by JetWooBuilder)',
				'default-woo-archive' => 'Default WooCommerce Archive (Classic)',
				'woocommerce-shortcode' => 'WooCommerce Shortcode',
			),
		),
		array(),
	),
	array(
		'control',
		'epro_posts_notice',
		array(
			'type' => 'raw_html',
			'raw' => 'M7: geef de lijst (Loop Grid / Posts / Products) en dit filter hetzelfde Query-ID.',
			'condition' => array(
				'content_provider' => array(
					'epro-posts',
					'epro-portfolio',
				),
			),
		),
		array(),
	),
	array(
		'control',
		'apply_type',
		array(
			'label' => 'Manier van toepassen',
			'type' => 'select',
			'default' => 'ajax',
			'options' => array(
				'ajax' => 'AJAX',
				'reload' => 'Pagina herladen',
				'mixed' => 'Gemengd',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_on',
		array(
			'label' => 'Toepassen bij',
			'type' => 'select',
			'default' => 'value',
			'options' => array(
				'value' => 'Elke wijziging',
				'submit' => 'Klik op toepassen-knop',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_button',
		array(
			'label' => 'Toepassen-knop tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
			'condition' => array(
				'apply_on' => 'submit',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_button_text',
		array(
			'label' => 'Tekst toepassen-knop',
			'type' => 'text',
			'default' => 'Apply filter',
			'condition' => array(
				'apply_on' => 'submit',
				'apply_button' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'show_label',
		array(
			'label' => 'Filterlabel tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
		),
		array(),
	),
	array(
		'control',
		'query_id',
		array(
			'label' => 'Query-ID',
			'type' => 'text',
			'label_block' => true,
			'description' => 'Set unique query ID if you use multiple widgets of same provider on the page. Same ID you need to set for filtered widget.',
		),
		array(),
	),
	array(
		'control',
		'query_id_wc_shortcode_notice',
		array(
			'type' => 'raw_html',
			'raw' => '<b>Query ID</b> for <b>WooCommerce Shortcode</b> must be specified as attribute class: [products class="query_id"]',
			'condition' => array(
				'content_provider' => array(
					'woocommerce-shortcode',
				),
			),
		),
		array(),
	),
	array(
		'control',
		'additional_providers_enabled',
		array(
			'label' => 'Extra lijsten',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => 'no',
		),
		array(),
	),
	array(
		'control',
		'additional_providers_list',
		array(
			'label' => 'Lijst met extra lijsten',
			'type' => 'repeater',
			'fields' => array(
				'_id' => array(
					'type' => 'hidden',
					'tab' => 'content',
					'name' => '_id',
					'default' => '',
				),
				'additional_provider' => array(
					'type' => 'select',
					'tab' => 'content',
					'default' => '',
					'name' => 'additional_provider',
				),
				'additional_query_id' => array(
					'type' => 'text',
					'tab' => 'content',
					'name' => 'additional_query_id',
					'default' => '',
				),
			),
			'title_field' => '{{ additional_provider + ( additional_query_id ? "/" + additional_query_id : "" ) }}',
			'condition' => array(
				'additional_providers_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_indexer_options',
		array(
			'label' => 'Tellers',
		),
	),
	array(
		'control',
		'apply_indexer',
		array(
			'label' => 'Tellers gebruiken',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
		),
		array(),
	),
	array(
		'control',
		'show_counter',
		array(
			'label' => 'Teller tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
			'condition' => array(
				'apply_indexer' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'counter_prefix',
		array(
			'label' => 'Voor de teller',
			'type' => 'text',
			'default' => '(',
			'condition' => array(
				'apply_indexer' => 'yes',
				'show_counter' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'counter_suffix',
		array(
			'label' => 'Na de teller',
			'type' => 'text',
			'default' => ')',
			'condition' => array(
				'apply_indexer' => 'yes',
				'show_counter' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'show_items_rule',
		array(
			'label' => 'Als optie leeg is',
			'type' => 'select',
			'default' => 'show',
			'options' => array(
				'show' => 'Tonen',
				'hide' => 'Verbergen',
				'disable' => 'Uitschakelen',
			),
			'condition' => array(
				'apply_indexer' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'change_items_rule',
		array(
			'label' => 'Tellers bijwerken',
			'type' => 'select',
			'default' => 'always',
			'options' => array(
				'always' => 'Altijd',
				'never' => 'Nooit',
				'other_changed' => 'Als andere filters wijzigen',
			),
			'condition' => array(
				'apply_indexer' => 'yes',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_content_style',
		array(
			'label' => 'Inhoud',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'content_position',
		array(
			'label' => 'Positie',
			'type' => 'choose',
			'toggle' => false,
			'label_block' => false,
			'options' => array(
				'line' => array(
					'title' => 'Naast elkaar',
					'icon' => 'eicon-ellipsis-h',
				),
				'column' => array(
					'title' => 'Columns',
					'icon' => 'eicon-menu-bar',
				),
			),
			'selectors_dictionary' => array(
				'line' => 'display:flex;',
				'column' => 'display:block;',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-select.m7sf-filter' => '{{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-hierarchy.m7sf-filter .m7sf-select' => '{{VALUE}}',
			),
			'prefix_class' => 'm7sf-smart-filter-content-position-',
			'responsive' => array(),
			'desktop_default' => 'column',
		),
		array(),
	),
	array(
		'responsive',
		'select_width',
		array(
			'label' => 'Breedte keuzelijst',
			'type' => 'slider',
			'size_units' => array(
				'%',
				'px',
			),
			'range' => array(
				'%' => array(
					'min' => 10,
					'max' => 100,
				),
				'px' => array(
					'min' => 50,
					'max' => 400,
				),
			),
			'default' => array(
				'unit' => 'px',
				'size' => 150,
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-select.m7sf-filter .m7sf-select' => 'max-width: {{SIZE}}{{UNIT}}; flex-basis: {{SIZE}}{{UNIT}}',
				'{{WRAPPER}} .m7sf-filter-hierarchy.m7sf-filter .m7sf-select__control' => 'max-width: {{SIZE}}{{UNIT}}; flex-basis: {{SIZE}}{{UNIT}}',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_select_style',
		array(
			'label' => 'Keuzelijst',
			'tab' => 'style',
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'select_typography',
			'selector' => '{{WRAPPER}} .m7sf-select__control',
		),
		array(),
	),
	array(
		'control',
		'select_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'default' => '',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-select__control' => 'color: {{VALUE}};',
			),
		),
		array(),
	),
	array(
		'control',
		'select_disabled_color',
		array(
			'label' => 'Tekstkleur uitgeschakeld',
			'type' => 'color',
			'default' => '',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-select__control option:disabled' => 'color: {{VALUE}};',
			),
			'conditions' => array(
				'terms' => array(
					array(
						'name' => 'apply_indexer',
						'value' => 'yes',
					),
					array(
						'name' => 'show_items_rule',
						'value' => 'disable',
					),
				),
			),
		),
		array(),
	),
	array(
		'control',
		'select_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-select__control' => 'background-color: {{VALUE}};',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'select_border',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-select__control',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'select_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-select__control' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'select_box_shadow',
			'selector' => '{{WRAPPER}} .m7sf-select__control',
		),
		array(),
	),
	array(
		'responsive',
		'select_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'em',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-select__control' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'select_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'selectors_dictionary' => array(
				'left' => 'margin-left: 0; margin-right: auto;',
				'center' => 'margin-left: auto; margin-right: auto;',
				'right' => 'margin-left: auto; margin-right: 0;',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-select' => '{{VALUE}}',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'reset_appearance',
		array(
			'label' => 'Standaardopmaak veld uitzetten',
			'description' => 'Check this option to reset field appearance CSS value. This will make field appearance the same for all browsers',
			'type' => 'switcher',
			'default' => '',
			'separator' => 'before',
			'selectors_dictionary' => array(
				'yes' => '-webkit-appearance: none;',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-select__control' => '{{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_label_style',
		array(
			'label' => 'Label',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'label_typography',
			'selector' => '{{WRAPPER}} .m7sf-filter-label',
		),
		array(),
	),
	array(
		'control',
		'label_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'label_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-filter-label',
		),
		array(),
	),
	array(
		'control',
		'label_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'responsive',
		'label_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'label_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'label_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'separator' => 'before',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'text-align: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_filter_apply_button_style',
		array(
			'label' => 'Knop',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'filter_apply_button_typography',
			'global' => array(
				'default' => 'globals/typography?id=primary',
			),
			'selector' => '{{WRAPPER}} .m7sf-apply-filters__button, {{WRAPPER}} .m7sf-filter-items-dropdown__apply-button',
		),
		array(),
	),
	array(
		'tabs',
		'filter_apply_button_style_tabs',
		array(),
	),
	array(
		'tab',
		'filter_apply_button_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'filter_apply_button_normal_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'background-color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'filter_apply_button_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'filter_apply_button_hover_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button:hover' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button:hover' => 'background-color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button:hover' => 'border-color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button:hover' => 'border-color: {{VALUE}}',
			),
			'condition' => array(
				'filter_apply_button_border_border!' => '',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'filter_apply_button_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-apply-filters__button, {{WRAPPER}} .m7sf-filter-items-dropdown__apply-button',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'filter_apply_button_shadow',
			'selector' => '{{WRAPPER}} .m7sf-apply-filters__button, {{WRAPPER}} .m7sf-filter-items-dropdown__apply-button',
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'flex-start' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'flex-end' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
				'stretch' => array(
					'title' => 'Uitrekken',
					'icon' => 'eicon-text-align-justify',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'align-self: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_group_filters_style',
		array(
			'label' => 'Gegroepeerde filters',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'group_filters_content_position',
		array(
			'label' => 'Positie',
			'type' => 'choose',
			'toggle' => false,
			'label_block' => false,
			'options' => array(
				'line' => array(
					'title' => 'Naast elkaar',
					'icon' => 'eicon-ellipsis-h',
				),
				'column' => array(
					'title' => 'Columns',
					'icon' => 'eicon-menu-bar',
				),
			),
			'selectors_dictionary' => array(
				'line' => 'display:flex; flex-direction:row;',
				'column' => 'display:flex; flex-direction:column;',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-group' => '{{VALUE}}',
			),
			'prefix_class' => 'm7sf-smart-filter-group-position-',
			'responsive' => array(),
			'desktop_default' => 'column',
		),
		array(),
	),
	array(
		'responsive',
		'group_filters_item_width',
		array(
			'label' => 'Breedte per filter',
			'description' => 'Leave blank for auto width',
			'type' => 'slider',
			'size_units' => array(
				'%',
				'px',
			),
			'range' => array(
				'%' => array(
					'min' => 10,
					'max' => 100,
				),
				'px' => array(
					'min' => 50,
					'max' => 500,
				),
			),
			'default' => array(
				'unit' => '%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-group .m7sf-filter' => 'width: {{SIZE}}{{UNIT}}',
				'{{WRAPPER}} .m7sf-filter .m7sf-filters-group .m7sf-select' => 'width: {{SIZE}}{{UNIT}}',
			),
			'condition' => array(
				'group_filters_content_position' => 'line',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'group_filters_wrap',
		array(
			'label' => 'Laten doorlopen',
			'type' => 'switcher',
			'default' => 'no',
			'selectors_dictionary' => array(
				'yes' => 'flex-wrap: wrap;',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-group' => '{{VALUE}}',
			),
			'condition' => array(
				'group_filters_content_position' => 'line',
			),
		),
		array(),
	),
	array(
		'responsive',
		'group_filters_horizontal_offset',
		array(
			'label' => 'Horizontale ruimte',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 100,
				),
			),
			'default' => array(
				'size' => 10,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-group' => 'margin-left: calc(-{{SIZE}}{{UNIT}}/2); margin-right: calc(-{{SIZE}}{{UNIT}}/2);',
				'{{WRAPPER}} .m7sf-filters-group .m7sf-filter' => 'margin-left: calc({{SIZE}}{{UNIT}}/2); margin-right: calc({{SIZE}}{{UNIT}}/2);',
				'{{WRAPPER}} .m7sf-filter .m7sf-filters-group' => 'margin-left: calc(-{{SIZE}}{{UNIT}}/2); margin-right: calc(-{{SIZE}}{{UNIT}}/2);',
				'{{WRAPPER}} .m7sf-filter .m7sf-filters-group .m7sf-select' => 'margin-left: calc({{SIZE}}{{UNIT}}/2); margin-right: calc({{SIZE}}{{UNIT}}/2);',
			),
			'condition' => array(
				'group_filters_content_position' => 'line',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'group_filters_vertical_offset',
		array(
			'label' => 'Verticale ruimte',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 100,
				),
			),
			'default' => array(
				'size' => 10,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-group' => 'margin-top: calc(-{{SIZE}}{{UNIT}}/2); margin-bottom: calc(-{{SIZE}}{{UNIT}}/2);',
				'{{WRAPPER}} .m7sf-filters-group .m7sf-filter' => 'margin-top: calc({{SIZE}}{{UNIT}}/2); margin-bottom: calc({{SIZE}}{{UNIT}}/2);',
				'{{WRAPPER}} .m7sf-filter .m7sf-filters-group' => 'margin-top: calc(-{{SIZE}}{{UNIT}}/2); margin-bottom: calc(-{{SIZE}}{{UNIT}}/2);',
				'{{WRAPPER}} .m7sf-filter .m7sf-filters-group .m7sf-select' => 'margin-top: calc({{SIZE}}{{UNIT}}/2); margin-bottom: calc({{SIZE}}{{UNIT}}/2);',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
);
