<?php
/**
 * Elementor-instellingen van het M7-widget "date-range": zelfde sleutels, standaarden, selectors en
 * volgorde als JetSmartFilters 3.7.0 (gegenereerd door tools/jsf-controls/build.py, niet met de hand wijzigen).
 *
 * @package M7SF
 */

defined( 'ABSPATH' ) || exit;

return array(
	array(
		'section',
		'section_general',
		array(
			'label' => 'Inhoud',
		),
	),
	array(
		'control',
		'filter_id',
		array(
			'label' => 'Kies filter',
			'label_block' => true,
			'type' => 'jet-query',
			'multiple' => false,
			'default' => '',
			'query_type' => 'post',
			'query' => array(
				'post_type' => 'jet-smart-filters',
				'posts_per_page' => -1,
				'meta_query' => array(
					array(
						'key' => '_filter_type',
						'value' => 'date-range',
						'compare' => '=',
					),
				),
			),
		),
		array(),
	),
	array(
		'control',
		'content_provider',
		array(
			'label' => 'Dit filter is voor',
			'type' => 'select',
			'default' => '',
			'options' => array(
				'' => 'Kies…',
				'epro-archive-products' => 'Elementor Pro Archive Products',
				'epro-archive' => 'Elementor Pro Archive',
				'epro-loop-builder' => 'Elementor Pro Loop Grid',
				'epro-portfolio' => 'Elementor Pro Portfolio',
				'epro-posts' => 'Elementor Pro Posts',
				'epro-products' => 'Elementor Pro Products',
				'jet-engine-calendar' => 'JetEngine Calendar',
				'jet-engine' => 'JetEngine',
				'jet-woo-products-grid' => 'JetWooBuilder Products Grid',
				'jet-woo-products-list' => 'JetWooBuilder Products List',
				'jsf-listing' => 'JSF Listing',
				'woocommerce-archive' => 'WooCommerce Archive (by JetWooBuilder)',
				'default-woo-archive' => 'Default WooCommerce Archive (Classic)',
				'woocommerce-shortcode' => 'WooCommerce Shortcode',
			),
		),
		array(),
	),
	array(
		'control',
		'epro_posts_notice',
		array(
			'type' => 'raw_html',
			'raw' => 'M7: geef de lijst (Loop Grid / Posts / Products) en dit filter hetzelfde Query-ID.',
			'condition' => array(
				'content_provider' => array(
					'epro-posts',
					'epro-portfolio',
				),
			),
		),
		array(),
	),
	array(
		'control',
		'apply_type',
		array(
			'label' => 'Manier van toepassen',
			'type' => 'select',
			'default' => 'ajax',
			'options' => array(
				'ajax' => 'AJAX',
				'reload' => 'Pagina herladen',
				'mixed' => 'Gemengd',
			),
		),
		array(),
	),
	array(
		'control',
		'hide_apply_button',
		array(
			'label' => 'Toepassen-knop verbergen',
			'type' => 'switcher',
			'default' => '',
			'return_value' => 'yes',
		),
		array(),
	),
	array(
		'control',
		'apply_button_text',
		array(
			'label' => 'Tekst toepassen-knop',
			'type' => 'text',
			'default' => 'Apply',
			'condition' => array(
				'hide_apply_button!' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_button_icon',
		array(
			'label' => 'Icoon toepassen-knop',
			'label_block' => true,
			'type' => 'icon',
			'default' => '',
			'condition' => array(
				'hide_apply_button!' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'show_label',
		array(
			'label' => 'Filterlabel tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
		),
		array(),
	),
	array(
		'control',
		'query_id',
		array(
			'label' => 'Query-ID',
			'type' => 'text',
			'label_block' => true,
			'description' => 'Set unique query ID if you use multiple widgets of same provider on the page. Same ID you need to set for filtered widget.',
		),
		array(),
	),
	array(
		'control',
		'additional_providers_enabled',
		array(
			'label' => 'Extra lijsten',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => 'no',
		),
		array(),
	),
	array(
		'control',
		'additional_providers_list',
		array(
			'label' => 'Lijst met extra lijsten',
			'type' => 'repeater',
			'fields' => array(
				'_id' => array(
					'type' => 'hidden',
					'tab' => 'content',
					'name' => '_id',
					'default' => '',
				),
				'additional_provider' => array(
					'type' => 'select',
					'tab' => 'content',
					'default' => '',
					'name' => 'additional_provider',
				),
				'additional_query_id' => array(
					'type' => 'text',
					'tab' => 'content',
					'name' => 'additional_query_id',
					'default' => '',
				),
			),
			'title_field' => '{{ additional_provider + ( additional_query_id ? "/" + additional_query_id : "" ) }}',
			'condition' => array(
				'additional_providers_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_date_range_content_style',
		array(
			'label' => 'Inhoud',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'content_position',
		array(
			'label' => 'Positie',
			'type' => 'choose',
			'label_block' => false,
			'options' => array(
				'line' => array(
					'title' => 'Naast elkaar',
					'icon' => 'eicon-ellipsis-h',
				),
				'column' => array(
					'title' => 'Columns',
					'icon' => 'eicon-menu-bar',
				),
			),
			'selectors_dictionary' => array(
				'line' => 'display:flex; flex-direction:row;',
				'column' => 'display:flex; flex-direction:column;',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-date-range .m7sf-date-range' => '{{VALUE}}',
			),
			'prefix_class' => 'm7sf-smart-filter-content-position-',
			'responsive' => array(),
		),
		array(),
	),
	array(
		'responsive',
		'content_date_range_input_width',
		array(
			'label' => 'Breedte invoervelden',
			'type' => 'slider',
			'size_units' => array(
				'px',
				'%',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 500,
				),
				'%' => array(
					'min' => 0,
					'max' => 100,
				),
			),
			'default' => array(
				'size' => 100,
				'unit' => '%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-range__inputs' => 'max-width: {{SIZE}}{{UNIT}}; width:100%;',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'content_line_horizontal_alignment',
		array(
			'label' => 'Horizontale uitlijning',
			'type' => 'choose',
			'options' => array(
				'flex-start' => array(
					'title' => 'Links',
					'icon' => 'eicon-h-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-h-align-center',
				),
				'flex-end' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-h-align-right',
				),
				'space-between' => array(
					'title' => 'Justify',
					'icon' => 'eicon-h-align-stretch',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-date-range .m7sf-date-range' => 'justify-content: {{VALUE}};',
			),
			'condition' => array(
				'content_position' => 'line',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'content_line_vertical_alignment',
		array(
			'label' => 'Verticale uitlijning',
			'type' => 'choose',
			'default' => 'left',
			'options' => array(
				'flex-start' => array(
					'title' => 'Boven',
					'icon' => 'eicon-v-align-top',
				),
				'center' => array(
					'title' => 'Middle',
					'icon' => 'eicon-v-align-middle',
				),
				'flex-end' => array(
					'title' => 'Onder',
					'icon' => 'eicon-v-align-bottom',
				),
				'stretch' => array(
					'title' => 'Uitrekken',
					'icon' => 'eicon-v-align-stretch',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-date-range .m7sf-date-range' => 'align-items: {{VALUE}};',
			),
			'condition' => array(
				'content_position' => 'line',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'content_column_horizontal_alignment',
		array(
			'label' => 'Horizontale uitlijning',
			'type' => 'choose',
			'options' => array(
				'flex-start' => array(
					'title' => 'Links',
					'icon' => 'eicon-h-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-h-align-center',
				),
				'flex-end' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-h-align-right',
				),
				'stretch' => array(
					'title' => 'Uitrekken',
					'icon' => 'eicon-h-align-stretch',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-date-range .m7sf-date-range' => 'align-items: {{VALUE}};',
			),
			'condition' => array(
				'content_position' => 'column',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_calendar_styles',
		array(
			'label' => 'Kalender',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'calendar_offset_top',
		array(
			'label' => 'Verticale verschuiving',
			'type' => 'slider',
			'range' => array(
				'px' => array(
					'min' => -300,
					'max' => 300,
				),
			),
			'default' => array(
				'size' => 10,
			),
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}}.ui-datepicker' => 'margin-top: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'calendar_offset_left',
		array(
			'label' => 'Horizontale verschuiving',
			'type' => 'slider',
			'range' => array(
				'px' => array(
					'min' => -300,
					'max' => 300,
				),
			),
			'default' => array(
				'size' => 0,
			),
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}}.ui-datepicker' => 'margin-left: {{SIZE}}{{UNIT}}',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'calendar_width',
		array(
			'label' => 'Breedte kalender',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 1000,
				),
			),
			'default' => array(
				'size' => 300,
				'unit' => 'px',
			),
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}}.ui-datepicker' => 'width: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'calendar_body_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}}.ui-datepicker' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'calendar_body_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '.m7sf-filter-datepicker-{{ID}}.ui-datepicker',
		),
		array(),
	),
	array(
		'control',
		'calendar_body_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}}.ui-datepicker' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'calendar_body_box_shadow',
			'selector' => '.m7sf-filter-datepicker-{{ID}}.ui-datepicker',
		),
		array(),
	),
	array(
		'responsive',
		'calendar_body_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}}.ui-datepicker' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_calendar_title',
		array(
			'label' => 'Kalendertitel',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'control',
		'calendar_title_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-title' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'calendar_title_typography',
			'selector' => '.m7sf-filter-datepicker-{{ID}} .ui-datepicker-title',
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_calendar_prev_next',
		array(
			'label' => 'Pijlen kalender',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'calendar_prev_next_size',
		array(
			'label' => 'Grootte',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 30,
				),
			),
			'default' => array(
				'size' => 15,
				'unit' => 'px',
			),
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}}.ui-datepicker .ui-datepicker-prev> span' => 'border-width: calc({{SIZE}}{{UNIT}} / 2) calc({{SIZE}}{{UNIT}} / 2) calc({{SIZE}}{{UNIT}} / 2) 0;',
				'.m7sf-filter-datepicker-{{ID}}.ui-datepicker .ui-datepicker-next> span' => 'border-width: calc({{SIZE}}{{UNIT}} / 2) 0 calc({{SIZE}}{{UNIT}} / 2) calc({{SIZE}}{{UNIT}} / 2);',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'calendar_prev_next_normal_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}}.ui-datepicker .ui-datepicker-next> span' => 'border-left-color: {{VALUE}}',
				'.m7sf-filter-datepicker-{{ID}}.ui-datepicker .ui-datepicker-prev> span' => 'border-right-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_prev_next_hover_color',
		array(
			'label' => 'Kleur bij hover',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}}.ui-datepicker .ui-datepicker-next:hover > span' => 'border-left-color: {{VALUE}}',
				'.m7sf-filter-datepicker-{{ID}}.ui-datepicker .ui-datepicker-prev:hover > span' => 'border-right-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_calendar_header',
		array(
			'label' => 'Weekdagen',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'calendar_header_border',
			'label' => 'Rand kop',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar thead',
		),
		array(),
	),
	array(
		'control',
		'calendar_header_background_color',
		array(
			'label' => 'Achtergrond kop',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar thead' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_header_cells_heading',
		array(
			'label' => 'Dag',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'responsive',
		'calendar_header_cells_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
			),
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar thead > tr > th' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'calendar_header_cells_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar thead > tr > th',
		),
		array(),
	),
	array(
		'control',
		'calendar_header_cells_first_border_width',
		array(
			'label' => 'Randbreedte eerste',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
			),
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar thead > tr > th:first-child' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'condition' => array(
				'calendar_header_cells_border_border!' => '',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_header_cells_last_border_width',
		array(
			'label' => 'Randbreedte laatste',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
			),
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar thead > tr > th:last-child' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'condition' => array(
				'calendar_header_cells_border_border!' => '',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_header_cells_content',
		array(
			'label' => 'Inhoud dag',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'calendar_header_cells_content_typography',
			'selector' => '.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar thead > tr > th > span',
		),
		array(),
	),
	array(
		'control',
		'calendar_header_cells_content_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar thead > tr > th > span' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_header_cells_content_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar thead > tr > th > span' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'calendar_header_cells_content_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar thead > tr > th > span',
		),
		array(),
	),
	array(
		'control',
		'calendar_header_cells_content_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar thead > tr > th > span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'responsive',
		'calendar_header_cells_content_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
			),
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar thead > tr > th > span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_calendar_content',
		array(
			'label' => 'Kalenderdagen',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'calendar_content_border',
			'label' => 'Rand inhoud',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody',
		),
		array(),
	),
	array(
		'control',
		'calendar_content_background_color',
		array(
			'label' => 'Achtergrond inhoud',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_content_cells_heading',
		array(
			'label' => 'Dag',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'responsive',
		'calendar_content_cells_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
			),
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'calendar_content_cells_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td',
		),
		array(),
	),
	array(
		'control',
		'calendar_content_cells_first_border_width',
		array(
			'label' => 'Randbreedte eerste',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
			),
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td:first-child' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'condition' => array(
				'calendar_content_cells_border_border!' => '',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_content_cells_last_border_width',
		array(
			'label' => 'Randbreedte laatste',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
			),
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td:last-child' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'condition' => array(
				'calendar_content_cells_border_border!' => '',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_content_cells_content',
		array(
			'label' => 'Inhoud dag',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'calendar_content_cells_content_typography',
			'selector' => '.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td > span,.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td > a',
		),
		array(),
	),
	array(
		'tabs',
		'calendar_content_cells_content_style_tabs',
		array(),
	),
	array(
		'tab',
		'calendar_content_cells_content_default_styles',
		array(
			'label' => 'Standaard',
		),
	),
	array(
		'control',
		'calendar_content_cells_content_default_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td > span' => 'color: {{VALUE}}',
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td > a' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_content_cells_content_default_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td > span' => 'background-color: {{VALUE}}',
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td > a' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'calendar_content_cells_content_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'calendar_content_cells_content_hover_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td > a:hover' => 'color: {{VALUE}}',
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td.ui-datepicker-today > a:hover' => 'color: {{VALUE}}',
				'.m7sf-filter-datepicker-{{ID}}.m7sf-date-period-week-type .ui-datepicker-calendar tbody > tr:hover > td > a' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_content_cells_content_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td > a:hover' => 'background-color: {{VALUE}}',
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td.ui-datepicker-today > a:hover' => 'background-color: {{VALUE}}',
				'.m7sf-filter-datepicker-{{ID}}.m7sf-date-period-week-type .ui-datepicker-calendar tbody > tr:hover > td > a' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_content_cells_content_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td > a:hover' => 'border-color: {{VALUE}}',
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td.ui-datepicker-today > a:hover' => 'border-color: {{VALUE}}',
				'.m7sf-filter-datepicker-{{ID}}.m7sf-date-period-week-type .ui-datepicker-calendar tbody > tr:hover > td > a' => 'border-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'calendar_content_cells_content_active_styles',
		array(
			'label' => 'Actief',
		),
	),
	array(
		'control',
		'calendar_content_cells_content_active_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td > a.ui-state-active' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_content_cells_content_active_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td > a.ui-state-active' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_content_cells_content_active_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td > a.ui-state-active' => 'border-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'calendar_content_cells_content_current_styles',
		array(
			'label' => 'Huidige',
		),
	),
	array(
		'control',
		'calendar_content_cells_content_current_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td.ui-datepicker-today > a' => 'color: {{VALUE}}',
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td.ui-datepicker-today > span' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_content_cells_content_current_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td.ui-datepicker-today > a' => 'background-color: {{VALUE}}',
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td.ui-datepicker-today > span' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_content_cells_content_current_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td.ui-datepicker-today > a' => 'border-color: {{VALUE}}',
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td.ui-datepicker-today > span' => 'border-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'calendar_content_cells_content_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td > span,.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td > a',
		),
		array(),
	),
	array(
		'control',
		'calendar_content_cells_content_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td > span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td > a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'responsive',
		'calendar_content_cells_content_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
			),
			'selectors' => array(
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td > span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'.m7sf-filter-datepicker-{{ID}} .ui-datepicker-calendar tbody > tr > td > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_date_range_input_style',
		array(
			'label' => 'Invoervelden',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'date_range_input_width',
		array(
			'label' => 'Breedte',
			'type' => 'slider',
			'size_units' => array(
				'%',
			),
			'range' => array(
				'%' => array(
					'min' => 0,
					'max' => 50,
				),
			),
			'default' => array(
				'size' => 45,
				'unit' => '%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-range__inputs > input' => 'max-width: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'date_range_input_typography',
			'selector' => '{{WRAPPER}} .m7sf-date-range__inputs > input',
		),
		array(),
	),
	array(
		'control',
		'date_range_input_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-range__inputs > input' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'date_range_input_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-range__inputs > input' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'date_range_input_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-date-range__inputs > input',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'date_range_input_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-range__inputs > input' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'date_range_input_box_shadow',
			'selector' => '{{WRAPPER}} .m7sf-date-range__inputs > input',
		),
		array(),
	),
	array(
		'responsive',
		'date_range_input_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-range__inputs > input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_label_style',
		array(
			'label' => 'Label',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'label_typography',
			'selector' => '{{WRAPPER}} .m7sf-filter-label',
		),
		array(),
	),
	array(
		'control',
		'label_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'label_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-filter-label',
		),
		array(),
	),
	array(
		'responsive',
		'label_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'label_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'label_alignment',
		array(
			'label' => 'Tekstuitlijning',
			'type' => 'choose',
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'text-align: {{VALUE}};',
			),
			'separator' => 'before',
			'condition' => array(
				'content_position' => '',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_filter_apply_button_style',
		array(
			'label' => 'Knop',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'filter_apply_button_typography',
			'selector' => '{{WRAPPER}} .m7sf-date-range__submit',
		),
		array(),
	),
	array(
		'tabs',
		'filter_apply_button_style_tabs',
		array(),
	),
	array(
		'tab',
		'filter_apply_button_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'filter_apply_button_normal_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-range__submit' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-range__submit' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'filter_apply_button_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'filter_apply_button_hover_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-range__submit:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-range__submit:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-range__submit:hover' => 'border-color: {{VALUE}}',
			),
			'condition' => array(
				'filter_apply_button_border_border!' => '',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'filter_apply_button_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-date-range__submit',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-range__submit' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'filter_apply_button_shadow',
			'selector' => '{{WRAPPER}} .m7sf-date-range__submit',
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-range__submit' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-range__submit' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_icon_heading',
		array(
			'label' => 'Icoon',
			'type' => 'heading',
			'separator' => 'before',
			'condition' => array(
				'apply_button_icon!' => '',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_icon_position',
		array(
			'label' => 'Positie',
			'type' => 'choose',
			'label_block' => false,
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-arrow-left',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-arrow-right',
				),
			),
			'toggle' => true,
			'default' => 'left',
			'condition' => array(
				'apply_button_icon!' => '',
			),
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_icon_size',
		array(
			'label' => 'Grootte',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 40,
				),
			),
			'default' => array(
				'size' => 15,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-range__submit > i' => 'font-size: {{SIZE}}{{UNIT}};',
			),
			'condition' => array(
				'apply_button_icon!' => '',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_icon_offset',
		array(
			'label' => 'Ruimte icoon',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 50,
				),
			),
			'default' => array(
				'size' => 0,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .button-icon-position-right .m7sf-date-range__submit > i' => 'margin-left: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .button-icon-position-left .m7sf-date-range__submit > i' => 'margin-right: {{SIZE}}{{UNIT}};',
			),
			'condition' => array(
				'apply_button_icon!' => '',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_icon_normal_color',
		array(
			'label' => 'Standaardkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-range__submit > i' => 'color: {{VALUE}}',
			),
			'condition' => array(
				'apply_button_icon!' => '',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_icon_hover_color',
		array(
			'label' => 'Kleur bij hover',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-range__submit:hover > i' => 'color: {{VALUE}}',
			),
			'condition' => array(
				'apply_button_icon!' => '',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
);
