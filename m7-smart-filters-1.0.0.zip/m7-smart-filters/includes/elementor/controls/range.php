<?php
/**
 * Elementor-instellingen van het M7-widget "range": zelfde sleutels, standaarden, selectors en
 * volgorde als JetSmartFilters 3.7.0 (gegenereerd door tools/jsf-controls/build.py, niet met de hand wijzigen).
 *
 * @package M7SF
 */

defined( 'ABSPATH' ) || exit;

return array(
	array(
		'section',
		'section_general',
		array(
			'label' => 'Inhoud',
		),
	),
	array(
		'control',
		'filter_id',
		array(
			'label' => 'Kies filter',
			'label_block' => true,
			'type' => 'jet-query',
			'multiple' => true,
			'default' => '',
			'query_type' => 'post',
			'query' => array(
				'post_type' => 'jet-smart-filters',
				'posts_per_page' => -1,
				'meta_query' => array(
					array(
						'key' => '_filter_type',
						'value' => 'range',
						'compare' => '=',
					),
				),
			),
		),
		array(),
	),
	array(
		'control',
		'content_provider',
		array(
			'label' => 'Dit filter is voor',
			'type' => 'select',
			'default' => '',
			'options' => array(
				'' => 'Kies…',
				'epro-archive-products' => 'Elementor Pro Archive Products',
				'epro-archive' => 'Elementor Pro Archive',
				'epro-loop-builder' => 'Elementor Pro Loop Grid',
				'epro-portfolio' => 'Elementor Pro Portfolio',
				'epro-posts' => 'Elementor Pro Posts',
				'epro-products' => 'Elementor Pro Products',
				'jet-engine-calendar' => 'JetEngine Calendar',
				'jet-engine' => 'JetEngine',
				'jet-woo-products-grid' => 'JetWooBuilder Products Grid',
				'jet-woo-products-list' => 'JetWooBuilder Products List',
				'jsf-listing' => 'JSF Listing',
				'woocommerce-archive' => 'WooCommerce Archive (by JetWooBuilder)',
				'default-woo-archive' => 'Default WooCommerce Archive (Classic)',
				'woocommerce-shortcode' => 'WooCommerce Shortcode',
			),
		),
		array(),
	),
	array(
		'control',
		'epro_posts_notice',
		array(
			'type' => 'raw_html',
			'raw' => 'M7: geef de lijst (Loop Grid / Posts / Products) en dit filter hetzelfde Query-ID.',
			'condition' => array(
				'content_provider' => array(
					'epro-posts',
					'epro-portfolio',
				),
			),
		),
		array(),
	),
	array(
		'control',
		'apply_type',
		array(
			'label' => 'Manier van toepassen',
			'type' => 'select',
			'default' => 'ajax',
			'options' => array(
				'ajax' => 'AJAX',
				'reload' => 'Pagina herladen',
				'mixed' => 'Gemengd',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_on',
		array(
			'label' => 'Toepassen bij',
			'type' => 'select',
			'default' => 'value',
			'options' => array(
				'value' => 'Elke wijziging',
				'submit' => 'Klik op toepassen-knop',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_button',
		array(
			'label' => 'Toepassen-knop tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
			'condition' => array(
				'apply_on' => 'submit',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_button_text',
		array(
			'label' => 'Tekst toepassen-knop',
			'type' => 'text',
			'default' => 'Apply filter',
			'condition' => array(
				'apply_on' => 'submit',
				'apply_button' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'show_label',
		array(
			'label' => 'Filterlabel tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
		),
		array(),
	),
	array(
		'control',
		'query_id',
		array(
			'label' => 'Query-ID',
			'type' => 'text',
			'label_block' => true,
			'description' => 'Set unique query ID if you use multiple widgets of same provider on the page. Same ID you need to set for filtered widget.',
		),
		array(),
	),
	array(
		'control',
		'query_id_wc_shortcode_notice',
		array(
			'type' => 'raw_html',
			'raw' => '<b>Query ID</b> for <b>WooCommerce Shortcode</b> must be specified as attribute class: [products class="query_id"]',
			'condition' => array(
				'content_provider' => array(
					'woocommerce-shortcode',
				),
			),
		),
		array(),
	),
	array(
		'control',
		'additional_providers_enabled',
		array(
			'label' => 'Extra lijsten',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => 'no',
		),
		array(),
	),
	array(
		'control',
		'additional_providers_list',
		array(
			'label' => 'Lijst met extra lijsten',
			'type' => 'repeater',
			'fields' => array(
				'_id' => array(
					'type' => 'hidden',
					'tab' => 'content',
					'name' => '_id',
					'default' => '',
				),
				'additional_provider' => array(
					'type' => 'select',
					'tab' => 'content',
					'default' => '',
					'name' => 'additional_provider',
				),
				'additional_query_id' => array(
					'type' => 'text',
					'tab' => 'content',
					'name' => 'additional_query_id',
					'default' => '',
				),
			),
			'title_field' => '{{ additional_provider + ( additional_query_id ? "/" + additional_query_id : "" ) }}',
			'condition' => array(
				'additional_providers_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_slider_style',
		array(
			'label' => 'Schuifje',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'slider_stroke',
		array(
			'label' => 'Lijn',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 1,
					'max' => 20,
				),
			),
			'default' => array(
				'size' => 4,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__slider__track' => 'height: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'tabs',
		'slider_style_tabs',
		array(),
	),
	array(
		'tab',
		'slider_default_styles',
		array(
			'label' => 'Standaard',
		),
	),
	array(
		'control',
		'slider_background_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__slider__track' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'slider_range_styles',
		array(
			'label' => 'Bereik',
		),
	),
	array(
		'control',
		'slider_range_background_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__slider__track__range' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'slider_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-range__slider__track',
		),
		array(),
	),
	array(
		'control',
		'slider_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__slider__track' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'control',
		'range_points_heading',
		array(
			'label' => 'Bereikstreepjes',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'responsive',
		'range_points_width',
		array(
			'label' => 'Breedte streepjes',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 30,
				),
			),
			'default' => array(
				'size' => 16,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__slider__input::-webkit-slider-thumb' => 'width: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-range__slider__input::-moz-range-thumb' => 'width: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-range__slider__input::-ms-thumb' => 'width: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'range_points_height',
		array(
			'label' => 'Hoogte streepjes',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 30,
				),
			),
			'default' => array(
				'size' => 16,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__slider__input' => 'height: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-range__slider__input::-webkit-slider-thumb' => 'height: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-range__slider__input::-moz-range-thumb' => 'height: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-range__slider__input::-ms-thumb' => 'height: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'range_points_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__slider__input::-webkit-slider-thumb' => 'background-color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-range__slider__input::-moz-range-thumb' => 'background-color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-range__slider__input::-ms-thumb' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'range_points_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-range__slider__input::-webkit-slider-thumb',
		),
		array(),
	),
	array(
		'control',
		'range_points_border_pseudo_classes',
		array(
			'type' => 'hidden',
			'default' => 'style',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__slider__input::-moz-range-thumb' => 'border-style: {{range_points_border_border.VALUE}}; border-width: {{range_points_border_width.TOP}}{{range_points_border_width.UNIT}} {{range_points_border_width.RIGHT}}{{range_points_border_width.UNIT}} {{range_points_border_width.BOTTOM}}{{range_points_border_width.UNIT}} {{range_points_border_width.LEFT}}{{range_points_border_width.UNIT}}; border-color: {{range_points_border_color.VALUE}}',
				'{{WRAPPER}} .m7sf-range__slider__input::-ms-thumb' => 'border-style: {{range_points_border_border.VALUE}}; border-width: {{range_points_border_width.TOP}}{{range_points_border_width.UNIT}} {{range_points_border_width.RIGHT}}{{range_points_border_width.UNIT}} {{range_points_border_width.BOTTOM}}{{range_points_border_width.UNIT}} {{range_points_border_width.LEFT}}{{range_points_border_width.UNIT}}; border-color: {{range_points_border_color.VALUE}}',
			),
			'condition' => array(
				'range_points_border_border!' => '',
			),
		),
		array(),
	),
	array(
		'control',
		'range_points_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__slider__input::-webkit-slider-thumb' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-range__slider__input::-moz-range-thumb' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-range__slider__input::-ms-thumb' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'range_points_shadow',
			'selector' => '{{WRAPPER}} .m7sf-range__slider__input::-webkit-slider-thumb',
		),
		array(),
	),
	array(
		'control',
		'range_points_shadow_pseudo_classes',
		array(
			'type' => 'hidden',
			'default' => 'style',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__slider__input::-moz-range-thumb' => 'box-shadow: {{range_points_shadow_box_shadow.HORIZONTAL}}px {{range_points_shadow_box_shadow.VERTICAL}}px {{range_points_shadow_box_shadow.BLUR}}px {{range_points_shadow_box_shadow.SPREAD}}px {{range_points_shadow_box_shadow.COLOR}} {{range_points_shadow_box_shadow_position.VALUE}};',
				'{{WRAPPER}} .m7sf-range__slider__input::-ms-thumb' => 'box-shadow: {{range_points_shadow_box_shadow.HORIZONTAL}}px {{range_points_shadow_box_shadow.VERTICAL}}px {{range_points_shadow_box_shadow.BLUR}}px {{range_points_shadow_box_shadow.SPREAD}}px {{range_points_shadow_box_shadow.COLOR}} {{range_points_shadow_box_shadow_position.VALUE}};',
			),
			'condition' => array(
				'range_points_shadow_box_shadow_type' => 'yes',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_values_style',
		array(
			'label' => 'Waarden',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'values_typography',
			'selector' => '{{WRAPPER}} .m7sf-range__values',
		),
		array(),
	),
	array(
		'control',
		'values_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__values' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'responsive',
		'values_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__values' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'values_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'default' => 'center',
			'toggle' => false,
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__values' => 'text-align: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_inputs_style',
		array(
			'label' => 'Invoervelden',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'inputs_width',
		array(
			'label' => 'Breedte',
			'type' => 'slider',
			'size_units' => array(
				'px',
				'%',
			),
			'range' => array(
				'px' => array(
					'min' => 100,
					'max' => 1000,
				),
				'%' => array(
					'min' => 0,
					'max' => 100,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__inputs__container' => 'max-width: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'inputs_offset',
		array(
			'label' => 'Ruimte invoervelden',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 100,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__inputs__group:first-child' => 'margin-right: calc({{SIZE}}{{UNIT}}/2);',
				'{{WRAPPER}} .m7sf-range__inputs__group:last-child' => 'margin-left: calc({{SIZE}}{{UNIT}}/2);',
				'.rtl {{WRAPPER}} .m7sf-range__inputs__group:first-child' => 'margin-left: calc({{SIZE}}{{UNIT}}/2); margin-right: 0;',
				'.rtl {{WRAPPER}} .m7sf-range__inputs__group:last-child' => 'margin-right: calc({{SIZE}}{{UNIT}}/2); margin-left: 0;',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'inputs_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__inputs' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'inputs_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'default' => 'center',
			'toggle' => false,
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'selectors_dictionary' => array(
				'left' => 'margin-left: 0; margin-right: auto;',
				'center' => 'margin-left: auto; margin-right: auto;',
				'right' => 'margin-left: auto; margin-right: 0;',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__inputs__container' => '{{VALUE}}',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'input_heading',
		array(
			'label' => 'Invoerveld',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'input_typography',
			'selector' => '{{WRAPPER}} .m7sf-range__inputs__group',
		),
		array(),
	),
	array(
		'control',
		'input_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__inputs__group' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'input_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__inputs__group' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'input_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-range__inputs__group',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'input_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__inputs__group' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'input_box_shadow',
			'selector' => '{{WRAPPER}} .m7sf-range__inputs__group',
		),
		array(),
	),
	array(
		'responsive',
		'input_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__inputs__group input' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'input_text_heading',
		array(
			'label' => 'Voor-/achtervoegsel',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'input_text_typography',
			'selector' => '{{WRAPPER}} .m7sf-range__inputs__group__text',
		),
		array(),
	),
	array(
		'control',
		'input_text_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__inputs__group__text' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'input_text_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__inputs__group__text' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'responsive',
		'input_text_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-range__inputs__group__text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_label_style',
		array(
			'label' => 'Label',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'label_typography',
			'selector' => '{{WRAPPER}} .m7sf-filter-label',
		),
		array(),
	),
	array(
		'control',
		'label_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'label_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-filter-label',
		),
		array(),
	),
	array(
		'control',
		'label_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'responsive',
		'label_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'label_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'label_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'separator' => 'before',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'text-align: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_filter_apply_button_style',
		array(
			'label' => 'Knop',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'filter_apply_button_typography',
			'global' => array(
				'default' => 'globals/typography?id=primary',
			),
			'selector' => '{{WRAPPER}} .m7sf-apply-filters__button, {{WRAPPER}} .m7sf-filter-items-dropdown__apply-button',
		),
		array(),
	),
	array(
		'tabs',
		'filter_apply_button_style_tabs',
		array(),
	),
	array(
		'tab',
		'filter_apply_button_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'filter_apply_button_normal_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'background-color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'filter_apply_button_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'filter_apply_button_hover_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button:hover' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button:hover' => 'background-color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button:hover' => 'border-color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button:hover' => 'border-color: {{VALUE}}',
			),
			'condition' => array(
				'filter_apply_button_border_border!' => '',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'filter_apply_button_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-apply-filters__button, {{WRAPPER}} .m7sf-filter-items-dropdown__apply-button',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'filter_apply_button_shadow',
			'selector' => '{{WRAPPER}} .m7sf-apply-filters__button, {{WRAPPER}} .m7sf-filter-items-dropdown__apply-button',
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'flex-start' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'flex-end' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
				'stretch' => array(
					'title' => 'Uitrekken',
					'icon' => 'eicon-text-align-justify',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'align-self: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_group_filters_style',
		array(
			'label' => 'Gegroepeerde filters',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'group_filters_content_position',
		array(
			'label' => 'Positie',
			'type' => 'choose',
			'label_block' => false,
			'options' => array(
				'line' => array(
					'title' => 'Naast elkaar',
					'icon' => 'eicon-ellipsis-h',
				),
				'column' => array(
					'title' => 'Columns',
					'icon' => 'eicon-menu-bar',
				),
			),
			'selectors_dictionary' => array(
				'line' => 'display:flex; flex-direction:row; justify-content: space-between;',
				'column' => 'display:flex; flex-direction:column;',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-group' => '{{VALUE}}',
			),
			'prefix_class' => 'm7sf-smart-filter-group-position-',
			'responsive' => array(),
		),
		array(),
	),
	array(
		'responsive',
		'group_filters_width',
		array(
			'label' => 'Breedte',
			'type' => 'slider',
			'size_units' => array(
				'%',
				'px',
			),
			'range' => array(
				'%' => array(
					'min' => 10,
					'max' => 100,
				),
				'px' => array(
					'min' => 50,
					'max' => 400,
				),
			),
			'default' => array(
				'unit' => '%',
				'size' => 100,
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-group .m7sf-filter' => 'width: {{SIZE}}{{UNIT}}; max-width: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'group_filters_vertical_offset',
		array(
			'label' => 'Verticale ruimte',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 100,
				),
			),
			'default' => array(
				'size' => 10,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-group .m7sf-filter+.m7sf-filter' => 'margin-top: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-select[data-hierarchical="1"] + .m7sf-select[data-hierarchical="1"]' => 'margin-top: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
);
