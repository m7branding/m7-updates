<?php
/**
 * Elementor-instellingen van het M7-widget "remove-filters": zelfde sleutels, standaarden, selectors en
 * volgorde als JetSmartFilters 3.7.0 (gegenereerd door tools/jsf-controls/build.py, niet met de hand wijzigen).
 *
 * @package M7SF
 */

defined( 'ABSPATH' ) || exit;

return array(
	array(
		'section',
		'section_general',
		array(
			'label' => 'Inhoud',
		),
	),
	array(
		'control',
		'content_provider',
		array(
			'label' => 'Dit filter is voor',
			'type' => 'select',
			'default' => '',
			'options' => array(
				'' => 'Kies…',
				'epro-archive-products' => 'Elementor Pro Archive Products',
				'epro-archive' => 'Elementor Pro Archive',
				'epro-loop-builder' => 'Elementor Pro Loop Grid',
				'epro-portfolio' => 'Elementor Pro Portfolio',
				'epro-posts' => 'Elementor Pro Posts',
				'epro-products' => 'Elementor Pro Products',
				'jet-engine-calendar' => 'JetEngine Calendar',
				'jet-engine' => 'JetEngine',
				'jet-woo-products-grid' => 'JetWooBuilder Products Grid',
				'jet-woo-products-list' => 'JetWooBuilder Products List',
				'jsf-listing' => 'JSF Listing',
				'woocommerce-archive' => 'WooCommerce Archive (by JetWooBuilder)',
				'default-woo-archive' => 'Default WooCommerce Archive (Classic)',
				'woocommerce-shortcode' => 'WooCommerce Shortcode',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_type',
		array(
			'label' => 'Manier van toepassen',
			'type' => 'select',
			'default' => 'ajax',
			'options' => array(
				'ajax' => 'AJAX',
				'reload' => 'Pagina herladen',
			),
		),
		array(),
	),
	array(
		'control',
		'remove_filters_text',
		array(
			'label' => 'Tekst wisknop',
			'type' => 'text',
			'default' => 'Remove filters',
		),
		array(),
	),
	array(
		'control',
		'query_id',
		array(
			'label' => 'Query-ID',
			'type' => 'text',
			'label_block' => true,
			'description' => 'Set unique query ID if you use multiple widgets of same provider on the page. Same ID you need to set for filtered widget.',
		),
		array(),
	),
	array(
		'control',
		'additional_providers_enabled',
		array(
			'label' => 'Extra lijsten',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => 'no',
		),
		array(),
	),
	array(
		'control',
		'additional_providers_list',
		array(
			'label' => 'Lijst met extra lijsten',
			'type' => 'repeater',
			'fields' => array(
				'_id' => array(
					'type' => 'hidden',
					'tab' => 'content',
					'name' => '_id',
					'default' => '',
				),
				'additional_provider' => array(
					'type' => 'select',
					'tab' => 'content',
					'default' => '',
					'name' => 'additional_provider',
				),
				'additional_query_id' => array(
					'type' => 'text',
					'tab' => 'content',
					'name' => 'additional_query_id',
					'default' => '',
				),
			),
			'title_field' => '{{ additional_provider + ( additional_query_id ? "/" + additional_query_id : "" ) }}',
			'condition' => array(
				'additional_providers_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_remove_filters_button_style',
		array(
			'label' => 'Knop',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'remove_filters_button_typography',
			'global' => array(
				'default' => 'globals/typography?id=primary',
			),
			'selector' => '{{WRAPPER}} .m7sf-remove-all-filters__button',
		),
		array(),
	),
	array(
		'tabs',
		'remove_filters_button_style_tabs',
		array(),
	),
	array(
		'tab',
		'remove_filters_button_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'remove_filters_button_normal_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-remove-all-filters__button' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'remove_filters_button_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-remove-all-filters__button' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'remove_filters_button_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'remove_filters_button_hover_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-remove-all-filters__button:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'remove_filters_button_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-remove-all-filters__button:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'remove_filters_button_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-remove-all-filters__button:hover' => 'border-color: {{VALUE}}',
			),
			'condition' => array(
				'remove_filters_button_border_border!' => '',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'remove_filters_button_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-remove-all-filters__button',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'remove_filters_button_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-remove-all-filters__button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'remove_filters_button_shadow',
			'selector' => '{{WRAPPER}} .m7sf-remove-all-filters__button',
		),
		array(),
	),
	array(
		'responsive',
		'remove_filters_button_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-remove-all-filters__button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'remove_filters_button_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-remove-all-filters__button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'remove_filters_button_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'flex-start' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'flex-end' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
				'stretch' => array(
					'title' => 'Uitrekken',
					'icon' => 'eicon-text-align-justify',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-remove-all-filters__button' => '-webkit-align-self:{{VALUE}}; align-self:{{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
);
