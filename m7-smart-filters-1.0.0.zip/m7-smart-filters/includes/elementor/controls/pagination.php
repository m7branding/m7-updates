<?php
/**
 * Elementor-instellingen van het M7-widget "pagination": zelfde sleutels, standaarden, selectors en
 * volgorde als JetSmartFilters 3.7.0 (gegenereerd door tools/jsf-controls/build.py, niet met de hand wijzigen).
 *
 * @package M7SF
 */

defined( 'ABSPATH' ) || exit;

return array(
	array(
		'section',
		'section_general',
		array(
			'label' => 'Inhoud',
		),
	),
	array(
		'control',
		'content_provider',
		array(
			'label' => 'Paginering voor:',
			'type' => 'select',
			'default' => '',
			'options' => array(
				'' => 'Kies…',
				'epro-archive-products' => 'Elementor Pro Archive Products',
				'epro-archive' => 'Elementor Pro Archive',
				'epro-loop-builder' => 'Elementor Pro Loop Grid',
				'epro-portfolio' => 'Elementor Pro Portfolio',
				'epro-posts' => 'Elementor Pro Posts',
				'epro-products' => 'Elementor Pro Products',
				'jet-engine-calendar' => 'JetEngine Calendar',
				'jet-engine' => 'JetEngine',
				'jet-woo-products-grid' => 'JetWooBuilder Products Grid',
				'jet-woo-products-list' => 'JetWooBuilder Products List',
				'jsf-listing' => 'JSF Listing',
				'woocommerce-archive' => 'WooCommerce Archive (by JetWooBuilder)',
				'default-woo-archive' => 'Default WooCommerce Archive (Classic)',
				'woocommerce-shortcode' => 'WooCommerce Shortcode',
			),
		),
		array(),
	),
	array(
		'control',
		'epro_posts_notice',
		array(
			'type' => 'raw_html',
			'raw' => 'M7: geef de lijst (Loop Grid / Posts / Products) en dit filter hetzelfde Query-ID.',
			'condition' => array(
				'content_provider' => array(
					'epro-posts',
					'epro-portfolio',
				),
			),
		),
		array(),
	),
	array(
		'control',
		'apply_type',
		array(
			'label' => 'Manier van toepassen',
			'type' => 'select',
			'default' => 'ajax',
			'options' => array(
				'ajax' => 'AJAX',
				'reload' => 'Pagina herladen',
				'mixed' => 'Gemengd',
			),
		),
		array(),
	),
	array(
		'control',
		'query_id',
		array(
			'label' => 'Query-ID',
			'type' => 'text',
			'label_block' => true,
			'description' => 'Set unique query ID if you use multiple widgets of same provider on the page. Same ID you need to set for filtered widget.',
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_controls',
		array(
			'label' => 'Bediening',
		),
	),
	array(
		'control',
		'enable_items',
		array(
			'label' => 'Paginanummers tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => 'yes',
		),
		array(),
	),
	array(
		'control',
		'pages_center_offset',
		array(
			'label' => 'Ruimte midden',
			'description' => 'Set number of items to either side of current page, not including current page.Set 0 to show all items.',
			'type' => 'number',
			'default' => 0,
			'min' => 0,
			'max' => 50,
			'step' => 1,
			'condition' => array(
				'enable_items' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'pages_end_offset',
		array(
			'label' => 'Ruimte rand',
			'description' => 'Set number of items on either the start and the end list edges.',
			'type' => 'number',
			'default' => 0,
			'min' => 0,
			'max' => 50,
			'step' => 1,
			'condition' => array(
				'enable_items' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'enable_prev_next',
		array(
			'label' => 'Vorige/volgende tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => 'yes',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'prev_text',
		array(
			'label' => 'Tekst vorige',
			'type' => 'text',
			'default' => 'Prev',
			'condition' => array(
				'enable_prev_next' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'next_text',
		array(
			'label' => 'Tekst volgende',
			'type' => 'text',
			'default' => 'Next',
			'condition' => array(
				'enable_prev_next' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'hide_inactive_prev_next',
		array(
			'label' => 'Inactieve verbergen',
			'type' => 'switcher',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => 'yes',
			'condition' => array(
				'enable_prev_next' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'enable_load_more',
		array(
			'label' => 'Meer laden tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'load_more_text',
		array(
			'label' => 'Tekst meer laden',
			'type' => 'text',
			'default' => 'Load More',
			'condition' => array(
				'enable_load_more' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'autoscroll',
		array(
			'label' => 'Automatisch scrollen',
			'description' => 'Autoscroll to top of the provider when reloading content via AJAX.',
			'type' => 'switcher',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => 'yes',
			'separator' => 'before',
			'condition' => array(
				'apply_type' => array(
					'ajax',
					'mixed',
				),
			),
			'render_type' => 'none',
		),
		array(),
	),
	array(
		'control',
		'provider_top_offset',
		array(
			'label' => 'Afstand tot lijst',
			'type' => 'number',
			'default' => 0,
			'min' => 0,
			'max' => 999,
			'step' => 1,
			'condition' => array(
				'autoscroll' => 'yes',
			),
			'render_type' => 'none',
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'pagination_style',
		array(
			'label' => 'Paginering',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'control',
		'pagination_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination' => 'background-color: {{VALUE}};',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'pagination_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-filters-pagination',
		),
		array(),
	),
	array(
		'control',
		'pagination_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; overflow:hidden;',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'pagination_shadow',
			'selector' => '{{WRAPPER}} .m7sf-filters-pagination',
		),
		array(),
	),
	array(
		'responsive',
		'pagination_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'pagination_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-pagination' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'pagination_items_style',
		array(
			'label' => 'Opties',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'pagination_items_typography',
			'selector' => '{{WRAPPER}} .m7sf-filters-pagination__link, {{WRAPPER}} .m7sf-filters-pagination__dots',
		),
		array(),
	),
	array(
		'tabs',
		'tabs_pagination_items_style',
		array(),
	),
	array(
		'tab',
		'pagination_items_normal',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'pagination_items_bg_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__link' => 'background-color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filters-pagination__dots' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'pagination_items_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__link' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filters-pagination__dots' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'pagination_items_hover',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'pagination_items_bg_color_hover',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__link:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'pagination_items_color_hover',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__link:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'pagination_items_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'condition' => array(
				'pagination_items_border_border!' => '',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__link:hover' => 'border-color: {{VALUE}};',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'pagination_items_active',
		array(
			'label' => 'Huidige',
		),
	),
	array(
		'control',
		'pagination_items_bg_color_active',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__current .m7sf-filters-pagination__link' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'pagination_items_color_active',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__current .m7sf-filters-pagination__link' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'pagination_items_active_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'condition' => array(
				'pagination_items_border_border!' => '',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__current .m7sf-filters-pagination__link' => 'border-color: {{VALUE}};',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'pagination_items_dots',
		array(
			'label' => 'Puntjes',
		),
	),
	array(
		'control',
		'pagination_items_bg_color_dots',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__dots' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'pagination_items_color_dots',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__dots' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'pagination_items_dots_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'condition' => array(
				'pagination_items_border_border!' => '',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__item .m7sf-filters-pagination__dots' => 'border-color: {{VALUE}};',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'responsive',
		'pagination_items_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
				'em',
			),
			'default' => array(
				'top' => 10,
				'right' => 10,
				'bottom' => 10,
				'left' => 10,
				'isLinked' => true,
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-filters-pagination__dots' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'pagination_items_horizontal_gap',
		array(
			'label' => 'Horizontale ruimte',
			'label_block' => true,
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'default' => array(
				'unit' => 'px',
				'size' => 6,
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 100,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination' => 'column-gap: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'pagination_items_vertical_gap',
		array(
			'label' => 'Verticale ruimte',
			'label_block' => true,
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'default' => array(
				'unit' => 'px',
				'size' => 6,
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 100,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination' => 'row-gap: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'pagination_items_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-filters-pagination__link, {{WRAPPER}} .m7sf-filters-pagination__dots',
		),
		array(),
	),
	array(
		'responsive',
		'pagination_items_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__link' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-filters-pagination__dots' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'pagination_items_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'toggle' => false,
			'default' => 'center',
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination' => 'justify-content: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'pagination_load_more_style',
		array(
			'label' => 'Meer laden',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'pagination_load_more_typography',
			'selector' => '{{WRAPPER}} .m7sf-filters-pagination__load-more .m7sf-filters-pagination__link',
		),
		array(),
	),
	array(
		'tabs',
		'tabs_pagination_load_more_style',
		array(),
	),
	array(
		'tab',
		'pagination_load_more_normal',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'pagination_load_more_bg_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__load-more .m7sf-filters-pagination__link' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'pagination_load_more_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__load-more .m7sf-filters-pagination__link' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'pagination_load_more_hover',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'pagination_load_more_bg_color_hover',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__load-more .m7sf-filters-pagination__link:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'pagination_load_more_color_hover',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__load-more .m7sf-filters-pagination__link:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'pagination_load_more_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'condition' => array(
				'pagination_load_more_border_border!' => '',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__load-more .m7sf-filters-pagination__link:hover' => 'border-color: {{VALUE}};',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'responsive',
		'pagination_load_more_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
				'em',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__load-more .m7sf-filters-pagination__link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'pagination_load_more_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__load-more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'pagination_load_more_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-filters-pagination__load-more .m7sf-filters-pagination__link, {{WRAPPER}} .m7sf-filters-pagination__dots',
		),
		array(),
	),
	array(
		'responsive',
		'pagination_load_more_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__load-more .m7sf-filters-pagination__link' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'pagination_load_more_position',
		array(
			'label' => 'Positie',
			'type' => 'choose',
			'toggle' => false,
			'default' => 'right',
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-order-start',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-order-end',
				),
			),
			'selectors_dictionary' => array(
				'left' => 'order: -1;',
				'right' => 'order: initial;',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filters-pagination__load-more' => '{{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
);
