<?php
/**
 * Elementor-instellingen van het M7-widget "active": zelfde sleutels, standaarden, selectors en
 * volgorde als JetSmartFilters 3.7.0 (gegenereerd door tools/jsf-controls/build.py, niet met de hand wijzigen).
 *
 * @package M7SF
 */

defined( 'ABSPATH' ) || exit;

return array(
	array(
		'section',
		'section_general',
		array(
			'label' => 'Inhoud',
		),
	),
	array(
		'control',
		'content_provider',
		array(
			'label' => 'Actieve filters tonen voor:',
			'type' => 'select',
			'default' => '',
			'options' => array(
				'' => 'Kies…',
				'epro-archive-products' => 'Elementor Pro Archive Products',
				'epro-archive' => 'Elementor Pro Archive',
				'epro-loop-builder' => 'Elementor Pro Loop Grid',
				'epro-portfolio' => 'Elementor Pro Portfolio',
				'epro-posts' => 'Elementor Pro Posts',
				'epro-products' => 'Elementor Pro Products',
				'jet-engine-calendar' => 'JetEngine Calendar',
				'jet-engine' => 'JetEngine',
				'jet-woo-products-grid' => 'JetWooBuilder Products Grid',
				'jet-woo-products-list' => 'JetWooBuilder Products List',
				'jsf-listing' => 'JSF Listing',
				'woocommerce-archive' => 'WooCommerce Archive (by JetWooBuilder)',
				'default-woo-archive' => 'Default WooCommerce Archive (Classic)',
				'woocommerce-shortcode' => 'WooCommerce Shortcode',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_type',
		array(
			'label' => 'Manier van toepassen',
			'type' => 'select',
			'default' => 'ajax',
			'options' => array(
				'ajax' => 'AJAX',
				'reload' => 'Pagina herladen',
			),
		),
		array(),
	),
	array(
		'control',
		'filters_label',
		array(
			'label' => 'Label',
			'type' => 'text',
			'default' => 'Active filters:',
		),
		array(),
	),
	array(
		'control',
		'query_id',
		array(
			'label' => 'Query-ID',
			'type' => 'text',
			'label_block' => true,
			'description' => 'Set unique query ID if you use multiple widgets of same provider on the page. Same ID you need to set for filtered widget.',
		),
		array(),
	),
	array(
		'control',
		'additional_providers_enabled',
		array(
			'label' => 'Extra lijsten',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => 'no',
		),
		array(),
	),
	array(
		'control',
		'additional_providers_list',
		array(
			'label' => 'Lijst met extra lijsten',
			'type' => 'repeater',
			'fields' => array(
				'_id' => array(
					'type' => 'hidden',
					'tab' => 'content',
					'name' => '_id',
					'default' => '',
				),
				'additional_provider' => array(
					'type' => 'select',
					'tab' => 'content',
					'default' => '',
					'name' => 'additional_provider',
				),
				'additional_query_id' => array(
					'type' => 'text',
					'tab' => 'content',
					'name' => 'additional_query_id',
					'default' => '',
				),
			),
			'title_field' => '{{ additional_provider + ( additional_query_id ? "/" + additional_query_id : "" ) }}',
			'condition' => array(
				'additional_providers_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_filters_title_style',
		array(
			'label' => 'Titel',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'filters_title_typography',
			'selector' => '{{WRAPPER}} .m7sf-active-filters__title',
		),
		array(),
	),
	array(
		'control',
		'filters_title_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filters__title' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'responsive',
		'filters_title_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filters__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_filters_styles',
		array(
			'label' => 'Filters',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'filters_position',
		array(
			'label' => 'Opties',
			'type' => 'choose',
			'toggle' => false,
			'label_block' => false,
			'default' => 'row',
			'options' => array(
				'row' => array(
					'title' => 'Naast elkaar',
					'icon' => 'eicon-ellipsis-h',
				),
				'column' => array(
					'title' => 'Onder elkaar',
					'icon' => 'eicon-menu-bar',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-active' => 'flex-direction: {{VALUE}};',
				'{{WRAPPER}} .m7sf-active-filters__list' => 'flex-direction: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filters_space_between_horizontal',
		array(
			'label' => 'Horizontale verschuiving',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 40,
				),
			),
			'default' => array(
				'size' => 5,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter' => 'margin-right: {{SIZE}}{{UNIT}};',
			),
			'condition' => array(
				'filters_position' => 'row',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filters_space_between_vertical',
		array(
			'label' => 'Verticale verschuiving',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 40,
				),
			),
			'default' => array(
				'size' => 5,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter' => 'margin-bottom: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'filters_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filters__list' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'filters_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-active-filters__list',
		),
		array(),
	),
	array(
		'control',
		'filters_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filters__list' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'filters_box_shadow',
			'selector' => '{{WRAPPER}} .m7sf-active-filters__list',
		),
		array(),
	),
	array(
		'responsive',
		'filters_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filters__list' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filters_alignment_column',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'flex-start' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'flex-end' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filters__list' => 'align-items: {{VALUE}};',
			),
			'condition' => array(
				'filters_position' => 'column',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filters_alignment_line',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'flex-start' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'flex-end' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filters__list' => 'justify-content: {{VALUE}};',
			),
			'condition' => array(
				'filters_position' => 'row',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_filters_item',
		array(
			'label' => 'Opties',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'filter_min_width',
		array(
			'label' => 'Minimale breedte',
			'type' => 'slider',
			'size_units' => array(
				'px',
				'%',
			),
			'range' => array(
				'px' => array(
					'min' => 10,
					'max' => 500,
				),
				'%' => array(
					'min' => 0,
					'max' => 100,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter' => 'min-width: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_position',
		array(
			'label' => 'Positie filterinhoud',
			'type' => 'choose',
			'label_block' => false,
			'options' => array(
				'row' => array(
					'title' => 'Naast elkaar',
					'icon' => 'eicon-ellipsis-h',
				),
				'column' => array(
					'title' => 'Onder elkaar',
					'icon' => 'eicon-menu-bar',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter' => 'flex-direction: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_item_content_space_between_h',
		array(
			'label' => 'Ruimte tot inhoud',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 40,
				),
			),
			'default' => array(
				'size' => 5,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter .m7sf-active-filter__label + .m7sf-active-filter__val' => 'margin-left: {{SIZE}}{{UNIT}};',
			),
			'condition' => array(
				'filter_position' => 'row',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_item_content_space_between_v',
		array(
			'label' => 'Ruimte tot inhoud',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 40,
				),
			),
			'default' => array(
				'size' => 5,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter .m7sf-active-filter__label + .m7sf-active-filter__val' => 'margin-top: {{SIZE}}{{UNIT}};',
			),
			'condition' => array(
				'filter_position' => 'column',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'filters_item_typography',
			'selector' => '{{WRAPPER}} .m7sf-active-filter',
		),
		array(),
	),
	array(
		'tabs',
		'filters_item_style_tabs',
		array(),
	),
	array(
		'tab',
		'filters_item_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'filters_item_normal_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filters_item_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'filters_item_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'filters_item_value_hover_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filters_item_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filters_item_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter:hover' => 'border-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'filters_item_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-active-filter',
		),
		array(),
	),
	array(
		'control',
		'filters_item_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'filters_item_box_shadow',
			'selector' => '{{WRAPPER}} .m7sf-active-filter',
		),
		array(),
	),
	array(
		'responsive',
		'filters_item_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'filters_item_label_heading',
		array(
			'label' => 'Label',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'filters_item_label_typography',
			'selector' => '{{WRAPPER}} .m7sf-active-filter__label',
		),
		array(),
	),
	array(
		'tabs',
		'filters_item_label_style_tabs',
		array(),
	),
	array(
		'tab',
		'filters_item_label_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'filters_item_label_normal_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter__label' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'filters_item_label_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'filters_item_label_hover_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter:hover .m7sf-active-filter__label' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'responsive',
		'filters_item_label_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter__label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'filters_item_remove_heading',
		array(
			'label' => 'Verwijderen',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'responsive',
		'filters_item_remove_size',
		array(
			'label' => 'Grootte',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 40,
				),
			),
			'default' => array(
				'size' => 12,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter__remove' => 'font-size: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filters_item_remove_offset_top',
		array(
			'label' => 'Afstand boven',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 40,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter__remove' => 'top: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filters_item_remove_offset_right',
		array(
			'label' => 'Afstand rechts',
			'type' => 'slider',
			'size_units' => array(
				'px',
			),
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 40,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter__remove' => 'right: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'tabs',
		'filters_item_remove_style_tabs',
		array(),
	),
	array(
		'tab',
		'filters_item_remove_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'filters_item_remove_normal_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter__remove' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filters_item_remove_normal_bg_color',
		array(
			'label' => 'Achtergrond',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter__remove' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'filters_item_remove_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'filters_item_remove_hover_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter:hover .m7sf-active-filter__remove' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filters_item_remove_hover_bg_color',
		array(
			'label' => 'Achtergrond',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter:hover .m7sf-active-filter__remove' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filters_item_remove_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter:hover .m7sf-active-filter__remove' => 'border-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'filters_item_remove_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-active-filter__remove',
		),
		array(),
	),
	array(
		'control',
		'filters_item_remove_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter__remove' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'responsive',
		'filters_item_remove_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-active-filter__remove' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
);
