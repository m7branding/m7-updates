<?php
/**
 * Elementor-instellingen van het M7-widget "date-period": zelfde sleutels, standaarden, selectors en
 * volgorde als JetSmartFilters 3.7.0 (gegenereerd door tools/jsf-controls/build.py, niet met de hand wijzigen).
 *
 * @package M7SF
 */

defined( 'ABSPATH' ) || exit;

return array(
	array(
		'section',
		'section_general',
		array(
			'label' => 'Inhoud',
		),
	),
	array(
		'control',
		'filter_id',
		array(
			'label' => 'Kies filter',
			'label_block' => true,
			'type' => 'jet-query',
			'multiple' => true,
			'default' => '',
			'query_type' => 'post',
			'query' => array(
				'post_type' => 'jet-smart-filters',
				'posts_per_page' => -1,
				'meta_query' => array(
					array(
						'key' => '_filter_type',
						'value' => 'date-period',
						'compare' => '=',
					),
				),
			),
		),
		array(),
	),
	array(
		'control',
		'content_provider',
		array(
			'label' => 'Dit filter is voor',
			'type' => 'select',
			'default' => '',
			'options' => array(
				'' => 'Kies…',
				'epro-archive-products' => 'Elementor Pro Archive Products',
				'epro-archive' => 'Elementor Pro Archive',
				'epro-loop-builder' => 'Elementor Pro Loop Grid',
				'epro-portfolio' => 'Elementor Pro Portfolio',
				'epro-posts' => 'Elementor Pro Posts',
				'epro-products' => 'Elementor Pro Products',
				'jet-engine-calendar' => 'JetEngine Calendar',
				'jet-engine' => 'JetEngine',
				'jet-woo-products-grid' => 'JetWooBuilder Products Grid',
				'jet-woo-products-list' => 'JetWooBuilder Products List',
				'jsf-listing' => 'JSF Listing',
				'woocommerce-archive' => 'WooCommerce Archive (by JetWooBuilder)',
				'default-woo-archive' => 'Default WooCommerce Archive (Classic)',
				'woocommerce-shortcode' => 'WooCommerce Shortcode',
			),
		),
		array(),
	),
	array(
		'control',
		'epro_posts_notice',
		array(
			'type' => 'raw_html',
			'raw' => 'M7: geef de lijst (Loop Grid / Posts / Products) en dit filter hetzelfde Query-ID.',
			'condition' => array(
				'content_provider' => array(
					'epro-posts',
					'epro-portfolio',
				),
			),
		),
		array(),
	),
	array(
		'control',
		'apply_type',
		array(
			'label' => 'Manier van toepassen',
			'type' => 'select',
			'default' => 'ajax',
			'options' => array(
				'ajax' => 'AJAX',
				'reload' => 'Pagina herladen',
				'mixed' => 'Gemengd',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_on',
		array(
			'label' => 'Toepassen bij',
			'type' => 'select',
			'default' => 'value',
			'options' => array(
				'value' => 'Elke wijziging',
				'submit' => 'Klik op toepassen-knop',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_button',
		array(
			'label' => 'Toepassen-knop tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
			'condition' => array(
				'apply_on' => 'submit',
			),
		),
		array(),
	),
	array(
		'control',
		'apply_button_text',
		array(
			'label' => 'Tekst toepassen-knop',
			'type' => 'text',
			'default' => 'Apply filter',
			'condition' => array(
				'apply_on' => 'submit',
				'apply_button' => 'yes',
			),
		),
		array(),
	),
	array(
		'control',
		'show_label',
		array(
			'label' => 'Filterlabel tonen',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => '',
		),
		array(),
	),
	array(
		'control',
		'query_id',
		array(
			'label' => 'Query-ID',
			'type' => 'text',
			'label_block' => true,
			'description' => 'Set unique query ID if you use multiple widgets of same provider on the page. Same ID you need to set for filtered widget.',
		),
		array(),
	),
	array(
		'control',
		'query_id_wc_shortcode_notice',
		array(
			'type' => 'raw_html',
			'raw' => '<b>Query ID</b> for <b>WooCommerce Shortcode</b> must be specified as attribute class: [products class="query_id"]',
			'condition' => array(
				'content_provider' => array(
					'woocommerce-shortcode',
				),
			),
		),
		array(),
	),
	array(
		'control',
		'additional_providers_enabled',
		array(
			'label' => 'Extra lijsten',
			'type' => 'switcher',
			'description' => '',
			'label_on' => 'Ja',
			'label_off' => 'Nee',
			'return_value' => 'yes',
			'default' => 'no',
		),
		array(),
	),
	array(
		'control',
		'additional_providers_list',
		array(
			'label' => 'Lijst met extra lijsten',
			'type' => 'repeater',
			'fields' => array(
				'_id' => array(
					'type' => 'hidden',
					'tab' => 'content',
					'name' => '_id',
					'default' => '',
				),
				'additional_provider' => array(
					'type' => 'select',
					'tab' => 'content',
					'default' => '',
					'name' => 'additional_provider',
				),
				'additional_query_id' => array(
					'type' => 'text',
					'tab' => 'content',
					'name' => 'additional_query_id',
					'default' => '',
				),
			),
			'title_field' => '{{ additional_provider + ( additional_query_id ? "/" + additional_query_id : "" ) }}',
			'condition' => array(
				'additional_providers_enabled' => 'yes',
			),
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_datepicker_button_style',
		array(
			'label' => 'Knop datumkiezer',
			'tab' => 'style',
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'datepicker_button_typography',
			'selector' => '{{WRAPPER}} .m7sf-date-period__datepicker-button',
		),
		array(),
	),
	array(
		'tabs',
		'datepicker_button_style_tabs',
		array(),
	),
	array(
		'tab',
		'datepicker_button_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'datepicker_button_normal_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-period__datepicker-button' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'datepicker_button_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-period__datepicker-button' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'datepicker_button_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'datepicker_button_hover_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-period__datepicker-button:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'datepicker_button_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-period__datepicker-button:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'datepicker_button_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-period__datepicker-button:hover' => 'border-color: {{VALUE}}',
			),
			'condition' => array(
				'datepicker_button_border_border!' => '',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'datepicker_button_border',
			'selector' => '{{WRAPPER}} .m7sf-date-period__datepicker-button',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'datepicker_button_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-period__datepicker-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'datepicker_button_box_shadow',
			'selector' => '{{WRAPPER}} .m7sf-date-period__datepicker-button',
		),
		array(),
	),
	array(
		'responsive',
		'datepicker_button_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'em',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-period__datepicker-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'datepicker_button_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'flex-start' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'flex-end' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'toggle' => false,
			'default' => 'flex-start',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-period__wrapper' => 'justify-content: {{VALUE}}',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'next_prev_buttons_style',
		array(
			'label' => 'Vorige/volgende',
			'tab' => 'style',
		),
	),
	array(
		'responsive',
		'next_prev_buttons_offset',
		array(
			'label' => 'Horizontale verschuiving',
			'type' => 'slider',
			'range' => array(
				'px' => array(
					'min' => 0,
					'max' => 50,
				),
			),
			'default' => array(
				'size' => 5,
				'unit' => 'px',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-period__prev' => 'margin-right: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-date-period__next' => 'margin-left: {{SIZE}}{{UNIT}};',
				'.rtl {{WRAPPER}} .m7sf-date-period__prev' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: 0;',
				'.rtl {{WRAPPER}} .m7sf-date-period__next' => 'margin-right: {{SIZE}}{{UNIT}}; margin-left: 0;',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'next_prev_buttons_width',
		array(
			'label' => 'Breedte',
			'type' => 'slider',
			'range' => array(
				'px' => array(
					'min' => 20,
					'max' => 100,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-period__prev, {{WRAPPER}} .m7sf-date-period__next' => 'width: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'tabs',
		'next_prev_buttons_style_tabs',
		array(),
	),
	array(
		'tab',
		'next_prev_buttons_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'next_prev_buttons_normal_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-period__prev, {{WRAPPER}} .m7sf-date-period__next' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'next_prev_buttons_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-period__prev, {{WRAPPER}} .m7sf-date-period__next' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'next_prev_buttons_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'next_prev_buttons_hover_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-period__prev:hover, {{WRAPPER}} .m7sf-date-period__next:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'next_prev_buttons_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-period__prev:hover, {{WRAPPER}} .m7sf-date-period__next:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'next_prev_buttons_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-period__prev:hover, {{WRAPPER}} .m7sf-date-period__next:hover' => 'border-color: {{VALUE}}',
			),
			'condition' => array(
				'next_prev_buttons_border_border!' => '',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'next_prev_buttons_border',
			'selector' => '{{WRAPPER}} .m7sf-date-period__prev, {{WRAPPER}} .m7sf-date-period__next',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'next_prev_buttons_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-date-period__prev, {{WRAPPER}} .m7sf-date-period__next' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'next_prev_buttons_box_shadow',
			'selector' => '{{WRAPPER}} .m7sf-date-period__prev, {{WRAPPER}} .m7sf-date-period__next',
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_calendar_styles',
		array(
			'label' => 'Kalender',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'responsive',
		'calendar_offset_top',
		array(
			'label' => 'Verticale verschuiving',
			'type' => 'slider',
			'range' => array(
				'px' => array(
					'min' => -300,
					'max' => 300,
				),
			),
			'default' => array(
				'size' => 10,
			),
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}}' => 'margin-top: {{SIZE}}{{UNIT}}',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'calendar_offset_left',
		array(
			'label' => 'Horizontale verschuiving',
			'type' => 'slider',
			'range' => array(
				'px' => array(
					'min' => -300,
					'max' => 300,
				),
			),
			'default' => array(
				'size' => 0,
			),
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}}' => 'margin-left: {{SIZE}}{{UNIT}}',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'calendar_width',
		array(
			'label' => 'Breedte kalender',
			'type' => 'slider',
			'range' => array(
				'px' => array(
					'min' => 100,
					'max' => 1000,
				),
			),
			'default' => array(
				'size' => 300,
				'unit' => 'px',
			),
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}}' => 'width: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'calendar_body_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}}' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'calendar_body_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '#datepickers-container .m7sf-date-period-{{ID}}',
		),
		array(),
	),
	array(
		'control',
		'calendar_body_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}}' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'calendar_body_box_shadow',
			'selector' => '#datepickers-container .m7sf-date-period-{{ID}}',
		),
		array(),
	),
	array(
		'responsive',
		'calendar_body_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}}' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_calendar_header_styles',
		array(
			'label' => 'Kop kalender',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'control',
		'calendar_header_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'calendar_header_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav',
		),
		array(),
	),
	array(
		'control',
		'calendar_header_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'responsive',
		'calendar_header_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'separator' => 'before',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'calendar_header_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'calendar_header_caption_heading',
		array(
			'label' => 'Titel',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'calendar_header_caption_typography',
			'selector' => '#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav-title',
		),
		array(),
	),
	array(
		'tabs',
		'calendar_header_caption_style_tabs',
		array(),
	),
	array(
		'tab',
		'calendar_header_caption_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'calendar_header_caption_normal_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav-title' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_header_caption_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav-title' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'calendar_header_caption_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'calendar_header_caption_hover_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav-title:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_header_caption_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav-title:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_header_caption_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav-title:hover' => 'border-color: {{VALUE}}',
			),
			'condition' => array(
				'calendar_header_caption_border_border!' => '',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'calendar_header_caption_border',
			'label' => 'Rand',
			'selector' => '#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav-title',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'calendar_header_caption_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'responsive',
		'calendar_header_caption_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'separator' => 'before',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'calendar_header_prev_next_heading',
		array(
			'label' => 'Navigatiepijlen',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'responsive',
		'calendar_header_prev_next_size',
		array(
			'label' => 'Grootte',
			'type' => 'slider',
			'range' => array(
				'px' => array(
					'min' => 10,
					'max' => 50,
				),
			),
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav-action svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'tabs',
		'calendar_header_prev_next_style_tabs',
		array(),
	),
	array(
		'tab',
		'calendar_header_prev_next_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'calendar_header_prev_next_normal_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav-action' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_header_prev_next_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav-action' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'calendar_header_prev_next_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'calendar_header_prev_next_hover_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav-action:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_header_prev_next_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav-action:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_header_prev_next_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav-action:hover' => 'border-color: {{VALUE}}',
			),
			'condition' => array(
				'calendar_header_prev_next_border_border!' => '',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'calendar_header_prev_next_border',
			'label' => 'Rand',
			'selector' => '#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav-action',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'calendar_header_prev_next_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav-action' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'responsive',
		'calendar_header_prev_next_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'separator' => 'before',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--nav-action' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_calendar_cell',
		array(
			'label' => 'Kalendercel',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'tabs',
		'calendar_cell_style_tabs',
		array(),
	),
	array(
		'tab',
		'calendar_cell_default_styles',
		array(
			'label' => 'Standaard',
		),
	),
	array(
		'control',
		'calendar_cell_default_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'calendar_cell_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'calendar_cell_hover_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell.-focus-' => 'color: {{VALUE}}',
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell.-in-range-.-focus-' => 'color: {{VALUE}}',
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell.-week-hover-' => 'color: {{VALUE}}',
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell.-range-from-' => 'color: {{VALUE}}',
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell.-range-to-' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_cell_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell.-focus-' => 'background-color: {{VALUE}}',
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell.-in-range-.-focus-' => 'background-color: {{VALUE}}',
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell.-week-hover-' => 'background-color: {{VALUE}}',
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell.-range-from-' => 'background-color: {{VALUE}}',
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell.-range-to-' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'calendar_cell_active_styles',
		array(
			'label' => 'Actief',
		),
	),
	array(
		'control',
		'calendar_cell_active_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell.-selected-' => 'color: {{VALUE}}',
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell.-week-selected-' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_cell_active_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell.-selected-' => 'background-color: {{VALUE}}',
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell.-week-selected-' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_cell_active_in_range_color',
		array(
			'label' => 'Kleur binnen bereik',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell.-in-range-' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_cell_active_in_range_background_color',
		array(
			'label' => 'Achtergrond binnen bereik',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell.-in-range-' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'calendar_cell_current_styles',
		array(
			'label' => 'Huidige',
		),
	),
	array(
		'control',
		'calendar_cell_current_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell.-current-' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_cell_current_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell.-current-' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'control',
		'calendar_cell_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'separator' => 'before',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_days_heading',
		array(
			'label' => 'Dagen',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'calendar_days_typography',
			'selector' => '#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell-day',
		),
		array(),
	),
	array(
		'control',
		'calendar_days_weekend_color',
		array(
			'label' => 'Kleur weekend',
			'type' => 'color',
			'separator' => 'before',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell-day.-weekend-' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_days_other_month_color',
		array(
			'label' => 'Kleur andere maand',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell-day.-other-month-' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'responsive',
		'calendar_days_cells_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'allowed_dimensions' => array(
				'top',
				'bottom',
			),
			'separator' => 'before',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell-day' => 'padding: {{TOP}}{{UNIT}} 0 {{BOTTOM}}{{UNIT}} 0;',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'calendar_month_heading',
		array(
			'label' => 'Maand',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'calendar_months_typography',
			'selector' => '#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell-month',
		),
		array(),
	),
	array(
		'responsive',
		'calendar_months_cells_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'allowed_dimensions' => array(
				'top',
				'bottom',
			),
			'separator' => 'before',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell-month' => 'padding: {{TOP}}{{UNIT}} 0 {{BOTTOM}}{{UNIT}} 0;',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'control',
		'calendar_year_heading',
		array(
			'label' => 'Jaar',
			'type' => 'heading',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'calendar_years_typography',
			'selector' => '#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell-year',
		),
		array(),
	),
	array(
		'responsive',
		'calendar_years_cells_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'allowed_dimensions' => array(
				'top',
				'bottom',
			),
			'separator' => 'before',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--cell-year' => 'padding: {{TOP}}{{UNIT}} 0 {{BOTTOM}}{{UNIT}} 0;',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_calendar_week_days',
		array(
			'label' => 'Weekdagen',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'calendar_week_days_typography',
			'selector' => '#datepickers-container .m7sf-date-period-{{ID}} .datepicker--day-name',
		),
		array(),
	),
	array(
		'control',
		'calendar_week_days_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--day-name' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'calendar_week_days_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--days-names' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'calendar_week_days_border',
			'label' => 'Rand kop',
			'separator' => 'before',
			'selector' => '#datepickers-container .m7sf-date-period-{{ID}} .datepicker--days-names',
		),
		array(),
	),
	array(
		'control',
		'calendar_week_days_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--days-names' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'responsive',
		'calendar_week_days_cells_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'allowed_dimensions' => array(
				'top',
				'bottom',
			),
			'separator' => 'before',
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--days-names' => 'padding: {{TOP}}{{UNIT}} 0 {{BOTTOM}}{{UNIT}} 0;',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'calendar_week_days_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'allowed_dimensions' => array(
				'top',
				'bottom',
			),
			'selectors' => array(
				'#datepickers-container .m7sf-date-period-{{ID}} .datepicker--days-names' => 'margin: {{TOP}}{{UNIT}} 0 {{BOTTOM}}{{UNIT}} 0;',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_label_style',
		array(
			'label' => 'Label',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'label_typography',
			'selector' => '{{WRAPPER}} .m7sf-filter-label',
		),
		array(),
	),
	array(
		'control',
		'label_color',
		array(
			'label' => 'Kleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'group',
		'border',
		array(
			'name' => 'label_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-filter-label',
		),
		array(),
	),
	array(
		'control',
		'label_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'responsive',
		'label_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'label_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'label_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'left' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'right' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
			),
			'separator' => 'before',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-filter-label' => 'text-align: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
	array(
		'section',
		'section_filter_apply_button_style',
		array(
			'label' => 'Knop',
			'tab' => 'style',
			'show_label' => false,
		),
	),
	array(
		'group',
		'typography',
		array(
			'name' => 'filter_apply_button_typography',
			'global' => array(
				'default' => 'globals/typography?id=primary',
			),
			'selector' => '{{WRAPPER}} .m7sf-apply-filters__button, {{WRAPPER}} .m7sf-filter-items-dropdown__apply-button',
		),
		array(),
	),
	array(
		'tabs',
		'filter_apply_button_style_tabs',
		array(),
	),
	array(
		'tab',
		'filter_apply_button_normal_styles',
		array(
			'label' => 'Normaal',
		),
	),
	array(
		'control',
		'filter_apply_button_normal_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_normal_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'background-color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'tab',
		'filter_apply_button_hover_styles',
		array(
			'label' => 'Hover',
		),
	),
	array(
		'control',
		'filter_apply_button_hover_color',
		array(
			'label' => 'Tekstkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button:hover' => 'color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button:hover' => 'color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_hover_background_color',
		array(
			'label' => 'Achtergrondkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button:hover' => 'background-color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button:hover' => 'background-color: {{VALUE}}',
			),
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_hover_border_color',
		array(
			'label' => 'Randkleur',
			'type' => 'color',
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button:hover' => 'border-color: {{VALUE}}',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button:hover' => 'border-color: {{VALUE}}',
			),
			'condition' => array(
				'filter_apply_button_border_border!' => '',
			),
		),
		array(),
	),
	array(
		'end_tab',
	),
	array(
		'end_tabs',
	),
	array(
		'group',
		'border',
		array(
			'name' => 'filter_apply_button_border',
			'label' => 'Rand',
			'placeholder' => '1px',
			'default' => '1px',
			'selector' => '{{WRAPPER}} .m7sf-apply-filters__button, {{WRAPPER}} .m7sf-filter-items-dropdown__apply-button',
			'separator' => 'before',
		),
		array(),
	),
	array(
		'control',
		'filter_apply_button_border_radius',
		array(
			'label' => 'Afronding',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		),
		array(),
	),
	array(
		'group',
		'box-shadow',
		array(
			'name' => 'filter_apply_button_shadow',
			'selector' => '{{WRAPPER}} .m7sf-apply-filters__button, {{WRAPPER}} .m7sf-filter-items-dropdown__apply-button',
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_padding',
		array(
			'label' => 'Binnenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'{{WRAPPER}} .m7sf-filter-items-dropdown__apply-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'separator' => 'before',
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_margin',
		array(
			'label' => 'Buitenruimte',
			'type' => 'dimensions',
			'size_units' => array(
				'px',
				'%',
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'responsive',
		'filter_apply_button_alignment',
		array(
			'label' => 'Uitlijning',
			'type' => 'choose',
			'options' => array(
				'flex-start' => array(
					'title' => 'Links',
					'icon' => 'eicon-text-align-left',
				),
				'center' => array(
					'title' => 'Midden',
					'icon' => 'eicon-text-align-center',
				),
				'flex-end' => array(
					'title' => 'Rechts',
					'icon' => 'eicon-text-align-right',
				),
				'stretch' => array(
					'title' => 'Uitrekken',
					'icon' => 'eicon-text-align-justify',
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .m7sf-apply-filters__button' => 'align-self: {{VALUE}};',
			),
			'responsive' => array(),
			'is_responsive' => true,
		),
		array(),
	),
	array(
		'end_section',
	),
);
