<?php
/**
 * Stijlinstellingen voor filterwidgets. De sleutels zijn gelijk aan die van JetSmartFilters
 * (items_space_between, item_typography, checkbox_*, label_*, filters_position, …), zodat bij
 * het omzetten de bestaande opmaak (incl. globale kleuren) ongewijzigd wordt overgenomen.
 * De selectors zijn eigen M7-markup.
 *
 * @package M7SF
 */

namespace M7SF\Elementor;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;

defined( 'ABSPATH' ) || exit;

final class Style_Controls {

	public static function layout( $w ) {
		$w->start_controls_section( 'section_m7_layout_style', array( 'label' => __( 'Indeling', 'm7-smart-filters' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$w->add_control(
			'filters_position',
			array(
				'label'                => __( 'Opties', 'm7-smart-filters' ),
				'type'                 => Controls_Manager::CHOOSE,
				'default'              => 'block',
				'options'              => array(
					'block'        => array( 'title' => __( 'Onder elkaar', 'm7-smart-filters' ), 'icon' => 'eicon-editor-list-ul' ),
					'inline-block' => array( 'title' => __( 'Naast elkaar', 'm7-smart-filters' ), 'icon' => 'eicon-ellipsis-h' ),
				),
				'selectors_dictionary' => array(
					'block'        => 'display: grid;',
					'inline-block' => 'display: flex; flex-wrap: wrap; align-items: center;',
				),
				'selectors'            => array( '{{WRAPPER}} .m7sf-list' => '{{VALUE}}' ),
				'prefix_class'         => 'm7sf-layout-',
			)
		);
		$w->add_responsive_control(
			'items_space_between',
			array(
				'label'      => __( 'Ruimte tussen opties', 'm7-smart-filters' ),
				'default'    => array( 'size' => 10, 'unit' => 'px' ), // Zelfde standaard als JetSmartFilters.
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 100 ) ),
				'selectors'  => array( '{{WRAPPER}}' => '--m7sf-item-space: {{SIZE}}{{UNIT}};' ),
			)
		);
		$w->add_responsive_control(
			'filters_list_alignment',
			array(
				'label'                => __( 'Uitlijning', 'm7-smart-filters' ),
				'type'                 => Controls_Manager::CHOOSE,
				'options'              => array(
					'left'   => array( 'title' => __( 'Links', 'm7-smart-filters' ), 'icon' => 'eicon-text-align-left' ),
					'center' => array( 'title' => __( 'Midden', 'm7-smart-filters' ), 'icon' => 'eicon-text-align-center' ),
					'right'  => array( 'title' => __( 'Rechts', 'm7-smart-filters' ), 'icon' => 'eicon-text-align-right' ),
				),
				'selectors_dictionary' => array(
					'left'   => 'flex-start',
					'center' => 'center',
					'right'  => 'flex-end',
				),
				'selectors'            => array( '{{WRAPPER}} .m7sf-list' => 'justify-content: {{VALUE}}; justify-items: {{VALUE}};' ),
			)
		);
		$w->add_responsive_control(
			'sub_items_offset_left',
			array(
				'label'      => __( 'Inspringing subopties', 'm7-smart-filters' ),
				'default'    => array( 'size' => 10, 'unit' => 'px' ), // Zelfde standaard als JetSmartFilters.
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'selectors'  => array( '{{WRAPPER}}' => '--m7sf-indent: {{SIZE}}{{UNIT}};' ),
			)
		);
		$w->end_controls_section();
	}

	public static function items( $w ) {
		$w->start_controls_section( 'section_m7_items_style', array( 'label' => __( 'Opties', 'm7-smart-filters' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$w->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'item_typography',
				'selector' => '{{WRAPPER}} .m7sf-item__label, {{WRAPPER}} .m7sf-select, {{WRAPPER}} .m7sf-search__input',
			)
		);
		foreach ( array(
			'item_normal_color'             => array( __( 'Tekstkleur', 'm7-smart-filters' ), '.m7sf-item__label', 'color' ),
			'item_normal_background_color'  => array( __( 'Achtergrond', 'm7-smart-filters' ), '.m7sf-item__label', 'background-color' ),
			'item_hover_color'              => array( __( 'Tekstkleur bij hover', 'm7-smart-filters' ), '.m7sf-item__label:hover', 'color' ),
			'item_hover_background_color'   => array( __( 'Achtergrond bij hover', 'm7-smart-filters' ), '.m7sf-item__label:hover', 'background-color' ),
			'item_checked_color'            => array( __( 'Tekstkleur aangevinkt', 'm7-smart-filters' ), '.m7sf-input:checked + .m7sf-item__label', 'color' ),
			'item_checked_background_color' => array( __( 'Achtergrond aangevinkt', 'm7-smart-filters' ), '.m7sf-input:checked + .m7sf-item__label', 'background-color' ),
			'item_checked_border_color'     => array( __( 'Rand aangevinkt', 'm7-smart-filters' ), '.m7sf-input:checked + .m7sf-item__label', 'border-color' ),
		) as $key => $def ) {
			$w->add_control(
				$key,
				array(
					'label'     => $def[0],
					'type'      => Controls_Manager::COLOR,
					'selectors' => array( '{{WRAPPER}} ' . $def[1] => $def[2] . ': {{VALUE}};' ),
				)
			);
		}
		$w->add_responsive_control(
			'item_padding',
			array(
				'label'      => __( 'Binnenruimte', 'm7-smart-filters' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array( '{{WRAPPER}} .m7sf-item__label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);
		$w->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'item_border',
				'selector' => '{{WRAPPER}} .m7sf-item__label',
			)
		);
		$w->add_responsive_control(
			'item_border_radius',
			array(
				'label'      => __( 'Afronding', 'm7-smart-filters' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array( '{{WRAPPER}} .m7sf-item__label' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);
		$w->end_controls_section();
	}

	public static function checkbox( $w ) {
		$w->start_controls_section( 'section_m7_checkbox_style', array( 'label' => __( 'Vakje', 'm7-smart-filters' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$w->add_control(
			'show_decorator',
			array(
				'label'        => __( 'Vakje tonen', 'm7-smart-filters' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'prefix_class' => 'm7sf-decorator-',
			)
		);
		$w->add_responsive_control(
			'checkbox_size',
			array(
				'label'      => __( 'Grootte', 'm7-smart-filters' ),
				'default'    => array( 'size' => 16, 'unit' => 'px' ), // Zelfde standaard als JetSmartFilters.
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 8, 'max' => 40 ) ),
				'selectors'  => array( '{{WRAPPER}}' => '--m7sf-box: {{SIZE}}{{UNIT}};' ),
			)
		);
		$w->add_responsive_control(
			'checkbox_label_offset',
			array(
				'label'      => __( 'Ruimte tot tekst', 'm7-smart-filters' ),
				'default'    => array( 'size' => 5, 'unit' => 'px' ), // Zelfde standaard als JetSmartFilters.
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'selectors'  => array( '{{WRAPPER}}' => '--m7sf-box-gap: {{SIZE}}{{UNIT}};' ),
			)
		);
		$w->add_responsive_control(
			'checkbox_top_offset',
			array(
				'label'      => __( 'Verschuiving omhoog/omlaag', 'm7-smart-filters' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => -20, 'max' => 20 ) ),
				'selectors'  => array( '{{WRAPPER}} .m7sf-decorator' => 'transform: translateY({{SIZE}}{{UNIT}});' ),
			)
		);
		foreach ( array(
			'checkbox_normal_background_color'  => array( __( 'Achtergrond', 'm7-smart-filters' ), '--m7sf-box-bg' ),
			'checkbox_checked_background_color' => array( __( 'Achtergrond aangevinkt', 'm7-smart-filters' ), '--m7sf-box-checked-bg' ),
			'checkbox_checked_border_color'     => array( __( 'Rand aangevinkt', 'm7-smart-filters' ), '--m7sf-box-checked-border' ),
			'checked_icon_color'                => array( __( 'Kleur vinkje', 'm7-smart-filters' ), '--m7sf-check-color' ),
		) as $key => $def ) {
			$w->add_control(
				$key,
				array(
					'label'     => $def[0],
					'type'      => Controls_Manager::COLOR,
					'selectors' => array( '{{WRAPPER}}' => $def[1] . ': {{VALUE}};' ),
				)
			);
		}
		$w->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'checkbox_border',
				'selector' => '{{WRAPPER}} .m7sf-decorator',
			)
		);
		$w->add_control(
			'checkbox_border_radius',
			array(
				'label'      => __( 'Afronding', 'm7-smart-filters' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array( '{{WRAPPER}} .m7sf-decorator' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);
		$w->add_responsive_control(
			'checked_icon_size',
			array(
				'label'      => __( 'Grootte vinkje', 'm7-smart-filters' ),
				'default'    => array( 'size' => 12, 'unit' => 'px' ), // Zelfde standaard als JetSmartFilters.
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'selectors'  => array( '{{WRAPPER}}' => '--m7sf-check-size: {{SIZE}}{{UNIT}};' ),
			)
		);
		$w->end_controls_section();
	}

	public static function label( $w ) {
		$w->start_controls_section( 'section_m7_label_style', array( 'label' => __( 'Label', 'm7-smart-filters' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$w->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'label_typography',
				'selector' => '{{WRAPPER}} .m7sf-label',
			)
		);
		$w->add_control(
			'label_color',
			array(
				'label'     => __( 'Kleur', 'm7-smart-filters' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .m7sf-label' => 'color: {{VALUE}};' ),
			)
		);
		$w->add_responsive_control(
			'label_alignment',
			array(
				'label'     => __( 'Uitlijning', 'm7-smart-filters' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'left'   => array( 'title' => __( 'Links', 'm7-smart-filters' ), 'icon' => 'eicon-text-align-left' ),
					'center' => array( 'title' => __( 'Midden', 'm7-smart-filters' ), 'icon' => 'eicon-text-align-center' ),
					'right'  => array( 'title' => __( 'Rechts', 'm7-smart-filters' ), 'icon' => 'eicon-text-align-right' ),
				),
				'selectors' => array( '{{WRAPPER}} .m7sf-label' => 'text-align: {{VALUE}};' ),
			)
		);
		$w->add_responsive_control(
			'label_margin',
			array(
				'label'      => __( 'Buitenruimte', 'm7-smart-filters' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array( '{{WRAPPER}} .m7sf-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);
		$w->add_responsive_control(
			'label_padding',
			array(
				'label'      => __( 'Binnenruimte', 'm7-smart-filters' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array( '{{WRAPPER}} .m7sf-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);
		$w->end_controls_section();
	}
}
