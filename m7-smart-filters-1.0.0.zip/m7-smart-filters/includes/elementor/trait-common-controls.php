<?php
/**
 * Gedeelde Elementor-instellingen voor alle M7-filterwidgets.
 *
 * @package M7SF
 */

namespace M7SF\Elementor;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || exit;

trait Common_Controls {

	protected function add_query_controls( $with_apply_on = false ) {
		$this->add_control(
			'query_id',
			array(
				'label'       => __( 'Query ID', 'm7-smart-filters' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'placeholder' => 'producten',
				'description' => __( 'Zelfde Query ID als bij de Loop Grid / Posts / Products-widget. Gebruik "main" voor het WooCommerce-archief.', 'm7-smart-filters' ),
				'label_block' => true,
			)
		);
		$this->add_control(
			'apply_type',
			array(
				'label'   => __( 'Toepassen', 'm7-smart-filters' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'ajax',
				'options' => array(
					'ajax'   => __( 'AJAX (zonder herladen)', 'm7-smart-filters' ),
					'reload' => __( 'Pagina herladen', 'm7-smart-filters' ),
					'mixed'  => __( 'Gemengd', 'm7-smart-filters' ),
				),
			)
		);
		if ( $with_apply_on ) {
			$this->add_control(
				'apply_on',
				array(
					'label'   => __( 'Toepassen bij', 'm7-smart-filters' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'value',
					'options' => array(
						'value'  => __( 'Elke wijziging', 'm7-smart-filters' ),
						'button' => __( 'Klik op toepassen-knop', 'm7-smart-filters' ),
					),
				)
			);
		}
		$this->add_control(
			'selector',
			array(
				'label'       => __( 'CSS-selector resultaten (optioneel)', 'm7-smart-filters' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'description' => __( 'Alleen nodig als de resultaten niet automatisch worden gevonden.', 'm7-smart-filters' ),
				'label_block' => true,
			)
		);
	}

	protected function common_args() {
		$s = $this->get_settings_for_display();
		return array(
			'query_id'   => isset( $s['query_id'] ) ? $s['query_id'] : '',
			'apply_type' => isset( $s['apply_type'] ) ? $s['apply_type'] : 'ajax',
			'apply_on'   => isset( $s['apply_on'] ) ? $s['apply_on'] : 'value',
			'selector'   => isset( $s['selector'] ) ? $s['selector'] : '',
			'redirect'   => isset( $s['redirect']['url'] ) ? $s['redirect']['url'] : '',
		);
	}

	protected function add_text_style_section( $id, $label, $selector ) {
		$this->start_controls_section(
			$id,
			array(
				'label' => $label,
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => $id . '_typography',
				'selector' => '{{WRAPPER}} ' . $selector,
			)
		);
		$this->add_control(
			$id . '_color',
			array(
				'label'     => __( 'Kleur', 'm7-smart-filters' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} ' . $selector => 'color: {{VALUE}};' ),
			)
		);
		$this->end_controls_section();
	}
}
