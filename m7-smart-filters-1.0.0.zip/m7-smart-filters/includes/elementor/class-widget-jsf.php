<?php
/**
 * M7-filterwidgets voor Elementor, één per type, met dezelfde instellingen als JetSmartFilters 3.7.0
 * (sleutels, standaarden, opmaakregels en volgorde uit includes/elementor/controls/<type>.php).
 * Daardoor neemt een omgezette pagina alle opgeslagen opmaak ongewijzigd over.
 *
 * @package M7SF
 */

namespace M7SF\Elementor;

use Elementor\Controls_Manager;
use M7SF\Elementor_Integration;
use M7SF\Filter_Post_Type;
use M7SF\Markup;

defined( 'ABSPATH' ) || exit;

abstract class Widget_Jsf extends \Elementor\Widget_Base {

	/** @var string Widgettype (checkboxes, radio, …). */
	protected $m7_type = '';

	const TITLES = array(
		'checkboxes'     => array( 'M7 Vinkjes', 'eicon-checkbox' ),
		'radio'          => array( 'M7 Keuzerondjes', 'eicon-radio' ),
		'select'         => array( 'M7 Keuzelijst', 'eicon-select' ),
		'range'          => array( 'M7 Schuifje (bereik)', 'eicon-h-align-stretch' ),
		'check-range'    => array( 'M7 Vaste bereiken', 'eicon-bullet-list' ),
		'search'         => array( 'M7 Zoeken', 'eicon-search' ),
		'rating'         => array( 'M7 Beoordeling', 'eicon-rating' ),
		'alphabet'       => array( 'M7 Alfabet', 'eicon-t-letter' ),
		'color-image'    => array( 'M7 Kleur / afbeelding', 'eicon-paint-brush' ),
		'date-range'     => array( 'M7 Datum van-tot', 'eicon-date' ),
		'date-period'    => array( 'M7 Datumperiode', 'eicon-calendar' ),
		'sorting'        => array( 'M7 Sorteren', 'eicon-sort-amount-desc' ),
		'apply-button'   => array( 'M7 Toepassen-knop', 'eicon-button' ),
		'remove-filters' => array( 'M7 Filters wissen', 'eicon-close-circle' ),
		'active'         => array( 'M7 Actieve filters', 'eicon-filter' ),
		'active-tags'    => array( 'M7 Actieve tags', 'eicon-tags' ),
		'pagination'     => array( 'M7 Paginering', 'eicon-number-field' ),
		'hidden'         => array( 'M7 Verborgen filter', 'eicon-hide' ),
	);

	public function get_name() {
		return 'm7sf-' . $this->m7_type;
	}

	public function get_title() {
		return isset( self::TITLES[ $this->m7_type ] ) ? self::TITLES[ $this->m7_type ][0] : 'M7';
	}

	public function get_icon() {
		return 'm7-eicon'; // M7-logo (zie M7_Admin_Menu::elementor_icons).
	}

	public function get_categories() {
		return array( Elementor_Integration::CATEGORY );
	}

	public function get_keywords() {
		return array( 'filter', 'm7', 'jet', 'smart filters', $this->m7_type );
	}

	public function get_style_depends() {
		$deps = array( 'm7sf' );
		if ( 'rating' === $this->m7_type ) {
			$deps[] = 'font-awesome';
		}
		if ( 'date-period' === $this->m7_type ) {
			$deps[] = 'm7sf-datepicker';
		}
		return $deps;
	}

	public function get_script_depends() {
		$deps = array( 'm7sf' );
		if ( 'date-range' === $this->m7_type ) {
			array_unshift( $deps, 'jquery-ui-datepicker', 'm7sf-dates' );
		}
		if ( 'date-period' === $this->m7_type ) {
			array_unshift( $deps, 'm7sf-airdp', 'm7sf-dates' );
		}
		return $deps;
	}

	/**
	 * Instellingen registreren in dezelfde volgorde en vorm als het origineel.
	 */
	protected function register_controls() {
		$file = M7SF_DIR . 'includes/elementor/controls/' . $this->m7_type . '.php';
		if ( ! is_readable( $file ) ) {
			return;
		}
		foreach ( (array) include $file as $call ) {
			switch ( $call[0] ) {
				case 'section':
					$this->start_controls_section( $call[1], $call[2] );
					break;
				case 'end_section':
					$this->end_controls_section();
					break;
				case 'tabs':
					$this->start_controls_tabs( $call[1], $call[2] );
					break;
				case 'end_tabs':
					$this->end_controls_tabs();
					break;
				case 'tab':
					$this->start_controls_tab( $call[1], $call[2] );
					break;
				case 'end_tab':
					$this->end_controls_tab();
					break;
				case 'control':
					$this->add_control( $call[1], $this->adjust( $call[1], $call[2] ), $call[3] );
					break;
				case 'responsive':
					$this->add_responsive_control( $call[1], $this->adjust( $call[1], $call[2] ), $call[3] );
					break;
				case 'group':
					$this->add_group_control( $call[1], $call[2], $call[3] );
					break;
				case 'update':
					$this->update_control( $call[1], $call[2], $call[3] );
					break;
				case 'update_responsive':
					$this->update_responsive_control( $call[1], $call[2], $call[3] );
					break;
				case 'remove':
					$this->remove_control( $call[1] );
					break;
			}
		}
	}

	/**
	 * Instellingen die naar M7-gegevens moeten verwijzen.
	 */
	private function adjust( $id, array $args ) {
		if ( 'filter_id' === $id ) {
			$type = isset( Markup::FILTER_TYPES[ $this->m7_type ] ) ? Markup::FILTER_TYPES[ $this->m7_type ] : '';
			return array(
				'label'       => __( 'Kies filter', 'm7-smart-filters' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple'    => ! empty( $args['multiple'] ),
				'default'     => '',
				'options'     => self::filter_options( $type ),
				'description' => __( 'Filters maak je onder M7 > Filters.', 'm7-smart-filters' ),
			);
		}
		// Het oude icoonveld (Font Awesome-class, zoals bij JetSmartFilters) bestaat nog in Elementor 3; mocht het
		// verdwijnen, dan blijft de waarde ("fa fa-star") bewaard en bewerkbaar als tekstveld.
		if ( isset( $args['type'] ) && 'icon' === $args['type'] && ! self::has_control_type( 'icon' ) ) {
			$args['type'] = Controls_Manager::TEXT;
		}
		if ( 'query_id' === $id ) {
			$args['description'] = __( 'Zelfde Query-ID als bij de lijst (Loop Grid, Posts, Products of [products class="…"]). Leeg = "default" (of het winkelarchief).', 'm7-smart-filters' );
		}
		return $args;
	}

	private static function has_control_type( $type ) {
		static $known = array();
		if ( ! isset( $known[ $type ] ) ) {
			$manager        = \Elementor\Plugin::$instance->controls_manager;
			$known[ $type ] = $manager && $manager->get_control( $type );
		}
		return $known[ $type ];
	}

	private static function filter_options( $type ) {
		static $cache = array();
		if ( isset( $cache[ $type ] ) ) {
			return $cache[ $type ];
		}
		$out   = array();
		$posts = get_posts(
			array(
				'post_type'      => Filter_Post_Type::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 300,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);
		foreach ( $posts as $p ) {
			$s = Filter_Post_Type::get( $p->ID );
			if ( $s && ( '' === $type || $s['type'] === $type ) ) {
				$out[ (string) $p->ID ] = $p->post_title;
			}
		}
		return $cache[ $type ] = $out;
	}

	protected function get_html_wrapper_class() {
		$class = parent::get_html_wrapper_class();
		// Alleen voor een widget op een pagina (niet voor het widgettype in de editorlijst).
		if ( ! $this->get_id() || ! in_array( $this->m7_type, array( 'active', 'active-tags', 'remove-filters' ), true ) ) {
			return $class;
		}
		try {
			if ( ! $this->has_active_items() ) {
				$class .= ' m7sf-hide-widget';
			}
		} catch ( \Throwable $e ) {
			return $class;
		}
		return $class;
	}

	private function has_active_items() {
		$set = $this->get_settings();
		$qid = Markup::query_id( is_array( $set ) ? $set : array() );
		if ( 'remove-filters' === $this->m7_type ) {
			return \M7SF\Query::is_active_for( $qid );
		}
		return (bool) \M7SF\Markup_Active::entries( $qid, true );
	}

	protected function render() {
		// Zoals JetSmartFilters: alle instellingen inclusief standaarden, ook als een voorwaarde in de editor
		// niet geldt (bijv. "label_block" bij sorteren); dynamische tags worden wel ingevuld.
		$set = array_merge( (array) $this->get_settings(), (array) $this->get_settings_for_display() );
		foreach ( (array) $this->get_settings() as $k => $v ) {
			if ( ! isset( $set[ $k ] ) ) {
				$set[ $k ] = $v;
			}
		}
		echo Markup::widget( $this->m7_type, is_array( $set ) ? $set : array(), $this->get_id() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup escapet zelf.
	}
}

// phpcs:disable Generic.Files.OneObjectStructurePerFile.MultipleFound, Squiz.Commenting.ClassComment.Missing
class Widget_Jsf_Checkboxes extends Widget_Jsf { protected $m7_type = 'checkboxes'; }
class Widget_Jsf_Radio extends Widget_Jsf { protected $m7_type = 'radio'; }
class Widget_Jsf_Select extends Widget_Jsf { protected $m7_type = 'select'; }
class Widget_Jsf_Range extends Widget_Jsf { protected $m7_type = 'range'; }
class Widget_Jsf_Check_Range extends Widget_Jsf { protected $m7_type = 'check-range'; }
class Widget_Jsf_Search extends Widget_Jsf { protected $m7_type = 'search'; }
class Widget_Jsf_Rating extends Widget_Jsf { protected $m7_type = 'rating'; }
class Widget_Jsf_Alphabet extends Widget_Jsf { protected $m7_type = 'alphabet'; }
class Widget_Jsf_Color_Image extends Widget_Jsf { protected $m7_type = 'color-image'; }
class Widget_Jsf_Date_Range extends Widget_Jsf { protected $m7_type = 'date-range'; }
class Widget_Jsf_Date_Period extends Widget_Jsf { protected $m7_type = 'date-period'; }
class Widget_Jsf_Sorting extends Widget_Jsf { protected $m7_type = 'sorting'; }
class Widget_Jsf_Apply_Button extends Widget_Jsf { protected $m7_type = 'apply-button'; }
class Widget_Jsf_Remove_Filters extends Widget_Jsf { protected $m7_type = 'remove-filters'; }
class Widget_Jsf_Active extends Widget_Jsf { protected $m7_type = 'active'; }
class Widget_Jsf_Active_Tags extends Widget_Jsf { protected $m7_type = 'active-tags'; }
class Widget_Jsf_Pagination extends Widget_Jsf { protected $m7_type = 'pagination'; }
class Widget_Jsf_Hidden extends Widget_Jsf { protected $m7_type = 'hidden'; }
