<?php
/**
 * Elementor-widget: M7 Filter (alle filtertypen).
 *
 * @package M7SF
 */

namespace M7SF\Elementor;

use Elementor\Controls_Manager;
use M7SF\Elementor_Integration;
use M7SF\Render;

defined( 'ABSPATH' ) || exit;

class Widget_Filter extends \Elementor\Widget_Base {

	use Common_Controls;

	public function get_name() {
		return 'm7sf-filter';
	}

	public function show_in_panel() {
		return false; // Vervangen door de widgets per type; bestaande pagina's blijven werken.
	}

	public function get_title() {
		return __( 'M7 Filter', 'm7-smart-filters' );
	}

	public function get_icon() {
		return 'eicon-filter';
	}

	public function get_categories() {
		return array( Elementor_Integration::CATEGORY );
	}

	public function get_keywords() {
		return array( 'filter', 'm7', 'checkbox', 'range', 'search', 'zoeken' );
	}

	public function get_style_depends() {
		return array( 'm7sf' );
	}

	public function get_script_depends() {
		return array( 'm7sf' );
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_filter', array( 'label' => __( 'Filter', 'm7-smart-filters' ) ) );
		$this->add_control(
			'filter_id',
			array(
				'label'       => __( 'Filter', 'm7-smart-filters' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => Elementor_Integration::filter_choices(),
				'default'     => '',
				'label_block' => true,
			)
		);
		$this->add_query_controls( true );
		$this->add_control(
			'redirect',
			array(
				'label'       => __( 'Doorsturen naar pagina (optioneel)', 'm7-smart-filters' ),
				'type'        => Controls_Manager::URL,
				'options'     => false,
				'description' => __( 'Bijvoorbeeld een filter op de homepage dat naar de winkel stuurt.', 'm7-smart-filters' ),
			)
		);
		$this->end_controls_section();

		$this->start_controls_section( 'section_display', array( 'label' => __( 'Weergave', 'm7-smart-filters' ) ) );
		$this->add_control( 'show_label', array( 'label' => __( 'Label tonen', 'm7-smart-filters' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ) );
		$this->add_control( 'show_counter', array( 'label' => __( 'Aantallen tonen', 'm7-smart-filters' ), 'type' => Controls_Manager::SWITCHER, 'default' => '' ) );
		$this->add_control( 'show_search', array( 'label' => __( 'Zoeken in opties', 'm7-smart-filters' ), 'type' => Controls_Manager::SWITCHER, 'default' => '' ) );
		$this->add_control(
			'more_less',
			array(
				'label'       => __( 'Meer/minder na aantal opties', 'm7-smart-filters' ),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'default'     => 0,
				'description' => __( '0 = alles tonen.', 'm7-smart-filters' ),
			)
		);
		$this->add_responsive_control(
			'columns',
			array(
				'label'     => __( 'Kolommen', 'm7-smart-filters' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 1,
				'max'       => 6,
				'default'   => 1,
				'selectors' => array( '{{WRAPPER}} .m7sf-filter' => '--m7sf-columns: {{VALUE}};' ),
			)
		);
		$this->end_controls_section();

		// Stijlinstellingen met dezelfde namen als JetSmartFilters, zodat de overstap de opmaak 1-op-1 overneemt.
		Style_Controls::layout( $this );
		Style_Controls::items( $this );
		Style_Controls::checkbox( $this );
		Style_Controls::label( $this );

		$this->start_controls_section( 'style_accent', array( 'label' => __( 'Accent en ruimte', 'm7-smart-filters' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_control(
			'accent',
			array(
				'label'     => __( 'Accentkleur (aangevinkt)', 'm7-smart-filters' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .m7sf-filter' => '--m7sf-accent: {{VALUE}};' ),
			)
		);
		$this->add_responsive_control(
			'gap',
			array(
				'label'      => __( 'Ruimte tussen opties', 'm7-smart-filters' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array( '{{WRAPPER}} .m7sf-list' => 'row-gap: {{SIZE}}{{UNIT}};' ),
			)
		);
		$this->end_controls_section();
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$args = array_merge(
			$this->common_args(),
			array(
				'show_label'   => 'yes' === $s['show_label'],
				'show_counter' => 'yes' === $s['show_counter'],
				'show_search'  => 'yes' === $s['show_search'],
				'more_less'    => isset( $s['more_less'] ) ? (int) $s['more_less'] : 0,
				'columns'      => 1, // via CSS-variabele (responsief).
			)
		);
		echo Render::filter( (int) $s['filter_id'], $args ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Render escapet zelf.
	}
}
