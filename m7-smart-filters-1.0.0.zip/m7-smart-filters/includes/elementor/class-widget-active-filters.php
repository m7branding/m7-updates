<?php
/**
 * Elementor-widget: M7 Actieve filters.
 *
 * @package M7SF
 */

namespace M7SF\Elementor;

use Elementor\Controls_Manager;
use M7SF\Elementor_Integration;
use M7SF\Render;

defined( 'ABSPATH' ) || exit;

class Widget_Active_Filters extends \Elementor\Widget_Base {

	use Common_Controls;

	public function get_name() {
		return 'm7sf-active-filters';
	}

	public function show_in_panel() {
		return false; // Vervangen door de widgets per type; bestaande pagina's blijven werken.
	}

	public function get_title() {
		return __( 'M7 Actieve filters', 'm7-smart-filters' );
	}

	public function get_icon() {
		return 'eicon-tags';
	}

	public function get_categories() {
		return array( Elementor_Integration::CATEGORY );
	}

	public function get_style_depends() {
		return array( 'm7sf' );
	}

	public function get_script_depends() {
		return array( 'm7sf' );
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_active', array( 'label' => __( 'Actieve filters', 'm7-smart-filters' ) ) );
		$this->add_query_controls();
		$this->add_control(
			'style',
			array(
				'label'   => __( 'Stijl', 'm7-smart-filters' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'list',
				'options' => array(
					'list' => __( 'Met filternaam', 'm7-smart-filters' ),
					'tags' => __( 'Alleen waarden (tags)', 'm7-smart-filters' ),
				),
			)
		);
		$this->add_control( 'title', array( 'label' => __( 'Titel', 'm7-smart-filters' ), 'type' => Controls_Manager::TEXT, 'default' => '' ) );
		$this->add_control( 'clear_label', array( 'label' => __( 'Tekst "alles wissen" (leeg = niet tonen)', 'm7-smart-filters' ), 'type' => Controls_Manager::TEXT, 'default' => '' ) );
		$this->end_controls_section();
		$this->add_text_style_section( 'style_items', __( 'Items', 'm7-smart-filters' ), '.m7sf-active__remove' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		echo Render::active_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			array_merge(
				$this->common_args(),
				array(
					'style'       => $s['style'],
					'title'       => $s['title'],
					'clear_label' => $s['clear_label'],
				)
			)
		);
	}
}
