<?php
/**
 * Beheerscherm van een filter (metabox) en lijstkolommen.
 *
 * @package M7SF
 */

namespace M7SF;

defined( 'ABSPATH' ) || exit;

final class Admin {

	public static function init() {
		add_action( 'add_meta_boxes_' . Filter_Post_Type::POST_TYPE, array( __CLASS__, 'meta_boxes' ) );
		add_action( 'save_post_' . Filter_Post_Type::POST_TYPE, array( __CLASS__, 'save' ), 10, 2 );
		add_filter( 'manage_' . Filter_Post_Type::POST_TYPE . '_posts_columns', array( __CLASS__, 'columns' ) );
		add_action( 'manage_' . Filter_Post_Type::POST_TYPE . '_posts_custom_column', array( __CLASS__, 'column' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	public static function assets() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		if ( ( $screen && Filter_Post_Type::POST_TYPE === $screen->post_type ) || 0 === strpos( $page, 'm7sf-' ) ) {
			wp_enqueue_style( 'm7sf-admin', M7SF_URL . 'assets/m7-admin.css', array(), M7SF_VERSION . '.' . (int) @filemtime( M7SF_DIR . 'assets/m7-admin.css' ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
	}


	public static function meta_boxes() {
		add_meta_box( 'm7sf-settings', __( 'Filterinstellingen', 'm7-smart-filters' ), array( __CLASS__, 'box' ), Filter_Post_Type::POST_TYPE, 'normal', 'high' );
		add_meta_box( 'm7sf-usage', __( 'Gebruik', 'm7-smart-filters' ), array( __CLASS__, 'usage' ), Filter_Post_Type::POST_TYPE, 'side' );
	}

	public static function usage( $post ) {
		$s = Filter_Post_Type::get( $post->ID );
		echo '<p>' . esc_html__( 'Shortcode:', 'm7-smart-filters' ) . '<br><code>[m7_filter id="' . (int) $post->ID . '" query="QUERY-ID"]</code></p>';
		echo '<p>' . esc_html__( 'Of gebruik de Elementor-widget "M7 Filter". Vul bij de lijst (Loop Grid, Posts, Products) hetzelfde Query ID in. Gebruik "main" voor het WooCommerce-archief.', 'm7-smart-filters' ) . '</p>';
		if ( $s ) {
			echo '<p>' . esc_html__( 'URL-parameter:', 'm7-smart-filters' ) . ' <code>' . esc_html( Filter_Post_Type::param_for( $s ) ) . '</code></p>';
			if ( $s['legacy_jsf_id'] ) {
				/* translators: %d: ID van het oude JetSmartFilters-filter */
				echo '<p>' . esc_html( sprintf( __( 'Geïmporteerd uit JetSmartFilters-filter #%d.', 'm7-smart-filters' ), $s['legacy_jsf_id'] ) ) . '</p>';
			}
		}
	}

	public static function box( $post ) {
		$s = Filter_Post_Type::get( $post->ID );
		$s           = $s ? $s : Filter_Post_Type::defaults();
		$saved       = get_post_meta( $post->ID, Filter_Post_Type::META, true );
		$saved_label = ( is_array( $saved ) && isset( $saved['label'] ) ) ? (string) $saved['label'] : '';
		wp_nonce_field( 'm7sf_save', 'm7sf_nonce' );
		$name = static function ( $key ) {
			return 'm7sf[' . $key . ']';
		};

		$taxonomies = get_taxonomies( array( 'show_ui' => true ), 'objects' );
		$post_types = get_post_types( array( 'public' => true ), 'objects' );

		$manual = '';
		foreach ( $s['manual_options'] as $o ) {
			$manual .= $o['value'] . ' | ' . $o['label'] . ( $o['color'] ? ' | ' . $o['color'] : ( $o['image'] ? ' |' : '' ) ) . ( $o['image'] ? ' | ' . $o['image'] : '' ) . "\n";
		}
		$ranges = '';
		foreach ( $s['check_ranges'] as $r ) {
			$ranges .= $r['min'] . ' - ' . $r['max'] . ( '' !== $r['label'] ? ' | ' . $r['label'] : '' ) . "\n";
		}
		?>
		<style>
			.m7sf-admin .form-table th { width: 220px; }
			.m7sf-admin [data-types], .m7sf-admin [data-sources] { display: none; }
			.m7sf-admin .is-visible { display: table-row; }
			.m7sf-admin textarea { width: 100%; min-height: 8em; font-family: monospace; }
		</style>
		<div class="m7sf-admin">
			<table class="form-table" role="presentation">
				<tr>
					<th><label for="m7sf-type"><?php esc_html_e( 'Type', 'm7-smart-filters' ); ?></label></th>
					<td><select id="m7sf-type" name="<?php echo esc_attr( $name( 'type' ) ); ?>">
						<?php foreach ( Filter_Post_Type::TYPES as $key => $label ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $s['type'], $key ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select></td>
				</tr>
				<tr>
					<th><label for="m7sf-label"><?php esc_html_e( 'Label op de site', 'm7-smart-filters' ); ?></label></th>
					<td><input id="m7sf-label" type="text" class="regular-text" name="<?php echo esc_attr( $name( 'label' ) ); ?>" value="<?php echo esc_attr( $saved_label ); ?>" placeholder="<?php esc_attr_e( 'Leeg = geen label boven het filter', 'm7-smart-filters' ); ?>">
					<p class="description"><?php esc_html_e( 'Zichtbaar als "Filterlabel tonen" in het widget aan staat. Leeg: geen label (de titel wordt dan alleen voor schermlezers gebruikt).', 'm7-smart-filters' ); ?></p>
					<p><label><?php esc_html_e( 'Label bij actieve filters', 'm7-smart-filters' ); ?> <input type="text" class="regular-text" name="<?php echo esc_attr( $name( 'active_label' ) ); ?>" value="<?php echo esc_attr( $s['active_label'] ); ?>"></label></p></td>
				</tr>
				<tr data-types="checkboxes select radio color_image">
					<th><label for="m7sf-source"><?php esc_html_e( 'Bron van de opties', 'm7-smart-filters' ); ?></label></th>
					<td><select id="m7sf-source" name="<?php echo esc_attr( $name( 'source' ) ); ?>">
						<?php foreach ( Filter_Post_Type::SOURCES as $key => $label ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $s['source'], $key ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select></td>
				</tr>

				<tr data-types="checkboxes select radio color_image" data-sources="taxonomy">
					<th><label for="m7sf-tax"><?php esc_html_e( 'Taxonomie', 'm7-smart-filters' ); ?></label></th>
					<td><select id="m7sf-tax" name="<?php echo esc_attr( $name( 'taxonomy' ) ); ?>">
						<?php foreach ( $taxonomies as $tax ) : ?>
							<option value="<?php echo esc_attr( $tax->name ); ?>" <?php selected( $s['taxonomy'], $tax->name ); ?>><?php echo esc_html( $tax->labels->singular_name . ' (' . $tax->name . ')' ); ?></option>
						<?php endforeach; ?>
					</select>
					<p><label><?php esc_html_e( 'Meerdere gekozen termen:', 'm7-smart-filters' ); ?>
						<select name="<?php echo esc_attr( $name( 'tax_relation' ) ); ?>">
							<option value="IN" <?php selected( $s['tax_relation'], 'IN' ); ?>><?php esc_html_e( 'een van (OF)', 'm7-smart-filters' ); ?></option>
							<option value="AND" <?php selected( $s['tax_relation'], 'AND' ); ?>><?php esc_html_e( 'allemaal (EN)', 'm7-smart-filters' ); ?></option>
						</select></label></p>
					<p><label><input type="checkbox" name="<?php echo esc_attr( $name( 'hide_empty' ) ); ?>" value="1" <?php checked( $s['hide_empty'] ); ?>> <?php esc_html_e( 'Lege termen verbergen', 'm7-smart-filters' ); ?></label>
					&nbsp; <label><input type="checkbox" name="<?php echo esc_attr( $name( 'hierarchical' ) ); ?>" value="1" <?php checked( $s['hierarchical'] ); ?>> <?php esc_html_e( 'Als boom tonen (ouders en kinderen)', 'm7-smart-filters' ); ?></label>
					&nbsp; <label><input type="checkbox" name="<?php echo esc_attr( $name( 'collapsible' ) ); ?>" value="1" <?php checked( $s['collapsible'] ); ?>> <?php esc_html_e( 'Subopties in- en uitklapbaar', 'm7-smart-filters' ); ?></label></p>
					<p><label><?php esc_html_e( 'Alleen onder term-ID', 'm7-smart-filters' ); ?> <input type="number" min="0" class="small-text" name="<?php echo esc_attr( $name( 'only_child_of' ) ); ?>" value="<?php echo esc_attr( (string) $s['only_child_of'] ); ?>"></label></p>
					<p><label><?php esc_html_e( 'Alleen deze term-ID\'s', 'm7-smart-filters' ); ?> <input type="text" name="<?php echo esc_attr( $name( 'terms_include' ) ); ?>" value="<?php echo esc_attr( $s['terms_include'] ); ?>"></label>
					&nbsp; <label><?php esc_html_e( 'Uitsluiten', 'm7-smart-filters' ); ?> <input type="text" name="<?php echo esc_attr( $name( 'terms_exclude' ) ); ?>" value="<?php echo esc_attr( $s['terms_exclude'] ); ?>"></label></p>
					<p><label><?php esc_html_e( 'Volgorde', 'm7-smart-filters' ); ?>
						<select name="<?php echo esc_attr( $name( 'terms_orderby' ) ); ?>">
							<?php foreach ( array( 'name' => __( 'Naam', 'm7-smart-filters' ), 'menu_order' => __( 'Eigen volgorde (WooCommerce)', 'm7-smart-filters' ), 'count' => __( 'Aantal', 'm7-smart-filters' ), 'slug' => 'Slug', 'id' => 'ID', 'term_order' => 'term_order' ) as $k => $l ) : ?>
								<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $s['terms_orderby'], $k ); ?>><?php echo esc_html( $l ); ?></option>
							<?php endforeach; ?>
						</select>
						<select name="<?php echo esc_attr( $name( 'terms_order' ) ); ?>">
							<option value="ASC" <?php selected( $s['terms_order'], 'ASC' ); ?>>ASC</option>
							<option value="DESC" <?php selected( $s['terms_order'], 'DESC' ); ?>>DESC</option>
						</select></label></p></td>
				</tr>

				<tr data-types="checkboxes select radio color_image" data-sources="manual">
					<th><label for="m7sf-manual"><?php esc_html_e( 'Opties', 'm7-smart-filters' ); ?></label></th>
					<td><textarea id="m7sf-manual" name="m7sf[manual_text]"><?php echo esc_textarea( $manual ); ?></textarea>
					<p class="description"><?php esc_html_e( 'Eén optie per regel: waarde | label | #kleur | afbeelding-ID. Label, kleur en afbeelding zijn optioneel.', 'm7-smart-filters' ); ?></p></td>
				</tr>

				<tr data-types="checkboxes select radio color_image" data-sources="posts">
					<th><label for="m7sf-pt"><?php esc_html_e( 'Berichttype van de opties', 'm7-smart-filters' ); ?></label></th>
					<td><select id="m7sf-pt" name="<?php echo esc_attr( $name( 'posts_post_type' ) ); ?>">
						<?php foreach ( $post_types as $pt ) : ?>
							<option value="<?php echo esc_attr( $pt->name ); ?>" <?php selected( $s['posts_post_type'], $pt->name ); ?>><?php echo esc_html( $pt->labels->singular_name ); ?></option>
						<?php endforeach; ?>
					</select></td>
				</tr>

				<tr data-types="checkboxes select radio color_image range check_range search date_range date_period" data-sources="meta manual posts" data-always-for="range check_range search date_range date_period">
					<th><label for="m7sf-meta"><?php esc_html_e( 'Custom field (metasleutel)', 'm7-smart-filters' ); ?></label></th>
					<td><input id="m7sf-meta" type="text" class="regular-text" name="<?php echo esc_attr( $name( 'meta_key' ) ); ?>" value="<?php echo esc_attr( $s['meta_key'] ); ?>" placeholder="_price">
					<p><label><?php esc_html_e( 'Vergelijking', 'm7-smart-filters' ); ?>
						<select name="<?php echo esc_attr( $name( 'meta_compare' ) ); ?>">
							<?php foreach ( array( 'IN' => __( 'is een van', 'm7-smart-filters' ), '=' => __( 'is gelijk aan', 'm7-smart-filters' ), 'LIKE' => __( 'bevat', 'm7-smart-filters' ), 'BETWEEN' => __( 'tussen', 'm7-smart-filters' ), '>=' => '>=', '<=' => '<=' ) as $k => $l ) : ?>
								<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $s['meta_compare'], $k ); ?>><?php echo esc_html( $l ); ?></option>
							<?php endforeach; ?>
						</select></label></p>
					<p class="description"><?php esc_html_e( 'Voor bereik leeg laten = WooCommerce-prijs (_price). Voor zoeken alleen invullen als je in een custom field zoekt.', 'm7-smart-filters' ); ?></p></td>
				</tr>

				<tr data-types="range">
					<th><?php esc_html_e( 'Bereik', 'm7-smart-filters' ); ?></th>
					<td><label><?php esc_html_e( 'Min', 'm7-smart-filters' ); ?> <input type="number" step="any" class="small-text" name="<?php echo esc_attr( $name( 'range_min' ) ); ?>" value="<?php echo esc_attr( (string) $s['range_min'] ); ?>"></label>
					<label><?php esc_html_e( 'Max', 'm7-smart-filters' ); ?> <input type="number" step="any" class="small-text" name="<?php echo esc_attr( $name( 'range_max' ) ); ?>" value="<?php echo esc_attr( (string) $s['range_max'] ); ?>"></label>
					<label><?php esc_html_e( 'Stap', 'm7-smart-filters' ); ?> <input type="number" step="any" min="0" class="small-text" name="<?php echo esc_attr( $name( 'range_step' ) ); ?>" value="<?php echo esc_attr( (string) $s['range_step'] ); ?>"></label>
					<p class="description"><?php esc_html_e( 'Min/max leeg = automatisch uit de gegevens.', 'm7-smart-filters' ); ?></p></td>
				</tr>
				<tr data-types="range check_range">
					<th><?php esc_html_e( 'Weergave van getallen', 'm7-smart-filters' ); ?></th>
					<td><label><?php esc_html_e( 'Voor', 'm7-smart-filters' ); ?> <input type="text" class="small-text" name="<?php echo esc_attr( $name( 'range_prefix' ) ); ?>" value="<?php echo esc_attr( $s['range_prefix'] ); ?>" placeholder="€ "></label>
					<label><?php esc_html_e( 'Na', 'm7-smart-filters' ); ?> <input type="text" class="small-text" name="<?php echo esc_attr( $name( 'range_suffix' ) ); ?>" value="<?php echo esc_attr( $s['range_suffix'] ); ?>"></label>
					<label><?php esc_html_e( 'Decimalen', 'm7-smart-filters' ); ?> <input type="number" min="0" max="4" class="small-text" name="<?php echo esc_attr( $name( 'range_decimals' ) ); ?>" value="<?php echo esc_attr( (string) $s['range_decimals'] ); ?>"></label>
					<label><?php esc_html_e( 'Decimaalteken', 'm7-smart-filters' ); ?> <input type="text" class="small-text" name="<?php echo esc_attr( $name( 'range_decimal_sep' ) ); ?>" value="<?php echo esc_attr( $s['range_decimal_sep'] ); ?>"></label>
					<label><?php esc_html_e( 'Duizendtal', 'm7-smart-filters' ); ?> <input type="text" class="small-text" name="<?php echo esc_attr( $name( 'range_thousand_sep' ) ); ?>" value="<?php echo esc_attr( $s['range_thousand_sep'] ); ?>"></label></td>
				</tr>
				<tr data-types="range">
					<th><?php esc_html_e( 'Invoervelden', 'm7-smart-filters' ); ?></th>
					<td><label><input type="checkbox" name="<?php echo esc_attr( $name( 'range_inputs' ) ); ?>" value="1" <?php checked( $s['range_inputs'] ); ?>> <?php esc_html_e( 'Invoervelden onder het schuifje in plaats van tekst', 'm7-smart-filters' ); ?></label>
					<label style="margin-left:12px"><input type="checkbox" name="<?php echo esc_attr( $name( 'range_inputs_separators' ) ); ?>" value="1" <?php checked( $s['range_inputs_separators'] ); ?>> <?php esc_html_e( 'Met scheidingstekens', 'm7-smart-filters' ); ?></label></td>
				</tr>
				<tr data-types="check_range">
					<th><label for="m7sf-ranges"><?php esc_html_e( 'Bereiken', 'm7-smart-filters' ); ?></label></th>
					<td><textarea id="m7sf-ranges" name="m7sf[ranges_text]"><?php echo esc_textarea( $ranges ); ?></textarea>
					<p class="description"><?php esc_html_e( 'Eén bereik per regel: min - max | label. Laat min of max leeg voor een open kant, bijv. "500 - | 500 en meer".', 'm7-smart-filters' ); ?></p></td>
				</tr>
				<tr data-types="search">
					<th><?php esc_html_e( 'Zoeken', 'm7-smart-filters' ); ?></th>
					<td><label><input type="radio" name="<?php echo esc_attr( $name( 'search_by' ) ); ?>" value="default" <?php checked( $s['search_by'], 'default' ); ?>> <?php esc_html_e( 'Titel en inhoud', 'm7-smart-filters' ); ?></label>
					&nbsp; <label><input type="radio" name="<?php echo esc_attr( $name( 'search_by' ) ); ?>" value="meta" <?php checked( $s['search_by'], 'meta' ); ?>> <?php esc_html_e( 'Custom field (hierboven)', 'm7-smart-filters' ); ?></label>
					<p><label><?php esc_html_e( 'Minimaal aantal tekens', 'm7-smart-filters' ); ?> <input type="number" min="0" class="small-text" name="<?php echo esc_attr( $name( 'search_min_chars' ) ); ?>" value="<?php echo esc_attr( (string) $s['search_min_chars'] ); ?>"></label></p></td>
				</tr>
				<tr data-types="select search">
					<th><label for="m7sf-ph"><?php esc_html_e( 'Placeholder', 'm7-smart-filters' ); ?></label></th>
					<td><input id="m7sf-ph" type="text" class="regular-text" name="<?php echo esc_attr( $name( 'placeholder' ) ); ?>" value="<?php echo esc_attr( $s['placeholder'] ); ?>"></td>
				</tr>
				<tr data-types="select color_image">
					<th><?php esc_html_e( 'Meerdere kiezen', 'm7-smart-filters' ); ?></th>
					<td><label><input type="checkbox" name="<?php echo esc_attr( $name( 'multiple' ) ); ?>" value="1" <?php checked( $s['multiple'] ); ?>> <?php esc_html_e( 'Bezoeker mag meerdere opties kiezen', 'm7-smart-filters' ); ?></label></td>
				</tr>
				<tr data-types="color_image">
					<th><?php esc_html_e( 'Weergave', 'm7-smart-filters' ); ?></th>
					<td><select name="<?php echo esc_attr( $name( 'color_image_type' ) ); ?>">
						<option value="color" <?php selected( $s['color_image_type'], 'color' ); ?>><?php esc_html_e( 'Kleur', 'm7-smart-filters' ); ?></option>
						<option value="image" <?php selected( $s['color_image_type'], 'image' ); ?>><?php esc_html_e( 'Afbeelding', 'm7-smart-filters' ); ?></option>
					</select></td>
				</tr>
				<tr data-types="radio select color_image alphabet">
					<th><?php esc_html_e( '"Alles"-optie', 'm7-smart-filters' ); ?></th>
					<td><label><input type="checkbox" name="<?php echo esc_attr( $name( 'show_all_option' ) ); ?>" value="1" <?php checked( $s['show_all_option'] ); ?>> <?php esc_html_e( 'Tonen (radio)', 'm7-smart-filters' ); ?></label>
					<label style="margin-left:12px"><input type="checkbox" name="<?php echo esc_attr( $name( 'can_deselect' ) ); ?>" value="1" <?php checked( $s['can_deselect'] ); ?>> <?php esc_html_e( 'Nogmaals klikken zet de keuze uit (radio)', 'm7-smart-filters' ); ?></label>
					<input type="text" name="<?php echo esc_attr( $name( 'all_label' ) ); ?>" value="<?php echo esc_attr( $s['all_label'] ); ?>" placeholder="<?php esc_attr_e( 'Alles', 'm7-smart-filters' ); ?>"></td>
				</tr>
				<tr data-types="rating">
					<th><?php esc_html_e( 'Aantal sterren', 'm7-smart-filters' ); ?></th>
					<td><input type="number" min="1" max="10" class="small-text" name="<?php echo esc_attr( $name( 'rating_max' ) ); ?>" value="<?php echo esc_attr( (string) $s['rating_max'] ); ?>">
					<select name="<?php echo esc_attr( $name( 'rating_compare' ) ); ?>">
						<option value="greater" <?php selected( $s['rating_compare'], 'greater' ); ?>><?php esc_html_e( 'zoveel sterren of meer', 'm7-smart-filters' ); ?></option>
						<option value="less" <?php selected( $s['rating_compare'], 'less' ); ?>><?php esc_html_e( 'zoveel sterren of minder', 'm7-smart-filters' ); ?></option>
						<option value="equal" <?php selected( $s['rating_compare'], 'equal' ); ?>><?php esc_html_e( 'precies zoveel sterren', 'm7-smart-filters' ); ?></option>
					</select></td>
				</tr>
				<tr data-types="alphabet">
					<th><?php esc_html_e( 'Letters', 'm7-smart-filters' ); ?></th>
					<td><input type="text" class="large-text" name="<?php echo esc_attr( $name( 'alphabet_letters' ) ); ?>" value="<?php echo esc_attr( $s['alphabet_letters'] ); ?>"><p class="description"><?php esc_html_e( 'Kommagescheiden. Gebruik # voor titels die met een cijfer beginnen.', 'm7-smart-filters' ); ?></p>
					<label><input type="checkbox" name="<?php echo esc_attr( $name( 'alphabet_multiple' ) ); ?>" value="1" <?php checked( $s['alphabet_multiple'] ); ?>> <?php esc_html_e( 'Meerdere letters tegelijk', 'm7-smart-filters' ); ?></label></td>
				</tr>
				<tr data-types="date_range date_period">
					<th><?php esc_html_e( 'Datum', 'm7-smart-filters' ); ?></th>
					<td><label><input type="radio" name="<?php echo esc_attr( $name( 'date_source' ) ); ?>" value="post_date" <?php checked( $s['date_source'], 'post_date' ); ?>> <?php esc_html_e( 'Publicatiedatum', 'm7-smart-filters' ); ?></label>
					&nbsp; <label><input type="radio" name="<?php echo esc_attr( $name( 'date_source' ) ); ?>" value="meta" <?php checked( $s['date_source'], 'meta' ); ?>> <?php esc_html_e( 'Custom field (JJJJ-MM-DD)', 'm7-smart-filters' ); ?></label>
					<p><label><?php esc_html_e( 'Te kiezen', 'm7-smart-filters' ); ?> <select name="<?php echo esc_attr( $name( 'date_available_range' ) ); ?>">
						<?php foreach ( array( 'all' => __( 'Alle datums', 'm7-smart-filters' ), 'future' => __( 'Vanaf vandaag', 'm7-smart-filters' ), 'past' => __( 'Tot en met vandaag', 'm7-smart-filters' ), 'custom' => __( 'Eigen grenzen', 'm7-smart-filters' ) ) as $k => $l ) : ?>
							<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $s['date_available_range'], $k ); ?>><?php echo esc_html( $l ); ?></option>
						<?php endforeach; ?>
					</select></label>
					<label><?php esc_html_e( 'Van', 'm7-smart-filters' ); ?> <input type="text" class="regular-text" style="width:10em" name="<?php echo esc_attr( $name( 'date_min' ) ); ?>" value="<?php echo esc_attr( $s['date_min'] ); ?>" placeholder="today"></label>
					<label><?php esc_html_e( 'Tot', 'm7-smart-filters' ); ?> <input type="text" class="regular-text" style="width:10em" name="<?php echo esc_attr( $name( 'date_max' ) ); ?>" value="<?php echo esc_attr( $s['date_max'] ); ?>" placeholder="today + 1 year"></label></p></td>
				</tr>
				<tr data-types="date_range">
					<th><?php esc_html_e( 'Velden', 'm7-smart-filters' ); ?></th>
					<td><label><?php esc_html_e( 'Notatie', 'm7-smart-filters' ); ?> <input type="text" class="small-text" style="width:7em" name="<?php echo esc_attr( $name( 'date_format' ) ); ?>" value="<?php echo esc_attr( $s['date_format'] ); ?>" placeholder="mm/dd/yy"></label>
					<label><?php esc_html_e( 'Placeholder van', 'm7-smart-filters' ); ?> <input type="text" name="<?php echo esc_attr( $name( 'date_from_placeholder' ) ); ?>" value="<?php echo esc_attr( $s['date_from_placeholder'] ); ?>"></label>
					<label><?php esc_html_e( 'Placeholder tot', 'm7-smart-filters' ); ?> <input type="text" name="<?php echo esc_attr( $name( 'date_to_placeholder' ) ); ?>" value="<?php echo esc_attr( $s['date_to_placeholder'] ); ?>"></label>
					<p class="description"><?php esc_html_e( 'Notatie: d, dd (dag), m, mm, M, MM (maand), y, yy (jaar), D, DD (weekdag). Bijvoorbeeld dd-mm-yy.', 'm7-smart-filters' ); ?></p></td>
				</tr>
				<tr data-types="date_period">
					<th><?php esc_html_e( 'Knop en notatie', 'm7-smart-filters' ); ?></th>
					<td><label><?php esc_html_e( 'Tekst knop', 'm7-smart-filters' ); ?> <input type="text" name="<?php echo esc_attr( $name( 'date_period_button_text' ) ); ?>" value="<?php echo esc_attr( $s['date_period_button_text'] ); ?>"></label>
					<label><?php esc_html_e( 'Notatie', 'm7-smart-filters' ); ?> <input type="text" style="width:7em" name="<?php echo esc_attr( $name( 'date_period_format' ) ); ?>" value="<?php echo esc_attr( $s['date_period_format'] ); ?>" placeholder="mm/dd/yy"></label>
					<p><label><input type="checkbox" name="<?php echo esc_attr( $name( 'date_period_start_end' ) ); ?>" value="1" <?php checked( $s['date_period_start_end'] ); ?>> <?php esc_html_e( 'Begin en eind tonen', 'm7-smart-filters' ); ?></label>
					<label><?php esc_html_e( 'Begin', 'm7-smart-filters' ); ?> <input type="text" style="width:7em" name="<?php echo esc_attr( $name( 'date_period_start_format' ) ); ?>" value="<?php echo esc_attr( $s['date_period_start_format'] ); ?>" placeholder="mm/dd/yy"></label>
					<label><?php esc_html_e( 'Scheiding', 'm7-smart-filters' ); ?> <input type="text" class="small-text" name="<?php echo esc_attr( $name( 'date_period_separator' ) ); ?>" value="<?php echo esc_attr( $s['date_period_separator'] ); ?>" placeholder="-"></label>
					<label><?php esc_html_e( 'Eind', 'm7-smart-filters' ); ?> <input type="text" style="width:7em" name="<?php echo esc_attr( $name( 'date_period_end_format' ) ); ?>" value="<?php echo esc_attr( $s['date_period_end_format'] ); ?>" placeholder="mm/dd/yy"></label></p></td>
				</tr>
				<tr data-types="date_period">
					<th><?php esc_html_e( 'Periode', 'm7-smart-filters' ); ?></th>
					<td><select name="<?php echo esc_attr( $name( 'date_period_type' ) ); ?>">
						<?php foreach ( array( 'day' => __( 'Dag', 'm7-smart-filters' ), 'week' => __( 'Week', 'm7-smart-filters' ), 'month' => __( 'Maand', 'm7-smart-filters' ), 'year' => __( 'Jaar', 'm7-smart-filters' ), 'range' => __( 'Eigen bereik', 'm7-smart-filters' ) ) as $k => $l ) : ?>
							<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $s['date_period_type'], $k ); ?>><?php echo esc_html( $l ); ?></option>
						<?php endforeach; ?>
					</select></td>
				</tr>
			</table>
			<input type="hidden" name="<?php echo esc_attr( $name( 'legacy_jsf_id' ) ); ?>" value="<?php echo esc_attr( (string) $s['legacy_jsf_id'] ); ?>">
		</div>
		<script>
		( function () {
			var type = document.getElementById( 'm7sf-type' );
			var source = document.getElementById( 'm7sf-source' );
			function update() {
				document.querySelectorAll( '.m7sf-admin tr[data-types]' ).forEach( function ( tr ) {
					var types = tr.getAttribute( 'data-types' ).split( ' ' );
					var sources = tr.getAttribute( 'data-sources' );
					var always = ( tr.getAttribute( 'data-always-for' ) || '' ).split( ' ' );
					var show = types.indexOf( type.value ) !== -1;
					if ( show && sources && always.indexOf( type.value ) === -1 ) {
						show = sources.split( ' ' ).indexOf( source.value ) !== -1;
					}
					tr.classList.toggle( 'is-visible', show );
				} );
			}
			type.addEventListener( 'change', update );
			source.addEventListener( 'change', update );
			update();
		} )();
		</script>
		<?php
	}

	public static function save( $post_id, $post ) {
		if ( ! isset( $_POST['m7sf_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['m7sf_nonce'] ) ), 'm7sf_save' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Filter_Post_Type::sanitize() schoont alles op.
		$raw = isset( $_POST['m7sf'] ) && is_array( $_POST['m7sf'] ) ? wp_unslash( $_POST['m7sf'] ) : array();

		if ( isset( $raw['manual_text'] ) ) {
			$raw['manual_options'] = array();
			foreach ( preg_split( '/\r\n|\r|\n/', (string) $raw['manual_text'] ) as $line ) {
				$bits = array_map( 'trim', explode( '|', $line ) );
				if ( '' === $bits[0] ) {
					continue;
				}
				$color = '';
				$image = 0;
				foreach ( array_slice( $bits, 2 ) as $extra ) {
					if ( '#' === substr( $extra, 0, 1 ) ) {
						$color = $extra;
					} elseif ( ctype_digit( $extra ) ) {
						$image = (int) $extra;
					}
				}
				$raw['manual_options'][] = array(
					'value' => $bits[0],
					'label' => isset( $bits[1] ) ? $bits[1] : $bits[0],
					'color' => $color,
					'image' => $image,
				);
			}
		}
		if ( isset( $raw['ranges_text'] ) ) {
			$raw['check_ranges'] = array();
			foreach ( preg_split( '/\r\n|\r|\n/', (string) $raw['ranges_text'] ) as $line ) {
				if ( '' === trim( $line ) ) {
					continue;
				}
				$parts  = array_map( 'trim', explode( '|', $line, 2 ) );
				$minmax = array_map( 'trim', explode( ' - ', $parts[0], 2 ) );
				$raw['check_ranges'][] = array(
					'min'   => isset( $minmax[0] ) ? $minmax[0] : '',
					'max'   => isset( $minmax[1] ) ? $minmax[1] : '',
					'label' => isset( $parts[1] ) ? $parts[1] : '',
				);
			}
		}
		update_post_meta( $post_id, Filter_Post_Type::META, Filter_Post_Type::sanitize( $raw ) );
	}

	public static function columns( $columns ) {
		$new = array();
		foreach ( $columns as $key => $label ) {
			$new[ $key ] = $label;
			if ( 'title' === $key ) {
				$new['m7sf_type']  = __( 'Type', 'm7-smart-filters' );
				$new['m7sf_param'] = __( 'URL-parameter', 'm7-smart-filters' );
				$new['m7sf_code']  = __( 'Shortcode', 'm7-smart-filters' );
			}
		}
		return $new;
	}

	public static function column( $column, $post_id ) {
		$s = Filter_Post_Type::get( $post_id );
		if ( ! $s ) {
			return;
		}
		if ( 'm7sf_type' === $column ) {
			echo esc_html( Filter_Post_Type::TYPES[ $s['type'] ] );
		} elseif ( 'm7sf_param' === $column ) {
			echo '<code>' . esc_html( Filter_Post_Type::param_for( $s ) ) . '</code>';
		} elseif ( 'm7sf_code' === $column ) {
			echo '<code>[m7_filter id="' . (int) $post_id . '" query=""]</code>';
		}
	}
}
