<?php
/**
 * Hoofdklasse: zet alle onderdelen aan.
 *
 * @package M7SF
 */

namespace M7SF;

defined( 'ABSPATH' ) || exit;

final class Plugin {

	/** @var Plugin|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		load_plugin_textdomain( 'm7-smart-filters', false, dirname( plugin_basename( M7SF_FILE ) ) . '/languages' );

		Filter_Post_Type::init();
		Sources::init();
		Query::init();
		Providers::init();
		Shortcodes::init();
		Assets::init();
		Legacy_Urls::init();
		Settings::init();
		Partial::init();

		if ( is_admin() ) {
			require_once M7SF_DIR . 'includes/m7/class-m7-admin-menu.php';
			add_action( 'init', array( __CLASS__, 'register_m7_menu' ) );
			Admin::init();
			Importer_Jsf::init();
		}
		Cli::register();

		add_action( 'elementor/widgets/register', array( Elementor_Integration::class, 'register_widgets' ) );
		add_action( 'elementor/elements/categories_registered', array( Elementor_Integration::class, 'register_category' ) );
	}

	/**
	 * Aanmelden bij het gedeelde M7-menu in wp-admin.
	 */
	public static function register_m7_menu() {
		\M7_Admin_Menu::register_plugin(
			array(
				'slug'        => 'm7-smart-filters',
				'name'        => __( 'Smart Filters', 'm7-smart-filters' ),
				'version'     => M7SF_VERSION,
				'description' => __( 'Filters voor producten en berichten, zonder herladen. Vervanger van JetSmartFilters.', 'm7-smart-filters' ),
				'order'       => 10,
				'tabs'        => array(
					__( 'Filters', 'm7-smart-filters' )      => 'edit.php?post_type=' . Filter_Post_Type::POST_TYPE,
					__( 'Instellingen', 'm7-smart-filters' ) => 'm7sf-settings',
					__( 'Overstappen', 'm7-smart-filters' )  => Importer_Jsf::PAGE,
				),
			)
		);
	}
}
