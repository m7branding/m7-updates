<?php
/**
 * Shortcodes:
 *   [m7_filter id="12" query="rijlaars" apply="ajax" apply_on="value" label="yes" counter="no" search="no" more="0" columns="1" selector="" redirect=""]
 *   [m7_sorting query="rijlaars" options="menu_order,price-asc,price-desc" label=""]
 *   [m7_active_filters query="rijlaars" style="tags" title="" clear=""]
 *   [m7_remove_filters query="rijlaars" label="Filters wissen"]
 *   [m7_apply_button query="rijlaars" label="Toepassen"]
 *
 * @package M7SF
 */

namespace M7SF;

defined( 'ABSPATH' ) || exit;

final class Shortcodes {

	public static function init() {
		add_shortcode( 'm7_filter', array( __CLASS__, 'filter' ) );
		add_shortcode( 'm7_sorting', array( __CLASS__, 'sorting' ) );
		add_shortcode( 'm7_active_filters', array( __CLASS__, 'active' ) );
		add_shortcode( 'm7_remove_filters', array( __CLASS__, 'remove' ) );
		add_shortcode( 'm7_apply_button', array( __CLASS__, 'apply' ) );
	}

	private static function common( $atts ) {
		return array(
			'query_id'   => isset( $atts['query'] ) ? $atts['query'] : '',
			'apply_type' => isset( $atts['apply'] ) ? $atts['apply'] : 'ajax',
			'selector'   => isset( $atts['selector'] ) ? $atts['selector'] : '',
			'redirect'   => isset( $atts['redirect'] ) ? $atts['redirect'] : '',
			'class'      => isset( $atts['class'] ) ? $atts['class'] : '',
		);
	}

	public static function filter( $atts ) {
		$atts = (array) $atts;
		$args = array_merge(
			self::common( $atts ),
			array(
				'apply_on'     => isset( $atts['apply_on'] ) ? $atts['apply_on'] : 'value',
				'show_label'   => isset( $atts['label'] ) ? $atts['label'] : 'yes',
				'show_counter' => isset( $atts['counter'] ) ? $atts['counter'] : 'no',
				'show_search'  => isset( $atts['search'] ) ? $atts['search'] : 'no',
				'more_less'    => isset( $atts['more'] ) ? $atts['more'] : 0,
				'columns'      => isset( $atts['columns'] ) ? $atts['columns'] : 1,
			)
		);
		return Render::filter( isset( $atts['id'] ) ? (int) $atts['id'] : 0, $args );
	}

	public static function sorting( $atts ) {
		$atts = (array) $atts;
		$args = self::common( $atts );
		if ( ! empty( $atts['options'] ) ) {
			$args['options'] = array_filter( array_map( 'trim', explode( ',', $atts['options'] ) ) );
		}
		$args['label']       = isset( $atts['label'] ) ? $atts['label'] : '';
		$args['placeholder'] = isset( $atts['placeholder'] ) ? $atts['placeholder'] : '';
		return Render::sorting( $args );
	}

	public static function active( $atts ) {
		$atts                = (array) $atts;
		$args                = self::common( $atts );
		$args['style']       = isset( $atts['style'] ) ? $atts['style'] : 'list';
		$args['title']       = isset( $atts['title'] ) ? $atts['title'] : '';
		$args['clear_label'] = isset( $atts['clear'] ) ? $atts['clear'] : '';
		return Render::active_filters( $args );
	}

	public static function remove( $atts ) {
		$atts          = (array) $atts;
		$args          = self::common( $atts );
		$args['label'] = isset( $atts['label'] ) ? $atts['label'] : '';
		return Render::remove_filters( $args );
	}

	public static function apply( $atts ) {
		$atts          = (array) $atts;
		$args          = self::common( $atts );
		$args['label'] = isset( $atts['label'] ) ? $atts['label'] : '';
		return Render::apply_button( $args );
	}
}
