<?php
/**
 * HTML van de M7-filterwidgets in dezelfde opbouw als JetSmartFilters 3.7.0 (classes jet-… heten hier m7sf-…).
 * Zo geven dezelfde Elementor-instellingen hetzelfde beeld. De M7-filterlogica (data-m7sf-*) zit op .m7sf-filter.
 *
 * @package M7SF
 */

namespace M7SF;

defined( 'ABSPATH' ) || exit;

final class Markup {

	/** Widgettypen die een filter (berichttype m7sf_filter) tonen, met het bijbehorende M7-filtertype. */
	const FILTER_TYPES = array(
		'checkboxes'  => 'checkboxes',
		'radio'       => 'radio',
		'select'      => 'select',
		'range'       => 'range',
		'check-range' => 'check_range',
		'search'      => 'search',
		'rating'      => 'rating',
		'alphabet'    => 'alphabet',
		'color-image' => 'color_image',
		'date-range'  => 'date_range',
		'date-period' => 'date_period',
	);

	/** Alle M7-widgettypen (Elementor-naam m7sf-{type}), zelfde namen als bij JetSmartFilters. */
	const WIDGET_TYPES = array( 'checkboxes', 'radio', 'select', 'range', 'check-range', 'search', 'rating', 'alphabet', 'color-image', 'date-range', 'date-period', 'sorting', 'apply-button', 'remove-filters', 'active', 'active-tags', 'pagination', 'hidden' );

	/** Widgets met één filter in plaats van een lijst. */
	const SINGLE_TYPES = array( 'search', 'rating', 'date-range' );

	/** Providers waarvan JetSmartFilters zonder query-ID de hoofdquery filtert. */
	const ARCHIVE_PROVIDERS = array( 'woocommerce-archive', 'default-woo-archive', 'epro-archive-products', 'epro-archive' );

	/** @var array Cache van standaardinstellingen per widgettype. */
	private static $defaults = array();

	/** @var string[] Parameters van de filters in de volgorde waarin ze op de pagina staan. */
	public static $rendered = array();

	/** @var int Teller voor unieke ID's. */
	private static $uid = 0;

	/**
	 * Een widget renderen.
	 *
	 * @param string $type       Widgettype (checkboxes, radio, …, sorting, apply-button, …).
	 * @param array  $set        Widgetinstellingen (zelfde sleutels als JetSmartFilters).
	 * @param string $element_id Elementor-element-ID (voor unieke ID's).
	 * @return string
	 */
	public static function widget( $type, array $set, $element_id = '' ) {
		$set = array_merge( self::defaults( $type ), $set );
		Assets::enqueue();
		if ( isset( self::FILTER_TYPES[ $type ] ) ) {
			return self::filters( $type, $set, $element_id );
		}
		switch ( $type ) {
			case 'sorting':
				return self::sorting( $set );
			case 'apply-button':
				return self::apply_button_widget( $set );
			case 'remove-filters':
				return self::remove_filters( $set );
			case 'active':
			case 'active-tags':
				return self::active( $type, $set );
			case 'pagination':
				return self::pagination( $set );
			case 'hidden':
				return self::hidden( $set );
		}
		return '';
	}

	/**
	 * Standaardwaarden van alle instellingen van een widgettype (uit de Elementor-definitie).
	 *
	 * @param string $type Widgettype.
	 * @return array
	 */
	public static function defaults( $type ) {
		if ( isset( self::$defaults[ $type ] ) ) {
			return self::$defaults[ $type ];
		}
		$file = M7SF_DIR . 'includes/elementor/controls/' . sanitize_key( $type ) . '.php';
		$out  = array();
		if ( is_readable( $file ) ) {
			foreach ( (array) include $file as $call ) {
				if ( in_array( $call[0], array( 'control', 'responsive' ), true ) && array_key_exists( 'default', $call[2] ) ) {
					$out[ $call[1] ] = $call[2]['default'];
				}
			}
		}
		return self::$defaults[ $type ] = $out;
	}

	/**
	 * Standaardopmaak die Elementor per widget schrijft (uit de standaardwaarden van de instellingen), voor gebruik
	 * buiten Elementor (shortcodes). {{WRAPPER}} wordt .m7sf-sc-{type}.
	 *
	 * @param string $type Widgettype.
	 * @return string CSS.
	 */
	public static function default_css( $type ) {
		$file = M7SF_DIR . 'includes/elementor/controls/' . sanitize_key( $type ) . '.php';
		if ( ! is_readable( $file ) ) {
			return '';
		}
		$calls    = (array) include $file;
		$defaults = self::defaults( $type );
		$section  = array();
		$css      = '';
		foreach ( $calls as $call ) {
			if ( 'section' === $call[0] ) {
				$section = isset( $call[2]['condition'] ) ? (array) $call[2]['condition'] : array();
				continue;
			}
			if ( ! in_array( $call[0], array( 'control', 'responsive' ), true ) || empty( $call[2]['selectors'] ) || ! array_key_exists( 'default', $call[2] ) ) {
				continue;
			}
			$args  = $call[2];
			$value = $args['default'];
			if ( '' === $value || null === $value || ( is_array( $value ) && isset( $value['size'] ) && '' === (string) $value['size'] ) ) {
				continue;
			}
			// Alleen eenvoudige voorwaarden (sleutel = waarde, sleutel! = waarde) met de standaardwaarden.
			$ok = true;
			foreach ( array_merge( $section, isset( $args['condition'] ) ? (array) $args['condition'] : array() ) as $key => $want ) {
				$neg  = '!' === substr( $key, -1 );
				$key  = rtrim( $key, '!' );
				$have = isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
				$hit  = is_array( $want ) ? in_array( $have, $want, true ) : $have === $want;
				if ( $neg === $hit ) {
					$ok = false;
					break;
				}
			}
			if ( ! $ok || ! empty( $args['conditions'] ) ) {
				continue;
			}
			if ( ! is_array( $value ) && isset( $args['selectors_dictionary'][ $value ] ) ) {
				$value = $args['selectors_dictionary'][ $value ];
			}
			foreach ( $args['selectors'] as $sel => $decl ) {
				if ( is_array( $value ) ) {
					$unit = isset( $value['unit'] ) ? $value['unit'] : 'px';
					$decl = str_replace( array( '{{SIZE}}', '{{UNIT}}' ), array( isset( $value['size'] ) ? $value['size'] : '', $unit ), $decl );
					foreach ( array( 'TOP', 'RIGHT', 'BOTTOM', 'LEFT' ) as $side ) {
						$decl = str_replace( '{{' . $side . '}}', isset( $value[ strtolower( $side ) ] ) ? $value[ strtolower( $side ) ] : '', $decl );
					}
				} else {
					$decl = str_replace( '{{VALUE}}', (string) $value, $decl );
				}
				if ( false !== strpos( $decl, '{{' ) ) {
					continue;
				}
				$css .= str_replace( '{{WRAPPER}}', '.m7sf-sc-' . $type, $sel ) . '{' . $decl . '}';
			}
		}
		return $css;
	}

	/**
	 * Query-ID van een widget: ingevuld ID, anders zoals JetSmartFilters ("default", of de hoofdquery bij archieven).
	 *
	 * @param array $set Instellingen.
	 * @return string
	 */
	public static function query_id( array $set ) {
		$qid = isset( $set['query_id'] ) ? trim( (string) $set['query_id'] ) : '';
		if ( '' === $qid || 'default' === $qid ) {
			$provider = isset( $set['content_provider'] ) ? (string) $set['content_provider'] : '';
			$qid      = in_array( $provider, self::ARCHIVE_PROVIDERS, true ) ? Providers::MAIN : 'default';
		}
		return Query::clean_query_id( $qid );
	}

	/* ------------------------------------------------------------------ */
	/* Filters                                                              */
	/* ------------------------------------------------------------------ */

	private static function filters( $type, array $set, $element_id ) {
		$ids = self::filter_ids( isset( $set['filter_id'] ) ? $set['filter_id'] : array() );
		$out = array();
		foreach ( $ids as $id ) {
			$s = Filter_Post_Type::get( $id );
			if ( ! $s || 'publish' !== get_post_status( $id ) ) {
				continue;
			}
			$out[] = self::filter_block( $type, $s, $set, $element_id );
		}
		if ( ! $out ) {
			if ( current_user_can( 'edit_posts' ) && ( is_admin() || ( defined( 'ELEMENTOR_VERSION' ) && \Elementor\Plugin::$instance->editor->is_edit_mode() ) ) ) {
				return '<p class="m7sf-notice">' . esc_html__( 'M7 Filter: kies een filter.', 'm7-smart-filters' ) . '</p>';
			}
			return '';
		}
		$html = implode( '', $out );
		if ( count( $out ) > 1 ) {
			$html = '<div class="m7sf-filters-group">' . $html . '</div>';
		}
		if ( 'search' !== $type && 'submit' === ( isset( $set['apply_on'] ) ? $set['apply_on'] : '' ) && self::yes( $set, 'apply_button' ) && '' !== (string) $set['apply_button_text'] ) {
			$html .= self::apply_block( $set, (string) $set['apply_button_text'] );
		}
		return $html;
	}

	/**
	 * Filter-ID's in oplopende volgorde (zoals JetSmartFilters ze ophaalt), alleen bestaande.
	 *
	 * @param mixed $raw Eén ID of lijst.
	 * @return int[]
	 */
	private static function filter_ids( $raw ) {
		$ids = array_values( array_unique( array_filter( array_map( 'absint', is_array( $raw ) ? $raw : array( $raw ) ) ) ) );
		sort( $ids );
		return $ids;
	}

	private static function filter_block( $type, array $s, array $set, $element_id ) {
		$qid      = self::query_id( $set );
		$param    = Filter_Post_Type::param_for( $s );
		$current  = Render::current_values( $qid, $param );
		if ( ! in_array( $param, self::$rendered, true ) ) {
			self::$rendered[] = $param;
		}
		$apply    = isset( $set['apply_type'] ) ? (string) $set['apply_type'] : 'ajax';
		$typing   = 0;
		if ( 'ajax-ontyping' === $apply ) {
			$typing = max( 1, (int) ( isset( $set['typing_min_letters_count'] ) ? $set['typing_min_letters_count'] : 3 ) );
			$apply  = 'ajax';
		}
		$apply   = in_array( $apply, array( 'ajax', 'reload', 'mixed' ), true ) ? $apply : 'ajax';
		$apply_on = 'search' === $type ? ( $typing ? 'value' : 'button' ) : ( 'submit' === ( isset( $set['apply_on'] ) ? $set['apply_on'] : 'value' ) ? 'button' : 'value' );
		$indexed  = in_array( $type, array( 'checkboxes', 'radio', 'check-range', 'color-image', 'select' ), true ) && self::yes( $set, 'apply_indexer' );

		$ctx = array(
			'type'       => $type,
			'qid'        => $qid,
			'param'      => $param,
			'current'    => $current,
			'element_id' => $element_id,
			'counter'    => $indexed && self::yes( $set, 'show_counter' ),
			'rule'       => $indexed ? ( isset( $set['show_items_rule'] ) ? (string) $set['show_items_rule'] : 'show' ) : 'show',
			'typing'     => $typing,
		);

		$hier  = 'select' === $type && ! empty( $s['hierarchy_levels'] );
		$class = 'm7sf-filter-' . ( $hier ? 'hierarchy' : $type ) . ' m7sf-filter' . ( $indexed ? ' m7sf-filter-indexed' : '' );
		$attrs = array(
			'class'              => $class,
			'data-m7sf-for'      => $qid,
			'data-m7sf-param'    => $param,
			'data-m7sf-type'     => $hier ? 'hierarchy' : self::FILTER_TYPES[ $type ],
			'data-m7sf-apply'    => $apply,
			'data-m7sf-apply-on' => $apply_on,
			'data-m7sf-filter'   => (string) $s['id'],
		);
		if ( $typing ) {
			$attrs['data-m7sf-typing'] = (string) $typing;
		}
		if ( ! empty( $set['m7sf_selector'] ) ) {
			$attrs['data-m7sf-selector'] = (string) $set['m7sf_selector'];
		}
		if ( ! empty( $set['m7sf_redirect'] ) ) {
			$attrs['data-m7sf-redirect'] = esc_url_raw( (string) $set['m7sf_redirect'] );
		}
		$label = '';
		if ( self::yes( $set, 'show_label' ) && '' !== trim( (string) $s['display_label'] ) ) {
			$label = '<div class="m7sf-filter-label">' . wp_kses_post( $s['display_label'] ) . '</div>';
		}

		switch ( $type ) {
			case 'checkboxes':
			case 'radio':
			case 'color-image':
				$body = self::choice_body( $type, $s, $set, $ctx );
				break;
			case 'check-range':
				$body = self::check_range_body( $s, $set, $ctx );
				break;
			case 'alphabet':
				$body = self::alphabet_body( $s, $set, $ctx );
				break;
			case 'rating':
				$body = self::rating_body( $s, $set, $ctx );
				break;
			case 'select':
				$body = $hier ? self::hierarchy_body( $s, $set, $ctx ) : self::select_body( $s, $set, $ctx );
				if ( $hier && isset( $ctx['tree'] ) ) {
					$attrs['data-m7sf-tree'] = $ctx['tree'];
				}
				break;
			case 'range':
				$body = self::range_body( $s, $set, $ctx );
				break;
			case 'search':
				$body = self::search_body( $s, $set, $ctx );
				break;
			case 'date-range':
				$body = self::date_range_body( $s, $set, $ctx );
				break;
			case 'date-period':
				$body = self::date_period_body( $s, $set, $ctx );
				break;
			default:
				$body = '';
		}
		return '<div' . self::attrs( $attrs ) . '>' . $label . $body . '</div>';
	}

	/* ---------- lijsten ---------- */

	/**
	 * Rijen voor vinkjes, keuzerondjes en kleur/afbeelding.
	 */
	private static function choice_body( $type, array $s, array $set, array $ctx ) {
		$options = Sources::options( $s );
		if ( ! $options ) {
			return '';
		}
		$input = 'radio' === $type ? 'radio' : ( 'color-image' === $type ? ( $s['multiple'] ? 'checkbox' : 'radio' ) : 'checkbox' );
		$rows  = array();
		if ( 'radio' === $input && $s['show_all_option'] ) {
			$rows[] = array(
				'value'   => '',
				'label'   => '' !== $s['all_label'] ? $s['all_label'] : __( 'All', 'm7-smart-filters' ),
				'checked' => empty( $ctx['current'] ),
				'all'     => true,
				'parent'  => '',
				'depth'   => 0,
				'count'   => null,
				'color'   => '',
				'image'   => 0,
			);
		}
		foreach ( $options as $o ) {
			$rows[] = array(
				'value'   => (string) $o['value'],
				'label'   => (string) $o['label'],
				'checked' => in_array( (string) $o['value'], $ctx['current'], true ),
				'all'     => false,
				'parent'  => isset( $o['parent'] ) ? (string) $o['parent'] : '',
				'depth'   => isset( $o['depth'] ) ? (int) $o['depth'] : 0,
				'count'   => isset( $o['count'] ) ? (int) $o['count'] : null, // Onbekend aantal: nooit verbergen.
				'color'   => isset( $o['color'] ) ? (string) $o['color'] : '',
				'image'   => isset( $o['image'] ) ? (int) $o['image'] : 0,
			);
		}
		$list = 'color-image' === $type ? 'color-image-list' : $type . '-list';
		$tree = 'color-image' !== $type && ! empty( $s['hierarchical'] );
		return self::list_markup( $list, $input, $s, $set, $ctx, $rows, $tree, 'radio' === $input && ! empty( $s['can_deselect'] ) );
	}

	private static function check_range_body( array $s, array $set, array $ctx ) {
		$rows = array();
		foreach ( (array) $s['check_ranges'] as $r ) {
			$min    = '' === (string) $r['min'] ? '0' : (string) $r['min'];
			$max    = '' === (string) $r['max'] ? '100' : (string) $r['max'];
			$value  = self::num( $min ) . '_' . self::num( $max );
			$label  = ! empty( $r['label'] ) ? (string) $r['label'] : self::fmt_number( $s, $min, true ) . ' — ' . self::fmt_number( $s, $max, true );
			$rows[] = array(
				'value'   => $value,
				'label'   => $label,
				'checked' => in_array( $value, $ctx['current'], true ),
				'all'     => false,
				'parent'  => '',
				'depth'   => 0,
				'count'   => null,
				'color'   => '',
				'image'   => 0,
			);
		}
		if ( ! $rows ) {
			return '';
		}
		return self::list_markup( 'checkboxes-list', 'checkbox', $s, $set, $ctx, $rows, false, false );
	}

	/**
	 * Lijst > [zoeken] > [scroll] > wrapper (fieldset, bij radio/kleur in een form) > [boom] > rijen > [meer/minder],
	 * eventueel binnen een uitklaplijst.
	 */
	private static function list_markup( $list, $input, array $s, array $set, array $ctx, array $rows, $tree, $deselect ) {
		$name     = self::query_var( $s );
		$decor    = 'color-image-list' === $list ? true : self::yes( $set, 'show_decorator' );
		$children = array();
		$roots    = array();
		if ( $tree ) {
			$values = array();
			foreach ( $rows as $r ) {
				$values[ $r['value'] ] = true;
			}
			foreach ( $rows as $r ) {
				if ( '' !== $r['parent'] && isset( $values[ $r['parent'] ] ) ) {
					$children[ $r['parent'] ][] = $r;
				} else {
					$roots[] = $r;
				}
			}
			$tree = (bool) $children;
		}
		if ( ! $tree ) {
			$roots = $rows;
		}
		$collapsible = $tree && ! empty( $s['collapsible'] );

		$has_checked = static function ( $r ) use ( &$has_checked, $children ) {
			foreach ( isset( $children[ $r['value'] ] ) ? $children[ $r['value'] ] : array() as $c ) {
				if ( $c['checked'] || $has_checked( $c ) ) {
					return true;
				}
			}
			return false;
		};
		$render = static function ( array $r ) use ( &$render, $children, $collapsible, $has_checked, $list, $input, $name, $decor, $ctx, $set, $s ) {
			$kids = isset( $children[ $r['value'] ] ) ? $children[ $r['value'] ] : array();
			$open = $kids && $has_checked( $r );
			$cls  = 'm7sf-' . $list . '__row m7sf-filter-row';
			if ( $kids ) {
				$cls .= ' m7sf-list-tree__parent' . ( $collapsible && ! $open ? ' m7sf-list-toggle-collapsed' : '' );
			}
			if ( ! $r['all'] && null !== $r['count'] && 0 === $r['count'] && ! $kids && 'show' !== $ctx['rule'] ) {
				$cls .= 'hide' === $ctx['rule'] ? ' m7sf-filter-row-hide' : ' m7sf-filter-row-disable';
			}
			$html = '<div class="' . $cls . '">';
			if ( $collapsible ) {
				$html .= $kids ? self::collapse_icon() : '<div class="m7sf-collapse-none"></div>';
			}
			$html .= self::item( $list, $input, $name, $r, $decor, $ctx, $set, $s );
			$html .= '</div>';
			if ( $kids ) {
				$hidden = $collapsible && ! $open;
				$html  .= '<div class="m7sf-list-tree__children' . ( $hidden ? ' m7sf-list-content-collapsed' : '' ) . '"' . ( $hidden ? ' style="display: none;"' : '' ) . '>';
				foreach ( $kids as $k ) {
					$html .= $render( $k );
				}
				$html .= '</div>';
			}
			return $html;
		};

		$body = '';
		foreach ( $roots as $r ) {
			$body .= $render( $r );
		}
		if ( $tree ) {
			$body = '<div class="m7sf-list-tree' . ( $collapsible ? ' m7sf-list-collapsible' : '' ) . '">' . $body . '</div>';
		}
		$legend = '<legend style="display:none;">' . esc_html( wp_strip_all_tags( $s['label'] ) ) . '</legend>';
		if ( 'checkboxes-list' === $list ) {
			$wrapper = '<fieldset class="m7sf-checkboxes-list-wrapper">' . $legend . $body . '</fieldset>';
		} else {
			$wrapper = '<form class="m7sf-' . $list . '-wrapper" onsubmit="return false;"><fieldset>' . $legend . $body . '</fieldset></form>';
		}
		if ( self::yes( $set, 'scroll_enabled' ) ) {
			$height  = max( 1, (int) ( isset( $set['scroll_height'] ) ? $set['scroll_height'] : 290 ) );
			$wrapper = '<div class="m7sf-filter-items-scroll" style="max-height:' . $height . 'px"><div class="m7sf-filter-items-scroll-container">' . $wrapper . '</div></div>';
		}
		$html  = '<div class="m7sf-' . $list . '"' . ( $deselect ? ' data-can-deselect="1"' : '' ) . '>';
		$html .= self::items_search( $s, $set ) . $wrapper . self::moreless( $set, count( $rows ) );
		$html .= '</div>';
		return self::dropdown( $set, $html, 'radio' === $input );
	}

	private static function item( $list, $input, $name, array $r, $decor, array $ctx, array $set, array $s ) {
		$html  = '<label class="m7sf-' . $list . '__item"' . self::tab() . '>';
		$html .= '<input type="' . $input . '" class="m7sf-' . $list . '__input" name="' . esc_attr( $name ) . '" value="' . esc_attr( $r['value'] ) . '" data-label="' . esc_attr( $r['label'] ) . '" aria-label="' . esc_attr( $r['label'] ) . '"' . ( $r['checked'] ? ' checked' : '' ) . '>';
		$html .= '<div class="m7sf-' . $list . '__button">';
		if ( 'color-image-list' === $list ) {
			$html .= '<span class="m7sf-color-image-list__decorator">';
			if ( 'image' === $s['color_image_type'] || $r['all'] ) {
				$size = isset( $set['filter_image_size'] ) && $set['filter_image_size'] ? $set['filter_image_size'] : 'full';
				$img  = $r['image'] ? wp_get_attachment_image_src( $r['image'], $size ) : false;
				$alt  = $r['image'] ? (string) get_post_meta( $r['image'], '_wp_attachment_image_alt', true ) : '';
				$src  = $img ? $img[0] : ( function_exists( 'wc_placeholder_img_src' ) ? wc_placeholder_img_src( 'thumbnail' ) : includes_url( 'images/media/default.svg' ) );
				$html .= '<span class="m7sf-color-image-list__image"><img src="' . esc_url( $src ) . '" alt="' . esc_attr( '' !== $alt ? $alt : $r['label'] ) . '"></span>';
			} elseif ( 'color' === $s['color_image_type'] ) {
				$html .= '<span class="m7sf-color-image-list__color" style="background-color: ' . esc_attr( $r['color'] ) . '"></span>';
			}
			$html .= '</span>';
			if ( self::yes( $set, 'show_items_label' ) ) {
				$html .= '<span class="m7sf-color-image-list__label">' . wp_kses_post( $r['label'] ) . '</span>';
			}
		} else {
			if ( $decor ) {
				$html .= '<span class="m7sf-' . $list . '__decorator"><i class="m7sf-' . $list . '__checked-icon">' . self::icon( 'check' ) . '</i></span>';
			}
			$html .= '<span class="m7sf-' . $list . '__label">' . wp_kses_post( $r['label'] ) . '</span>';
		}
		if ( $ctx['counter'] && ! $r['all'] && null !== $r['count'] ) {
			$html .= self::counter( $set, (int) $r['count'] );
		}
		return $html . '</div></label>';
	}

	private static function counter( array $set, $count ) {
		$prefix = isset( $set['counter_prefix'] ) ? (string) $set['counter_prefix'] : '(';
		$suffix = isset( $set['counter_suffix'] ) ? (string) $set['counter_suffix'] : ')';
		return '<span class="m7sf-filters-counter">' . ( '' !== $prefix ? '<span class="counter-prefix">' . esc_html( $prefix ) . '</span>' : '' ) . '<span class="value">' . (int) $count . '</span>' . ( '' !== $suffix ? '<span class="counter-suffix">' . esc_html( $suffix ) . '</span>' : '' ) . '</span>';
	}

	private static function items_search( array $s, array $set ) {
		if ( ! self::yes( $set, 'search_enabled' ) ) {
			return '';
		}
		$placeholder = isset( $set['search_placeholder'] ) && '' !== (string) $set['search_placeholder'] ? (string) $set['search_placeholder'] : __( 'Search...', 'm7-smart-filters' );
		/* translators: %s: filterlabel */
		$aria = sprintf( __( 'Search in %s', 'm7-smart-filters' ), wp_strip_all_tags( $s['label'] ) );
		return '<div class="m7sf-filter-items-search"><input class="m7sf-filter-items-search__input" type="search" autocomplete="off" aria-label="' . esc_attr( $aria ) . '" placeholder="' . esc_attr( $placeholder ) . '"><div class="m7sf-filter-items-search__clear">' . self::icon( 'close' ) . '</div></div>';
	}

	private static function moreless( array $set, $count ) {
		if ( ! self::yes( $set, 'moreless_enabled' ) ) {
			return '';
		}
		$n = (int) ( isset( $set['less_items_count'] ) ? $set['less_items_count'] : 5 );
		if ( $n < 1 || $count < $n ) {
			return '';
		}
		$more = isset( $set['more_text'] ) && '' !== (string) $set['more_text'] ? (string) $set['more_text'] : __( 'More', 'm7-smart-filters' );
		$less = isset( $set['less_text'] ) && '' !== (string) $set['less_text'] ? (string) $set['less_text'] : __( 'Less', 'm7-smart-filters' );
		return '<div class="m7sf-filter-items-moreless"' . self::tab() . ' data-less-items-count="' . $n . '" data-more-text="' . esc_attr( $more ) . '" data-less-text="' . esc_attr( $less ) . '"><div class="m7sf-filter-items-moreless__toggle">' . esc_html( $more ) . '</div></div>';
	}

	private static function dropdown( array $set, $inner, $is_radio ) {
		if ( ! self::yes( $set, 'dropdown_enabled' ) ) {
			return $inner;
		}
		$placeholder = isset( $set['dropdown_placeholder'] ) && '' !== (string) $set['dropdown_placeholder'] ? (string) $set['dropdown_placeholder'] : __( 'Select some options', 'm7-smart-filters' );
		$attrs       = '';
		if ( ! $is_radio && self::yes( $set, 'dropdown_n_selected_enabled' ) ) {
			$n     = isset( $set['dropdown_n_selected_number'] ) && (int) $set['dropdown_n_selected_number'] >= 0 ? (int) $set['dropdown_n_selected_number'] : 3;
			$text  = array_key_exists( 'dropdown_n_selected_text', $set ) ? (string) $set['dropdown_n_selected_text'] : __( 'and {number} others', 'm7-smart-filters' );
			$attrs = ' data-dropdown-n-selected="' . $n . '" data-dropdown-n-selected-text="' . esc_attr( $text ) . '"';
		}
		$footer = '';
		if ( self::yes( $set, 'dropdown_apply_button' ) ) {
			$text   = isset( $set['dropdown_apply_button_text'] ) && '' !== (string) $set['dropdown_apply_button_text'] ? (string) $set['dropdown_apply_button_text'] : __( 'Apply', 'm7-smart-filters' );
			$footer = '<div class="m7sf-filter-items-dropdown__footer"><button type="button" class="m7sf-filter-items-dropdown__apply-button"' . self::tab() . '>' . esc_html( $text ) . '</button></div>';
		}
		return '<div class="m7sf-filter-items-dropdown"' . $attrs . '><div class="m7sf-filter-items-dropdown__label"' . self::tab() . ' data-placeholder="' . esc_attr( $placeholder ) . '">' . esc_html( $placeholder ) . '</div><div class="m7sf-filter-items-dropdown__body">' . $inner . $footer . '</div></div>';
	}

	private static function collapse_icon() {
		return '<div class="m7sf-collapse-icon" role="button" tabindex="0" aria-label="' . esc_attr__( 'Subopties tonen of verbergen', 'm7-smart-filters' ) . '">'
			. '<svg class="m7sf-collapse-icon-open" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 12H18M12 6V18" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
			. '<svg class="m7sf-collapse-icon-close" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 12L18 12" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
			. '</div>';
	}

	private static function alphabet_body( array $s, array $set, array $ctx ) {
		$letters = array_values( array_filter( array_map( 'trim', explode( ',', (string) $s['alphabet_letters'] ) ), 'strlen' ) );
		if ( ! $letters ) {
			return '';
		}
		$input = ! empty( $s['alphabet_multiple'] ) ? 'checkbox' : 'radio';
		$rows  = '';
		foreach ( $letters as $l ) {
			$upper = strtoupper( $l );
			$rows .= '<div class="m7sf-alphabet-list__row m7sf-filter-row"><label class="m7sf-alphabet-list__item"' . self::tab() . '>'
				. '<input type="' . $input . '" class="m7sf-alphabet-list__input" name="alphabet-filter' . (int) $s['id'] . '" value="' . esc_attr( $l ) . '" data-label="' . esc_attr( $upper ) . '" aria-label="' . esc_attr( $upper ) . '"' . ( in_array( $l, $ctx['current'], true ) || in_array( strtolower( $l ), array_map( 'strtolower', $ctx['current'] ), true ) ? ' checked' : '' ) . '>'
				. '<span class="m7sf-alphabet-list__button">' . esc_html( $upper ) . '</span></label></div>';
		}
		$deselect = 'radio' === $input && ! empty( $s['can_deselect'] );
		return '<div class="m7sf-alphabet-list"' . ( $deselect ? ' data-can-deselect="1"' : '' ) . '><form class="m7sf-alphabet-list-wrapper" onsubmit="return false;"><fieldset><legend style="display:none;">' . esc_html( wp_strip_all_tags( $s['label'] ) ) . '</legend>' . $rows . '</fieldset></form></div>';
	}

	private static function rating_body( array $s, array $set, array $ctx ) {
		$max = (int) $s['rating_max'];
		if ( $max < 1 ) {
			return '';
		}
		$cur   = $ctx['current'] ? (string) (int) $ctx['current'][0] : '';
		$icon  = isset( $set['rating_icon'] ) && '' !== (string) $set['rating_icon'] ? (string) $set['rating_icon'] : 'fa fa-star';
		$eid   = '' !== (string) $ctx['element_id'] ? (string) $ctx['element_id'] : 'm7sf' . ( ++self::$uid );
		$name  = self::query_var( $s );
		$html  = '<div class="m7sf-rating"><div class="m7sf-rating__control"><div class="m7sf-rating-stars"><fieldset class="m7sf-rating-stars__fields"><legend style="display:none;">' . esc_html( wp_strip_all_tags( $s['label'] ) ) . '</legend>';
		for ( $v = $max; $v >= 1; $v-- ) {
			$id    = 'm7sf-rating-' . $eid . '-' . $v;
			$on    = (string) $v === $cur;
			$html .= '<input class="m7sf-rating-star__input' . ( $on ? ' is-checked' : '' ) . '" type="radio" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . $v . '" aria-label="' . $v . '"' . ( $on ? ' checked' : '' ) . '>';
			$html .= '<label class="m7sf-rating-star__label" for="' . esc_attr( $id ) . '"' . self::tab() . '><span class="m7sf-rating-star__icon"><i class="m7sf-rating-icon ' . esc_attr( $icon ) . '"></i></span></label>';
		}
		return $html . '</fieldset></div></div></div>';
	}

	/* ---------- keuzelijst ---------- */

	private static function select_body( array $s, array $set, array $ctx ) {
		$flat                 = $s;
		$flat['hierarchical'] = false;
		$options              = Sources::options( $flat );
		$name                 = self::query_var( $s );
		if ( ! $options ) {
			return '<div class="m7sf-select"></div>';
		}
		$prefix      = $ctx['counter'] ? ( isset( $set['counter_prefix'] ) ? (string) $set['counter_prefix'] : '(' ) : '';
		$suffix      = $ctx['counter'] ? ( isset( $set['counter_suffix'] ) ? (string) $set['counter_suffix'] : ')' ) : '';
		$placeholder = '' !== (string) $s['placeholder'] ? (string) $s['placeholder'] : __( 'Select...', 'm7-smart-filters' );
		$html        = '<div class="m7sf-select"><select class="m7sf-select__control" name="' . esc_attr( $name ) . '"' . self::tab() . ' aria-label="' . esc_attr( wp_strip_all_tags( $s['label'] ) ) . '">';
		$html       .= '<option value="" data-label="' . esc_attr( $placeholder ) . '" data-counter-prefix="' . esc_attr( $prefix ) . '" data-counter-suffix="' . esc_attr( $suffix ) . '">' . esc_html( $placeholder ) . '</option>';
		foreach ( $options as $o ) {
			$known    = isset( $o['count'] );
			$count    = $known ? (int) $o['count'] : 0;
			$disabled = $known && 0 === $count && 'disable' === $ctx['rule'];
			if ( $known && 0 === $count && 'hide' === $ctx['rule'] ) {
				continue;
			}
			$text  = (string) $o['label'] . ( $ctx['counter'] && $known ? ' ' . $prefix . $count . $suffix : '' );
			$html .= '<option value="' . esc_attr( $o['value'] ) . '" data-label="' . esc_attr( $o['label'] ) . '" data-counter-prefix="' . esc_attr( $prefix ) . '" data-counter-suffix="' . esc_attr( $suffix ) . '"' . ( in_array( (string) $o['value'], $ctx['current'], true ) ? ' selected' : '' ) . ( $disabled ? ' disabled' : '' ) . '>' . esc_html( $text ) . '</option>';
		}
		return $html . '</select></div>';
	}

	/**
	 * Keuzelijst per niveau: elk niveau een eigen keuzelijst; de opties van een niveau zijn de kinderen van de keuze
	 * erboven. Label van de hele groep staat erboven, per niveau optioneel een eigen label (zoals JetSmartFilters).
	 */
	private static function hierarchy_body( array $s, array $set, array &$ctx ) {
		$levels = $s['hierarchy_levels'];
		$tax    = $levels[0]['tax'];
		$terms  = taxonomy_exists( $tax ) ? get_terms(
			array(
				'taxonomy'   => $tax,
				'hide_empty' => (bool) $s['hide_empty'],
				'orderby'    => in_array( $s['terms_orderby'], array( 'name', 'slug', 'count', 'term_id', 'id' ), true ) ? $s['terms_orderby'] : 'name',
				'order'      => 'DESC' === $s['terms_order'] ? 'DESC' : 'ASC',
			)
		) : array();
		$tree   = array();
		$slugs  = array();
		foreach ( is_array( $terms ) ? $terms : array() as $t ) {
			$slugs[ $t->term_id ] = $t->slug;
		}
		foreach ( is_array( $terms ) ? $terms : array() as $t ) {
			$parent            = isset( $slugs[ $t->parent ] ) ? $slugs[ $t->parent ] : '';
			$tree[ $parent ][] = array( $t->slug, $t->name );
		}
		$ctx['tree'] = wp_json_encode( $tree );
		// Pad van de gekozen term naar boven.
		$path = array();
		$cur  = $ctx['current'] ? $ctx['current'][0] : '';
		$up   = array();
		foreach ( $tree as $parent => $kids ) {
			foreach ( $kids as $k ) {
				$up[ $k[0] ] = $parent;
			}
		}
		while ( '' !== $cur && isset( $up[ $cur ] ) && count( $path ) < 20 ) {
			array_unshift( $path, $cur );
			$cur = $up[ $cur ];
		}
		$html   = '<div class="m7sf-filters-group">';
		$parent = '';
		foreach ( $levels as $i => $lvl ) {
			$placeholder = '' !== $lvl['placeholder'] ? $lvl['placeholder'] : __( 'Select...', 'm7-smart-filters' );
			$label       = '' !== $lvl['label'] ? $lvl['label'] : wp_strip_all_tags( $s['label'] );
			$html       .= '<div class="m7sf-select" data-hierarchical="1" data-depth="' . (int) $i . '">';
			if ( self::yes( $set, 'show_label' ) && '' !== $lvl['label'] ) {
				$html .= '<div class="m7sf-filter-label">' . esc_html( $lvl['label'] ) . '</div>';
			}
			$html .= '<select class="m7sf-select__control depth-' . (int) $i . '" name="' . esc_attr( $tax ) . '"' . self::tab() . ' aria-label="' . esc_attr( $label ) . '"><option value="">' . esc_html( $placeholder ) . '</option>';
			if ( 0 === $i || '' !== $parent ) {
				foreach ( isset( $tree[ $parent ] ) ? $tree[ $parent ] : array() as $k ) {
					$sel   = isset( $path[ $i ] ) && $path[ $i ] === $k[0];
					$html .= '<option value="' . esc_attr( $k[0] ) . '"' . ( $sel ? ' selected' : '' ) . '>' . esc_html( $k[1] ) . '</option>';
				}
			}
			$html  .= '</select></div>';
			$parent = isset( $path[ $i ] ) ? $path[ $i ] : '';
		}
		return $html . '</div>';
	}

	/* ---------- bereik ---------- */

	private static function range_body( array $s, array $set, array $ctx ) {
		list( $min, $max ) = self::range_bounds( $s );
		$step              = (float) $s['range_step'] > 0 ? (float) $s['range_step'] : 1;
		$from              = $min;
		$to                = $max;
		if ( $ctx['current'] ) {
			$r = Query::numeric_range( $ctx['current'][0] );
			if ( $r ) {
				$from = null === $r[0] ? $min : max( $min, (float) $r[0] );
				$to   = null === $r[1] ? $max : min( $max, (float) $r[1] );
			}
		}
		$span   = $max - $min;
		$low    = $span > 0 ? ( $from - $min ) / $span * 100 : 0;
		$high   = $span > 0 ? ( $to - $min ) / $span * 100 : 100;
		$format = array(
			'decimal_num'   => (int) $s['range_decimals'],
			'decimal_sep'   => (string) $s['range_decimal_sep'],
			'thousands_sep' => (string) $s['range_thousand_sep'],
		);
		$label  = esc_html( wp_strip_all_tags( $s['label'] ) );
		$html   = '<div class="m7sf-range" data-min="' . esc_attr( self::num( $min ) ) . '" data-max="' . esc_attr( self::num( $max ) ) . '" data-step="' . esc_attr( self::num( $step ) ) . '" data-format="' . esc_attr( wp_json_encode( $format ) ) . '"' . ( ! empty( $s['range_inputs_separators'] ) ? ' data-inputs-separators="1"' : '' ) . '>';
		$html  .= '<fieldset class="m7sf-range__slider"><legend style="display:none;">' . $label . ' - slider</legend>';
		$html  .= '<div class="m7sf-range__slider__track"><div class="m7sf-range__slider__track__range" style="--low: ' . self::num( round( $low, 4 ) ) . '%; --high: ' . self::num( round( $high, 4 ) ) . '%;"></div></div>';
		$html  .= '<input type="range" class="m7sf-range__slider__input m7sf-range__slider__input--min" step="' . esc_attr( self::num( $step ) ) . '" min="' . esc_attr( self::num( $min ) ) . '" max="' . esc_attr( self::num( $max ) ) . '" value="' . esc_attr( self::num( $from ) ) . '" aria-label="' . esc_attr__( 'Minimal value', 'm7-smart-filters' ) . '">';
		$html  .= '<input type="range" class="m7sf-range__slider__input m7sf-range__slider__input--max" step="' . esc_attr( self::num( $step ) ) . '" min="' . esc_attr( self::num( $min ) ) . '" max="' . esc_attr( self::num( $max ) ) . '" value="' . esc_attr( self::num( $to ) ) . '" aria-label="' . esc_attr__( 'Maximum value', 'm7-smart-filters' ) . '"' . self::tab() . '>';
		$html  .= '</fieldset>';
		$prefix = (string) $s['range_prefix'];
		$suffix = (string) $s['range_suffix'];
		if ( ! empty( $s['range_inputs'] ) ) {
			$sep   = ! empty( $s['range_inputs_separators'] );
			$type  = $sep ? 'text' : 'number';
			$group = static function ( $which, $value, $aria ) use ( $prefix, $suffix, $type, $sep, $min, $max, $step, $s ) {
				$v = $sep ? self::fmt_number( $s, $value, false ) : self::num( $value );
				return '<div class="m7sf-range__inputs__group">' . ( '' !== $prefix ? '<span class="m7sf-range__inputs__group__text">' . esc_html( $prefix ) . '</span>' : '' )
					. '<input class="m7sf-range__inputs__' . $which . '" ' . $which . '-range' . self::tab() . ' type="' . $type . '" step="' . esc_attr( self::num( $step ) ) . '" min="' . esc_attr( self::num( $min ) ) . '" max="' . esc_attr( self::num( $max ) ) . '" value="' . esc_attr( $v ) . '" aria-label="' . esc_attr( $aria ) . '">'
					. ( '' !== $suffix ? '<span class="m7sf-range__inputs__group__text">' . esc_html( $suffix ) . '</span>' : '' ) . '</div>';
			};
			$html .= '<div class="m7sf-range__inputs"><fieldset class="m7sf-range__inputs__container"><legend style="display:none;">' . $label . ' - inputs</legend>';
			$html .= $group( 'min', $from, __( 'Minimal value', 'm7-smart-filters' ) ) . $group( 'max', $to, __( 'Maximum value', 'm7-smart-filters' ) );
			$html .= '</fieldset></div>';
		} else {
			$html .= '<div class="m7sf-range__values">';
			$html .= '<span class="m7sf-range__values-prefix">' . esc_html( $prefix ) . '</span><span class="m7sf-range__values-min">' . esc_html( self::fmt_number( $s, $from, false ) ) . '</span><span class="m7sf-range__values-suffix">' . esc_html( $suffix ) . '</span>';
			$html .= ' — ';
			$html .= '<span class="m7sf-range__values-prefix">' . esc_html( $prefix ) . '</span><span class="m7sf-range__values-max">' . esc_html( self::fmt_number( $s, $to, false ) ) . '</span><span class="m7sf-range__values-suffix">' . esc_html( $suffix ) . '</span>';
			$html .= '</div>';
		}
		return $html . '</div>';
	}

	/**
	 * Grenzen van een schuifje: vast ingesteld, of uit de gegevens (naar beneden/boven afgerond, max op een hele stap).
	 *
	 * @param array $s Filter.
	 * @return float[]
	 */
	public static function range_bounds( array $s ) {
		$key = $s['meta_key'] ? $s['meta_key'] : '_price';
		if ( '' === (string) $s['range_min'] || '' === (string) $s['range_max'] ) {
			list( $auto_min, $auto_max ) = Sources::numeric_bounds( $key );
			$min  = '' === (string) $s['range_min'] ? floor( $auto_min ) : (float) $s['range_min'];
			$max  = '' === (string) $s['range_max'] ? ceil( $auto_max ) : (float) $s['range_max'];
			$step = (float) $s['range_step'];
			if ( '' === (string) $s['range_max'] && $step > 0 && 1.0 !== $step && $max > $min ) {
				$max = $min + ceil( ( $max - $min ) / $step ) * $step;
			}
			return array( (float) $min, (float) $max );
		}
		return array( (float) $s['range_min'], (float) $s['range_max'] );
	}

	/* ---------- zoeken ---------- */

	private static function search_body( array $s, array $set, array $ctx ) {
		$value  = $ctx['current'] ? implode( ',', $ctx['current'] ) : '';
		$typing = (int) $ctx['typing'];
		$icon   = isset( $set['apply_button_icon'] ) ? (string) $set['apply_button_icon'] : '';
		$pos    = isset( $set['filter_apply_button_icon_position'] ) && 'right' === $set['filter_apply_button_icon_position'] ? 'right' : 'left';
		$html   = '<div class="m7sf-search-filter' . ( '' !== $icon ? ' button-icon-position-' . $pos : '' ) . '"' . ( $typing ? ' data-min-letters-count="' . $typing . '"' : '' ) . '>';
		$html  .= '<div class="m7sf-search-filter__input-wrapper"><input class="m7sf-search-filter__input' . ( '' !== $value ? ' m7sf-input-not-empty' : '' ) . '" type="search" autocomplete="off" name="' . esc_attr( 'meta' === $s['search_by'] ? $s['meta_key'] : 'query' ) . '" value="' . esc_attr( $value ) . '" placeholder="' . esc_attr( (string) $s['placeholder'] ) . '" aria-label="' . esc_attr( wp_strip_all_tags( $s['label'] ) ) . '">';
		if ( $typing ) {
			$html .= '<div class="m7sf-search-filter__input-clear">' . self::icon( 'close' ) . '</div><div class="m7sf-search-filter__input-loading"></div>';
		}
		$html .= '</div>';
		if ( ! $typing && ! self::yes( $set, 'hide_apply_button' ) ) {
			$text  = isset( $set['apply_button_text'] ) ? (string) $set['apply_button_text'] : '';
			$i     = '' !== $icon ? '<i class="' . esc_attr( $icon ) . '"></i>' : '';
			$html .= '<button type="button" class="m7sf-search-filter__submit m7sf-apply-filters__button" data-m7sf-apply-button' . self::tab() . '>' . ( 'left' === $pos ? $i : '' ) . '<span class="m7sf-search-filter__submit-text">' . esc_html( $text ) . '</span>' . ( 'right' === $pos ? $i : '' ) . '</button>';
		}
		return $html . '</div>';
	}

	/* ---------- datum (opbouw volgt in date-filters) ---------- */

	private static function date_range_body( array $s, array $set, array $ctx ) {
		return Markup_Dates::range( $s, $set, $ctx );
	}

	private static function date_period_body( array $s, array $set, array $ctx ) {
		return Markup_Dates::period( $s, $set, $ctx );
	}

	/* ------------------------------------------------------------------ */
	/* Hulpwidgets                                                          */
	/* ------------------------------------------------------------------ */

	private static function apply_block( array $set, $text, array $extra = array() ) {
		$attrs = array_merge(
			array(
				'class'         => 'm7sf-apply-filters',
				'data-m7sf-for' => self::query_id( $set ),
			),
			$extra
		);
		return '<div' . self::attrs( $attrs ) . '><button type="button" class="m7sf-apply-filters__button" data-m7sf-apply-button' . self::tab() . '>' . esc_html( $text ) . '</button></div>';
	}

	private static function sorting( array $set ) {
		$rows = isset( $set['sorting_list'] ) && is_array( $set['sorting_list'] ) ? $set['sorting_list'] : array();
		$opts = '';
		$qid  = self::query_id( $set );
		$cur  = Render::current_values( $qid, 'mf_sort' );
		$cur  = $cur ? $cur[0] : '';
		$all  = Query::sort_options();
		foreach ( $rows as $row ) {
			$title = isset( $row['title'] ) ? (string) $row['title'] : '';
			$key   = self::sort_key( $row );
			if ( '' === $title || ! $key ) {
				continue;
			}
			if ( ! isset( $all[ $key ] ) && 0 !== strpos( $key, 'meta:' ) ) {
				continue;
			}
			$opts .= '<option value="' . esc_attr( $key ) . '"' . selected( $cur, $key, false ) . '>' . esc_html( $title ) . '</option>';
		}
		if ( '' === $opts ) {
			return '';
		}
		$label       = isset( $set['label'] ) ? (string) $set['label'] : '';
		$placeholder = isset( $set['placeholder'] ) && '' !== (string) $set['placeholder'] ? (string) $set['placeholder'] : __( 'Sort...', 'm7-smart-filters' );
		$block       = self::yes( $set, 'label_block' ) ? 'm7sf-sorting--flex-column' : 'm7sf-sorting--flex-row';
		$apply_on    = 'submit' === ( isset( $set['apply_on'] ) ? $set['apply_on'] : 'value' ) ? 'button' : 'value';
		$html        = '<div' . self::attrs(
			array(
				'class'              => 'm7sf-filter-sorting m7sf-filter',
				'data-m7sf-for'      => $qid,
				'data-m7sf-param'    => 'mf_sort',
				'data-m7sf-type'     => 'sorting',
				'data-m7sf-apply'    => in_array( $set['apply_type'], array( 'ajax', 'reload', 'mixed' ), true ) ? $set['apply_type'] : 'ajax',
				'data-m7sf-apply-on' => $apply_on,
			)
		) . '><div class="m7sf-sorting ' . $block . '">';
		if ( '' !== $label ) {
			$html .= '<div class="m7sf-sorting-label">' . esc_html( $label ) . '</div>';
		}
		$html .= '<select class="m7sf-sorting-select" name="select-name"' . self::tab() . ' aria-label="' . esc_attr( '' !== $label ? $label : __( 'Sort filter', 'm7-smart-filters' ) ) . '"><option value="">' . esc_html( $placeholder ) . '</option>' . $opts . '</select></div></div>';
		if ( 'button' === $apply_on && self::yes( $set, 'apply_button' ) && '' !== (string) $set['apply_button_text'] ) {
			$html .= self::apply_block( $set, (string) $set['apply_button_text'] );
		}
		return $html;
	}

	/**
	 * Sorteerregel van JetSmartFilters (orderby/order/meta_key) naar een M7-sorteersleutel.
	 *
	 * @param array $row Regel.
	 * @return string
	 */
	public static function sort_key( array $row ) {
		if ( ! empty( $row['m7_key'] ) ) {
			return (string) $row['m7_key'];
		}
		$orderby = isset( $row['orderby'] ) ? (string) $row['orderby'] : '';
		$desc    = isset( $row['order'] ) && 'DESC' === strtoupper( (string) $row['order'] );
		$map     = array(
			'price'          => $desc ? 'price-desc' : 'price-asc',
			'date'           => $desc ? 'date-desc' : 'date-asc',
			'modified'       => 'modified-desc',
			'title'          => $desc ? 'title-desc' : 'title-asc',
			'name'           => $desc ? 'title-desc' : 'title-asc',
			'sales_number'   => 'popularity',
			'rating'         => 'rating',
			'reviews_number' => 'rating',
			'rand'           => 'rand',
			'menu_order'     => 'menu_order',
		);
		if ( isset( $map[ $orderby ] ) ) {
			return $map[ $orderby ];
		}
		if ( in_array( $orderby, array( 'meta_value', 'meta_value_num' ), true ) && ! empty( $row['meta_key'] ) ) {
			return 'meta:' . preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $row['meta_key'] ) . ':' . ( 'meta_value_num' === $orderby ? 'num' : 'str' ) . ':' . ( $desc ? 'desc' : 'asc' );
		}
		return '';
	}

	private static function apply_button_widget( array $set ) {
		$text = isset( $set['apply_button_text'] ) ? (string) $set['apply_button_text'] : '';
		if ( '' === $text ) {
			return '';
		}
		$extra = array(
			'data-m7sf-apply' => 'reload' === ( isset( $set['apply_type'] ) ? $set['apply_type'] : 'ajax' ) ? 'reload' : 'ajax',
		);
		if ( self::yes( $set, 'apply_redirect' ) && ! empty( $set['redirect_path'] ) ) {
			$extra['data-m7sf-redirect'] = esc_url_raw( self::redirect_url( (string) $set['redirect_path'] ) );
			if ( self::yes( $set, 'redirect_in_new_window' ) ) {
				$extra['data-m7sf-new-window'] = '1';
			}
		}
		$state = isset( $set['active_state'] ) ? (string) $set['active_state'] : 'always';
		$btn   = '';
		if ( 'always' !== $state ) {
			$extra['data-active-state'] = $state;
			$extra['data-if-inactive']  = isset( $set['if_inactive'] ) && 'hide' === $set['if_inactive'] ? 'hide' : 'disable';
		}
		$html = self::apply_block( $set, $text, $extra );
		if ( 'always' !== $state && ! Query::is_active_for( self::query_id( $set ) ) ) {
			$html = 'hide' === $extra['data-if-inactive']
				? str_replace( 'class="m7sf-apply-filters__button"', 'class="m7sf-apply-filters__button m7sf-hidden"', $html )
				: str_replace( 'class="m7sf-apply-filters__button"', 'class="m7sf-apply-filters__button m7sf-disabled" disabled', $html );
		}
		unset( $btn );
		return '<div class="m7sf-filter-apply-button m7sf-filter">' . $html . '</div>';
	}

	private static function redirect_url( $path ) {
		if ( preg_match( '#^https?://#i', $path ) ) {
			return $path;
		}
		return home_url( '/' . trim( $path, '/' ) . '/' );
	}

	private static function remove_filters( array $set ) {
		$qid    = self::query_id( $set );
		$active = Query::is_active_for( $qid );
		$text   = isset( $set['remove_filters_text'] ) ? (string) $set['remove_filters_text'] : '';
		$active = $active || Markup_Active::editing();
		return '<div class="m7sf-filter-remove-filters m7sf-filter" data-m7sf-for="' . esc_attr( $qid ) . '" data-m7sf-refresh="remove" data-m7sf-apply="' . esc_attr( in_array( $set['apply_type'], array( 'ajax', 'reload', 'mixed' ), true ) ? $set['apply_type'] : 'ajax' ) . '"><div class="m7sf-remove-all-filters' . ( $active ? '' : ' hide' ) . '"><button type="button" class="m7sf-remove-all-filters__button" data-m7sf-clear' . self::tab() . '>' . esc_html( $text ) . '</button></div></div>';
	}

	/**
	 * Verborgen filter: vaste waarde voor een taxonomie of metaveld, één keer toegepast na het laden.
	 */
	private static function hidden( array $set ) {
		$type  = isset( $set['argument_type'] ) ? (string) $set['argument_type'] : 'plain';
		$name  = isset( $set['argument_name'] ) ? trim( (string) $set['argument_name'] ) : '';
		$value = isset( $set['argument_value'] ) ? trim( do_shortcode( (string) $set['argument_value'] ) ) : '';
		$inner = '';
		if ( is_admin() || ( defined( 'ELEMENTOR_VERSION' ) && \Elementor\Plugin::$instance->editor->is_edit_mode() ) ) {
			$inner = '<div class="m7sf-hidden-admin-info">' . esc_html__( 'Verborgen filter', 'm7-smart-filters' ) . '</div>';
		} elseif ( '' !== $name && '' !== $value && in_array( $type, array( 'tax', 'meta' ), true ) ) {
			$param = 'meta' === $type ? 'mf_meta_' . $name : 'mf_tax_' . $name;
			if ( 'tax' === $type ) {
				$term = get_term_by( 'slug', $value, $name );
				if ( ! $term && ctype_digit( $value ) ) {
					$term = get_term( (int) $value, $name );
				}
				if ( ! $term || is_wp_error( $term ) ) {
					return '<div class="m7sf-filter-hidden m7sf-filter"></div>';
				}
				$value = $term->slug;
			}
			$inner = '<div class="m7sf-hidden-data"></div>';
			return '<div' . self::attrs(
				array(
					'class'              => 'm7sf-filter-hidden m7sf-filter',
					'data-m7sf-for'      => self::query_id( $set ),
					'data-m7sf-param'    => $param,
					'data-m7sf-type'     => 'hidden',
					'data-m7sf-value'    => $value,
					'data-m7sf-apply'    => 'mixed' === ( isset( $set['apply_type'] ) ? $set['apply_type'] : 'ajax' ) ? 'mixed' : 'ajax',
					'data-m7sf-apply-on' => 'value',
				)
			) . '>' . $inner . '</div>';
		}
		return '<div class="m7sf-filter-hidden m7sf-filter">' . $inner . '</div>';
	}

	private static function active( $type, array $set ) {
		return Markup_Active::render( $type, $set, self::query_id( $set ) );
	}

	private static function pagination( array $set ) {
		return Markup_Active::pagination( $set, self::query_id( $set ) );
	}

	/* ------------------------------------------------------------------ */
	/* Hulpfuncties                                                         */
	/* ------------------------------------------------------------------ */

	/**
	 * Naam van de invoervelden (zoals JetSmartFilters: taxonomie of metasleutel).
	 */
	private static function query_var( array $s ) {
		if ( 'taxonomy' === $s['source'] && 'range' !== $s['type'] && 'check_range' !== $s['type'] ) {
			return (string) $s['taxonomy'];
		}
		return (string) $s['meta_key'];
	}

	/**
	 * Getal opmaken zoals JetSmartFilters (number_format met de ingestelde decimalen en scheidingstekens).
	 */
	public static function fmt_number( array $s, $value, $with_affix ) {
		$out = number_format( (float) $value, (int) $s['range_decimals'], (string) $s['range_decimal_sep'], (string) $s['range_thousand_sep'] );
		return $with_affix ? $s['range_prefix'] . $out . $s['range_suffix'] : $out;
	}

	public static function num( $v ) {
		$v = (float) $v;
		return floor( $v ) === $v ? (string) (int) $v : rtrim( rtrim( number_format( $v, 4, '.', '' ), '0' ), '.' );
	}

	/**
	 * tabindex="0" als bediening met het toetsenbord aan staat (instelling, zoals JetSmartFilters).
	 */
	public static function tab() {
		static $on = null;
		if ( null === $on ) {
			$on = (bool) Settings::get( 'tabindex' );
		}
		return $on ? ' tabindex="0"' : '';
	}

	public static function yes( array $set, $key ) {
		return isset( $set[ $key ] ) && in_array( $set[ $key ], array( 'yes', 'true', true, 1, '1' ), true );
	}

	public static function attrs( array $attrs ) {
		$out = '';
		foreach ( $attrs as $name => $value ) {
			if ( null === $value || false === $value ) {
				continue;
			}
			$out .= ' ' . $name . '="' . esc_attr( (string) $value ) . '"';
		}
		return $out;
	}

	/**
	 * Font Awesome 4-icoon als inline SVG (assets/icons, SIL OFL 1.1).
	 */
	public static function icon( $name ) {
		static $cache = array();
		if ( ! isset( $cache[ $name ] ) ) {
			$file           = M7SF_DIR . 'assets/icons/' . sanitize_key( $name ) . '.svg';
			$cache[ $name ] = is_readable( $file ) ? trim( (string) file_get_contents( $file ) ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- lokaal pluginbestand.
		}
		return $cache[ $name ];
	}
}
