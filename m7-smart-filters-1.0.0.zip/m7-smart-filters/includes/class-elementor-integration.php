<?php
/**
 * Elementor-widgets registreren.
 *
 * @package M7SF
 */

namespace M7SF;

defined( 'ABSPATH' ) || exit;

final class Elementor_Integration {

	const CATEGORY = 'm7-smart-filters';

	/**
	 * Eigen groep "M7 Smart Filters" in het Elementor-paneel (los van andere M7-plugins).
	 * Hier zelf geregistreerd: een oudere gedeelde M7-kopie van een andere plugin kent alleen de groep "M7".
	 *
	 * @param object $manager Elementor elements manager.
	 */
	public static function register_category( $manager ) {
		\M7_Admin_Menu::elementor_icons();
		$cats = method_exists( $manager, 'get_categories' ) ? $manager->get_categories() : array();
		if ( ! isset( $cats[ self::CATEGORY ] ) ) {
			$manager->add_category(
				self::CATEGORY,
				array(
					'title' => 'M7 Smart Filters',
					'icon'  => 'm7-eicon',
				)
			);
		}
	}

	public static function register_widgets( $widgets_manager ) {
		require_once M7SF_DIR . 'includes/elementor/trait-common-controls.php';
		require_once M7SF_DIR . 'includes/elementor/class-widget-jsf.php';
		\M7_Admin_Menu::elementor_icons();
		// Eén widget per filtertype, met dezelfde instellingen als JetSmartFilters.
		foreach ( Markup::WIDGET_TYPES as $type ) {
			$class = __NAMESPACE__ . '\\Elementor\\Widget_Jsf_' . str_replace( ' ', '_', ucwords( str_replace( '-', ' ', $type ) ) );
			if ( class_exists( $class ) ) {
				$widgets_manager->register( new $class() );
			}
		}
		// Het eerste algemene M7 Filter-widget blijft werken op bestaande pagina's, maar staan niet meer in het paneel.
		$widgets_manager->register( new Elementor\Widget_Filter() );
		$widgets_manager->register( new Elementor\Widget_Active_Filters() );
	}

	/**
	 * Filters voor de keuzelijst in widgets.
	 *
	 * @return array
	 */
	public static function filter_choices() {
		$out   = array( '' => __( '— Kies een filter —', 'm7-smart-filters' ) );
		$posts = get_posts(
			array(
				'post_type'      => Filter_Post_Type::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 200,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);
		foreach ( $posts as $p ) {
			$s                       = Filter_Post_Type::get( $p->ID );
			$out[ (string) $p->ID ] = $p->post_title . ( $s ? ' (' . Filter_Post_Type::TYPES[ $s['type'] ] . ')' : '' );
		}
		return $out;
	}
}
