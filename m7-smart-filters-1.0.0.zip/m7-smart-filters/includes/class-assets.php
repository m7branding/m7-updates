<?php
/**
 * Scripts en stijlen; alleen geladen op pagina's met een filter.
 *
 * @package M7SF
 */

namespace M7SF;

defined( 'ABSPATH' ) || exit;

final class Assets {

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register' ), 5 );
		add_action( 'elementor/preview/enqueue_scripts', array( __CLASS__, 'enqueue' ) );
	}

	public static function register() {
		// Versie = plugin-versie + bestandstijd, zodat browsers na een update meteen de nieuwe bestanden laden.
		$ver_css = M7SF_VERSION . '.' . (int) @filemtime( M7SF_DIR . 'assets/m7sf.css' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		$ver_js  = M7SF_VERSION . '.' . (int) @filemtime( M7SF_DIR . 'assets/m7sf.js' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		wp_register_style( 'm7sf', M7SF_URL . 'assets/m7sf.css', array(), $ver_css );
		$focus = sanitize_hex_color( (string) Settings::get( 'tabindex_color' ) );
		if ( $focus && '#0085f2' !== strtolower( $focus ) ) {
			$rgb = sscanf( strlen( $focus ) === 4 ? '#' . $focus[1] . $focus[1] . $focus[2] . $focus[2] . $focus[3] . $focus[3] : $focus, '#%02x%02x%02x' );
			wp_add_inline_style( 'm7sf', '.m7sf-filter{--tabindex-color:' . $focus . ';--tabindex-shadow-color:rgba(' . implode( ',', array_map( 'intval', $rgb ) ) . ',.4)}' );
		}
		if ( Settings::get( 'preloader' ) ) {
			$color = sanitize_hex_color( (string) Settings::get( 'preloader_color' ) );
			wp_add_inline_style(
				'm7sf',
				'.m7sf-preloader{font-size:' . (int) Settings::get( 'preloader_size' ) . 'px;color:' . ( $color ? $color : '#007cba' ) . '}' . wp_strip_all_tags( (string) Settings::get( 'preloader_css' ) )
			);
		}
		wp_register_script( 'm7sf', M7SF_URL . 'assets/m7sf.js', array(), $ver_js, array( 'in_footer' => true, 'strategy' => 'defer' ) );

		// Datumfilters: jQuery UI (WordPress) voor van-tot, Air Datepicker 2.2.3 (MIT) voor perioden.
		$ver_dates = M7SF_VERSION . '.' . (int) @filemtime( M7SF_DIR . 'assets/m7sf-dates.js' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		wp_register_script( 'm7sf-airdp', M7SF_URL . 'assets/vendor/air-datepicker/datepicker.js', array( 'jquery' ), '2.2.3', true );
		wp_register_style( 'm7sf-datepicker', M7SF_URL . 'assets/vendor/air-datepicker/datepicker.css', array(), '2.2.3' );
		wp_add_inline_style( 'm7sf-datepicker', self::datepicker_css() );
		wp_register_script( 'm7sf-dates', M7SF_URL . 'assets/m7sf-dates.js', array( 'jquery' ), $ver_dates, true );
		global $wp_locale;
		wp_localize_script(
			'm7sf-dates',
			'm7sfDates',
			array(
				'weekStart' => (int) get_option( 'start_of_week', 1 ),
				'i18n'      => array(
					'closeText'       => __( 'Done', 'm7-smart-filters' ),
					'prevText'        => __( 'Prev', 'm7-smart-filters' ),
					'nextText'        => __( 'Next', 'm7-smart-filters' ),
					'currentText'     => __( 'Today', 'm7-smart-filters' ),
					'monthNames'      => array_values( $wp_locale->month ),
					'monthNamesShort' => array_values( $wp_locale->month_abbrev ),
					'dayNames'        => array_values( $wp_locale->weekday ),
					'dayNamesShort'   => array_values( $wp_locale->weekday_abbrev ),
					'dayNamesMin'     => array_values( $wp_locale->weekday_initial ),
					'weekHeader'      => __( 'Wk', 'm7-smart-filters' ),
				),
			)
		);
		wp_localize_script(
			'm7sf',
			'm7sfConfig',
			array(
				'mainSelector' => Settings::get( 'main_selector' ),
				'scrollTop'    => (bool) Settings::get( 'scroll_top' ),
				'scrollOffset' => (int) Settings::get( 'scroll_offset' ),
				'urlMode'      => (string) Settings::get( 'url_mode' ),
				'tabindex'     => (bool) Settings::get( 'tabindex' ),
				'dropdownClose' => (bool) Settings::get( 'dropdown_close' ),
				'preloader'    => Settings::get( 'preloader' ) ? array(
					'fixed' => (bool) Settings::get( 'preloader_fixed' ),
					'gap'   => (int) Settings::get( 'preloader_gap' ),
				) : false,
				'i18n'         => array(
					'more'    => __( 'Meer tonen', 'm7-smart-filters' ),
					'less'    => __( 'Minder tonen', 'm7-smart-filters' ),
					'loading' => __( 'Resultaten laden…', 'm7-smart-filters' ),
					'loaded'  => __( 'Resultaten bijgewerkt.', 'm7-smart-filters' ),
					'error'   => __( 'Filteren lukte niet. De pagina wordt opnieuw geladen.', 'm7-smart-filters' ),
				),
			)
		);
	}

	/**
	 * Kalenderopmaak zoals bij JetSmartFilters (afwijkingen op Air Datepicker 2.2.3).
	 */
	private static function datepicker_css() {
		return '.datepickers-container{z-index:10000}.datepicker{padding:5px;transition:none}.datepicker--pointer{display:none}'
			. '.datepicker--nav{border-bottom:0;padding:0;min-height:0}.datepicker--nav-action svg{width:16px;height:16px}.datepicker--nav-action path{fill:currentColor;stroke:none}'
			. '.datepicker--cell.datepicker--cell-day.-week-hover-{border-radius:0;color:inherit;background-color:rgba(92,196,239,.1)}'
			. '.datepicker--cell.datepicker--cell-day.-week-hover-.-disabled-{opacity:.4}'
			. '.datepicker--cell.datepicker--cell-day.-week-start-hover-{border-radius:5px 0 0 5px}.datepicker--cell.datepicker--cell-day.-week-end-hover-{border-radius:0 5px 5px 0}'
			. '.datepicker--cell.datepicker--cell-day.-week-selected-{border-radius:0;color:#fff;background-color:#5cc4ef}'
			. '.datepicker--cell.datepicker--cell-day.-week-start-selected-{border-radius:5px 0 0 5px}.datepicker--cell.datepicker--cell-day.-week-end-selected-{border-radius:0 5px 5px 0}'
			. 'body.rtl #datepickers-container .datepicker:not(.active){left:100000px!important}body.rtl #datepickers-container .datepicker--nav-action{transform:rotate(180deg)}';
	}

	public static function enqueue() {
		if ( ! wp_script_is( 'm7sf', 'registered' ) ) {
			self::register();
		}
		wp_enqueue_style( 'm7sf' );
		wp_enqueue_script( 'm7sf' );
	}
}
