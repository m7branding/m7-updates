<?php
/**
 * Koppelt filters aan de inhoud die gefilterd wordt (providers) en markeert
 * de containers zodat de browser bij AJAX precies dat blok kan vervangen.
 *
 * Ondersteund: Elementor Pro Loop Grid / Posts / Products (via Query ID),
 * WooCommerce-archief en hoofdquery ("main"), WooCommerce-shortcode [products]
 * en het Gutenberg Query Loop-blok (CSS-klasse m7sf-query-<id>).
 *
 * @package M7SF
 */

namespace M7SF;

defined( 'ABSPATH' ) || exit;

final class Providers {

	const MAIN = 'main';

	/** @var bool */
	private static $main_open = false;

	/** @var array Numeriek queryId van Query Loop-blok => M7-query-ID. */
	private static $block_map = array();

	/** @var array Stapel van query-ID's van Elementor-widgets die nu worden opgebouwd. */
	private static $rendering_stack = array();

	/** @var array Paginagegevens per Elementor-widget (ID => [huidige pagina, aantal pagina's]). */
	private static $widget_pages = array();

	/** @var array|null Laatste resultaten van [products]. */
	private static $wc_results = null;

	public static function init() {
		add_action( 'init', array( __CLASS__, 'hook_queries' ), 20 );

		// Paginagegevens voor het M7-pagineringswidget (zoals JetSmartFilters ze uit de lijst haalt).
		add_action( 'elementor/query/query_results', array( __CLASS__, 'remember_elementor_pages' ), 10, 2 );
		add_filter( 'elementor/widget/render_content', array( __CLASS__, 'add_elementor_pages' ), 20, 2 );
		add_filter( 'woocommerce_shortcode_products_query_results', array( __CLASS__, 'remember_wc_pages' ), 10, 2 );
		add_filter( 'render_block_data', array( __CLASS__, 'remember_query_block' ) );

		// Containers markeren (altijd, ook zonder actieve filters: de eerste klik moet het blok kunnen vinden).
		add_action( 'elementor/frontend/widget/before_render', array( __CLASS__, 'mark_elementor_widget' ) );
		add_action( 'elementor/frontend/widget/after_render', array( __CLASS__, 'end_elementor_widget' ) );
		add_filter( 'render_block_core/query', array( __CLASS__, 'mark_query_block' ), 10, 2 );
		// WooCommerce Product Collection-blok (blokthema's en de nieuwe winkelpagina's).
		add_filter( 'render_block_woocommerce/product-collection', array( __CLASS__, 'mark_query_block' ), 10, 2 );
		add_filter( 'do_shortcode_tag', array( __CLASS__, 'mark_products_shortcode' ), 10, 3 );

		add_action( 'woocommerce_before_shop_loop', array( __CLASS__, 'open_main' ), 1 );
		add_action( 'woocommerce_after_shop_loop', array( __CLASS__, 'close_main' ), 999 );
		add_action( 'woocommerce_no_products_found', array( __CLASS__, 'open_main' ), 1 );
		add_action( 'woocommerce_no_products_found', array( __CLASS__, 'close_main' ), 999 );
	}

	/**
	 * Hangt de filter aan precies de query uit de URL.
	 */
	public static function hook_queries() {
		$qid = Query::query_id();
		if ( '' === $qid || is_admin() && ! wp_doing_ajax() ) {
			return;
		}

		if ( self::MAIN === $qid ) {
			add_action( 'pre_get_posts', array( __CLASS__, 'filter_main_query' ), 20 );
			return;
		}

		// Elementor Pro: Loop Grid, Posts, Archive, Portfolio. Herkend aan "Query ID" of aan de CSS-ID
		// van de widget (zo werkte JetSmartFilters; bestaande pagina's hoeven dus niet aangepast).
		add_filter( 'elementor/query/query_args', array( __CLASS__, 'filter_elementor_args' ), 20, 2 );
		add_action( 'elementor/query/' . $qid, array( __CLASS__, 'filter_wp_query' ), 20 );
		// Loop Grid / Posts op "Current Query": Elementor Pro geeft de widget niet mee, dus kijken we
		// welke widget op dat moment wordt opgebouwd (bijgehouden in mark/end_elementor_widget).
		add_filter( 'elementor/query/get_query_args/current_query', array( __CLASS__, 'filter_elementor_current_query' ), 20 );

		// Gutenberg Query Loop-blok met CSS-klasse m7sf-query-<id>.
		add_filter( 'query_loop_block_query_vars', array( __CLASS__, 'filter_query_block' ), 20, 2 );

		// WooCommerce [products class="m7sf-query-<id>"].
		add_filter( 'woocommerce_shortcode_products_query', array( __CLASS__, 'filter_products_shortcode' ), 20, 3 );
	}

	public static function filter_main_query( $query ) {
		if ( ! $query instanceof \WP_Query || ! $query->is_main_query() || is_admin() ) {
			return;
		}
		if ( ! ( $query->is_archive() || $query->is_home() || $query->is_search() || $query->is_post_type_archive() ) ) {
			return;
		}
		Query::apply_to_query( $query, Query::state() );
	}

	public static function filter_wp_query( $query ) {
		if ( $query instanceof \WP_Query && ! $query->get( 'm7sf_applied' ) ) {
			Query::apply_to_query( $query, Query::state() );
			$query->set( 'm7sf_applied', 1 );
		}
	}

	/**
	 * Elementor Pro bouwt de query-args van lijstwidgets; filter als het query-ID klopt.
	 *
	 * @param array  $args   Query-args.
	 * @param object $widget Widget.
	 * @return array
	 */
	public static function filter_elementor_args( $args, $widget ) {
		if ( ! is_array( $args ) || ! empty( $args['m7sf_applied'] ) || ! is_object( $widget ) || ! method_exists( $widget, 'get_settings' ) ) {
			return $args;
		}
		if ( in_array( Query::query_id(), self::elementor_ids( $widget ), true ) ) {
			$args                 = Query::apply_to_vars( $args, Query::state() );
			$args['m7sf_applied'] = 1;
		}
		return $args;
	}

	/** Widgettypen waarvan de CSS-ID als query-ID telt. */
	const ELEMENTOR_QUERY_WIDGETS = array( 'loop-grid', 'loop-carousel', 'posts', 'archive-posts', 'portfolio', 'woocommerce-products', 'wc-archive-products' );

	/**
	 * Alle ID's waarmee filters naar deze Elementor-widget kunnen verwijzen.
	 *
	 * @param object $widget Widget.
	 * @return string[]
	 */
	public static function elementor_ids( $widget ) {
		$settings = $widget->get_settings();
		$ids      = array();
		$name     = method_exists( $widget, 'get_name' ) ? (string) $widget->get_name() : '';
		// Filterwidgets (M7 en JetSmartFilters) hebben ook een query_id, maar zijn zelf geen lijst.
		if ( ! is_array( $settings ) || 0 === strpos( $name, 'm7sf-' ) || 0 === strpos( $name, 'jet-smart-filters-' ) ) {
			return $ids;
		}
		foreach ( $settings as $key => $value ) {
			if ( is_string( $key ) && is_string( $value ) && '' !== $value && 'query_id' === substr( $key, -8 ) && 'jet-smart-filters' !== $value ) {
				$ids[] = Query::clean_query_id( $value );
			}
		}
		if ( in_array( $name, self::ELEMENTOR_QUERY_WIDGETS, true ) ) {
			if ( ! empty( $settings['_element_id'] ) && is_string( $settings['_element_id'] ) ) {
				$ids[] = Query::clean_query_id( $settings['_element_id'] );
			} else {
				// Zoals JetSmartFilters: een lijst zonder CSS-ID heeft query-ID "default"; filters zonder query-ID
				// (Elementor Pro-providers) werken op die lijst.
				$ids[] = 'default';
			}
		}
		return array_values( array_unique( array_filter( $ids ) ) );
	}

	public static function filter_query_block( $vars, $block ) {
		if ( self::block_query_id( $block ) === Query::query_id() ) {
			$vars = Query::apply_to_vars( $vars, Query::state() );
		}
		return $vars;
	}

	public static function filter_products_shortcode( $args, $atts, $type = '' ) {
		// Query-ID = klasse "m7sf-query-<id>" of (zoals bij JetSmartFilters) een klasse gelijk aan het ID.
		if ( in_array( Query::query_id(), self::class_ids( isset( $atts['class'] ) ? $atts['class'] : '' ), true ) ) {
			// WooCommerce cachet op basis van de query-args; gefilterde args krijgen dus een eigen cache.
			$args = Query::apply_to_vars( $args, Query::state() );
		}
		return $args;
	}

	/**
	 * Elementor-widgets met een Query ID krijgen data-m7sf-query.
	 *
	 * @param \Elementor\Element_Base $widget Widget.
	 */
	public static function mark_elementor_widget( $widget ) {
		$ids                    = self::elementor_ids( $widget );
		self::$rendering_stack[] = $ids;
		if ( $ids ) {
			// Meerdere ID's gescheiden door spaties; de browser zoekt met [data-m7sf-query~="id"].
			$widget->add_render_attribute( '_wrapper', 'data-m7sf-query', implode( ' ', $ids ) );
		}
	}

	public static function end_elementor_widget( $widget ) {
		array_pop( self::$rendering_stack );
	}

	/**
	 * Query-vars van een Loop Grid op "Current Query" filteren als die widget het juiste ID heeft.
	 *
	 * @param array $vars Query-vars (kopie van de hoofdquery).
	 * @return array
	 */
	public static function filter_elementor_current_query( $vars ) {
		$current = self::$rendering_stack ? end( self::$rendering_stack ) : array();
		if ( is_array( $vars ) && empty( $vars['m7sf_applied'] ) && in_array( Query::query_id(), (array) $current, true ) ) {
			$vars                 = Query::apply_to_vars( $vars, Query::state() );
			$vars['m7sf_applied'] = 1;
		}
		return $vars;
	}

	public static function mark_query_block( $content, $block ) {
		$qid = self::block_query_id( $block );
		if ( ! $qid && is_array( $block ) && ! empty( $block['attrs']['query']['inherit'] ) ) {
			$qid = self::MAIN;
		}
		if ( $qid ) {
			$content = self::add_attribute_to_first_tag( $content, $qid );
		}
		return $content;
	}

	public static function mark_products_shortcode( $output, $tag, $attr ) {
		if ( 'products' !== $tag || ! is_array( $attr ) ) {
			return $output;
		}
		$ids = self::class_ids( isset( $attr['class'] ) ? $attr['class'] : '' );
		if ( $ids ) {
			$pages = '';
			if ( self::$wc_results ) {
				$pages = self::pages_attr( (int) self::$wc_results['page'], (int) self::$wc_results['max'], 'product-page' );
			}
			self::$wc_results = null;
			$output = '<div class="m7sf-provider" data-m7sf-query="' . esc_attr( implode( ' ', $ids ) ) . '"' . $pages . '>' . $output . '</div>';
		}
		return $output;
	}

	/**
	 * Mogelijke query-ID's uit een klassenlijst: "m7sf-query-<id>" en elke losse klasse.
	 *
	 * @param string $classes Klassen.
	 * @return string[]
	 */
	public static function class_ids( $classes ) {
		$ids = array();
		foreach ( preg_split( '/\s+/', trim( (string) $classes ) ) as $c ) {
			if ( '' === $c ) {
				continue;
			}
			$ids[] = Query::clean_query_id( 0 === strpos( $c, 'm7sf-query-' ) ? substr( $c, 11 ) : $c );
		}
		return array_values( array_unique( array_filter( $ids ) ) );
	}

	public static function remember_wc_pages( $results, $shortcode = null ) {
		if ( is_object( $results ) ) {
			self::$wc_results = array(
				'page' => isset( $results->current_page ) ? max( 1, (int) $results->current_page ) : 1,
				'max'  => isset( $results->total_pages ) ? (int) $results->total_pages : 1,
			);
		}
		return $results;
	}

	public static function remember_elementor_pages( $query, $widget = null ) {
		if ( $query instanceof \WP_Query && is_object( $widget ) && method_exists( $widget, 'get_id' ) ) {
			self::$widget_pages[ $widget->get_id() ] = array( max( 1, (int) $query->get( 'paged' ) ), (int) $query->max_num_pages );
		}
	}

	/**
	 * Paginagegevens als verborgen element in de lijstwidget (wordt bij filteren mee vervangen).
	 */
	public static function add_elementor_pages( $content, $widget ) {
		if ( ! is_object( $widget ) || ! method_exists( $widget, 'get_id' ) || ! isset( self::$widget_pages[ $widget->get_id() ] ) || ! self::elementor_ids( $widget ) ) {
			return $content;
		}
		list( $page, $max ) = self::$widget_pages[ $widget->get_id() ];
		return $content . '<span class="m7sf-pages" hidden' . self::pages_attr( $page, $max, 'e-page-' . $widget->get_id() ) . '></span>';
	}

	/**
	 * data-m7sf-pages met huidige pagina, aantal en de adressen per pagina (met de huidige filters).
	 */
	private static function pages_attr( $page, $max, $param ) {
		if ( $max < 1 ) {
			return '';
		}
		$current = remove_query_arg( array( 'm7sf_partial', 'm7sf_ajax', $param ), self::request_url() );
		$urls    = array();
		for ( $i = 1; $i <= min( $max, 500 ); $i++ ) {
			if ( 'paged' === $param ) {
				$urls[ $i ] = get_pagenum_link( $i, false );
			} else {
				$urls[ $i ] = 1 === $i ? $current : add_query_arg( $param, $i, $current );
			}
		}
		return ' data-m7sf-pages="' . esc_attr(
			wp_json_encode(
				array(
					'page' => $page,
					'max'  => $max,
					'urls' => $urls,
				)
			)
		) . '"';
	}

	private static function request_url() {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- alleen gebruikt om een eigen URL op te bouwen.
		return esc_url_raw( home_url( $uri ) );
	}

	public static function open_main() {
		if ( self::$main_open || ! self::is_main_shop_loop() ) {
			return;
		}
		self::$main_open = true;
		echo '<div class="m7sf-provider" data-m7sf-query="' . esc_attr( self::MAIN ) . '">';
	}

	public static function close_main() {
		if ( ! self::$main_open ) {
			return;
		}
		self::$main_open = false;
		global $wp_query;
		if ( $wp_query instanceof \WP_Query ) {
			echo '<span class="m7sf-pages" hidden' . self::pages_attr( max( 1, (int) get_query_var( 'paged' ) ), (int) $wp_query->max_num_pages, 'paged' ) . '></span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pages_attr escapet zelf.
		}
		echo '</div>';
	}

	private static function is_main_shop_loop() {
		if ( ! function_exists( 'is_shop' ) ) {
			return false;
		}
		// Alleen de hoofdlus van winkel/categorie/tag/attribuut, niet shortcodes of widgets.
		return ( is_shop() || is_product_taxonomy() ) && ! wc_get_loop_prop( 'is_shortcode' );
	}

	/**
	 * Onthoudt welk numeriek queryId van een Query Loop-blok bij welke M7-query hoort.
	 * Het post-template-blok (waar de query-vars worden gezet) kent alleen dat nummer.
	 *
	 * @param array $parsed Blokdata.
	 * @return array
	 */
	public static function remember_query_block( $parsed ) {
		if ( isset( $parsed['blockName'] ) && in_array( $parsed['blockName'], array( 'core/query', 'woocommerce/product-collection' ), true ) ) {
			$qid = self::class_query_id( isset( $parsed['attrs']['className'] ) ? $parsed['attrs']['className'] : '' );
			if ( ! $qid && ! empty( $parsed['attrs']['query']['inherit'] ) ) {
				$qid = self::MAIN; // Neemt de hoofdquery over (winkel/categorie): zelfde als het WooCommerce-archief.
			}
			if ( $qid && isset( $parsed['attrs']['queryId'] ) ) {
				self::$block_map[ (string) $parsed['attrs']['queryId'] ] = $qid;
			}
		}
		return $parsed;
	}

	private static function block_query_id( $block ) {
		if ( $block instanceof \WP_Block ) {
			if ( isset( $block->context['queryId'] ) && isset( self::$block_map[ (string) $block->context['queryId'] ] ) ) {
				return self::$block_map[ (string) $block->context['queryId'] ];
			}
			$attrs = isset( $block->parsed_block['attrs'] ) ? $block->parsed_block['attrs'] : array();
		} elseif ( is_array( $block ) ) {
			$attrs = isset( $block['attrs'] ) ? $block['attrs'] : array();
		} else {
			return '';
		}
		return self::class_query_id( isset( $attrs['className'] ) ? $attrs['className'] : '' );
	}

	/**
	 * Haalt <id> uit een klassenlijst met "m7sf-query-<id>".
	 *
	 * @param string $classes Klassen.
	 * @return string
	 */
	public static function class_query_id( $classes ) {
		if ( is_string( $classes ) && preg_match( '/(?:^|\s)m7sf-query-([A-Za-z0-9_\-]+)/', $classes, $m ) ) {
			return Query::clean_query_id( $m[1] );
		}
		return '';
	}

	private static function add_attribute_to_first_tag( $html, $qid ) {
		if ( class_exists( '\WP_HTML_Tag_Processor' ) ) {
			$p = new \WP_HTML_Tag_Processor( $html );
			if ( $p->next_tag() ) {
				$p->set_attribute( 'data-m7sf-query', $qid );
				return $p->get_updated_html();
			}
			return $html;
		}
		return preg_replace( '/^(\s*<[a-zA-Z0-9\-]+)/', '$1 data-m7sf-query="' . esc_attr( $qid ) . '"', $html, 1 );
	}
}
