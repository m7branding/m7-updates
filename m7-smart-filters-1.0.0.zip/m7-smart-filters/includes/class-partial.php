<?php
/**
 * Snelle AJAX-respons: alleen de Elementor-widgets die veranderen (lijst, actieve filters),
 * in plaats van de hele pagina.
 *
 * De browser stuurt ?m7sf_partial=<document-ID>:<element-ID>,… mee. Na de hoofdquery
 * (template_redirect) renderen we alleen die elementen en geven JSON terug:
 *   { ok: true, parts: { "2050:2682d6ab": "<div …>…</div>", … } }
 * Lukt iets niet, dan antwoordt de server met ok=false en haalt de browser de hele pagina op.
 *
 * Veiligheid: alleen gepubliceerde documenten, en alleen elementen die bij de gevraagde
 * query horen (M7-widgets of elementen waarvan de instellingen het query-ID bevatten).
 *
 * @package M7SF
 */

namespace M7SF;

defined( 'ABSPATH' ) || exit;

final class Partial {

	const PARAM     = 'm7sf_partial';
	const MAX_PARTS = 12;

	public static function init() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Openbaar, alleen lezen.
		if ( empty( $_GET[ self::PARAM ] ) ) {
			return;
		}
		// Pagineringslinks mogen de hulpparameter niet bevatten.
		if ( isset( $_SERVER['REQUEST_URI'] ) ) {
			$_SERVER['REQUEST_URI'] = remove_query_arg( self::PARAM, wp_unslash( $_SERVER['REQUEST_URI'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		}
		add_action( 'template_redirect', array( __CLASS__, 'respond' ), PHP_INT_MAX );
	}

	/**
	 * Gevraagde onderdelen uit de URL: [ [doc, element], … ].
	 *
	 * @return array
	 */
	private static function requested() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$raw   = (string) wp_unslash( $_GET[ self::PARAM ] );
		$parts = array();
		foreach ( array_slice( explode( ',', $raw ), 0, self::MAX_PARTS ) as $item ) {
			if ( preg_match( '/^(\d{1,10}):([a-z0-9]{1,12})$/', trim( $item ), $m ) ) {
				$parts[ $m[1] . ':' . $m[2] ] = array( (int) $m[1], $m[2] );
			}
		}
		return $parts;
	}

	public static function respond() {
		if ( ! class_exists( '\Elementor\Plugin' ) || is_404() ) {
			self::send( false );
		}
		$qid      = Query::query_id();
		$requested = self::requested();
		if ( ! $requested ) {
			self::send( false );
		}

		$elementor = \Elementor\Plugin::$instance;
		$out       = array();
		foreach ( $requested as $key => $pair ) {
			list( $doc_id, $element_id ) = $pair;
			if ( 'publish' !== get_post_status( $doc_id ) || post_password_required( $doc_id ) ) {
				self::send( false );
			}
			$document = $elementor->documents->get( $doc_id );
			if ( ! $document ) {
				self::send( false );
			}
			$data = self::find( $document->get_elements_data(), $element_id );
			if ( ! $data || ! self::allowed( $data, $qid ) ) {
				self::send( false );
			}

			$elementor->documents->switch_to_document( $document );
			$element = $elementor->elements_manager->create_element_instance( $data );
			if ( ! $element ) {
				$elementor->documents->restore_document();
				self::send( false );
			}
			ob_start();
			$element->print_element();
			$out[ $key ] = ob_get_clean();
			$elementor->documents->restore_document();
		}
		self::send( true, $out );
	}

	private static function find( $elements, $id ) {
		foreach ( (array) $elements as $el ) {
			if ( isset( $el['id'] ) && $el['id'] === $id ) {
				return $el;
			}
			if ( ! empty( $el['elements'] ) ) {
				$found = self::find( $el['elements'], $id );
				if ( $found ) {
					return $found;
				}
			}
		}
		return null;
	}

	/**
	 * Alleen M7-widgets en elementen die aantoonbaar bij deze query horen.
	 */
	private static function allowed( array $data, $qid ) {
		if ( 'widget' !== ( isset( $data['elType'] ) ? $data['elType'] : '' ) ) {
			return false;
		}
		$type = isset( $data['widgetType'] ) ? (string) $data['widgetType'] : '';
		if ( 0 === strpos( $type, 'm7sf-' ) ) {
			return true;
		}
		if ( '' === $qid ) {
			return false;
		}
		$settings = isset( $data['settings'] ) ? wp_json_encode( $data['settings'] ) : '';
		return false !== strpos( (string) $settings, '"' . $qid . '"' ) || false !== strpos( (string) $settings, $qid . '\"' ) || false !== strpos( (string) $settings, 'm7sf-query-' . $qid );
	}

	private static function send( $ok, array $parts = array() ) {
		nocache_headers();
		wp_send_json(
			array(
				'ok'    => (bool) $ok,
				'parts' => $parts,
			)
		);
	}
}
