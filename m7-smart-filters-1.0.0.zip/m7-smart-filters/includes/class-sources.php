<?php
/**
 * Levert de keuzeopties van een filter (termen, handmatige opties, metawaarden, berichten).
 *
 * @package M7SF
 */

namespace M7SF;

defined( 'ABSPATH' ) || exit;

final class Sources {

	const CACHE_GROUP = 'm7sf';

	public static function init() {
		add_action( 'save_post', array( __CLASS__, 'flush' ) );
		add_action( 'edited_term', array( __CLASS__, 'flush' ) );
		add_action( 'created_term', array( __CLASS__, 'flush' ) );
		add_action( 'delete_term', array( __CLASS__, 'flush' ) );
	}

	public static function flush() {
		update_option( 'm7sf_cache_version', time(), false );
	}

	private static function cache_key( $suffix ) {
		return 'm7sf_' . md5( get_option( 'm7sf_cache_version', '1' ) . '|' . $suffix );
	}

	/**
	 * Opties van een filter.
	 *
	 * Elke optie: value, label, depth, parent, image (attachment-ID), color.
	 *
	 * @param array $s Filterinstellingen.
	 * @return array
	 */
	public static function options( array $s ) {
		switch ( $s['source'] ) {
			case 'manual':
				$options = self::manual( $s );
				break;
			case 'meta':
				$options = self::meta_values( $s );
				break;
			case 'posts':
				$options = self::posts( $s );
				break;
			case 'taxonomy':
			default:
				$options = self::terms( $s );
		}
		return apply_filters( 'm7sf/options', $options, $s );
	}

	private static function manual( array $s ) {
		$out = array();
		foreach ( $s['manual_options'] as $o ) {
			$out[] = array(
				'value'  => (string) $o['value'],
				'label'  => (string) $o['label'],
				'depth'  => 0,
				'parent' => '',
				'image'  => (int) $o['image'],
				'color'  => (string) $o['color'],
			);
		}
		return $out;
	}

	private static function terms( array $s ) {
		if ( ! taxonomy_exists( $s['taxonomy'] ) ) {
			return array();
		}
		$args = array(
			'taxonomy'   => $s['taxonomy'],
			'hide_empty' => (bool) $s['hide_empty'],
			'orderby'    => $s['terms_orderby'],
			'order'      => $s['terms_order'],
		);
		if ( 'menu_order' === $s['terms_orderby'] ) {
			$args['orderby']  = 'meta_value_num';
			$args['meta_key'] = 'order'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- WooCommerce-termvolgorde.
		}
		if ( $s['terms_include'] ) {
			$args['include'] = array_map( 'absint', explode( ',', $s['terms_include'] ) );
		}
		if ( $s['terms_exclude'] ) {
			$args['exclude'] = array_map( 'absint', explode( ',', $s['terms_exclude'] ) );
		}
		if ( $s['only_child_of'] ) {
			$args['child_of'] = (int) $s['only_child_of'];
		}
		$terms = get_terms( $args );
		if ( is_wp_error( $terms ) || ! $terms ) {
			return array();
		}

		$by_id = array();
		foreach ( $terms as $t ) {
			$by_id[ $t->term_id ] = $t;
		}

		$make = static function ( $t, $depth ) use ( $by_id ) {
			$image = (int) get_term_meta( $t->term_id, 'thumbnail_id', true );
			if ( ! $image ) {
				$image = (int) get_term_meta( $t->term_id, 'm7sf_image', true );
			}
			$color = (string) get_term_meta( $t->term_id, 'm7sf_color', true );
			return array(
				'value'  => $t->slug,
				'label'  => $t->name,
				'depth'  => $depth,
				'parent' => ( $t->parent && isset( $by_id[ $t->parent ] ) ) ? $by_id[ $t->parent ]->slug : '',
				'image'  => $image,
				'color'  => $color ? $color : '',
				'count'  => (int) $t->count,
				'id'     => (int) $t->term_id,
			);
		};

		if ( ! $s['hierarchical'] ) {
			$out = array();
			foreach ( $terms as $t ) {
				$out[] = $make( $t, 0 );
			}
			return $out;
		}

		// Boomvolgorde met diepte; termen waarvan de ouder ontbreekt worden wortels.
		$children = array();
		foreach ( $terms as $t ) {
			$parent                = isset( $by_id[ $t->parent ] ) ? (int) $t->parent : 0;
			$children[ $parent ][] = $t;
		}
		$out  = array();
		$walk = static function ( $parent, $depth ) use ( &$walk, &$out, $children, $make ) {
			if ( empty( $children[ $parent ] ) || $depth > 10 ) {
				return;
			}
			foreach ( $children[ $parent ] as $t ) {
				$out[] = $make( $t, $depth );
				$walk( (int) $t->term_id, $depth + 1 );
			}
		};
		$walk( 0, 0 );
		return $out;
	}

	private static function meta_values( array $s ) {
		if ( ! $s['meta_key'] ) {
			return array();
		}
		$key    = self::cache_key( 'meta|' . $s['meta_key'] );
		$values = get_transient( $key );
		if ( false === $values ) {
			global $wpdb;
			$post_types   = array_values( get_post_types( array( 'public' => true ) ) );
			$placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- placeholders worden hierboven opgebouwd.
			$values = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT pm.meta_value FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = %s AND p.post_status = 'publish' AND p.post_type IN ($placeholders) AND pm.meta_value <> '' ORDER BY pm.meta_value ASC LIMIT 500", array_merge( array( $s['meta_key'] ), $post_types ) ) );
			set_transient( $key, $values, 12 * HOUR_IN_SECONDS );
		}
		$out = array();
		foreach ( (array) $values as $v ) {
			if ( is_serialized( $v ) ) {
				continue;
			}
			$out[] = array(
				'value'  => (string) $v,
				'label'  => (string) $v,
				'depth'  => 0,
				'parent' => '',
				'image'  => 0,
				'color'  => '',
			);
		}
		return $out;
	}

	private static function posts( array $s ) {
		$ids = get_posts(
			array(
				'post_type'      => $s['posts_post_type'],
				'post_status'    => 'publish',
				'posts_per_page' => 500,
				'orderby'        => 'title',
				'order'          => 'ASC',
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		$out = array();
		foreach ( $ids as $id ) {
			$out[] = array(
				'value'  => (string) $id,
				'label'  => get_the_title( $id ),
				'depth'  => 0,
				'parent' => '',
				'image'  => (int) get_post_thumbnail_id( $id ),
				'color'  => '',
			);
		}
		return $out;
	}

	/**
	 * Kleinste en grootste waarde van een numeriek metaveld (voor sliders zonder vaste grenzen).
	 *
	 * @param string $meta_key Sleutel.
	 * @return array [min, max]
	 */
	public static function numeric_bounds( $meta_key ) {
		$key    = self::cache_key( 'bounds|' . $meta_key );
		$bounds = get_transient( $key );
		if ( false === $bounds ) {
			global $wpdb;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$row    = $wpdb->get_row( $wpdb->prepare( "SELECT MIN(CAST(pm.meta_value AS DECIMAL(20,4))) AS mn, MAX(CAST(pm.meta_value AS DECIMAL(20,4))) AS mx FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = %s AND p.post_status = 'publish' AND pm.meta_value <> ''", $meta_key ), ARRAY_A );
			$bounds = array(
				$row && null !== $row['mn'] ? (float) $row['mn'] : 0.0,
				$row && null !== $row['mx'] ? (float) $row['mx'] : 100.0,
			);
			set_transient( $key, $bounds, 12 * HOUR_IN_SECONDS );
		}
		return $bounds;
	}
}
