<?php
/**
 * Plugin Name:       M7 Smart Filters
 * Description:       AJAX-filters voor berichten en WooCommerce-producten (Elementor, WooCommerce, Gutenberg). Vervanger van JetSmartFilters.
 * Version:           1.0.0
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            M7 Branding
 * Author URI:        https://m7branding.com
 * License:           GPL-2.0-or-later
 * Text Domain:       m7-smart-filters
 *
 * @package M7SF
 */

defined( 'ABSPATH' ) || exit;

define( 'M7SF_VERSION', '1.0.0' );
define( 'M7SF_FILE', __FILE__ );
define( 'M7SF_DIR', plugin_dir_path( __FILE__ ) );
define( 'M7SF_URL', plugin_dir_url( __FILE__ ) );

// Gedeelde M7-code: M7-menu en updates (nooit automatisch).
require_once M7SF_DIR . 'includes/m7/class-m7-admin-menu.php';
add_action( 'plugins_loaded', array( 'M7_Updates', 'init' ), 1 );

spl_autoload_register(
	static function ( $class ) {
		if ( 0 !== strpos( $class, 'M7SF\\' ) ) {
			return;
		}
		$relative = substr( $class, 5 );
		$parts    = explode( '\\', $relative );
		$name     = array_pop( $parts );
		$file     = strtolower( str_replace( '_', '-', $name ) );
		$dir      = $parts ? strtolower( implode( '/', $parts ) ) . '/' : '';
		foreach ( array( 'class-', 'trait-' ) as $prefix ) {
			$path = M7SF_DIR . 'includes/' . $dir . $prefix . $file . '.php';
			if ( is_readable( $path ) ) {
				require_once $path;
				return;
			}
		}
	}
);

add_action( 'plugins_loaded', array( 'M7SF\\Plugin', 'instance' ) );

// Geen bestellingen, dus geschikt voor de nieuwe WooCommerce-opslag (HPOS) en de blokkassa.
add_action(
	'before_woocommerce_init',
	static function () {
		if ( class_exists( '\\Automattic\\WooCommerce\\Utilities\\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
		}
	}
);

register_activation_hook(
	__FILE__,
	static function () {
		M7SF\Filter_Post_Type::register();
		M7SF\Filter_Post_Type::rebuild_allowed_keys();
		flush_rewrite_rules();
	}
);
