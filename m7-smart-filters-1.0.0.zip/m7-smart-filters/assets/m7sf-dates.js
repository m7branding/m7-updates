/**
 * M7 Smart Filters – datumfilters.
 * Van-tot: jQuery UI-datumkiezer (WordPress). Periode (dag/week/maand/jaar/bereik): Air Datepicker.
 * Werking en notatie gelijk aan JetSmartFilters; de waarde in de M7-URL is JJJJ-MM-DD_JJJJ-MM-DD.
 */
( function ( $ ) {
	'use strict';

	var cfg = window.m7sfDates || {};
	var i18n = cfg.i18n || {};

	function pad( n ) { return ( n < 10 ? '0' : '' ) + n; }
	function iso( d ) { return d.getFullYear() + '-' + pad( d.getMonth() + 1 ) + '-' + pad( d.getDate() ); }
	function fromIso( s ) {
		var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec( s || '' );
		return m ? new Date( +m[ 1 ], +m[ 2 ] - 1, +m[ 3 ] ) : null;
	}
	function addDays( d, n ) { return new Date( d.getFullYear(), d.getMonth(), d.getDate() + n ); }

	/* Notatie zoals jQuery UI: d dd D DD m mm M MM y (2 cijfers) yy (4 cijfers). */
	function format( fmt, d ) {
		if ( ! d ) { return ''; }
		fmt = fmt || 'mm/dd/yy';
		var names = {
			D: i18n.dayNamesShort || [ 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat' ],
			DD: i18n.dayNames || [ 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday' ],
			M: i18n.monthNamesShort || [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ],
			MM: i18n.monthNames || [ 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December' ],
		};
		return fmt.replace( /yy|y|MM|M|mm|m|DD|D|dd|d/g, function ( t ) {
			switch ( t ) {
				case 'yy': return String( d.getFullYear() );
				case 'y': return String( d.getFullYear() ).slice( -2 );
				case 'MM': return names.MM[ d.getMonth() ];
				case 'M': return names.M[ d.getMonth() ];
				case 'mm': return pad( d.getMonth() + 1 );
				case 'm': return String( d.getMonth() + 1 );
				case 'DD': return names.DD[ d.getDay() ];
				case 'D': return names.D[ d.getDay() ];
				case 'dd': return pad( d.getDate() );
				case 'd': return String( d.getDate() );
			}
			return t;
		} );
	}

	/* Grenzen: "today", "today + 3 days", "current-current-15" of een datum. */
	function limit( raw ) {
		if ( ! raw ) { return null; }
		raw = String( raw ).trim();
		var now = new Date();
		var d = null;
		if ( /^today/i.test( raw ) ) {
			d = new Date( now.getFullYear(), now.getMonth(), now.getDate() );
			var re = /([+-])\s*(\d+)\s*([a-z]+)/gi, m;
			while ( ( m = re.exec( raw ) ) ) {
				var n = ( '-' === m[ 1 ] ? -1 : 1 ) * parseInt( m[ 2 ], 10 );
				var u = m[ 3 ].toLowerCase();
				if ( u.indexOf( 'day' ) !== -1 ) { d = addDays( d, n ); }
				else if ( u.indexOf( 'week' ) !== -1 ) { d = addDays( d, n * 7 ); }
				else if ( u.indexOf( 'month' ) !== -1 ) { var day = d.getDate(); d = new Date( d.getFullYear(), d.getMonth() + n, 1 ); d.setDate( Math.min( day, new Date( d.getFullYear(), d.getMonth() + 1, 0 ).getDate() ) ); }
				else if ( u.indexOf( 'year' ) !== -1 ) { d = new Date( d.getFullYear() + n, d.getMonth(), d.getDate() ); }
			}
			return d;
		}
		if ( raw.indexOf( 'current' ) !== -1 ) {
			var p = raw.split( '-' );
			var y = 'current' === p[ 0 ] ? now.getFullYear() : +p[ 0 ];
			var mo = p[ 1 ] === undefined ? 1 : ( 'current' === p[ 1 ] ? now.getMonth() + 1 : +p[ 1 ] );
			var da = p[ 2 ] === undefined ? 1 : ( 'current' === p[ 2 ] ? now.getDate() : +p[ 2 ] );
			return new Date( y, mo - 1, da );
		}
		d = fromIso( raw ) || new Date( raw );
		return isNaN( d ) ? null : new Date( d.getFullYear(), d.getMonth(), d.getDate() );
	}

	function firstDay() {
		var n = parseInt( cfg.weekStart, 10 );
		return isNaN( n ) ? 1 : n;
	}

	function change( input ) {
		input.dispatchEvent( new Event( 'change', { bubbles: true } ) );
	}

	/* ---------------- van-tot ---------------- */

	function initRange( el ) {
		var box = el.querySelector( '.m7sf-date-range' );
		if ( ! box || box.getAttribute( 'data-m7sf-dates' ) || ! $.fn.datepicker ) { return; }
		box.setAttribute( 'data-m7sf-dates', '1' );
		var hidden = box.querySelector( '.m7sf-date-range__input' );
		var from = box.querySelector( '.m7sf-date-range__from' );
		var to = box.querySelector( '.m7sf-date-range__to' );
		var fmt = hidden.getAttribute( 'data-date-format' ) || 'mm/dd/yy';
		var min = limit( hidden.getAttribute( 'data-mindate' ) );
		var max = limit( hidden.getAttribute( 'data-maxdate' ) );
		var widget = el.closest( '.elementor-element[data-id]' );
		var cls = 'm7sf-datepicker-' + ( widget ? widget.getAttribute( 'data-id' ) : 'x' );
		var opts = {
			dateFormat: fmt,
			firstDay: firstDay(),
			minDate: min,
			maxDate: max,
			closeText: i18n.closeText || 'Done',
			prevText: i18n.prevText || 'Prev',
			nextText: i18n.nextText || 'Next',
			currentText: i18n.currentText || 'Today',
			monthNames: i18n.monthNames,
			monthNamesShort: i18n.monthNamesShort,
			dayNames: i18n.dayNames,
			dayNamesShort: i18n.dayNamesShort,
			dayNamesMin: i18n.dayNamesMin,
			weekHeader: i18n.weekHeader || 'Wk',
			beforeShow: function ( input, inst ) { inst.dpDiv.addClass( cls ); },
		};
		$( from ).datepicker( $.extend( {}, opts, { onSelect: function () { syncRange( el, from ); } } ) );
		$( to ).datepicker( $.extend( {}, opts, { onSelect: function () { syncRange( el, to ); } } ) );
		$( from ).add( to ).on( 'change', function () { syncRange( el, this ); } );
		writeRange( el, hidden.value );
	}

	function parse( input, fmt ) {
		if ( ! input.value ) { return null; }
		try { return $.datepicker.parseDate( fmt, input.value ); } catch ( e ) { return null; }
	}

	function syncRange( el, source ) {
		var box = el.querySelector( '.m7sf-date-range' );
		if ( ! box ) { return; }
		var hidden = box.querySelector( '.m7sf-date-range__input' );
		var from = box.querySelector( '.m7sf-date-range__from' );
		var to = box.querySelector( '.m7sf-date-range__to' );
		var fmt = hidden.getAttribute( 'data-date-format' ) || 'mm/dd/yy';
		var a = parse( from, fmt );
		var b = parse( to, fmt );
		if ( $.fn.datepicker && source ) {
			if ( source === from ) { $( to ).datepicker( 'option', 'minDate', a || limit( hidden.getAttribute( 'data-mindate' ) ) ); }
			if ( source === to ) { $( from ).datepicker( 'option', 'maxDate', b || limit( hidden.getAttribute( 'data-maxdate' ) ) ); }
		}
		hidden.value = a || b ? ( a ? iso( a ) : '' ) + '_' + ( b ? iso( b ) : '' ) : '';
	}

	function writeRange( el, value ) {
		var box = el.querySelector( '.m7sf-date-range' );
		if ( ! box ) { return; }
		var hidden = box.querySelector( '.m7sf-date-range__input' );
		var fmt = hidden.getAttribute( 'data-date-format' ) || 'mm/dd/yy';
		var parts = String( value || '' ).split( '_' );
		hidden.value = value || '';
		box.querySelector( '.m7sf-date-range__from' ).value = format( fmt, fromIso( parts[ 0 ] ) );
		box.querySelector( '.m7sf-date-range__to' ).value = format( fmt, fromIso( parts[ 1 ] ) );
	}

	/* ---------------- periode ---------------- */

	function periodFormat( input ) {
		var raw = input.getAttribute( 'data-format' ) || '';
		if ( raw && '{' === raw.charAt( 0 ) ) {
			try { return JSON.parse( raw ); } catch ( e ) {}
		}
		return raw;
	}

	function periodRange( type, d, first, min, max ) {
		var start = d, end = d;
		if ( 'week' === type ) {
			var diff = d.getDay() - first;
			if ( diff < 0 ) { diff += 7; }
			start = addDays( d, -diff );
			end = addDays( start, 6 );
		} else if ( 'month' === type ) {
			start = new Date( d.getFullYear(), d.getMonth(), 1 );
			end = new Date( d.getFullYear(), d.getMonth() + 1, 0 );
		} else if ( 'year' === type ) {
			start = new Date( d.getFullYear(), 0, 1 );
			end = new Date( d.getFullYear(), 11, 31 );
		}
		if ( 'day' !== type ) {
			if ( min && start < min ) { start = min; }
			if ( max && end > max ) { end = max; }
		}
		return [ start, end ];
	}

	function initPeriod( el ) {
		var box = el.querySelector( '.m7sf-date-period' );
		if ( ! box || box.getAttribute( 'data-m7sf-dates' ) || ! $.fn.m7AirDatepicker ) { return; }
		box.setAttribute( 'data-m7sf-dates', '1' );
		var input = box.querySelector( '.m7sf-date-period__datepicker-input' );
		var button = box.querySelector( '.m7sf-date-period__datepicker-button' );
		var type = box.getAttribute( 'data-period-type' ) || 'day';
		var min = limit( input.getAttribute( 'data-mindate' ) );
		var max = limit( input.getAttribute( 'data-maxdate' ) );
		var widget = el.closest( '.elementor-element[data-id]' );
		var id = widget ? widget.getAttribute( 'data-id' ) : 'x';
		var picker;
		box._m7sf = { placeholder: button.innerHTML, type: type, min: min, max: max, length: 0 };
		if ( ! $.fn.m7AirDatepicker.language.m7sf ) {
			$.fn.m7AirDatepicker.language.m7sf = {
				days: i18n.dayNames || [ 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday' ],
				daysShort: i18n.dayNamesShort || [ 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat' ],
				daysMin: i18n.dayNamesMin || [ 'Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa' ],
				months: i18n.monthNames || [ 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December' ],
				monthsShort: i18n.monthNamesShort || [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ],
				today: i18n.currentText || 'Today',
				clear: i18n.closeText || 'Done',
				dateFormat: 'yyyy/m/d',
				timeFormat: 'hh:ii',
				firstDay: firstDay(),
			};
		}
		input.type = 'text';
		var view = 'month' === type ? 'months' : ( 'year' === type ? 'years' : 'days' );
		$( input ).m7AirDatepicker( {
			language: 'm7sf',
			autoClose: true,
			position: 'bottom left',
			offset: 0,
			view: view,
			minView: view,
			range: 'range' === type,
			firstDay: firstDay(),
			minDate: min || '',
			maxDate: max || '',
			onShow: function ( inst ) {
				inst.$datepicker.addClass( 'm7sf-date-period-' + id + ' m7sf-date-period-' + type );
				box.classList.add( 'm7sf-date-period-datepicker-opened' );
			},
			onHide: function ( inst ) {
				inst.$datepicker.removeClass( 'm7sf-date-period-' + id + ' m7sf-date-period-' + type );
				box.classList.remove( 'm7sf-date-period-datepicker-opened' );
			},
			onSelect: function ( fd, date ) {
				if ( box._m7sfSilent ) { return; }
				var value = '';
				if ( 'range' === type ) {
					if ( ! date || date.length < 2 ) { return; }
					var s = date[ 0 ], e = date[ 1 ];
					if ( min && s < min ) { s = min; }
					if ( max && e > max ) { e = max; }
					box._m7sf.length = Math.round( ( e - s ) / 86400000 );
					value = iso( s ) + '_' + iso( e );
				} else if ( date ) {
					var r = periodRange( type, date, firstDay(), min, max );
					value = iso( r[ 0 ] ) + '_' + iso( r[ 1 ] );
				}
				if ( value !== input.getAttribute( 'data-value' ) ) {
					input.setAttribute( 'data-value', value );
					showPeriod( box, value );
					change( input );
				}
			},
		} );
		picker = $( input ).data( 'm7AirDatepicker' );
		box._m7sf.picker = picker;
		button.addEventListener( 'click', function () { if ( picker ) { picker.show(); } } );
		box.querySelector( '.m7sf-date-period__prev' ).addEventListener( 'click', function () { step( box, -1 ); } );
		box.querySelector( '.m7sf-date-period__next' ).addEventListener( 'click', function () { step( box, 1 ); } );
		var initial = input.value;
		input.setAttribute( 'data-value', initial );
		showPeriod( box, initial );
	}

	function showPeriod( box, value ) {
		var input = box.querySelector( '.m7sf-date-period__datepicker-input' );
		var button = box.querySelector( '.m7sf-date-period__datepicker-button' );
		var parts = String( value || '' ).split( '_' );
		var start = fromIso( parts[ 0 ] );
		var end = fromIso( parts[ 1 ] );
		input.value = value || '';
		if ( ! start ) {
			button.innerHTML = box._m7sf.placeholder;
			box.classList.remove( 'm7sf-date-period-is-set' );
			return;
		}
		var f = periodFormat( input );
		var html;
		if ( 'object' === typeof f && f ) {
			html = '<div class="m7sf-date-period-start">' + format( f.start || 'mm/dd/yy', start ) + '</div>';
			if ( end && 'day' !== box._m7sf.type ) {
				html += '<div class="m7sf-date-period-separator">' + ( f.separator ? ' ' + f.separator + ' ' : ' - ' ) + '</div><div class="m7sf-date-period-end">' + format( f.end || 'mm/dd/yy', end ) + '</div>';
			}
		} else {
			html = '<div class="m7sf-date-period-start">' + format( f || 'mm/dd/yy', start ) + '</div>';
		}
		button.innerHTML = html;
		box.classList.add( 'm7sf-date-period-is-set' );
	}

	function step( box, dir ) {
		var input = box.querySelector( '.m7sf-date-period__datepicker-input' );
		var parts = String( input.value || '' ).split( '_' );
		var start = fromIso( parts[ 0 ] );
		var end = fromIso( parts[ 1 ] ) || start;
		if ( ! start ) { return; }
		var t = box._m7sf.type, min = box._m7sf.min, max = box._m7sf.max, value;
		if ( dir < 0 ) {
			if ( min && start <= min ) { return; }
			var p = addDays( start, -1 );
			if ( 'range' === t ) {
				var ps = addDays( start, -( box._m7sf.length || ( Math.round( ( end - start ) / 86400000 ) ) ) - 1 );
				if ( min && ps < min ) { ps = min; }
				value = iso( ps ) + '_' + iso( p );
			} else {
				var r = periodRange( t, p, firstDay(), min, max );
				value = iso( r[ 0 ] ) + '_' + iso( r[ 1 ] );
			}
		} else {
			if ( max && end >= max ) { return; }
			var n = addDays( end, 1 );
			if ( 'range' === t ) {
				var ne = addDays( n, box._m7sf.length || Math.round( ( end - start ) / 86400000 ) );
				if ( max && ne > max ) { ne = max; }
				value = iso( n ) + '_' + iso( ne );
			} else {
				var r2 = periodRange( t, n, firstDay(), min, max );
				value = iso( r2[ 0 ] ) + '_' + iso( r2[ 1 ] );
			}
		}
		input.setAttribute( 'data-value', value );
		showPeriod( box, value );
		if ( box._m7sf.picker ) {
			box._m7sfSilent = true;
			box._m7sf.picker.selectDate( fromIso( value.split( '_' )[ 0 ] ) );
			box._m7sfSilent = false;
		}
		change( input );
	}

	window.M7SFDates = {
		init: function ( el ) {
			if ( el.querySelector( '.m7sf-date-range' ) ) { initRange( el ); }
			if ( el.querySelector( '.m7sf-date-period' ) ) { initPeriod( el ); }
		},
		sync: function ( el ) { syncRange( el, null ); },
		setRange: function ( el, value ) { writeRange( el, value ); },
		setPeriod: function ( el, value ) {
			var box = el.querySelector( '.m7sf-date-period' );
			if ( ! box || ! box._m7sf ) { return; }
			box.querySelector( '.m7sf-date-period__datepicker-input' ).setAttribute( 'data-value', value );
			showPeriod( box, value );
			if ( box._m7sf.picker ) {
				box._m7sfSilent = true;
				if ( value ) { box._m7sf.picker.selectDate( fromIso( value.split( '_' )[ 0 ] ) ); } else { box._m7sf.picker.clear(); }
				box._m7sfSilent = false;
			}
		},
		format: format,
	};
}( window.jQuery ) );
