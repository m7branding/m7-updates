/**
 * M7 Smart Filters – frontend.
 *
 * Werking: filters met dezelfde data-m7sf-for (query-ID) vormen samen één filterstaat.
 * Bij toepassen bouwen we de URL (mfq + mf_* parameters). Bij AJAX halen we die URL op,
 * en vervangen we in de pagina alleen het resultaatblok ([data-m7sf-query="<id>"]) en de
 * widgets die van de staat afhangen (actieve filters, wis-knop).
 */
( function () {
	'use strict';

	var config = window.m7sfConfig || {};
	var i18n = config.i18n || {};
	var busy = {};
	var controllers = {};

	function qsa( root, sel ) {
		return Array.prototype.slice.call( ( root || document ).querySelectorAll( sel ) );
	}

	function cssEscape( v ) {
		return window.CSS && CSS.escape ? CSS.escape( v ) : String( v ).replace( /["\\]/g, '\\$&' );
	}

	function isEditor() {
		return document.body.classList.contains( 'elementor-editor-active' ) || !! ( window.elementorFrontend && window.elementorFrontend.isEditMode && window.elementorFrontend.isEditMode() );
	}

	/* ---------------- waarden lezen en zetten per filtertype ---------------- */

	function choiceInputs( el ) {
		return qsa( el, 'input[type="checkbox"], input[type="radio"]' );
	}

	function readValue( el ) {
		var type = el.getAttribute( 'data-m7sf-type' );
		switch ( type ) {
			case 'checkboxes':
			case 'check_range':
			case 'color_image':
			case 'radio':
			case 'alphabet':
				return choiceInputs( el ).filter( function ( i ) { return i.checked && i.value; } ).map( function ( i ) { return i.value; } ).join( ',' );
			case 'rating':
				var star = el.querySelector( '.m7sf-rating-star__input.is-checked' );
				return star ? star.value : '';
			case 'select':
			case 'sorting':
				var s = el.querySelector( 'select' );
				if ( ! s ) { return ''; }
				return qsa( s, 'option' ).filter( function ( o ) { return o.selected && o.value; } ).map( function ( o ) { return o.value; } ).join( ',' );
			case 'range':
				var box = el.querySelector( '.m7sf-range' );
				if ( ! box ) { return ''; }
				var min = parseFloat( box.getAttribute( 'data-min' ) );
				var max = parseFloat( box.getAttribute( 'data-max' ) );
				var from = parseFloat( box.querySelector( '.m7sf-range__slider__input--min' ).value );
				var to = parseFloat( box.querySelector( '.m7sf-range__slider__input--max' ).value );
				if ( isNaN( from ) ) { from = min; }
				if ( isNaN( to ) ) { to = max; }
				if ( from <= min && to >= max ) { return ''; }
				return num( from ) + '_' + num( to );
			case 'search':
				var input = el.querySelector( '.m7sf-search-filter__input' );
				var v = input ? input.value.trim() : '';
				var minLetters = parseInt( el.getAttribute( 'data-m7sf-typing' ) || '0', 10 );
				return minLetters && v.length < minLetters ? '' : v;
			case 'date_range':
				var hidden = el.querySelector( '.m7sf-date-range__input' );
				return hidden ? hidden.value : '';
			case 'date_period':
				var pi = el.querySelector( '.m7sf-date-period__datepicker-input' );
				return pi ? pi.value : '';
			case 'hidden':
				return el.hasAttribute( 'data-m7sf-off' ) ? '' : ( el.getAttribute( 'data-m7sf-value' ) || '' );
			case 'hierarchy':
				var deepest = '';
				qsa( el, 'select.m7sf-select__control' ).forEach( function ( sel ) { if ( sel.value ) { deepest = sel.value; } } );
				return deepest;
		}
		return '';
	}

	function hierarchyTree( el ) {
		if ( ! el._m7sfTree ) {
			try { el._m7sfTree = JSON.parse( el.getAttribute( 'data-m7sf-tree' ) || '{}' ); } catch ( e ) { el._m7sfTree = {}; }
		}
		return el._m7sfTree;
	}

	function fillLevel( sel, tree, parent ) {
		var first = sel.options[ 0 ];
		sel.innerHTML = '';
		sel.appendChild( first );
		if ( ! parent ) { return; }
		( tree[ parent ] || [] ).forEach( function ( k ) {
			var o = document.createElement( 'option' );
			o.value = k[ 0 ];
			o.textContent = k[ 1 ];
			sel.appendChild( o );
		} );
	}

	/* Keuzelijst per niveau: diepere niveaus opnieuw vullen na een keuze. */
	function hierarchyChanged( el, sel ) {
		var selects = qsa( el, 'select.m7sf-select__control' );
		var tree = hierarchyTree( el );
		var idx = selects.indexOf( sel );
		for ( var i = idx + 1; i < selects.length; i++ ) {
			fillLevel( selects[ i ], tree, i === idx + 1 ? sel.value : '' );
		}
	}

	function num( v ) {
		return String( Math.round( v * 10000 ) / 10000 );
	}

	function writeValue( el, value ) {
		var type = el.getAttribute( 'data-m7sf-type' );
		var values = value ? String( value ).split( ',' ) : [];
		switch ( type ) {
			case 'checkboxes':
			case 'check_range':
			case 'color_image':
			case 'radio':
			case 'alphabet':
				choiceInputs( el ).forEach( function ( i ) {
					i.checked = i.value === '' ? ! values.length : values.indexOf( i.value ) !== -1;
				} );
				refreshDropdown( el );
				break;
			case 'rating':
				qsa( el, '.m7sf-rating-star__input' ).forEach( function ( i ) {
					var on = values.indexOf( i.value ) !== -1;
					i.checked = on;
					i.classList.toggle( 'is-checked', on );
				} );
				break;
			case 'select':
			case 'sorting':
				qsa( el, 'select option' ).forEach( function ( o ) {
					o.selected = o.value === '' ? ! values.length : values.indexOf( o.value ) !== -1;
				} );
				break;
			case 'range':
				var box = el.querySelector( '.m7sf-range' );
				if ( ! box ) { break; }
				var parts = value ? String( value ).split( '_' ) : [ '', '' ];
				box.querySelector( '.m7sf-range__slider__input--min' ).value = parts[ 0 ] !== '' ? parts[ 0 ] : box.getAttribute( 'data-min' );
				box.querySelector( '.m7sf-range__slider__input--max' ).value = parts[ 1 ] !== '' && parts[ 1 ] !== undefined ? parts[ 1 ] : box.getAttribute( 'data-max' );
				updateRange( box, null );
				break;
			case 'search':
				var input = el.querySelector( '.m7sf-search-filter__input' );
				if ( input ) {
					input.value = value || '';
					input.classList.toggle( 'm7sf-input-not-empty', !! value );
				}
				break;
			case 'date_range':
				if ( window.M7SFDates ) { window.M7SFDates.setRange( el, value || '' ); }
				break;
			case 'date_period':
				if ( window.M7SFDates ) { window.M7SFDates.setPeriod( el, value || '' ); }
				break;
			case 'hidden':
				if ( value ) { el.removeAttribute( 'data-m7sf-off' ); } else { el.setAttribute( 'data-m7sf-off', '1' ); }
				break;
			case 'hierarchy':
				var tree = hierarchyTree( el );
				var up = {};
				Object.keys( tree ).forEach( function ( p ) { tree[ p ].forEach( function ( k ) { up[ k[ 0 ] ] = p; } ); } );
				var path = [];
				var cur = value || '';
				while ( cur && up[ cur ] !== undefined && path.length < 20 ) { path.unshift( cur ); cur = up[ cur ]; }
				var selects = qsa( el, 'select.m7sf-select__control' );
				selects.forEach( function ( sel, i ) {
					if ( i > 0 ) { fillLevel( sel, tree, path[ i - 1 ] || '' ); }
					sel.value = path[ i ] || '';
				} );
				break;
		}
	}

	/* Verborgen filters: één keer toepassen als de waarde nog niet in het adres staat (zoals JetSmartFilters). */
	function applyHiddenOnce() {
		var done = {};
		qsa( document, '.m7sf-filter[data-m7sf-type="hidden"][data-m7sf-value]' ).forEach( function ( el ) {
			var qid = el.getAttribute( 'data-m7sf-for' );
			var params = paramsFromUrl( qid, window.location.href );
			if ( params[ el.getAttribute( 'data-m7sf-param' ) ] || done[ qid ] ) { return; }
			done[ qid ] = true;
			apply( qid, { source: el } );
		} );
	}

	/* ---------------- schuifje (bereik) ---------------- */

	function rangeFormat( box ) {
		try { return JSON.parse( box.getAttribute( 'data-format' ) || '{}' ); } catch ( e ) { return {}; }
	}

	function formatNumber( value, f ) {
		var decimals = parseInt( f.decimal_num || 0, 10 );
		var parts = Number( value ).toFixed( decimals ).split( '.' );
		var thousands = String( f.thousands_sep || '' ).replace( /&nbsp;/g, ' ' );
		if ( thousands ) { parts[ 0 ] = parts[ 0 ].replace( /\B(?=(\d{3})+(?!\d))/g, thousands ); }
		return parts.join( f.decimal_sep !== undefined ? f.decimal_sep : '.' );
	}

	function updateRange( box, source ) {
		var minI = box.querySelector( '.m7sf-range__slider__input--min' );
		var maxI = box.querySelector( '.m7sf-range__slider__input--max' );
		var min = parseFloat( box.getAttribute( 'data-min' ) );
		var max = parseFloat( box.getAttribute( 'data-max' ) );
		var step = parseFloat( box.getAttribute( 'data-step' ) ) || 1;
		var a = parseFloat( minI.value );
		var b = parseFloat( maxI.value );
		if ( source === minI && a > b - step ) { a = Math.max( min, b - step ); minI.value = a; }
		if ( source === maxI && b < a + step ) { b = Math.min( max, a + step ); maxI.value = b; }
		var span = max - min;
		var track = box.querySelector( '.m7sf-range__slider__track__range' );
		if ( track ) {
			track.style.setProperty( '--low', ( span > 0 ? ( a - min ) / span * 100 : 0 ) + '%' );
			track.style.setProperty( '--high', ( span > 0 ? ( b - min ) / span * 100 : 100 ) + '%' );
		}
		var f = rangeFormat( box );
		var vmin = box.querySelector( '.m7sf-range__values-min' );
		var vmax = box.querySelector( '.m7sf-range__values-max' );
		if ( vmin ) { vmin.textContent = formatNumber( a, f ); }
		if ( vmax ) { vmax.textContent = formatNumber( b, f ); }
		var sep = box.hasAttribute( 'data-inputs-separators' );
		var imin = box.querySelector( '.m7sf-range__inputs__min' );
		var imax = box.querySelector( '.m7sf-range__inputs__max' );
		if ( imin && document.activeElement !== imin ) { imin.value = sep ? formatNumber( a, f ) : num( a ); }
		if ( imax && document.activeElement !== imax ) { imax.value = sep ? formatNumber( b, f ) : num( b ); }
	}

	function rangeFromInput( box, input ) {
		var f = rangeFormat( box );
		var raw = String( input.value );
		if ( box.hasAttribute( 'data-inputs-separators' ) ) {
			if ( f.thousands_sep ) { raw = raw.split( String( f.thousands_sep ).replace( /&nbsp;/g, ' ' ) ).join( '' ); }
			if ( f.decimal_sep && f.decimal_sep !== '.' ) { raw = raw.split( f.decimal_sep ).join( '.' ); }
		}
		var min = parseFloat( box.getAttribute( 'data-min' ) );
		var max = parseFloat( box.getAttribute( 'data-max' ) );
		var v = parseFloat( raw );
		var isMin = input.classList.contains( 'm7sf-range__inputs__min' );
		if ( isNaN( v ) ) { v = isMin ? min : max; }
		v = Math.min( max, Math.max( min, v ) );
		var slider = box.querySelector( isMin ? '.m7sf-range__slider__input--min' : '.m7sf-range__slider__input--max' );
		slider.value = v;
		updateRange( box, slider );
	}

	/* Welke duim ligt het dichtst bij de muis: die komt bovenop (zoals JetSmartFilters). */
	function rangePointer( e ) {
		var box = e.target.closest && e.target.closest( '.m7sf-range' );
		if ( ! box ) { return; }
		var minI = box.querySelector( '.m7sf-range__slider__input--min' );
		var maxI = box.querySelector( '.m7sf-range__slider__input--max' );
		var rect = minI.getBoundingClientRect();
		var x = ( e.touches ? e.touches[ 0 ].clientX : e.clientX );
		if ( ! rect.width ) { return; }
		var min = parseFloat( box.getAttribute( 'data-min' ) );
		var max = parseFloat( box.getAttribute( 'data-max' ) );
		var ratio = ( x - rect.left ) / rect.width;
		if ( document.body.classList.contains( 'rtl' ) ) { ratio = 1 - ratio; }
		var value = min + ratio * ( max - min );
		var middle = ( parseFloat( minI.value ) + parseFloat( maxI.value ) ) / 2;
		minI.style.zIndex = value <= middle ? 21 : 20;
		maxI.style.zIndex = value <= middle ? 20 : 21;
	}

	/* ---------------- uitklaplijst ---------------- */

	function refreshDropdown( el ) {
		qsa( el, '.m7sf-filter-items-dropdown' ).forEach( function ( dd ) {
			var label = dd.querySelector( '.m7sf-filter-items-dropdown__label' );
			if ( ! label ) { return; }
			var checked = choiceInputs( dd ).filter( function ( i ) { return i.checked && i.value; } );
			if ( ! checked.length ) {
				label.textContent = label.getAttribute( 'data-placeholder' ) || '';
				return;
			}
			var n = dd.hasAttribute( 'data-dropdown-n-selected' ) ? parseInt( dd.getAttribute( 'data-dropdown-n-selected' ), 10 ) : -1;
			var shown = n >= 0 ? checked.slice( 0, n ) : checked;
			var box = document.createElement( 'div' );
			box.className = 'm7sf-filter-items-dropdown__active';
			shown.forEach( function ( input ) {
				var item = document.createElement( 'div' );
				item.className = 'm7sf-filter-items-dropdown__active__item';
				item.setAttribute( 'data-value', input.value );
				item.textContent = input.getAttribute( 'data-label' ) || input.value;
				var x = document.createElement( 'span' );
				x.className = 'm7sf-filter-items-dropdown__active__item__remove';
				x.textContent = '×';
				item.appendChild( x );
				box.appendChild( item );
			} );
			if ( n >= 0 && checked.length > n ) {
				var more = document.createElement( 'div' );
				more.className = 'm7sf-filter-items-dropdown__n-selected';
				more.textContent = ( dd.getAttribute( 'data-dropdown-n-selected-text' ) || 'and {number} others' ).replace( '{number}', checked.length - n );
				box.appendChild( more );
			}
			label.innerHTML = '';
			label.appendChild( box );
		} );
	}

	/* ---------------- meer/minder en zoeken in opties ---------------- */

	function rowsOf( el ) {
		return qsa( el, '.m7sf-filter-row' );
	}

	function applyVisibility( el ) {
		var term = '';
		var search = el.querySelector( '.m7sf-filter-items-search__input' );
		if ( search ) { term = search.value.trim().toLowerCase(); }
		var visible = [];
		rowsOf( el ).forEach( function ( row ) {
			if ( row.classList.contains( 'm7sf-filter-row-hide' ) ) { return; }
			var input = row.querySelector( 'input' );
			var label = ( input && input.getAttribute( 'data-label' ) || row.textContent ).toLowerCase();
			var match = term === '' || label.indexOf( term ) !== -1;
			row.style.display = match ? '' : 'none';
			if ( match ) { visible.push( row ); }
		} );
		var holder = el.querySelector( '.m7sf-filter-items-moreless' );
		if ( holder ) {
			var count = parseInt( holder.getAttribute( 'data-less-items-count' ), 10 ) || 0;
			var toggle = holder.querySelector( '.m7sf-filter-items-moreless__toggle' );
			var open = toggle && toggle.classList.contains( 'm7sf-less-btn' );
			if ( count && visible.length > count ) {
				holder.style.display = '';
				if ( ! open ) {
					visible.slice( count ).forEach( function ( row ) { row.style.display = 'none'; } );
				}
			} else {
				holder.style.display = 'none';
			}
		}
	}

	/* Actieve filters/tags in de volgorde van de filters op de pagina (zoals JetSmartFilters). */
	function orderActive() {
		var params = qsa( document, '.m7sf-filter[data-m7sf-param]' ).map( function ( f ) { return f.getAttribute( 'data-m7sf-param' ); } );
		qsa( document, '.m7sf-active-filters__list, .m7sf-active-tags__list' ).forEach( function ( list ) {
			var items = qsa( list, ':scope > [data-m7sf-remove-param]' );
			var rank = function ( el ) {
				var i = params.indexOf( el.getAttribute( 'data-m7sf-remove-param' ) );
				return i === -1 ? params.length : i;
			};
			var sorted = items.map( function ( el, i ) { return { el: el, r: rank( el ), i: i }; } ).sort( function ( a, b ) { return a.r - b.r || a.i - b.i; } );
			if ( sorted.some( function ( x, i ) { return x.el !== items[ i ]; } ) ) {
				sorted.forEach( function ( x ) { list.appendChild( x.el ); } );
			}
		} );
	}

	function setupLists( root ) {
		orderActive();
		qsa( root, '.m7sf-filter' ).forEach( function ( el ) {
			if ( el.getAttribute( 'data-m7sf-ready' ) ) { return; }
			el.setAttribute( 'data-m7sf-ready', '1' );
			var toggle = el.querySelector( '.m7sf-filter-items-moreless__toggle' );
			if ( toggle ) { toggle.classList.add( 'm7sf-more-btn' ); }
			if ( el.querySelector( '.m7sf-filter-items-moreless, .m7sf-filter-items-search' ) ) { applyVisibility( el ); }
			refreshDropdown( el );
			qsa( el, '.m7sf-range' ).forEach( function ( box ) { updateRange( box, null ); } );
			if ( window.M7SFDates ) { window.M7SFDates.init( el ); }
		} );
		setupPagination( root );
		updateApplyStates();
	}

	/* ---------------- in- en uitklappen van subopties ---------------- */

	function slide( el, open ) {
		if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
			el.style.display = open ? '' : 'none';
			return;
		}
		el.style.overflow = 'hidden';
		if ( open ) {
			el.style.display = '';
			var h = el.scrollHeight;
			el.style.height = '0px';
			el.offsetHeight; // eslint-disable-line no-unused-expressions
			el.style.transition = 'height 300ms';
			el.style.height = h + 'px';
		} else {
			el.style.height = el.scrollHeight + 'px';
			el.offsetHeight; // eslint-disable-line no-unused-expressions
			el.style.transition = 'height 300ms';
			el.style.height = '0px';
		}
		setTimeout( function () {
			el.style.transition = '';
			el.style.height = '';
			el.style.overflow = '';
			if ( ! open ) { el.style.display = 'none'; }
		}, 310 );
	}

	function toggleBranch( row ) {
		var kids = row.nextElementSibling;
		if ( ! kids || ! kids.classList.contains( 'm7sf-list-tree__children' ) ) { return; }
		var open = row.classList.contains( 'm7sf-list-toggle-collapsed' );
		row.classList.toggle( 'm7sf-list-toggle-collapsed', ! open );
		kids.classList.toggle( 'm7sf-list-content-collapsed', ! open );
		var icon = row.querySelector( '.m7sf-collapse-icon' );
		if ( icon ) { icon.setAttribute( 'aria-expanded', open ? 'true' : 'false' ); }
		slide( kids, open );
	}

	/* ---------------- toepassen-knop: actief als er iets gekozen is ---------------- */

	function updateApplyStates() {
		qsa( document, '[data-active-state]' ).forEach( function ( holder ) {
			var qid = holder.getAttribute( 'data-m7sf-for' );
			var btn = holder.querySelector( '.m7sf-apply-filters__button' );
			if ( ! btn ) { return; }
			var filters = filtersFor( qid ).filter( function ( f ) { return f.getAttribute( 'data-m7sf-param' ) && 'sorting' !== f.getAttribute( 'data-m7sf-type' ); } );
			var withValue = filters.filter( function ( f ) { return !! readValue( f ); } ).length;
			var active = 'all' === holder.getAttribute( 'data-active-state' ) ? filters.length && withValue === filters.length : withValue > 0;
			var hide = 'hide' === holder.getAttribute( 'data-if-inactive' );
			btn.classList.toggle( 'm7sf-hidden', hide && ! active );
			btn.classList.toggle( 'm7sf-disabled', ! hide && ! active );
			btn.disabled = ! hide && ! active;
		} );
	}

	/* ---------------- paginering (opgebouwd uit de gegevens van de lijst) ---------------- */

	function setupPagination( root ) {
		qsa( root, '[data-m7sf-pagination]' ).forEach( function ( el ) {
			var qid = el.getAttribute( 'data-m7sf-for' );
			var props = ( window.m7sfProps || {} )[ qid ];
			var box = containersFor( qid )[ 0 ];
			var holder = box && ( box.hasAttribute( 'data-m7sf-pages' ) ? box : box.querySelector( '[data-m7sf-pages]' ) );
			if ( holder ) {
				try { props = JSON.parse( holder.getAttribute( 'data-m7sf-pages' ) ); } catch ( e ) {}
			}
			if ( el._m7sfExtra && props ) { props.extra = el._m7sfExtra; }
			var c;
			try { c = JSON.parse( el.getAttribute( 'data-m7sf-pagination' ) ); } catch ( e ) { c = {}; }
			if ( el.hasAttribute( 'data-m7sf-sample' ) ) { props = { page: 4, max: 10 }; } // Voorbeeld in de editor.
			el.innerHTML = props ? paginationHtml( c, parseInt( props.page, 10 ) || 1, parseInt( props.max, 10 ) || 0, el._m7sfExtra || [] ) : '';
			el._m7sfProps = props;
		} );
	}

	function paginationHtml( c, current, count, extra ) {
		if ( count < 2 ) { return ''; }
		var tab = config.tabindex ? ' tabindex="0"' : '';
		var item = function ( value, text, cls ) {
			return '<div class="m7sf-filters-pagination__item' + ( cls ? ' ' + cls : '' ) + '" data-value="' + value + '"' + tab + '><div class="m7sf-filters-pagination__link">' + text + '</div></div>';
		};
		var html = '';
		var prevInactive = current <= 1 || extra.indexOf( 1 ) !== -1;
		if ( c.nav_enabled && ! ( prevInactive && c.hide_inactive_nav ) ) {
			html += item( 'prev', c.prev || '', 'prev-next prev' ).replace( '"prev">', prevInactive ? '"prev" disabled="">' : '"prev">' );
		}
		if ( c.items_enabled ) {
			var mid = c.pages_mid_size || 0;
			var end = c.pages_end_size || 0;
			var dots = false;
			for ( var i = 1; i <= count; i++ ) {
				var hidden = mid && ( ( i > end && i < current - mid ) || ( i <= count - end && i > current + mid ) );
				if ( hidden ) {
					if ( ! dots ) { html += '<div class="m7sf-filters-pagination__item"><div class="m7sf-filters-pagination__dots">&hellip;</div></div>'; dots = true; }
					continue;
				}
				dots = false;
				html += item( i, i, i === current || extra.indexOf( i ) !== -1 ? 'm7sf-filters-pagination__current' : '' );
			}
		}
		if ( c.nav_enabled && ! ( current >= count && c.hide_inactive_nav ) ) {
			html += item( 'next', c.next || '', 'prev-next next' ).replace( '"next">', current >= count ? '"next" disabled="">' : '"next">' );
		}
		if ( c.load_more_enabled && current < count ) {
			html += '<div class="m7sf-filters-pagination__load-more"' + tab + '><div class="m7sf-filters-pagination__link">' + ( c.load_more_text || '' ) + '</div></div>';
		}
		return '<div class="m7sf-filters-pagination">' + html + '</div>';
	}

	/* ---------------- staat en URL ---------------- */

	function filtersFor( qid ) {
		return qsa( document, '.m7sf-filter[data-m7sf-for="' + cssEscape( qid ) + '"]' );
	}

	function collect( qid ) {
		var params = {};
		filtersFor( qid ).forEach( function ( el ) {
			var param = el.getAttribute( 'data-m7sf-param' );
			var value = readValue( el );
			if ( ! param || ! value ) { return; }
			if ( params[ param ] && ! /^mf_(s|like_|date|daterange_|sort|rating|letter)/.test( param ) ) {
				var merged = params[ param ].split( ',' ).concat( value.split( ',' ) );
				params[ param ] = merged.filter( function ( v, i ) { return v && merged.indexOf( v ) === i; } ).join( ',' );
			} else {
				params[ param ] = value;
			}
		} );
		return params;
	}

	function stripPaging( url ) {
		url.pathname = url.pathname.replace( /\/page\/\d+\/?$/, '/' );
		[ 'paged', 'page', 'product-page', 'e-page' ].forEach( function ( p ) { url.searchParams.delete( p ); } );
		Array.from( url.searchParams.keys() ).forEach( function ( k ) {
			if ( /^e-page-/.test( k ) || /^query-\d+-page$/.test( k ) ) { url.searchParams.delete( k ); }
		} );
		return url;
	}

	function buildUrl( qid, params, base ) {
		var url = new URL( base || window.location.href );
		Array.from( url.searchParams.keys() ).forEach( function ( k ) {
			if ( 'mfq' === k || 0 === k.indexOf( 'mf_' ) || 'm7sf_ajax' === k ) { url.searchParams.delete( k ); }
		} );
		stripPaging( url );
		var keys = Object.keys( params );
		if ( keys.length ) {
			url.searchParams.set( 'mfq', qid );
			keys.sort().forEach( function ( k ) { url.searchParams.set( k, params[ k ] ); } );
		}
		return url.toString();
	}

	function paramsFromUrl( qid, href ) {
		var url = new URL( href );
		var out = {};
		if ( url.searchParams.get( 'mfq' ) !== qid ) { return out; }
		url.searchParams.forEach( function ( v, k ) {
			if ( 0 === k.indexOf( 'mf_' ) ) { out[ k ] = v; }
		} );
		return out;
	}

	function syncInputs( qid, href ) {
		var params = paramsFromUrl( qid, href );
		filtersFor( qid ).forEach( function ( el ) {
			writeValue( el, params[ el.getAttribute( 'data-m7sf-param' ) ] || '' );
		} );
	}

	/* ---------------- toepassen ---------------- */

	function settingFor( qid, attr ) {
		var el = document.querySelector( '[data-m7sf-for="' + cssEscape( qid ) + '"][' + attr + ']' );
		return el ? el.getAttribute( attr ) : '';
	}

	function containersFor( qid, root ) {
		root = root || document;
		var found = qsa( root, '[data-m7sf-query~="' + cssEscape( qid ) + '"]' );
		if ( ! found.length ) {
			var selector = settingFor( qid, 'data-m7sf-selector' ) || ( 'main' === qid ? config.mainSelector : '' );
			if ( selector ) {
				try { found = qsa( root, selector ); } catch ( e ) { found = []; }
			}
		}
		return found;
	}

	function apply( qid, opts ) {
		opts = opts || {};
		var params = opts.params || collect( qid );
		var redirect = opts.redirect || ( opts.source && opts.source.getAttribute( 'data-m7sf-redirect' ) ) || '';
		var url = buildUrl( qid, params, redirect || null );
		var mode = opts.mode || ( opts.source && opts.source.getAttribute( 'data-m7sf-apply' ) ) || settingFor( qid, 'data-m7sf-apply' ) || 'ajax';
		updateApplyStates();
		qsa( document, '[data-m7sf-pagination]' ).forEach( function ( p ) { if ( p.getAttribute( 'data-m7sf-for' ) === qid ) { p._m7sfExtra = []; } } );

		if ( redirect || 'reload' === mode || ! containersFor( qid ).length ) {
			window.location.href = url;
			return;
		}
		load( qid, url, { push: true, mode: mode, params: params } );
	}

	function load( qid, url, opts ) {
		opts = opts || {};
		if ( controllers[ qid ] ) { controllers[ qid ].abort(); }
		var ctrl = window.AbortController ? new AbortController() : null;
		controllers[ qid ] = ctrl;
		var containers = containersFor( qid );
		setBusy( qid, containers, true );
		var signal = ctrl ? ctrl.signal : undefined;

		var done = function () {
			if ( opts.push ) {
				if ( 'mixed' === opts.mode ) {
					// Gemengd (zoals JetSmartFilters): resultaten via AJAX, adres wel bijwerken.
					window.history.replaceState( window.history.state, '', url );
				} else if ( 'keep' === config.urlMode ) {
					// Zoals JetSmartFilters: in het adres staan alleen filters waarvan het laatste exemplaar op de pagina
					// "herladen" of "gemengd" is; zonder zulke filters blijft het adres schoon. Geen nieuwe stap in de geschiedenis.
					var last = {};
					var keep = {};
					filtersFor( qid ).forEach( function ( el ) { last[ el.getAttribute( 'data-m7sf-param' ) ] = el; } );
					Object.keys( last ).forEach( function ( p ) {
						var m = last[ p ].getAttribute( 'data-m7sf-apply' );
						if ( p && ( 'reload' === m || 'mixed' === m ) && opts.params && opts.params[ p ] ) { keep[ p ] = opts.params[ p ]; }
					} );
					var clean = buildUrl( qid, keep );
					if ( clean !== window.location.href ) { window.history.replaceState( window.history.state, '', clean ); }
				} else {
					window.history.pushState( { m7sf: qid }, '', url );
				}
			}
			setBusy( qid, containersFor( qid ), false );
			announce( i18n.loaded || '' );
			maybeScroll( qid );
			document.dispatchEvent( new CustomEvent( 'm7sf:updated', { detail: { queryId: qid, url: url } } ) );
		};

		// Snel pad: alleen de betrokken Elementor-widgets laten renderen (of uit het geheugen).
		var parts = opts.append ? null : partialTargets( qid );
		if ( parts ) {
			fetchPartial( url, parts, signal ).then( function ( data ) {
				applyPartial( parts, data );
				done();
			} ).catch( function ( err ) {
				if ( err && 'AbortError' === err.name ) { return; }
				fullLoad( qid, url, signal, containersFor( qid ), done );
			} );
			return;
		}
		fullLoad( qid, url, signal, containers, done, opts.append );
	}

	/* ---------- gedeeltelijke respons, geheugen en voorladen ---------- */

	var partialCache = {};
	var CACHE_MS = 5 * 60 * 1000;

	function partialKey( url, parts ) {
		return url + '|' + Object.keys( parts ).sort().join( ',' );
	}

	function fetchPartial( url, parts, signal ) {
		var key = partialKey( url, parts );
		var hit = partialCache[ key ];
		if ( hit && Date.now() - hit.time < CACHE_MS ) {
			return hit.promise;
		}
		var partialUrl = new URL( url );
		partialUrl.searchParams.set( 'm7sf_partial', Object.keys( parts ).join( ',' ) );
		var promise = fetch( partialUrl.toString(), {
			credentials: 'same-origin',
			headers: { 'X-Requested-With': 'M7SmartFilters', Accept: 'application/json' },
			// Voorladen mag niet afgebroken worden door een nieuwe klik: het resultaat blijft bruikbaar.
			signal: hit ? undefined : signal,
		} ).then( function ( res ) {
			return res.ok ? res.json() : { ok: false };
		} ).then( function ( data ) {
			var keys = Object.keys( parts );
			if ( ! data || ! data.ok || ! data.parts || keys.some( function ( k ) { return 'string' !== typeof data.parts[ k ]; } ) ) {
				throw new Error( 'partial' );
			}
			return data;
		} );
		partialCache[ key ] = { time: Date.now(), promise: promise };
		promise.catch( function () { delete partialCache[ key ]; } );
		return promise;
	}

	function applyPartial( parts, data ) {
		Object.keys( parts ).forEach( function ( k ) {
			var tpl = document.createElement( 'template' );
			tpl.innerHTML = data.parts[ k ].trim();
			var next = tpl.content.firstElementChild;
			var el = parts[ k ];
			if ( next && el.parentNode ) {
				el.parentNode.replaceChild( next, el );
				reinit( next );
			}
		} );
	}

	/**
	 * URL's van de standen die één klik verderop liggen (elke optie aan/uit zetten).
	 * Alleen voor kleine filters, om de server niet te belasten.
	 */
	function nextStates( qid ) {
		var urls = [];
		var redirect = null; // Voorladen alleen voor deze pagina.
		filtersFor( qid ).forEach( function ( el ) {
			if ( 'value' !== el.getAttribute( 'data-m7sf-apply-on' ) ) { return; }
			var type = el.getAttribute( 'data-m7sf-type' );
			if ( [ 'checkboxes', 'radio', 'check_range', 'color_image', 'rating', 'alphabet' ].indexOf( type ) === -1 ) { return; }
			var inputs = choiceInputs( el );
			var saved = inputs.map( function ( i ) { return i.checked; } );
			inputs.forEach( function ( input ) {
				if ( ! input.value || input.disabled ) { return; }
				// Klik nabootsen in de DOM, URL uitlezen zoals bij een echte klik, en terugzetten.
				var was = input.checked;
				if ( 'radio' === input.type && ! was ) {
					inputs.forEach( function ( i ) { i.checked = false; } );
				}
				input.checked = ! was;
				urls.push( buildUrl( qid, collect( qid ), redirect ) );
				inputs.forEach( function ( i, n ) { i.checked = saved[ n ]; } );
			} );
		} );
		return urls;
	}

	var prefetching = {};
	function prefetch( qid ) {
		if ( prefetching[ qid ] || isEditor() || window.M7SF_NO_PREFETCH ) { return; }
		var conn = navigator.connection;
		if ( conn && ( conn.saveData || /2g/.test( conn.effectiveType || '' ) ) ) { return; }
		if ( 'ajax' !== ( settingFor( qid, 'data-m7sf-apply' ) || 'ajax' ) ) { return; }
		var parts = partialTargets( qid );
		if ( ! parts ) { return; }
		var urls = nextStates( qid ).filter( function ( u ) {
			var hit = partialCache[ partialKey( u, parts ) ];
			return ! hit || Date.now() - hit.time >= CACHE_MS;
		} );
		if ( ! urls.length || urls.length > 8 ) { return; }
		prefetching[ qid ] = true;
		// Eén voor één, zodat de server niet meerdere zware verzoeken tegelijk krijgt.
		urls.reduce( function ( chain, u ) {
			return chain.then( function () {
				return fetchPartial( u, partialTargets( qid ) || parts ).catch( function () {} );
			} );
		}, Promise.resolve() ).then( function () { prefetching[ qid ] = false; } );
	}

	/**
	 * De stand waarmee de pagina laadt staat al in de DOM: bewaar die, zodat terugklikken direct is.
	 */
	function seedCurrentState() {
		var seen = {};
		qsa( document, '.m7sf-filter[data-m7sf-for]' ).forEach( function ( el ) {
			var qid = el.getAttribute( 'data-m7sf-for' );
			if ( seen[ qid ] ) { return; }
			seen[ qid ] = true;
			var parts = partialTargets( qid );
			if ( ! parts ) { return; }
			var data = { ok: true, parts: {} };
			Object.keys( parts ).forEach( function ( k ) { data.parts[ k ] = parts[ k ].outerHTML; } );
			var url = buildUrl( qid, paramsFromUrl( qid, window.location.href ) );
			partialCache[ partialKey( url, parts ) ] = { time: Date.now(), promise: Promise.resolve( data ) };
		} );
	}

	function onIntent( e ) {
		var el = e.target && e.target.closest ? e.target.closest( '.m7sf-filter[data-m7sf-for]' ) : null;
		if ( el ) {
			prefetch( el.getAttribute( 'data-m7sf-for' ) );
		}
	}

	/**
	 * Elementor-widgets die bij een filterwijziging vervangen moeten worden:
	 * { "<document-ID>:<element-ID>": element }. Null als niet alles via Elementor loopt.
	 */
	function partialTargets( qid ) {
		var els = containersFor( qid ).concat( qsa( document, '[data-m7sf-for="' + cssEscape( qid ) + '"][data-m7sf-refresh]' ) );
		if ( ! els.length ) { return null; }
		var map = {};
		for ( var i = 0; i < els.length; i++ ) {
			var widget = els[ i ].closest( '.elementor-element[data-id]' );
			var doc = widget ? widget.parentElement && widget.parentElement.closest( '[data-elementor-id]' ) : null;
			if ( ! widget || ! doc ) { return null; }
			map[ doc.getAttribute( 'data-elementor-id' ) + ':' + widget.getAttribute( 'data-id' ) ] = widget;
		}
		return Object.keys( map ).length <= 12 ? map : null;
	}

	/* "Meer laden": nieuwe items achter de bestaande lijst zetten (zoals JetSmartFilters). */
	function appendItems( current, fresh ) {
		var listSel = 'ul.products, .elementor-loop-container, .elementor-posts-container, .products, .wp-block-post-template';
		var list = current.querySelector( listSel );
		var next = fresh.querySelector( listSel );
		if ( ! list || ! next ) { return false; }
		Array.prototype.slice.call( next.children ).forEach( function ( item ) { list.appendChild( document.importNode( item, true ) ); } );
		var oldPages = current.hasAttribute( 'data-m7sf-pages' ) ? current : current.querySelector( '[data-m7sf-pages]' );
		var newPages = fresh.hasAttribute( 'data-m7sf-pages' ) ? fresh : fresh.querySelector( '[data-m7sf-pages]' );
		if ( oldPages && newPages ) { oldPages.setAttribute( 'data-m7sf-pages', newPages.getAttribute( 'data-m7sf-pages' ) ); }
		return true;
	}

	function fullLoad( qid, url, signal, containers, done, append ) {
		// Zelfde URL als de echte pagina: dan bevatten pagineringslinks geen hulpparameters
		// en kan een paginacache het antwoord gewoon hergebruiken.
		fetch( url, {
			credentials: 'same-origin',
			headers: { 'X-Requested-With': 'M7SmartFilters' },
			signal: signal,
		} ).then( function ( res ) {
			if ( ! res.ok && 404 !== res.status ) { throw new Error( 'HTTP ' + res.status ); }
			return res.text();
		} ).then( function ( html ) {
			var doc = new DOMParser().parseFromString( html, 'text/html' );
			var fresh = containersFor( qid, doc );
			if ( ! fresh.length ) { throw new Error( 'container' ); }
			containers.forEach( function ( el, i ) {
				var next = fresh[ i ] || fresh[ 0 ];
				if ( append && appendItems( el, next ) ) {
					reinit( el );
					return;
				}
				var imported = document.importNode( next, true );
				el.parentNode.replaceChild( imported, el );
				reinit( imported );
			} );
			refreshDependents( qid, doc );
			done();
		} ).catch( function ( err ) {
			if ( err && 'AbortError' === err.name ) { return; }
			setBusy( qid, containersFor( qid ), false );
			window.location.href = url;
		} );
	}

	function refreshDependents( qid, doc ) {
		[ 'active', 'remove' ].forEach( function ( kind ) {
			var sel = '[data-m7sf-for="' + cssEscape( qid ) + '"][data-m7sf-refresh="' + kind + '"]';
			var current = qsa( document, sel );
			var fresh = qsa( doc, sel );
			current.forEach( function ( el, i ) {
				var next = fresh[ i ] || fresh[ 0 ];
				if ( next ) {
					var imported = document.importNode( next, true );
					el.parentNode.replaceChild( imported, el );
					// Elementor-houder verbergen als er niets actief is (zoals JetSmartFilters met "hide-widget").
					var empty = imported.hasAttribute( 'data-m7sf-empty' ) || !! imported.querySelector( '.m7sf-remove-all-filters.hide' );
					var widget = imported.closest( '.elementor-widget' );
					if ( widget ) { widget.classList.toggle( 'm7sf-hide-widget', empty ); }
				}
			} );
		} );
	}

	function reinit( el ) {
		if ( window.elementorFrontend && window.jQuery && window.elementorFrontend.elementsHandler ) {
			var $ = window.jQuery;
			var nodes = [ el ].concat( qsa( el, '.elementor-element' ) );
			nodes.forEach( function ( node ) {
				if ( node.classList && node.classList.contains( 'elementor-element' ) ) {
					try { window.elementorFrontend.elementsHandler.runReadyTrigger( $( node ) ); } catch ( e ) {}
				}
			} );
		}
		if ( window.jQuery ) {
			window.jQuery( document.body ).trigger( 'post-load' );
		}
	}

	/* Laadweergave zoals JetSmartFilters: bij een Elementor Loop Grid de productlijst zelf, anders de container. */
	function loadingTarget( el ) {
		return el.querySelector( '.elementor-loop-container' ) || el;
	}

	var preloaders = {};
	var preloaderBound = false;

	function positionPreloader( item ) {
		var opts = config.preloader || {};
		var gap = parseInt( opts.gap, 10 ) || 0;
		var r = item.target.getBoundingClientRect();
		var h = item.el.offsetHeight;
		var middle = window.innerHeight / 2 - h / 2;
		if ( middle - r.top - gap > 0 && r.height + r.top - h - middle - gap > 0 ) {
			item.el.style.position = 'fixed';
			item.el.style.top = middle + 'px';
			item.el.style.left = ( r.left + r.width / 2 ) + 'px';
		} else {
			item.el.style.position = 'absolute';
			item.el.style.top = ( r.top >= 0 ? gap : r.height - h - gap ) + 'px';
			item.el.style.left = '50%';
		}
	}

	function positionAllPreloaders() {
		Object.keys( preloaders ).forEach( function ( q ) { preloaders[ q ].forEach( positionPreloader ); } );
	}

	function showPreloader( qid, target ) {
		if ( ! config.preloader || target.querySelector( ':scope > .m7sf-preloader' ) ) { return; }
		var el = document.createElement( 'div' );
		el.className = 'm7sf-preloader';
		el.setAttribute( 'aria-hidden', 'true' );
		el.innerHTML = '<div class="m7sf-preloader-circle-clip-growing"><svg width="0" height="0" viewBox="0 0 50 50"><circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle></svg></div>';
		target.appendChild( el );
		var item = { target: target, el: el };
		( preloaders[ qid ] = preloaders[ qid ] || [] ).push( item );
		if ( config.preloader.fixed ) {
			positionPreloader( item );
			if ( ! preloaderBound ) {
				window.addEventListener( 'scroll', positionAllPreloaders, { passive: true } );
				window.addEventListener( 'resize', positionAllPreloaders );
				preloaderBound = true;
			}
		}
	}

	function hidePreloaders( qid ) {
		( preloaders[ qid ] || [] ).forEach( function ( item ) {
			if ( item.el.parentNode ) { item.el.parentNode.removeChild( item.el ); }
		} );
		delete preloaders[ qid ];
		if ( preloaderBound && ! Object.keys( preloaders ).length ) {
			window.removeEventListener( 'scroll', positionAllPreloaders );
			window.removeEventListener( 'resize', positionAllPreloaders );
			preloaderBound = false;
		}
	}

	function setBusy( qid, containers, on ) {
		busy[ qid ] = on;
		if ( ! on ) { hidePreloaders( qid ); }
		containers.forEach( function ( el ) {
			var target = loadingTarget( el );
			target.classList.toggle( 'm7sf-loading', on );
			if ( target !== el ) { el.classList.remove( 'm7sf-loading' ); }
			if ( on ) { el.setAttribute( 'aria-busy', 'true' ); showPreloader( qid, target ); } else { el.removeAttribute( 'aria-busy' ); }
		} );
		filtersFor( qid ).forEach( function ( el ) { el.classList.toggle( 'm7sf-is-loading', on ); } );
		if ( on ) { announce( i18n.loading || '' ); }
	}

	var live;
	function announce( text ) {
		if ( ! live ) {
			live = document.createElement( 'div' );
			live.className = 'm7sf-visually-hidden';
			live.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( live );
		}
		live.textContent = text;
	}

	function maybeScroll( qid ) {
		if ( ! config.scrollTop ) { return; }
		var el = containersFor( qid )[ 0 ];
		if ( ! el ) { return; }
		var top = el.getBoundingClientRect().top;
		if ( top < 0 || top > window.innerHeight * 0.6 ) {
			window.scrollTo( { top: window.pageYOffset + top - ( config.scrollOffset || 0 ), behavior: 'smooth' } );
		}
	}

	/* ---------------- gebeurtenissen ---------------- */

	var searchTimers = {};

	function qidOf( node ) {
		var holder = node.closest( '[data-m7sf-for]' );
		return holder ? holder.getAttribute( 'data-m7sf-for' ) : '';
	}

	/* Hetzelfde filter meerdere keren op de pagina: waarden gelijk houden (zoals JetSmartFilters). */
	function syncTwins( el ) {
		var id = el.getAttribute( 'data-m7sf-filter' );
		var param = el.getAttribute( 'data-m7sf-param' );
		// Zelfde filter (of, zonder filter-ID zoals sorteren: zelfde parameter) voor dezelfde lijst: zelfde waarde tonen.
		var match = id ? '[data-m7sf-filter="' + cssEscape( id ) + '"]' : ( param ? ':not([data-m7sf-filter])[data-m7sf-param="' + cssEscape( param ) + '"]' : '' );
		if ( ! match ) { return; }
		var value = readValue( el );
		qsa( document, '.m7sf-filter' + match + '[data-m7sf-for="' + cssEscape( el.getAttribute( 'data-m7sf-for' ) ) + '"]' ).forEach( function ( other ) {
			if ( other !== el ) { writeValue( other, value ); }
		} );
	}

	function changed( el ) {
		syncTwins( el );
		updateApplyStates();
		if ( 'value' === el.getAttribute( 'data-m7sf-apply-on' ) ) {
			apply( el.getAttribute( 'data-m7sf-for' ), { source: el } );
		}
	}

	function onChange( e ) {
		var el = e.target.closest( '.m7sf-filter[data-m7sf-param]' );
		if ( ! el || isEditor() ) { return; }
		var type = el.getAttribute( 'data-m7sf-type' );
		var t = e.target;
		if ( 'search' === type || t.classList.contains( 'm7sf-filter-items-search__input' ) ) { return; }
		if ( 'range' === type ) {
			var box = t.closest( '.m7sf-range' );
			if ( t.matches( '.m7sf-range__inputs__min, .m7sf-range__inputs__max' ) ) { rangeFromInput( box, t ); }
			updateRange( box, null );
		}
		if ( 'rating' === type ) { return; } // via klik (is-checked)
		if ( 'hierarchy' === type && t.tagName === 'SELECT' ) { hierarchyChanged( el, t ); }
		if ( 'date_range' === type ) { return; } // via knop of Enter
		refreshDropdown( el );
		changed( el );
	}

	function onInput( e ) {
		var t = e.target;
		var el = t.closest( '.m7sf-filter[data-m7sf-param]' );
		if ( ! el || isEditor() ) { return; }
		if ( t.classList.contains( 'm7sf-range__slider__input' ) ) {
			updateRange( t.closest( '.m7sf-range' ), t );
			return;
		}
		if ( t.matches( '.m7sf-range__inputs__min, .m7sf-range__inputs__max' ) ) { return; }
		if ( t.classList.contains( 'm7sf-filter-items-search__input' ) ) {
			t.classList.toggle( 'm7sf-input-not-empty', '' !== t.value );
			applyVisibility( el );
			return;
		}
		if ( 'search' === el.getAttribute( 'data-m7sf-type' ) ) {
			qsa( document, '.m7sf-filter[data-m7sf-filter="' + cssEscape( el.getAttribute( 'data-m7sf-filter' ) || '' ) + '"]' ).forEach( function ( other ) {
				var oi = other !== el && other.querySelector( '.m7sf-search-filter__input' );
				if ( oi ) {
					oi.value = t.value;
					oi.classList.toggle( 'm7sf-input-not-empty', '' !== t.value );
				}
			} );
			var typing = parseInt( el.getAttribute( 'data-m7sf-typing' ) || '0', 10 );
			if ( ! typing ) { return; }
			var qid = el.getAttribute( 'data-m7sf-for' );
			var len = t.value.trim().length;
			var wasSet = t.classList.contains( 'm7sf-input-not-empty' );
			if ( len >= typing ) {
				t.classList.add( 'm7sf-input-not-empty' );
			} else if ( wasSet ) {
				t.classList.remove( 'm7sf-input-not-empty' );
			} else {
				return;
			}
			clearTimeout( searchTimers[ qid ] );
			searchTimers[ qid ] = setTimeout( function () {
				var wrap = el.querySelector( '.m7sf-search-filter' );
				if ( wrap ) { wrap.classList.add( 'm7sf-filters-single-loading' ); }
				apply( qid, { source: el } );
			}, 350 );
		}
	}

	function onKeydown( e ) {
		var t = e.target;
		if ( ( 'Enter' === e.key || ' ' === e.key ) && t.classList && t.classList.contains( 'm7sf-collapse-icon' ) ) {
			e.preventDefault();
			toggleBranch( t.closest( '.m7sf-filter-row' ) );
			return;
		}
		// Bediening met toetsenbord (instelling "Toetsenbord", zoals JetSmartFilters met tabindex).
		if ( ( 'Enter' === e.key || ' ' === e.key ) && t.hasAttribute && t.hasAttribute( 'tabindex' ) && t.closest( '.m7sf-filter' ) && ! /^(INPUT|SELECT|BUTTON|TEXTAREA)$/.test( t.tagName ) ) {
			e.preventDefault();
			if ( 'LABEL' === t.tagName ) {
				var inp = t.querySelector( 'input' ) || ( t.htmlFor && document.getElementById( t.htmlFor ) );
				if ( t.classList.contains( 'm7sf-rating-star__label' ) ) { t.click(); return; }
				if ( inp ) { inp.click(); }
				return;
			}
			var target = t.classList.contains( 'm7sf-filter-items-moreless' ) ? t.querySelector( '.m7sf-filter-items-moreless__toggle' ) : t;
			if ( target ) { target.click(); }
			return;
		}
		if ( 'Escape' === e.key ) {
			qsa( document, '.m7sf-filter-items-dropdown.m7sf-dropdown-open' ).forEach( function ( dd ) { dd.classList.remove( 'm7sf-dropdown-open', 'm7sf-dropdown-position-top' ); } );
		}
		if ( 'Enter' !== e.key || isEditor() ) { return; }
		var el = t.closest && t.closest( '.m7sf-filter[data-m7sf-param]' );
		if ( ! el ) { return; }
		var type = el.getAttribute( 'data-m7sf-type' );
		if ( 'search' === type && t.classList.contains( 'm7sf-search-filter__input' ) ) {
			e.preventDefault();
			clearTimeout( searchTimers[ el.getAttribute( 'data-m7sf-for' ) ] );
			apply( el.getAttribute( 'data-m7sf-for' ), { source: el } );
		} else if ( 'date_range' === type && t.classList.contains( 'm7sf-date-range__control' ) ) {
			e.preventDefault();
			if ( window.M7SFDates ) { window.M7SFDates.sync( el ); }
			apply( el.getAttribute( 'data-m7sf-for' ), { source: el } );
		} else if ( 'range' === type && t.matches( '.m7sf-range__inputs__min, .m7sf-range__inputs__max' ) ) {
			rangeFromInput( t.closest( '.m7sf-range' ), t );
			changed( el );
		}
	}

	function onClick( e ) {
		if ( isEditor() ) { return; }
		var t = e.target;

		// Boom: klik op de ouderrij (behalve op het label) klapt in of uit.
		var parentRow = t.closest( '.m7sf-list-collapsible .m7sf-list-tree__parent' );
		if ( parentRow && ! t.closest( 'label' ) ) {
			toggleBranch( parentRow );
			return;
		}

		// Keuzerondje uitzetten door nogmaals te klikken (alleen als het filter dat toestaat).
		if ( t.matches && t.matches( '.m7sf-filter input[type="radio"]' ) && ! t.classList.contains( 'm7sf-rating-star__input' ) ) {
			var list = t.closest( '[data-can-deselect]' );
			if ( list && t.getAttribute( 'data-was-checked' ) === '1' && t.value !== '' ) {
				t.checked = false;
				t.removeAttribute( 'data-was-checked' );
				var all = qsa( list, 'input[type="radio"]' ).filter( function ( r ) { return '' === r.value; } )[ 0 ];
				if ( all ) { all.checked = true; }
				t.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				return;
			}
			qsa( t.closest( '.m7sf-filter' ), 'input[type="radio"]' ).forEach( function ( r ) { r.removeAttribute( 'data-was-checked' ); } );
			t.setAttribute( 'data-was-checked', '1' );
		}

		// Beoordeling: klik op een ster zet die aan, nogmaals klikken zet alles uit.
		var starLabel = t.closest( '.m7sf-rating-star__label' );
		if ( starLabel ) {
			e.preventDefault();
			var rf = starLabel.closest( '.m7sf-filter' );
			var star = document.getElementById( starLabel.getAttribute( 'for' ) );
			var on = star && ! star.classList.contains( 'is-checked' );
			qsa( rf, '.m7sf-rating-star__input' ).forEach( function ( i ) { i.classList.remove( 'is-checked' ); i.checked = false; } );
			if ( on ) { star.classList.add( 'is-checked' ); star.checked = true; }
			changed( rf );
			return;
		}

		// Uitklaplijst.
		var ddLabel = t.closest( '.m7sf-filter-items-dropdown__label' );
		var activeChip = t.closest( '.m7sf-filter-items-dropdown__active__item' );
		if ( activeChip ) {
			var df = activeChip.closest( '.m7sf-filter' );
			choiceInputs( df ).forEach( function ( i ) { if ( i.value === activeChip.getAttribute( 'data-value' ) ) { i.checked = false; } } );
			refreshDropdown( df );
			changed( df );
			return;
		}
		if ( ddLabel ) {
			var dd = ddLabel.closest( '.m7sf-filter-items-dropdown' );
			var open = dd.classList.toggle( 'm7sf-dropdown-open' );
			if ( open ) {
				var body = dd.querySelector( '.m7sf-filter-items-dropdown__body' );
				var r = dd.getBoundingClientRect();
				var h = ddLabel.offsetHeight + ( body ? body.offsetHeight : 0 );
				var docH = document.documentElement.scrollHeight;
				dd.classList.toggle( 'm7sf-dropdown-position-top', h < docH && docH < window.pageYOffset + r.top + h );
				var s = dd.querySelector( '.m7sf-filter-items-search__input' );
				if ( s ) { s.focus(); }
			} else {
				dd.classList.remove( 'm7sf-dropdown-position-top' );
			}
			return;
		}
		qsa( document, '.m7sf-filter-items-dropdown.m7sf-dropdown-open' ).forEach( function ( dd ) {
			if ( ! dd.contains( t ) ) { dd.classList.remove( 'm7sf-dropdown-open', 'm7sf-dropdown-position-top' ); }
		} );
		var ddApply = t.closest( '.m7sf-filter-items-dropdown__apply-button' );
		if ( ddApply ) {
			if ( config.dropdownClose ) { ddApply.closest( '.m7sf-filter-items-dropdown' ).classList.remove( 'm7sf-dropdown-open', 'm7sf-dropdown-position-top' ); }
			apply( qidOf( ddApply ), { source: ddApply.closest( '.m7sf-filter' ) } );
			return;
		}

		// Zoeken in opties: wissen.
		var itemsClear = t.closest( '.m7sf-filter-items-search__clear' );
		if ( itemsClear ) {
			var si = itemsClear.parentNode.querySelector( '.m7sf-filter-items-search__input' );
			si.value = '';
			si.classList.remove( 'm7sf-input-not-empty' );
			applyVisibility( itemsClear.closest( '.m7sf-filter' ) );
			return;
		}

		// Meer/minder.
		var more = t.closest( '.m7sf-filter-items-moreless__toggle' );
		if ( more ) {
			var holder = more.closest( '.m7sf-filter-items-moreless' );
			var expand = more.classList.contains( 'm7sf-more-btn' );
			more.classList.toggle( 'm7sf-more-btn', ! expand );
			more.classList.toggle( 'm7sf-less-btn', expand );
			more.textContent = expand ? holder.getAttribute( 'data-less-text' ) : holder.getAttribute( 'data-more-text' );
			applyVisibility( more.closest( '.m7sf-filter' ) );
			return;
		}

		// Zoeken tijdens typen: wissen.
		var searchClear = t.closest( '.m7sf-search-filter__input-clear' );
		if ( searchClear ) {
			var sf = searchClear.closest( '.m7sf-filter' );
			var input = sf.querySelector( '.m7sf-search-filter__input' );
			input.value = '';
			input.classList.remove( 'm7sf-input-not-empty' );
			apply( sf.getAttribute( 'data-m7sf-for' ), { source: sf } );
			return;
		}

		// Paginering.
		var page = t.closest( '[data-m7sf-pagination] .m7sf-filters-pagination__item[data-value], [data-m7sf-pagination] .m7sf-filters-pagination__load-more' );
		if ( page ) {
			goToPage( page );
			return;
		}

		var applyBtn = t.closest( '[data-m7sf-apply-button]' );
		if ( applyBtn ) {
			if ( applyBtn.disabled ) { return; }
			var f = applyBtn.closest( '.m7sf-filter[data-m7sf-param]' );
			if ( f && window.M7SFDates && 'date_range' === f.getAttribute( 'data-m7sf-type' ) ) { window.M7SFDates.sync( f ); }
			var holderEl = applyBtn.closest( '[data-m7sf-for]' );
			if ( holderEl && holderEl.getAttribute( 'data-m7sf-new-window' ) && holderEl.getAttribute( 'data-m7sf-redirect' ) ) {
				var qn = holderEl.getAttribute( 'data-m7sf-for' );
				window.open( buildUrl( qn, collect( qn ), holderEl.getAttribute( 'data-m7sf-redirect' ) ), '_blank' );
				return;
			}
			apply( qidOf( applyBtn ), { redirect: holderEl && holderEl.getAttribute( 'data-m7sf-redirect' ), mode: holderEl && ( holderEl.getAttribute( 'data-m7sf-apply' ) || ( f && f.getAttribute( 'data-m7sf-apply' ) ) ) } );
			return;
		}

		var remove = t.closest( '[data-m7sf-remove-param]' );
		if ( remove ) {
			var qid = qidOf( remove );
			var param = remove.getAttribute( 'data-m7sf-remove-param' );
			var value = remove.getAttribute( 'data-m7sf-remove-value' );
			var params = paramsFromUrl( qid, window.location.href );
			var current = collect( qid );
			Object.keys( current ).forEach( function ( k ) { params[ k ] = current[ k ]; } );
			if ( params[ param ] !== undefined ) {
				var rest = '' === value || /^mf_(s|like_|date|daterange_|range_|rating)/.test( param ) ? [] : params[ param ].split( ',' ).filter( function ( v ) { return v !== value; } );
				if ( rest.length ) { params[ param ] = rest.join( ',' ); } else { delete params[ param ]; }
			}
			filtersFor( qid ).forEach( function ( el ) {
				if ( el.getAttribute( 'data-m7sf-param' ) === param ) { writeValue( el, params[ param ] || '' ); }
			} );
			apply( qid, { params: params, mode: remove.closest( '[data-m7sf-apply]' ) && remove.closest( '[data-m7sf-apply]' ).getAttribute( 'data-m7sf-apply' ) } );
			return;
		}

		var clear = t.closest( '[data-m7sf-clear]' );
		if ( clear ) {
			var cq = qidOf( clear );
			filtersFor( cq ).forEach( function ( el ) { writeValue( el, '' ); } );
			apply( cq, { params: {}, mode: clear.closest( '[data-m7sf-apply]' ) && clear.closest( '[data-m7sf-apply]' ).getAttribute( 'data-m7sf-apply' ) } );
			return;
		}

		// Paginering binnen een gefilterd resultaatblok via AJAX.
		var link = t.closest( 'a[href]' );
		if ( link && ! e.defaultPrevented && 0 === e.button && ! e.metaKey && ! e.ctrlKey && ! e.shiftKey ) {
			var box = link.closest( '[data-m7sf-query]' );
			if ( box && isPaginationLink( link ) ) {
				var pq = box.getAttribute( 'data-m7sf-query' ).split( /\s+/ ).filter( function ( id ) { return filtersFor( id ).length; } )[ 0 ];
				if ( pq && 'ajax' === ( settingFor( pq, 'data-m7sf-apply' ) || 'ajax' ) ) {
					e.preventDefault();
					load( pq, link.href, { push: true } );
				}
			}
		}
	}

	function goToPage( item ) {
		var el = item.closest( '[data-m7sf-pagination]' );
		var qid = el.getAttribute( 'data-m7sf-for' );
		var props = el._m7sfProps;
		if ( ! props || busy[ qid ] || item.hasAttribute( 'disabled' ) ) { return; }
		var current = parseInt( props.page, 10 ) || 1;
		var max = parseInt( props.max, 10 ) || 1;
		var v = item.classList.contains( 'm7sf-filters-pagination__load-more' ) ? 'more' : item.getAttribute( 'data-value' );
		var extra = el._m7sfExtra || [];
		var target = 'prev' === v ? ( extra.length ? extra[ 0 ] : current ) - 1 : ( 'next' === v || 'more' === v ? current + 1 : parseInt( v, 10 ) );
		if ( ! target || target < 1 || target > max || target === current || extra.indexOf( target ) !== -1 ) { return; }
		var mode = el.getAttribute( 'data-m7sf-apply' ) || 'ajax';
		qsa( document, '[data-m7sf-pagination][data-m7sf-for="' + cssEscape( qid ) + '"]' ).forEach( function ( p ) {
			p._m7sfExtra = 'more' === v ? extra.concat( [ current ] ) : [];
		} );
		var url = ( props.urls && props.urls[ target ] ) || '';
		if ( ! url ) { return; }
		var c;
		try { c = JSON.parse( el.getAttribute( 'data-m7sf-pagination' ) ); } catch ( err ) { c = {}; }
		if ( 'reload' === el.getAttribute( 'data-m7sf-apply' ) && 'more' !== v ) {
			window.location.href = url;
			return;
		}
		if ( c.provider_top_offset !== undefined && 'more' !== v ) {
			var box = containersFor( qid )[ 0 ];
			if ( box ) { window.scrollTo( { top: window.pageYOffset + box.getBoundingClientRect().top - c.provider_top_offset, behavior: 'smooth' } ); }
		}
		load( qid, url, { push: 'ajax' !== mode, mode: mode, append: 'more' === v } );
	}

	function isPaginationLink( a ) {
		if ( a.closest( '.page-numbers, .elementor-pagination, .woocommerce-pagination, .navigation, .pagination, .wp-block-query-pagination, nav[aria-label]' ) ) {
			try {
				var u = new URL( a.href );
				return u.origin === window.location.origin && ( /\/page\/\d+/.test( u.pathname ) || /(^|&)(paged|product-page|e-page-[^=]+|query-\d+-page)=/.test( u.search.slice( 1 ) ) );
			} catch ( err ) {
				return false;
			}
		}
		return false;
	}

	window.addEventListener( 'popstate', function () {
		var url = new URL( window.location.href );
		var qid = url.searchParams.get( 'mfq' );
		var known = qid ? [ qid ] : Array.from( new Set( qsa( document, '.m7sf-filter[data-m7sf-for]' ).map( function ( el ) { return el.getAttribute( 'data-m7sf-for' ); } ) ) );
		known.forEach( function ( q ) {
			syncInputs( q, window.location.href );
			if ( containersFor( q ).length ) { load( q, window.location.href, { push: false } ); }
		} );
	} );

	function boot() {
		document.addEventListener( 'change', onChange );
		document.addEventListener( 'input', onInput );
		document.addEventListener( 'keydown', onKeydown );
		document.addEventListener( 'click', onClick );
		document.addEventListener( 'pointerover', onIntent, { passive: true } );
		document.addEventListener( 'focusin', onIntent );
		document.addEventListener( 'touchstart', onIntent, { passive: true } );
		document.addEventListener( 'mousemove', rangePointer, { passive: true } );
		document.addEventListener( 'touchstart', rangePointer, { passive: true } );
		if ( ! isEditor() ) {
			try { seedCurrentState(); } catch ( err ) {}
		}
		setupLists( document );
		if ( ! isEditor() ) { applyHiddenOnce(); }
		// Elementor (ook de editor): widgets die later verschijnen of opnieuw worden opgebouwd.
		var hookElementor = function () {
			if ( window.elementorFrontend && window.elementorFrontend.hooks ) {
				window.elementorFrontend.hooks.addAction( 'frontend/element_ready/global', function ( $scope ) {
					if ( $scope && $scope[ 0 ] ) { setupLists( $scope[ 0 ] ); }
				} );
				return true;
			}
			return false;
		};
		if ( ! hookElementor() && window.jQuery ) {
			window.jQuery( window ).on( 'elementor/frontend/init', hookElementor );
		}
		document.addEventListener( 'm7sf:updated', function ( e ) {
			setupLists( document );
			qsa( document, '.m7sf-filters-single-loading' ).forEach( function ( w ) { w.classList.remove( 'm7sf-filters-single-loading' ); } );
			// Na een wijziging alvast de volgende standen voorladen als de bezoeker het filter gebruikt.
			var qid = e.detail && e.detail.queryId;
			if ( qid ) { prefetching[ qid ] = false; setTimeout( function () { prefetch( qid ); }, 300 ); }
		} );
	}

	window.M7SmartFilters = { apply: apply, collect: collect, buildUrl: buildUrl, readValue: readValue, writeValue: writeValue };

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}
} )();
