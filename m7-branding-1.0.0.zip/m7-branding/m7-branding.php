<?php
/**
 * Plugin Name:       M7 Branding
 * Description:       M7-dashboard in wp-admin. Bevat alle M7-plugins: installeren, activeren en bijwerken vanuit het M7-menu.
 * Version:           1.0.0
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            M7 Branding
 * Author URI:        https://m7branding.com
 * License:           GPL-2.0-or-later
 * Text Domain:       m7-branding
 *
 * @package M7B
 */

defined( 'ABSPATH' ) || exit;

define( 'M7B_VERSION', '1.0.0' );
define( 'M7B_FILE', __FILE__ );
define( 'M7B_DIR', plugin_dir_path( __FILE__ ) );

require_once M7B_DIR . 'includes/m7/class-m7-admin-menu.php';
add_action( 'plugins_loaded', array( 'M7_Updates', 'init' ), 1 );

if ( is_admin() ) {
	require_once M7B_DIR . 'includes/class-hub.php';
	require_once M7B_DIR . 'includes/class-shop.php';
	add_action( 'plugins_loaded', array( 'M7B\\Hub', 'init' ), 1 );
	add_action( 'plugins_loaded', array( 'M7B\\Shop', 'init' ), 1 );
}
