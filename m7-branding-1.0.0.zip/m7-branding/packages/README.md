Deze map wordt bij het bouwen (`tools/build-zip.sh`) gevuld met de zips van alle M7-plugins en `catalog.json`.
In de repository blijft hij leeg; in `m7-branding-<versie>.zip` zitten de pakketten wel.
