<?php
/**
 * Licenties kopen in de plugin: afrekenscherm in wp-admin (M7 > Licentie), betalen via Mollie op de M7-licentieserver,
 * daarna wordt de sleutel automatisch geactiveerd. Ook verlengen van jaarlicenties.
 *
 * De betaalgegevens (Mollie-sleutel) staan alleen op de licentieserver; deze plugin stuurt alleen de bestelling door.
 *
 * @package M7B
 */

namespace M7B;

defined( 'ABSPATH' ) || exit;

final class Shop {

	const ORDERS = 'm7_shop_orders';

	public static function init() {
		add_action( 'admin_post_m7_checkout', array( __CLASS__, 'handle_checkout' ) );
		add_action( 'wp_ajax_m7_quote', array( __CLASS__, 'ajax_quote' ) );
	}

	public static function available() {
		return class_exists( 'M7_License' ) && \M7_License::can_buy();
	}

	/**
	 * Producten van de licentieserver (1 uur onthouden).
	 *
	 * @return array
	 */
	public static function catalog() {
		$cached = get_transient( 'm7_shop_catalog' );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		$data = \M7_License::shop( 'catalog', array(), true );
		if ( ! empty( $data['error'] ) || empty( $data['products'] ) ) {
			return array();
		}
		set_transient( 'm7_shop_catalog', $data, HOUR_IN_SECONDS );
		return $data;
	}

	/**
	 * Product-ID om een plugin te kopen (eerste product dat alleen die plugin bevat).
	 */
	public static function product_for( $slug ) {
		$cat = self::catalog();
		foreach ( isset( $cat['products'] ) ? $cat['products'] : array() as $p ) {
			if ( empty( $p['bundle'] ) && in_array( $slug, (array) $p['plugins'], true ) ) {
				return $p['id'];
			}
		}
		return '';
	}

	public static function buy_url( $product, $renew = '' ) {
		return add_query_arg(
			array_filter(
				array(
					'page'  => Hub::LICENSE,
					'koop'  => '' !== (string) $product ? $product : 'alle',
					'renew' => $renew,
				)
			),
			admin_url( 'admin.php' )
		);
	}

	/* ------------------------------ scherm ------------------------------ */

	/**
	 * Afrekenscherm (Licentie-tab met ?koop=product).
	 */
	public static function render( $product_id, $renew = '' ) {
		$cat      = self::catalog();
		$products = array();
		foreach ( isset( $cat['products'] ) ? $cat['products'] : array() as $p ) {
			$products[ $p['id'] ] = $p;
		}
		echo '<div class="wrap m7-overview m7-shop"><h1 class="screen-reader-text">' . esc_html__( 'Licentie kopen', 'm7-branding' ) . '</h1>';
		if ( ! $products ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'De licentieserver is nu niet bereikbaar. Probeer het later opnieuw.', 'm7-branding' ) . '</p></div></div>';
			return;
		}
		if ( ! isset( $products[ $product_id ] ) ) {
			$product_id = key( $products );
		}
		$user    = wp_get_current_user();
		$country = 'NL';
		$prev    = get_option( 'm7_shop_customer', array() );
		$prev    = is_array( $prev ) ? $prev : array();
		$val     = static function ( $k, $default = '' ) use ( $prev ) {
			return isset( $prev[ $k ] ) ? (string) $prev[ $k ] : $default;
		};
		$period  = static function ( $p ) {
			return 'lifetime' === $p['period'] ? __( 'eenmalig, voor altijd', 'm7-branding' ) : __( 'per jaar', 'm7-branding' );
		};
		$sites   = static function ( $p ) {
			/* translators: %d: aantal sites */
			return sprintf( _n( '%d site', '%d sites', (int) $p['sites'], 'm7-branding' ), (int) $p['sites'] );
		};
		$excl    = empty( $cat['prices_include_vat'] );

		echo '<p class="m7-ov-intro">' . ( $renew ? esc_html__( 'Licentie verlengen. Na betaling loopt je licentie een jaar langer; je hoeft niets opnieuw in te vullen.', 'm7-branding' ) : esc_html__( 'Kies een licentie voor één plugin of de bundel voor alle M7-plugins. Na betaling wordt de licentie direct op deze site geactiveerd.', 'm7-branding' ) ) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" id="m7-shop-form" class="m7-shop__grid">';
		wp_nonce_field( 'm7_checkout' );
		echo '<input type="hidden" name="action" value="m7_checkout">';
		if ( $renew ) {
			echo '<input type="hidden" name="renew" value="' . esc_attr( $renew ) . '">';
		}

		// Producten.
		echo '<div class="m7-shop__products">';
		foreach ( $products as $p ) {
			if ( $renew && $p['id'] !== $product_id ) {
				continue;
			}
			echo '<label class="m7-ov-card m7-shop__product' . ( $p['id'] === $product_id ? ' is-chosen' : '' ) . '">';
			echo '<input type="radio" name="product" value="' . esc_attr( $p['id'] ) . '"' . checked( $p['id'], $product_id, false ) . '>';
			echo '<span class="m7-shop__name">' . esc_html( $p['name'] ) . ( ! empty( $p['bundle'] ) ? ' <span class="m7-shop__badge">' . esc_html__( 'Alle plugins', 'm7-branding' ) . '</span>' : '' ) . '</span>';
			if ( '' !== $p['description'] ) {
				echo '<span class="m7-shop__desc">' . esc_html( $p['description'] ) . '</span>';
			}
			echo '<span class="m7-shop__price">€ ' . esc_html( number_format_i18n( (float) $p['price'], 2 ) ) . ' <small>' . esc_html( $period( $p ) . ' · ' . $sites( $p ) . ( $excl ? ' · ' . __( 'excl. btw', 'm7-branding' ) : '' ) ) . '</small></span>';
			echo '</label>';
		}
		echo '</div>';

		// Gegevens.
		$field = static function ( $name, $label, $value, $required = false, $type = 'text', $auto = '' ) {
			echo '<p class="m7-shop__field"><label for="m7-shop-' . esc_attr( $name ) . '">' . esc_html( $label ) . ( $required ? ' <span aria-hidden="true">*</span>' : '' ) . '</label>';
			echo '<input type="' . esc_attr( $type ) . '" id="m7-shop-' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '"' . ( $required ? ' required' : '' ) . ( $auto ? ' autocomplete="' . esc_attr( $auto ) . '"' : '' ) . '></p>';
		};
		echo '<div class="m7-ov-card m7-shop__details"><h2>' . esc_html__( 'Factuurgegevens', 'm7-branding' ) . '</h2>';
		$field( 'name', __( 'Naam', 'm7-branding' ), $val( 'name', $user->display_name ), true, 'text', 'name' );
		$field( 'company', __( 'Bedrijf', 'm7-branding' ), $val( 'company', get_bloginfo( 'name' ) ), false, 'text', 'organization' );
		$field( 'email', __( 'E-mailadres', 'm7-branding' ), $val( 'email', $user->user_email ), true, 'email', 'email' );
		$field( 'address', __( 'Adres', 'm7-branding' ), $val( 'address' ), true, 'text', 'street-address' );
		echo '<div class="m7-shop__row">';
		$field( 'postcode', __( 'Postcode', 'm7-branding' ), $val( 'postcode' ), true, 'text', 'postal-code' );
		$field( 'city', __( 'Plaats', 'm7-branding' ), $val( 'city' ), true, 'text', 'address-level2' );
		echo '</div>';
		echo '<p class="m7-shop__field"><label for="m7-shop-country">' . esc_html__( 'Land', 'm7-branding' ) . ' <span aria-hidden="true">*</span></label><select id="m7-shop-country" name="country" required>';
		$countries = self::countries( isset( $cat['eu_countries'] ) ? (array) $cat['eu_countries'] : array() );
		$current   = $val( 'country', $country );
		foreach ( $countries as $code => $name ) {
			echo '<option value="' . esc_attr( $code ) . '"' . selected( $current, $code, false ) . '>' . esc_html( $name ) . '</option>';
		}
		echo '</select></p>';
		$field( 'vat_id', __( 'Btw-nummer (zakelijk, optioneel)', 'm7-branding' ), $val( 'vat_id' ), false, 'text', '' );
		echo '<p class="m7-ov-note">' . esc_html__( 'Bedrijf in een ander EU-land met een geldig btw-nummer? Dan wordt de btw verlegd.', 'm7-branding' ) . '</p>';
		echo '</div>';

		// Overzicht en betalen.
		echo '<div class="m7-ov-card m7-shop__summary"><h2>' . esc_html__( 'Overzicht', 'm7-branding' ) . '</h2>';
		echo '<table class="m7-shop__totals" aria-live="polite"><tr><td>' . esc_html__( 'Licentie', 'm7-branding' ) . '</td><td data-m7="net">–</td></tr>';
		echo '<tr><td data-m7="vat-label">' . esc_html__( 'Btw', 'm7-branding' ) . '</td><td data-m7="vat">–</td></tr>';
		echo '<tr class="is-total"><td>' . esc_html__( 'Totaal', 'm7-branding' ) . '</td><td data-m7="total">–</td></tr></table>';
		echo '<p class="m7-ov-note" data-m7="note"></p>';
		$terms = isset( $cat['terms_url'] ) ? (string) $cat['terms_url'] : '';
		echo '<p><label><input type="checkbox" name="terms" value="1" required> ';
		if ( $terms ) {
			/* translators: %s: link naar voorwaarden */
			printf( esc_html__( 'Ik ga akkoord met de %s.', 'm7-branding' ), '<a href="' . esc_url( $terms ) . '" target="_blank" rel="noopener">' . esc_html__( 'voorwaarden', 'm7-branding' ) . '</a>' );
		} else {
			esc_html_e( 'Ik ga akkoord met de voorwaarden.', 'm7-branding' );
		}
		echo '</label></p>';
		echo '<button type="submit" class="m7-ov-btn is-primary m7-shop__pay">' . esc_html__( 'Afrekenen', 'm7-branding' ) . '</button>';
		echo '<p class="m7-ov-note">' . esc_html__( 'Je betaalt veilig via Mollie (iDEAL, creditcard, Bancontact en meer) en komt daarna automatisch hier terug.', 'm7-branding' ) . '</p>';
		echo '</div></form>';
		echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=' . Hub::LICENSE ) ) . '">' . esc_html__( '← Terug naar licenties', 'm7-branding' ) . '</a></p></div>';
		self::assets();
		\M7_Admin_Menu::cards_css();
	}

	/**
	 * Terug van het betalen: status opvragen, sleutel activeren.
	 *
	 * @param string $order_id Bestelling.
	 */
	public static function render_return( $order_id ) {
		$orders = get_option( self::ORDERS, array() );
		$orders = is_array( $orders ) ? $orders : array();
		echo '<div class="wrap m7-overview m7-shop"><h1 class="screen-reader-text">' . esc_html__( 'Betaling', 'm7-branding' ) . '</h1>';
		if ( ! isset( $orders[ $order_id ] ) ) {
			echo '<div class="m7-ov-card"><h2>' . esc_html__( 'Bestelling niet gevonden', 'm7-branding' ) . '</h2><p>' . esc_html__( 'Deze bestelling hoort niet bij deze site.', 'm7-branding' ) . '</p></div></div>';
			return;
		}
		$o      = $orders[ $order_id ];
		$status = \M7_License::shop( 'order_status', array( 'order' => $order_id, 'token' => $o['token'] ), true );
		$state  = isset( $status['status'] ) ? (string) $status['status'] : 'error';
		$back   = '<p><a class="m7-ov-btn" href="' . esc_url( admin_url( 'admin.php?page=' . Hub::LICENSE ) ) . '">' . esc_html__( 'Naar licenties', 'm7-branding' ) . '</a></p>';

		if ( 'paid' === $state && ! empty( $status['license_key'] ) ) {
			if ( empty( $o['done'] ) ) {
				if ( ! empty( $status['renew'] ) ) {
					\M7_License::validate();
					$msg = __( 'Bedankt! Je licentie is verlengd.', 'm7-branding' );
				} else {
					list( , $msg ) = \M7_License::activate( (string) $status['license_key'] );
					$msg           = __( 'Bedankt! Je licentie is betaald en geactiveerd.', 'm7-branding' ) . ' ' . $msg;
				}
				$orders[ $order_id ]['done'] = time();
				$orders[ $order_id ]['msg']  = $msg;
				unset( $orders[ $order_id ]['token'] );
				update_option( self::ORDERS, $orders, false );
				delete_transient( 'm7_shop_catalog' );
			}
			echo '<div class="m7-ov-card is-active"><h2>' . esc_html__( 'Betaling gelukt', 'm7-branding' ) . '</h2>';
			echo '<p>' . esc_html( $orders[ $order_id ]['msg'] ) . '</p>';
			/* translators: %s: factuurnummer */
			echo '<p>' . esc_html( sprintf( __( 'De bevestiging en factuur %s zijn naar je e-mailadres gestuurd.', 'm7-branding' ), (string) $status['invoice'] ) ) . '</p>';
			echo '<p><a class="m7-ov-btn is-primary" href="' . esc_url( admin_url( 'admin.php?page=' . Hub::MARKET ) ) . '">' . esc_html__( 'Naar de Markt om te installeren', 'm7-branding' ) . '</a></p></div></div>';
		} elseif ( ! empty( $o['done'] ) ) {
			echo '<div class="m7-ov-card is-active"><h2>' . esc_html__( 'Betaling gelukt', 'm7-branding' ) . '</h2><p>' . esc_html( (string) $o['msg'] ) . '</p>' . $back . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $back is geëscapet.
		} elseif ( in_array( $state, array( 'open', 'pending', 'authorized' ), true ) ) {
			echo '<div class="m7-ov-card"><h2>' . esc_html__( 'Betaling wordt verwerkt…', 'm7-branding' ) . '</h2><p>' . esc_html__( 'Dit duurt meestal een paar seconden. Deze pagina ververst vanzelf.', 'm7-branding' ) . '</p></div>';
			echo '<script>setTimeout(function(){location.reload()},4000)</script></div>';
		} else {
			$retry = ! empty( $o['product'] ) ? self::buy_url( $o['product'], isset( $o['renew'] ) ? $o['renew'] : '' ) : admin_url( 'admin.php?page=' . Hub::LICENSE );
			echo '<div class="m7-ov-card is-missing"><h2>' . esc_html__( 'Betaling niet gelukt', 'm7-branding' ) . '</h2>';
			echo '<p>' . esc_html( isset( $status['error'] ) ? (string) $status['error'] : __( 'De betaling is geannuleerd of mislukt. Er is niets afgeschreven.', 'm7-branding' ) ) . '</p>';
			echo '<p><a class="m7-ov-btn is-primary" href="' . esc_url( $retry ) . '">' . esc_html__( 'Opnieuw proberen', 'm7-branding' ) . '</a></p></div></div>';
		}
		\M7_Admin_Menu::cards_css();
	}

	/* ------------------------------ acties ------------------------------ */

	public static function handle_checkout() {
		check_admin_referer( 'm7_checkout' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Je hebt hier geen rechten voor.', 'm7-branding' ) );
		}
		$f        = array();
		$fields   = array( 'product', 'name', 'company', 'email', 'address', 'postcode', 'city', 'country', 'vat_id', 'renew' );
		foreach ( $fields as $k ) {
			$f[ $k ] = isset( $_POST[ $k ] ) ? sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) : '';
		}
		$back = self::buy_url( $f['product'], $f['renew'] );
		if ( empty( $_POST['terms'] ) ) {
			self::fail( $back, __( 'Ga akkoord met de voorwaarden om af te rekenen.', 'm7-branding' ) );
		}
		$customer = array_intersect_key( $f, array_flip( array( 'name', 'company', 'email', 'address', 'postcode', 'city', 'country', 'vat_id' ) ) );
		update_option( 'm7_shop_customer', $customer, false ); // Volgende keer alvast ingevuld.
		$res = \M7_License::shop(
			'checkout',
			array_merge(
				$customer,
				array(
					'product'    => $f['product'],
					'renew_key'  => $f['renew'],
					'site'       => wp_parse_url( home_url(), PHP_URL_HOST ),
					'return_url' => admin_url( 'admin.php?page=' . Hub::LICENSE ),
				)
			)
		);
		if ( ! empty( $res['error'] ) || empty( $res['checkout_url'] ) || empty( $res['order'] ) ) {
			self::fail( $back, ! empty( $res['error'] ) ? (string) $res['error'] : __( 'Afrekenen lukte niet. Probeer het later opnieuw.', 'm7-branding' ) );
		}
		$orders                   = get_option( self::ORDERS, array() );
		$orders                   = is_array( $orders ) ? array_slice( $orders, -20, null, true ) : array();
		$orders[ $res['order'] ] = array(
			'token'   => (string) $res['token'],
			'product' => $f['product'],
			'renew'   => $f['renew'],
			'created' => time(),
		);
		update_option( self::ORDERS, $orders, false );
		// Alleen doorsturen naar Mollie of naar de eigen licentieserver (testbetaling).
		$url  = (string) $res['checkout_url'];
		$host = (string) wp_parse_url( $url, PHP_URL_HOST );
		$own  = (string) wp_parse_url( \M7_Updates::licensing()['api'], PHP_URL_HOST );
		if ( ! preg_match( '/(^|\.)mollie\.com$/', $host ) && $host !== $own ) {
			self::fail( $back, __( 'Onverwacht betaaladres; afrekenen is gestopt.', 'm7-branding' ) );
		}
		wp_redirect( $url ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- gecontroleerd: Mollie of de eigen licentieserver.
		exit;
	}

	private static function fail( $url, $message ) {
		set_transient( Hub::NOTICE . get_current_user_id(), array( 'error', $message ), 120 );
		wp_safe_redirect( $url );
		exit;
	}

	/**
	 * Prijs met btw voor het gekozen land en btw-nummer (via de licentieserver).
	 */
	public static function ajax_quote() {
		check_ajax_referer( 'm7_checkout', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}
		$res = \M7_License::shop(
			'quote',
			array(
				'product' => isset( $_POST['product'] ) ? sanitize_text_field( wp_unslash( $_POST['product'] ) ) : '',
				'country' => isset( $_POST['country'] ) ? sanitize_text_field( wp_unslash( $_POST['country'] ) ) : 'NL',
				'vat_id'  => isset( $_POST['vat_id'] ) ? sanitize_text_field( wp_unslash( $_POST['vat_id'] ) ) : '',
			)
		);
		if ( ! empty( $res['error'] ) ) {
			wp_send_json_error( $res );
		}
		wp_send_json_success( $res );
	}

	private static function assets() {
		$nonce = wp_create_nonce( 'm7_checkout' );
		?>
		<style>
		.m7-shop__grid{display:grid;grid-template-columns:minmax(0,1.2fr) minmax(0,1fr);gap:16px;align-items:start;max-width:1100px}
		.m7-shop__products{grid-column:1/-1;display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px}
		.m7-shop__product{cursor:pointer;display:flex;flex-direction:column;gap:6px;position:relative}
		.m7-shop__product input{position:absolute;opacity:0}
		.m7-shop__product.is-chosen{outline:2px solid #3affff;outline-offset:-2px}
		.m7-shop__product:focus-within{box-shadow:0 0 0 2px #2271b1}
		.m7-shop__name{font-weight:600;font-size:15px}.m7-shop__desc{color:#50575e}
		.m7-shop__price{font-size:18px;font-weight:600}.m7-shop__price small{font-size:12px;font-weight:400;color:#50575e}
		.m7-shop__badge{display:inline-block;margin-left:6px;padding:1px 6px;border-radius:9px;background:#030304;color:#3affff;font-size:11px;font-weight:600}
		.m7-shop__field{display:flex;flex-direction:column;gap:4px;margin:0 0 10px}.m7-shop__field input,.m7-shop__field select{width:100%;max-width:none}
		.m7-shop__row{display:grid;grid-template-columns:1fr 2fr;gap:10px}
		.m7-shop__totals{width:100%;border-collapse:collapse}.m7-shop__totals td{padding:6px 0;border-bottom:1px solid #f0f0f1}.m7-shop__totals td:last-child{text-align:right}
		.m7-shop__totals .is-total td{font-weight:600;font-size:16px;border-bottom:0}
		.m7-shop__pay{width:100%;justify-content:center;font-size:15px;padding:10px}
		@media (max-width:782px){.m7-shop__grid{grid-template-columns:1fr}}
		</style>
		<script>
		( function () {
			var form = document.getElementById( 'm7-shop-form' );
			if ( ! form ) { return; }
			var money = function ( v ) { return '€ ' + Number( v ).toLocaleString( 'nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 } ); };
			var timer, seq = 0;
			var set = function ( k, v ) { var el = form.querySelector( '[data-m7="' + k + '"]' ); if ( el ) { el.textContent = v; } };
			function quote() {
				var my = ++seq;
				var p = form.querySelector( 'input[name="product"]:checked' );
				form.querySelectorAll( '.m7-shop__product' ).forEach( function ( l ) { l.classList.toggle( 'is-chosen', !! l.querySelector( 'input:checked' ) ); } );
				var body = new URLSearchParams( { action: 'm7_quote', nonce: <?php echo wp_json_encode( $nonce ); ?>, product: p ? p.value : '', country: form.country.value, vat_id: form.vat_id.value } );
				fetch( ajaxurl, { method: 'POST', credentials: 'same-origin', body: body } ).then( function ( r ) { return r.json(); } ).then( function ( r ) {
					if ( my !== seq || ! r || ! r.success ) { return; }
					var q = r.data;
					set( 'net', money( q.net ) );
					set( 'vat-label', q.reverse_charge ? <?php echo wp_json_encode( __( 'Btw verlegd', 'm7-branding' ) ); ?> : <?php echo wp_json_encode( __( 'Btw', 'm7-branding' ) ); ?> + ' ' + String( q.vat_rate ).replace( '.', ',' ) + '%' );
					set( 'vat', money( q.vat ) );
					set( 'total', money( q.total ) );
					set( 'note', q.note || '' );
				} );
			}
			form.addEventListener( 'change', quote );
			form.vat_id.addEventListener( 'input', function () { clearTimeout( timer ); timer = setTimeout( quote, 600 ); } );
			form.addEventListener( 'submit', function () { var b = form.querySelector( '.m7-shop__pay' ); b.disabled = true; b.textContent = <?php echo wp_json_encode( __( 'Even geduld…', 'm7-branding' ) ); ?>; } );
			quote();
		} )();
		</script>
		<?php
	}

	/**
	 * Landen: EU-landen eerst (Nederland bovenaan), daarna veelvoorkomende landen buiten de EU.
	 */
	private static function countries( array $eu ) {
		$names = array(
			'NL' => 'Nederland', 'BE' => 'België', 'DE' => 'Duitsland', 'FR' => 'Frankrijk', 'LU' => 'Luxemburg', 'AT' => 'Oostenrijk',
			'BG' => 'Bulgarije', 'HR' => 'Kroatië', 'CY' => 'Cyprus', 'CZ' => 'Tsjechië', 'DK' => 'Denemarken', 'EE' => 'Estland',
			'FI' => 'Finland', 'GR' => 'Griekenland', 'HU' => 'Hongarije', 'IE' => 'Ierland', 'IT' => 'Italië', 'LV' => 'Letland',
			'LT' => 'Litouwen', 'MT' => 'Malta', 'PL' => 'Polen', 'PT' => 'Portugal', 'RO' => 'Roemenië', 'SK' => 'Slowakije',
			'SI' => 'Slovenië', 'ES' => 'Spanje', 'SE' => 'Zweden', 'GB' => 'Verenigd Koninkrijk', 'CH' => 'Zwitserland',
			'NO' => 'Noorwegen', 'US' => 'Verenigde Staten', 'CA' => 'Canada', 'AU' => 'Australië', 'XX' => 'Ander land',
		);
		$out = array( 'NL' => $names['NL'] );
		foreach ( $eu as $c ) {
			if ( isset( $names[ $c ] ) ) {
				$out[ $c ] = $names[ $c ];
			}
		}
		asort( $out );
		$out = array( 'NL' => $names['NL'] ) + $out;
		foreach ( array( 'GB', 'CH', 'NO', 'US', 'CA', 'AU', 'XX' ) as $c ) {
			$out[ $c ] = $names[ $c ];
		}
		return $out;
	}
}
