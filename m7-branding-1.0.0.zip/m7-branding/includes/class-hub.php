<?php
/**
 * M7 Branding: Markt met alle M7-plugins. Installeren, activeren, bijwerken en een andere (oudere) versie kiezen.
 *
 * Bronnen: de meegeleverde zips in packages/ (gevuld door tools/build-zip.sh) en de M7-updatelijst (M7_Updates).
 * Niets wordt automatisch geïnstalleerd of bijgewerkt: de beheerder kiest zelf.
 *
 * @package M7B
 */

namespace M7B;

defined( 'ABSPATH' ) || exit;

final class Hub {

	const ACTION = 'm7_hub';
	const NOTICE = 'm7_hub_notice_';
	const MARKET = 'm7-markt';
	const LICENSE = 'm7-licentie';

	public static function init() {
		\M7_Admin_Menu::boot();
		add_filter( 'm7_admin_catalog', array( __CLASS__, 'catalog_cards' ) );
		add_filter( 'm7_home_tabs', array( __CLASS__, 'home_tabs' ) );
		add_filter(
			'm7_home_version',
			static function () {
				return M7B_VERSION;
			}
		);
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 10 );
		add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'handle' ) );
		add_action( 'admin_post_m7_license', array( __CLASS__, 'handle_license' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
		add_action( 'm7_admin_overview_top', array( __CLASS__, 'updates_bar' ) );
	}

	public static function home_tabs( $tabs ) {
		if ( current_user_can( 'install_plugins' ) || current_user_can( 'update_plugins' ) ) {
			$tabs['Markt'] = self::MARKET;
		}
		if ( class_exists( 'M7_License' ) && \M7_License::enabled() && current_user_can( 'manage_options' ) ) {
			$tabs['Licentie'] = self::LICENSE;
		}
		return $tabs;
	}

	public static function menu() {
		add_submenu_page( \M7_Admin_Menu::SLUG, __( 'M7 Markt', 'm7-branding' ), __( 'Markt', 'm7-branding' ), 'install_plugins', self::MARKET, array( __CLASS__, 'market' ) );
		if ( class_exists( 'M7_License' ) && \M7_License::enabled() ) {
			add_submenu_page( \M7_Admin_Menu::SLUG, __( 'M7 Licentie', 'm7-branding' ), __( 'Licentie', 'm7-branding' ), 'manage_options', self::LICENSE, array( __CLASS__, 'license_page' ) );
		}
	}

	/* ------------------------------ bronnen ------------------------------ */

	/**
	 * Meegeleverde M7-plugins (packages/catalog.json).
	 *
	 * @return array slug => [slug, name, version, description, file]
	 */
	public static function catalog() {
		static $catalog = null;
		if ( null !== $catalog ) {
			return $catalog;
		}
		$catalog = array();
		$file    = M7B_DIR . 'packages/catalog.json';
		if ( ! is_readable( $file ) ) {
			return $catalog;
		}
		$data = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- lokaal bestand.
		foreach ( is_array( $data ) ? $data : array() as $item ) {
			if ( empty( $item['slug'] ) || ! preg_match( '/^m7-[a-z0-9-]+$/', $item['slug'] ) ) {
				continue;
			}
			$item['file']             = sanitize_file_name( isset( $item['file'] ) ? $item['file'] : $item['slug'] . '.zip' );
			$catalog[ $item['slug'] ] = $item;
		}
		return $catalog;
	}

	private static function manifest() {
		return class_exists( 'M7_Updates' ) ? \M7_Updates::manifest() : array();
	}

	/**
	 * Wat er te installeren valt: meegeleverde zips en (nieuwere) versies uit de M7-updatelijst.
	 *
	 * @return array slug => [name, description, version, package, versions]
	 */
	public static function available() {
		$out = array();
		foreach ( self::catalog() as $slug => $item ) {
			$out[ $slug ] = array(
				'name'        => $item['name'],
				'description' => isset( $item['description'] ) ? $item['description'] : '',
				'version'     => $item['version'],
				'package'     => self::package_path( $item ),
				'versions'    => array(),
			);
		}
		foreach ( self::manifest() as $slug => $m ) {
			if ( 'm7-branding' === $slug ) {
				continue;
			}
			$have = isset( $out[ $slug ] ) ? $out[ $slug ] : null;
			if ( ! $have || '' === $have['package'] || version_compare( $m['version'], $have['version'], '>' ) ) {
				$out[ $slug ] = array(
					'name'        => preg_replace( '/^M7\s+/', '', $m['name'] ),
					'description' => '' !== $m['description'] ? $m['description'] : ( $have ? $have['description'] : '' ),
					'version'     => $m['version'],
					'package'     => $m['download_url'],
					'versions'    => array(),
				);
			}
			$out[ $slug ]['versions'] = $m['versions'];
		}
		// Betaalde plugins: alleen met geldige licentie installeren of bijwerken (ook uit de meegeleverde zip).
		foreach ( $out as $slug => $item ) {
			$out[ $slug ]['needs_license'] = false;
			if ( class_exists( 'M7_License' ) && \M7_License::requires( $slug ) ) {
				if ( \M7_License::allows( $slug ) ) {
					$out[ $slug ]['package'] = 0 === strpos( $item['package'], 'http' ) ? \M7_License::package_url( $slug, $item['package'] ) : $item['package'];
				} else {
					$out[ $slug ]['package']       = '';
					$out[ $slug ]['needs_license'] = true;
				}
			}
		}
		return $out;
	}

	private static function plugin_file( $slug ) {
		return $slug . '/' . $slug . '.php';
	}

	private static function package_path( $item ) {
		$path = M7B_DIR . 'packages/' . $item['file'];
		return is_readable( $path ) ? $path : '';
	}

	private static function action_url( $do, $slug, $version = '' ) {
		$url = admin_url( 'admin-post.php?action=' . self::ACTION . '&do=' . $do . '&slug=' . rawurlencode( $slug ) . ( '' !== $version ? '&v=' . rawurlencode( $version ) : '' ) );
		return wp_nonce_url( $url, self::ACTION . '_' . $do . '_' . $slug . '_' . $version );
	}

	private static function file_mods() {
		return ! ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS );
	}

	/* ------------------------------ kaarten ------------------------------ */

	/**
	 * Kaarten voor het overzicht en de Markt.
	 *
	 * @param array $cards Kaarten van andere bronnen.
	 * @return array
	 */
	public static function catalog_cards( $cards ) {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$installed = get_plugins();
		$file_mods = self::file_mods();
		foreach ( self::available() as $slug => $item ) {
			$file    = self::plugin_file( $slug );
			$card    = array(
				'slug'        => $slug,
				'name'        => $item['name'],
				'version'     => $item['version'],
				'description' => $item['description'],
				'actions'     => array(),
				'note'        => '',
			);
			$has_zip = '' !== $item['package'];
			if ( ! empty( $item['needs_license'] ) ) {
				$card['note'] = __( 'Betaalde plugin: installeren en bijwerken vraagt een M7-licentie.', 'm7-branding' );
			}
			if ( ! isset( $installed[ $file ] ) ) {
				$card['status'] = 'missing';
				if ( ! empty( $item['needs_license'] ) ) {
					if ( Shop::available() ) {
						$product           = Shop::product_for( $slug );
						$card['actions'][] = array( __( 'Kopen', 'm7-branding' ), Shop::buy_url( $product ? $product : 'm7-bundel' ) );
					}
					$card['actions'][] = array( __( 'Licentie invullen', 'm7-branding' ), admin_url( 'admin.php?page=' . self::LICENSE ) );
					$store             = \M7_Updates::licensing()['store_url'];
					if ( $store && ! Shop::available() ) {
						$card['actions'][] = array( __( 'Licentie kopen', 'm7-branding' ), $store );
					}
				} elseif ( $file_mods && $has_zip && current_user_can( 'install_plugins' ) ) {
					$card['actions'][] = array( __( 'Installeren', 'm7-branding' ), self::action_url( 'install', $slug ) );
				} elseif ( ! $has_zip ) {
					$card['note'] = __( 'Niet beschikbaar in deze M7 Branding-zip of de updatelijst.', 'm7-branding' );
				}
			} else {
				$current         = $installed[ $file ]['Version'];
				$card['version'] = $current;
				$card['status']  = is_plugin_active( $file ) ? 'active' : 'inactive';
				if ( 'inactive' === $card['status'] && current_user_can( 'activate_plugins' ) ) {
					$card['actions'][] = array( __( 'Activeren', 'm7-branding' ), self::action_url( 'activate', $slug ) );
				}
				if ( $file_mods && $has_zip && version_compare( $item['version'], $current, '>' ) && current_user_can( 'update_plugins' ) ) {
					/* translators: %s: versie */
					$card['actions'][] = array( sprintf( __( 'Bijwerken naar v%s', 'm7-branding' ), $item['version'] ), self::action_url( 'update', $slug ) );
				}
			}
			if ( $file_mods && count( $item['versions'] ) > 1 && current_user_can( 'install_plugins' ) ) {
				$card['actions'][] = array( __( 'Andere versie', 'm7-branding' ), admin_url( 'admin.php?page=' . self::MARKET . '&versions=' . rawurlencode( $slug ) ) );
			}
			if ( ! $file_mods && 'missing' === $card['status'] ) {
				$card['note'] = __( 'Installeren is op deze site uitgeschakeld (DISALLOW_FILE_MODS).', 'm7-branding' );
			}
			$cards[] = $card;
		}
		return $cards;
	}

	/* ------------------------------ schermen ------------------------------ */

	/**
	 * Boven de kaarten: update van M7 Branding zelf en "op updates controleren".
	 */
	public static function updates_bar() {
		if ( ! class_exists( 'M7_Updates' ) || '' === \M7_Updates::url() || ! current_user_can( 'update_plugins' ) ) {
			return;
		}
		$manifest = self::manifest();
		echo '<div class="m7-ov-updates">';
		if ( isset( $manifest['m7-branding'] ) && version_compare( $manifest['m7-branding']['version'], M7B_VERSION, '>' ) ) {
			/* translators: %s: versie */
			echo '<span><strong>' . esc_html( sprintf( __( 'M7 Branding v%s is beschikbaar.', 'm7-branding' ), $manifest['m7-branding']['version'] ) ) . '</strong> <a href="' . esc_url( admin_url( 'plugins.php?plugin_status=upgrade' ) ) . '">' . esc_html__( 'Bijwerken via Plugins', 'm7-branding' ) . '</a></span>';
		}
		echo '<a href="' . esc_url( self::action_url( 'check', 'm7-branding' ) ) . '">' . esc_html__( 'Op updates controleren', 'm7-branding' ) . '</a>';
		echo '</div>';
	}

	/**
	 * Markt: alle M7-plugins, of de versielijst van één plugin.
	 */
	public static function market() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$slug = isset( $_GET['versions'] ) ? sanitize_key( wp_unslash( $_GET['versions'] ) ) : '';
		echo '<div class="wrap m7-overview"><h1 class="screen-reader-text">' . esc_html__( 'M7 Markt', 'm7-branding' ) . '</h1>';
		self::updates_bar();
		if ( $slug ) {
			self::versions( $slug );
		} else {
			echo '<p class="m7-ov-intro">' . esc_html__( 'Alle M7-plugins. Installeer wat deze site nodig heeft; geïnstalleerde plugins staan daarna in het M7-menu. Updates en andere versies kies je hier zelf.', 'm7-branding' ) . '</p>';
			\M7_Admin_Menu::render_cards( \M7_Admin_Menu::cards() );
		}
		echo '</div>';
		\M7_Admin_Menu::cards_css();
	}

	private static function versions( $slug ) {
		$available = self::available();
		$back      = admin_url( 'admin.php?page=' . self::MARKET );
		if ( ! isset( $available[ $slug ] ) || ! $available[ $slug ]['versions'] ) {
			echo '<p>' . esc_html__( 'Geen versies gevonden voor deze plugin.', 'm7-branding' ) . ' <a href="' . esc_url( $back ) . '">' . esc_html__( 'Terug naar de Markt', 'm7-branding' ) . '</a></p>';
			return;
		}
		$item = $available[ $slug ];
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$installed = get_plugins();
		$file      = self::plugin_file( $slug );
		$current   = isset( $installed[ $file ] ) ? $installed[ $file ]['Version'] : '';
		echo '<p><a href="' . esc_url( $back ) . '">&larr; ' . esc_html__( 'Markt', 'm7-branding' ) . '</a></p>';
		/* translators: %s: naam */
		echo '<h2>' . esc_html( sprintf( __( '%s: versies', 'm7-branding' ), $item['name'] ) ) . '</h2>';
		echo '<p class="m7-ov-intro">' . esc_html__( 'Kies een versie om te installeren. Een oudere versie zet je terug als een update problemen geeft; instellingen die pas in een nieuwere versie bestaan, worden dan niet gebruikt. Maak eerst een back-up.', 'm7-branding' ) . '</p>';
		echo '<table class="widefat striped" style="max-width:640px"><thead><tr><th>' . esc_html__( 'Versie', 'm7-branding' ) . '</th><th>' . esc_html__( 'Datum', 'm7-branding' ) . '</th><th></th></tr></thead><tbody>';
		foreach ( $item['versions'] as $i => $v ) {
			echo '<tr><td><strong>v' . esc_html( $v['version'] ) . '</strong>' . ( 0 === $i ? ' <span class="m7-ov-status">' . esc_html__( 'nieuwste', 'm7-branding' ) . '</span>' : '' ) . '</td><td>' . esc_html( $v['date'] ) . '</td><td style="text-align:right">';
			if ( $current && version_compare( $v['version'], $current, '==' ) ) {
				echo '<em>' . esc_html__( 'Geïnstalleerd', 'm7-branding' ) . '</em>';
			} else {
				$older   = $current && version_compare( $v['version'], $current, '<' );
				$label   = $current ? ( $older ? __( 'Terugzetten naar deze versie', 'm7-branding' ) : __( 'Bijwerken naar deze versie', 'm7-branding' ) ) : __( 'Deze versie installeren', 'm7-branding' );
				/* translators: 1: naam, 2: versie */
				$confirm = $older ? sprintf( __( '%1$s terugzetten naar v%2$s? Maak eerst een back-up.', 'm7-branding' ), $item['name'], $v['version'] ) : '';
				echo '<a class="m7-ov-btn' . ( $older ? '' : ' is-primary' ) . '" href="' . esc_url( self::action_url( 'version', $slug, $v['version'] ) ) . '"' . ( $confirm ? ' onclick="return confirm(' . esc_attr( wp_json_encode( $confirm ) ) . ');"' : '' ) . '>' . esc_html( $label ) . '</a>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}

	/* ------------------------------ acties ------------------------------ */

	/**
	 * Installeren, activeren, bijwerken, andere versie of op updates controleren.
	 */
	public static function handle() {
		$do      = isset( $_GET['do'] ) ? sanitize_key( wp_unslash( $_GET['do'] ) ) : '';
		$slug    = isset( $_GET['slug'] ) ? sanitize_key( wp_unslash( $_GET['slug'] ) ) : '';
		$version = isset( $_GET['v'] ) ? preg_replace( '/[^0-9A-Za-z.\-]/', '', (string) wp_unslash( $_GET['v'] ) ) : '';
		check_admin_referer( self::ACTION . '_' . $do . '_' . $slug . '_' . $version );

		if ( 'check' === $do ) {
			if ( ! current_user_can( 'update_plugins' ) ) {
				self::back( 'error', __( 'Je hebt hier geen rechten voor.', 'm7-branding' ) );
			}
			\M7_Updates::check_now();
			self::back( 'success', __( 'Gecontroleerd op updates.', 'm7-branding' ) );
		}

		$available = self::available();
		if ( ! isset( $available[ $slug ] ) || ! in_array( $do, array( 'install', 'activate', 'update', 'version' ), true ) ) {
			self::back( 'error', __( 'Onbekende plugin of actie.', 'm7-branding' ) );
		}
		$item = $available[ $slug ];
		$file = self::plugin_file( $slug );
		$cap  = array(
			'install'  => 'install_plugins',
			'activate' => 'activate_plugins',
			'update'   => 'update_plugins',
			'version'  => 'install_plugins',
		);
		if ( ! current_user_can( $cap[ $do ] ) ) {
			self::back( 'error', __( 'Je hebt hier geen rechten voor.', 'm7-branding' ) );
		}
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$all           = get_plugins();
		$was_installed = isset( $all[ $file ] );

		if ( 'activate' !== $do ) {
			if ( ! self::file_mods() ) {
				self::back( 'error', __( 'Installeren is op deze site uitgeschakeld.', 'm7-branding' ) );
			}
			$package = $item['package'];
			$target  = $item['version'];
			if ( 'version' === $do ) {
				$package = '';
				foreach ( $item['versions'] as $v ) {
					if ( $v['version'] === $version ) {
						$package = $v['download_url'];
						$target  = $v['version'];
					}
				}
			}
			if ( ! $package ) {
				self::back( 'error', __( 'Het pakket ontbreekt.', 'm7-branding' ) );
			}
			self::install( $package, $was_installed );
			if ( $was_installed ) {
				/* translators: 1: naam, 2: versie */
				self::back( 'success', sprintf( __( '%1$s staat nu op v%2$s.', 'm7-branding' ), $item['name'], $target ) );
			}
		}

		// Na een nieuwe installatie, of bij "Activeren": activeren.
		$activated = activate_plugin( $file );
		if ( is_wp_error( $activated ) ) {
			self::back( 'error', $activated->get_error_message() );
		}
		self::back(
			'success',
			'activate' !== $do
				/* translators: %s: naam */
				? sprintf( __( '%s is geïnstalleerd en actief. Je vindt hem nu in het M7-menu.', 'm7-branding' ), $item['name'] )
				/* translators: %s: naam */
				: sprintf( __( '%s is geactiveerd. Je vindt hem nu in het M7-menu.', 'm7-branding' ), $item['name'] )
		);
	}

	/**
	 * Zip installeren (lokaal pad of https-adres), bestaande versie overschrijven als die er al staat.
	 *
	 * @param string $package   Pakket.
	 * @param bool   $overwrite Overschrijven.
	 */
	private static function install( $package, $overwrite ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		$skin     = new \WP_Ajax_Upgrader_Skin();
		$upgrader = new \Plugin_Upgrader( $skin );
		$result   = $upgrader->install( $package, array( 'overwrite_package' => $overwrite ) );
		if ( is_wp_error( $result ) ) {
			self::back( 'error', $result->get_error_message() );
		}
		if ( $skin->get_errors()->has_errors() ) {
			self::back( 'error', $skin->get_error_messages() );
		}
		if ( ! $result ) {
			self::back( 'error', __( 'Installeren lukte niet. Controleer of WordPress naar de pluginmap mag schrijven.', 'm7-branding' ) );
		}
		wp_clean_plugins_cache();
		\M7_Updates::flush();
		\M7_Updates::sync_transient();
	}

	/* ------------------------------ licentie ------------------------------ */

	public static function license_page() {
		// Afrekenen in de plugin: terug van betalen, of het afrekenscherm.
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- alleen lezen en tonen; de bestelling wordt bij de server gecontroleerd met een eigen token.
		if ( isset( $_GET['m7_order'] ) ) {
			Shop::render_return( sanitize_text_field( wp_unslash( $_GET['m7_order'] ) ) );
			return;
		}
		if ( isset( $_GET['koop'] ) && Shop::available() ) {
			Shop::render( sanitize_text_field( wp_unslash( $_GET['koop'] ) ), isset( $_GET['renew'] ) ? sanitize_text_field( wp_unslash( $_GET['renew'] ) ) : '' );
			return;
		}
		// phpcs:enable
		$all = \M7_License::all();
		$cfg = \M7_Updates::licensing();
		$lab = array(
			'active'   => __( 'Actief', 'm7-branding' ),
			'expired'  => __( 'Verlopen', 'm7-branding' ),
			'disabled' => __( 'Uitgeschakeld', 'm7-branding' ),
			'inactive' => __( 'Niet geactiveerd', 'm7-branding' ),
			'invalid'  => __( 'Ongeldig', 'm7-branding' ),
		);
		$form = static function ( $do, $label, $primary, $key = '' ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'm7_license' );
			echo '<input type="hidden" name="action" value="m7_license"><input type="hidden" name="do" value="' . esc_attr( $do ) . '">';
			if ( $key ) {
				echo '<input type="hidden" name="license_key" value="' . esc_attr( $key ) . '">';
			}
			echo '<button type="submit" class="m7-ov-btn' . ( $primary ? ' is-primary' : '' ) . '">' . esc_html( $label ) . '</button></form>';
		};

		echo '<div class="wrap m7-overview"><h1 class="screen-reader-text">' . esc_html__( 'M7 Licentie', 'm7-branding' ) . '</h1>';
		echo '<p class="m7-ov-intro">' . esc_html__( 'Betaalde M7-plugins installeer en werk je bij met een licentie: per plugin, of één bundelsleutel voor alle plugins. Geïnstalleerde plugins blijven altijd werken.', 'm7-branding' ) . '</p>';
		echo '<div class="m7-ov-grid">';
		foreach ( $all as $key => $d ) {
			$masked = substr( $key, 0, 4 ) . str_repeat( '•', max( 0, strlen( $key ) - 8 ) ) . substr( $key, -4 );
			$covers = \M7_License::covers( $d );
			echo '<div class="m7-ov-card is-' . ( 'active' === $d['status'] ? 'active' : 'missing' ) . '">';
			echo '<h2>' . esc_html( $d['product'] ? $d['product'] : __( 'Licentie', 'm7-branding' ) ) . '</h2>';
			echo '<span class="m7-ov-status">' . esc_html( isset( $lab[ $d['status'] ] ) ? $lab[ $d['status'] ] : $d['status'] ) . '</span>';
			echo '<p><code>' . esc_html( $masked ) . '</code></p>';
			/* translators: %s: pluginnamen */
			echo '<p>' . esc_html( sprintf( __( 'Geeft vrij: %s', 'm7-branding' ), $covers ? implode( ', ', $covers ) : __( 'geen M7-plugin herkend', 'm7-branding' ) ) ) . '</p>';
			if ( $d['expires'] ) {
				/* translators: %s: datum */
				echo '<p>' . esc_html( sprintf( __( 'Geldig tot %s', 'm7-branding' ), date_i18n( get_option( 'date_format' ), strtotime( $d['expires'] ) ) ) ) . '</p>';
			}
			if ( $d['checked'] ) {
				/* translators: %s: tijd geleden */
				echo '<p class="m7-ov-note">' . esc_html( sprintf( __( 'Laatst gecontroleerd: %s geleden', 'm7-branding' ), human_time_diff( (int) $d['checked'] ) ) ) . '</p>';
			}
			if ( $d['message'] ) {
				echo '<p class="m7-ov-note">' . esc_html( $d['message'] ) . '</p>';
			}
			echo '<div class="m7-ov-actions">';
			$soon = $d['expires'] && strtotime( $d['expires'] ) < time() + 45 * DAY_IN_SECONDS;
			if ( Shop::available() && ( $soon || 'expired' === $d['status'] ) && ! empty( $d['product_ids'] ) ) {
				echo '<a class="m7-ov-btn is-primary" href="' . esc_url( Shop::buy_url( (string) $d['product_ids'][0], $key ) ) . '">' . esc_html__( 'Verlengen', 'm7-branding' ) . '</a>';
			}
			$form( 'check', __( 'Opnieuw controleren', 'm7-branding' ), ! $soon );
			$form( 'deactivate', __( 'Loskoppelen', 'm7-branding' ), false, $key );
			echo '</div></div>';
		}

		echo '<div class="m7-ov-card"><h2>' . esc_html( $all ? __( 'Nog een licentie toevoegen', 'm7-branding' ) : __( 'Licentie invullen', 'm7-branding' ) ) . '</h2>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:flex;flex-wrap:wrap;gap:8px;align-items:center">';
		wp_nonce_field( 'm7_license' );
		echo '<input type="hidden" name="action" value="m7_license"><input type="hidden" name="do" value="activate">';
		echo '<label class="screen-reader-text" for="m7-license-key">' . esc_html__( 'Licentiesleutel', 'm7-branding' ) . '</label>';
		echo '<input type="text" id="m7-license-key" name="license_key" class="regular-text" autocomplete="off" spellcheck="false" placeholder="XXXX-XXXX-XXXX-XXXX">';
		echo '<button type="submit" class="m7-ov-btn is-primary">' . esc_html__( 'Activeren', 'm7-branding' ) . '</button></form>';
		if ( Shop::available() ) {
			echo '<p><a class="m7-ov-btn" href="' . esc_url( Shop::buy_url( '' ) ) . '">' . esc_html__( 'Licentie kopen (per plugin of alles)', 'm7-branding' ) . '</a></p>';
		} elseif ( $cfg['store_url'] ) {
			echo '<p><a href="' . esc_url( $cfg['store_url'] ) . '" target="_blank" rel="noopener">' . esc_html__( 'Licenties per plugin of als bundel bekijken', 'm7-branding' ) . '</a></p>';
		}
		echo '</div></div></div>';
		\M7_Admin_Menu::cards_css();
	}

	public static function handle_license() {
		check_admin_referer( 'm7_license' );
		if ( ! current_user_can( 'manage_options' ) ) {
			self::back( 'error', __( 'Je hebt hier geen rechten voor.', 'm7-branding' ) );
		}
		$do  = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
		if ( 'activate' === $do ) {
			list( $ok, $msg ) = \M7_License::activate( $key );
		} elseif ( 'deactivate' === $do ) {
			list( $ok, $msg ) = \M7_License::deactivate( $key );
		} else {
			$all = \M7_License::validate();
			$bad = array_filter(
				$all,
				static function ( $d ) {
					return 'active' !== $d['status'];
				}
			);
			$ok  = ! $bad;
			$msg = $ok ? __( 'Alle licenties zijn geldig.', 'm7-branding' ) : __( 'Niet alle licenties zijn geldig; zie hieronder.', 'm7-branding' );
		}
		self::back( $ok ? 'success' : 'error', $msg );
	}

	private static function back( $type, $message ) {
		set_transient( self::NOTICE . get_current_user_id(), array( $type, $message ), 120 );
		$ref = wp_get_referer();
		$url = $ref && false !== strpos( $ref, 'page=m7' ) ? remove_query_arg( 'versions', $ref ) : admin_url( 'admin.php?page=' . \M7_Admin_Menu::SLUG );
		wp_safe_redirect( $url );
		exit;
	}

	public static function notice() {
		$key  = self::NOTICE . get_current_user_id();
		$data = get_transient( $key );
		if ( ! $data ) {
			return;
		}
		delete_transient( $key );
		echo '<div class="notice notice-' . ( 'success' === $data[0] ? 'success' : 'error' ) . ' is-dismissible"><p>' . esc_html( $data[1] ) . '</p></div>';
	}
}
